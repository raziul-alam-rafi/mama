import React from "react";
import { AbsoluteFill } from "remotion";
import { theme } from "../theme";
import { useScene } from "../SceneContext";
import { Card, Chip, ip, keys, lerp, mono, useBreathe, WordReveal, Entrance } from "../components/Motion";
import { Iris } from "../components/Iris";
import { ShutterFront } from "../components/ShutterFront";
import { Sfx } from "../components/Sfx";

// Scene 1 · Hook (cue 1): Kinetic headline + the two mechanisms appear as the words are spoken.
export const Hook: React.FC = () => {
  const S = useScene();
  const f = S.frame;
  const fA = Math.max(S.word(1, "Aperture"), 70);
  const fS = Math.max(S.word(1, "Shutter"), fA + 24);
  const b = useBreathe(1);

  const k = mono([0, 22, 46, fA - 8]);
  const open = keys(f, k, [0.08, 0.95, 0.3, 0.95]);
  const q = ip(f, [fA - 6, fA + 24], [0, 1]);
  const size = lerp(600, 400, q);
  const cx = lerp(960, 600, q);
  const cy = lerp(640, 585, q);

  // shutter loop
  const t = Math.max(0, f - fS) % 80;
  const p1 = ip(t, [8, 20], [0, 1]);
  const p2 = ip(t, [44, 58], [0, 1]);
  const sIn = ip(f, [fS - 6, fS + 20], [0, 1]);

  return (
    <AbsoluteFill>
      <div style={{ position: "absolute", left: 0, right: 0, top: 96 }}>
        <WordReveal text="দুটি গুরুত্বপূর্ণ বিষয়" delay={2} per={5} size={108} align="center" highlight={{ "বিষয়": theme.colors.accent }} />
      </div>

      <Card x={250} y={290} w={640} h={650} delay={fA - 8} border={theme.colors.primary} />
      <Card x={1030} y={290} w={640} h={650} delay={fS - 8} border={theme.colors.accent} />

      {/* iris: hook-size at centre, glides into its card on the word "Aperture" */}
      <div style={{ position: "absolute", left: cx - size / 2, top: cy - size / 2 + b.float, transform: `scale(${b.scale})` }}>
        <Iris size={size} open={open} highlight={q > 0.5} glow={0.85} uid="hk" />
      </div>

      <div style={{ position: "absolute", left: 1350 - 190, top: 460, opacity: sIn, transform: `scale(${0.9 + 0.1 * sIn})` }}>
        <ShutterFront w={380} h={300} p1={p1} p2={p2} uid="hk" />
      </div>

      <div style={{ position: "absolute", left: 250, width: 640, top: 800, display: "flex", justifyContent: "center" }}>
        <Entrance delay={fA + 4} y={26}>
          <div style={{ fontFamily: theme.fonts.display, fontWeight: 700, fontSize: 92, color: theme.colors.primarySoft, lineHeight: 1.2 }}>Aperture</div>
        </Entrance>
      </div>
      <div style={{ position: "absolute", left: 1030, width: 640, top: 800, display: "flex", justifyContent: "center" }}>
        <Entrance delay={fS + 4} y={26}>
          <div style={{ fontFamily: theme.fonts.display, fontWeight: 700, fontSize: 92, color: theme.colors.accent, lineHeight: 1.2 }}>Shutter</div>
        </Entrance>
      </div>

      <Sfx name="thud" at={2} />
      <Sfx name="pop" at={fA - 8} />
      <Sfx name="chime" at={fA + 2} />
      <Sfx name="pop" at={fS - 8} rate={1.08} />
      <Sfx name="click" at={fS + 8 + 0} rate={1} vol={0.8} />
    </AbsoluteFill>
  );
};
