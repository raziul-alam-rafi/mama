import * as THREE from 'three';

// ---- World layout (metres, stylised: distances are compressed, NOT to scale) ----
export const STADIUM = new THREE.Vector3(0, 0, 0);
export const CAM_STATION = new THREE.Vector3(33, 0, 0); // studio camera on the boundary, lens faces -X (to the pitch)
export const TOWER = new THREE.Vector3(90, 0, 0);
export const TOWER_H = 58;
export const HOUSE = new THREE.Vector3(200, 0, 0); // house spans x 196..204, z -3.2..3.2
export const TV_POS = new THREE.Vector3(200, 0.6, -2.1);
export const ANT_POS = new THREE.Vector3(202.2, 7.4, 0); // Yagi group origin (reflector end)

const v = (x: number, y: number, z: number) => new THREE.Vector3(x, y, z);

// Camera -> transmitter tower (ground cable, then feeder up the tower).
export const BROADCAST_CURVE = new THREE.CatmullRomCurve3(
  [
    v(33.6, 1.5, 0.1),
    v(34.3, 0.9, 0.3),
    v(34.8, 0.3, 0.7),
    v(40, 0.08, 6),
    v(58, 0.08, 10),
    v(76, 0.08, 4),
    v(87, 0.08, 1.2),
    v(90, 0.4, 0.9),
    v(90, 12, 0.7),
    v(90, 30, 0.4),
    v(90, TOWER_H, 0.2),
  ],
  false,
  'centripetal',
);

// Yagi feed point -> mast -> ridge -> gable end -> down the outer wall -> into the room -> TV rear.
export const HOUSE_CURVE = new THREE.CatmullRomCurve3(
  [
    v(201.5, 7.4, 0.0),
    v(200.9, 7.3, 0.06),
    v(200.9, 5.45, 0.06),
    v(202.2, 5.4, 0.08),
    v(203.9, 5.38, 0.08),
    v(204.3, 5.0, 0.08),
    v(204.27, 3.3, 0.08),
    v(204.25, 2.3, -0.6),
    v(204.22, 1.5, -1.8),
    v(203.7, 1.45, -1.95),
    v(202.4, 0.95, -2.5),
    v(200.6, 0.78, -2.45),
  ],
  false,
  'centripetal',
);

export const TOWER_TOP = v(90, TOWER_H, 0);
export const ANT_FEED = v(201.5, 7.4, 0);
