// সিন ১ (cue 1–2): হুক — Sensor-এর তথ্য → একটা ছবি, তারপর একটা ছবি ভেঙে একাধিক ফ্রেম (3D Carousel)
import React from "react";
import { useCurrentFrame } from "remotion";
import { theme } from "../theme";
import { makeT } from "../timing";
import { Entrance, SceneShell, Words, tween, useBreathe } from "../components/anim";
import { Chip } from "../components/ui";
import { PhoneCamIcon } from "../components/icons";
import { EXPO, Photo } from "../components/photo";
import { SfxEvent } from "../sfx";

const T = makeT(0);
const tB = T(2, "কিন্তু এখন"); // ধাপ B: একাধিক ফ্রেম
const tTitleB = T(2, "একটা ছবির বদলে");

const FAN = [
  { g: 0.26, dx: -610, rot: 42, s: 0.66 },
  { g: 0.4, dx: -330, rot: 28, s: 0.78 },
  { g: EXPO.single, dx: 0, rot: 0, s: 0.92 },
  { g: 0.8, dx: 330, rot: -28, s: 0.78 },
  { g: 1.0, dx: 610, rot: -42, s: 0.66 },
];

export const sfx01: SfxEvent[] = [
  { kind: "thud", frame: 6, vol: 0.8 },
  { kind: "pop", frame: 12 },
  { kind: "pop", frame: 34, rate: 1.06 },
  { kind: "whoosh", frame: tB + 2, rate: 1.1, vol: 0.8 },
  { kind: "pop", frame: tB + 22 }, { kind: "pop", frame: tB + 26, rate: 1.08 },
  { kind: "chime", frame: tTitleB + 18, vol: 0.8 },
];

const SensorDie: React.FC = () => {
  const frame = useCurrentFrame();
  const cells: React.ReactNode[] = [];
  for (let r = 0; r < 10; r++) for (let c = 0; c < 10; c++) {
    const v = 0.35 + 0.35 * Math.sin(frame / 14 + r * 0.6 + c * 0.9) + 0.2 * Math.sin(r * 1.3 + c * 0.7);
    cells.push(<rect key={`${r}-${c}`} x={22 + c * 25.6} y={22 + r * 25.6} width={22} height={22} rx={4} fill={theme.colors.hero} opacity={Math.max(0.12, Math.min(1, v))} />);
  }
  return (
    <svg width={300} height={300} viewBox="0 0 300 300" style={{ filter: `drop-shadow(0 0 30px ${theme.colors.glowHero})` }}>
      <rect x={4} y={4} width={292} height={292} rx={26} fill={theme.colors.surface} stroke={theme.colors.hero} strokeWidth={4} />
      {cells}
    </svg>
  );
};

export const Scene01: React.FC = () => {
  const frame = useCurrentFrame();
  const bob = useBreathe(36, 6);
  const outA = tween(frame, tB, tB + 12, 1, 0, theme.ease.in);
  const outX = tween(frame, tB, tB + 14, 0, -140, theme.ease.in);
  const cardMove = tween(frame, tB + 2, tB + 26, 0, 1, theme.ease.inOut);
  const cardX = 370 * (1 - cardMove);
  const cardS = 1 + (FAN[2].s - 1) * cardMove;

  return (
    <SceneShell first>
      {/* ধাপ A: Sensor → তথ্য → একটা ছবি */}
      <div style={{ position: "absolute", inset: 0, opacity: outA, transform: `translateX(${outX}px)` }}>
        <div style={{ position: "absolute", top: 120, left: 0, right: 0 }}>
          <Words text="ছবি নির্ভর করত Sensor-এর তথ্যের উপর" delay={4} per={4} style={{ fontSize: 76 }} hl={{ "Sensor-এর": theme.colors.hero }} />
        </div>
        <svg width={1920} height={1080} style={{ position: "absolute", inset: 0 }}>
          {[430, 485, 540, 595, 650].map((y, i) => (
            <g key={y}>
              <line x1={70} y1={y} x2={230} y2={y} stroke={theme.colors.hero} strokeOpacity={0.35} strokeWidth={3} strokeDasharray="10 8" />
              <circle cx={70 + ((frame * 4 + i * 37) % 160)} cy={y} r={7} fill={theme.colors.text} />
            </g>
          ))}
          {[0, 1, 2, 3, 4, 5, 6, 7].map((k) => {
            const x = 560 + ((frame * 5 + k * 58) % 440);
            return <rect key={k} x={x} y={530} width={20} height={20} rx={5} fill={theme.colors.accent} opacity={tween(x, 560, 620, 0, 1) * tween(x, 940, 1000, 1, 0)} />;
          })}
        </svg>
        <Entrance delay={8} style={{ position: "absolute", left: 230, top: 390 + bob }}><SensorDie /></Entrance>
        <Entrance delay={22} style={{ position: "absolute", left: 300, top: 720 }}><Chip text="Sensor" color={theme.colors.hero} /></Entrance>
        <Entrance delay={34} style={{ position: "absolute", left: 690, top: 450 }}><Chip text="তথ্য" color={theme.colors.accent} /></Entrance>
      </div>

      {/* ক্যারোসেল: একটাই ছবি-কার্ড (মাঝেরটা) ধাপ A থেকে B-তে চলে আসে */}
      <div style={{ position: "absolute", inset: 0, perspective: 2200 }}>
        {FAN.map((f, i) => {
          const isC = i === 2;
          const d = Math.abs(i - 2);
          const p = tween(frame, tB + 12 + d * 5, tB + 36 + d * 5, 0, 1);
          const enterA = isC ? tween(frame, 20, 44, 0, 1) : 0;
          const x = isC ? cardX : f.dx * p;
          const s = isC ? cardS : 0.92 + (f.s - 0.92) * p;
          const rot = isC ? 0 : f.rot * p;
          const op = isC ? enterA : p;
          return (
            <div key={i} style={{
              position: "absolute", left: 960 - 320, top: 540 - 180 + 60 + bob * (i % 2 ? -1 : 1), width: 640, height: 360, opacity: op, zIndex: 10 - d,
              transform: `translateX(${x}px) rotateY(${rot}deg) scale(${isC ? s * (0.92 + 0.08 * enterA) : s})`,
              boxShadow: theme.shadow.card, borderRadius: 18, border: `2px solid ${theme.colors.line}`,
            }}>
              <Photo uid={`s1-${i}`} gRoom={f.g} gSky={f.g} radius={16} />
            </div>
          );
        })}
      </div>

      {/* ক্যাপশন ধাপ A */}
      <div style={{ position: "absolute", left: 1010, top: 790, opacity: outA }}>
        <Entrance delay={46}><Chip text="একটা ছবি" color={theme.colors.text} /></Entrance>
      </div>

      {/* ধাপ B */}
      <div style={{ position: "absolute", top: 120, left: 0, right: 0 }}>
        <Words text="একটা ছবির বদলে একাধিক ফ্রেম" delay={tTitleB} per={4} style={{ fontSize: 88 }} hl={{ "একাধিক": theme.colors.accent }} />
      </div>
      <div style={{ position: "absolute", left: 0, right: 0, top: 830, display: "flex", justifyContent: "center" }}>
        <Entrance delay={T(2, "Smartphone")}>
          <div style={{ display: "flex", alignItems: "center", gap: 18 }}>
            <PhoneCamIcon size={64} color={theme.colors.hero} />
            <Chip text="Smartphone ক্যামেরা" color={theme.colors.hero} />
          </div>
        </Entrance>
      </div>
    </SceneShell>
  );
};
