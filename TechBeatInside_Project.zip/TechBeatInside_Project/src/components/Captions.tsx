import React from 'react';
import {interpolate, useCurrentFrame} from 'remotion';
import {COLORS, FPS, SHOW_CAPTIONS} from '../config/theme';
import {activeCue} from '../subtitles/subtitles';
import {BN_FONT} from './Fonts';

/** Burned-in narration text. Words are never split by letter (Bengali conjuncts stay intact). */
export const Captions: React.FC = () => {
  const frame = useCurrentFrame();
  if (!SHOW_CAPTIONS) return null;
  const cue = activeCue(frame);
  if (!cue) return null;
  const a = cue.start * FPS;
  const b = cue.end * FPS;
  const opacity = interpolate(frame, [a, a + 6, b - 6, b], [0, 1, 1, 0], {
    extrapolateLeft: 'clamp',
    extrapolateRight: 'clamp',
  });
  const rise = interpolate(frame, [a, a + 8], [10, 0], {extrapolateLeft: 'clamp', extrapolateRight: 'clamp'});
  return (
    <div
      style={{
        position: 'absolute',
        left: 0,
        right: 0,
        bottom: 54,
        display: 'flex',
        justifyContent: 'center',
        opacity,
        transform: `translateY(${rise}px)`,
      }}
    >
      <div
        style={{
          fontFamily: BN_FONT,
          fontWeight: 700,
          fontSize: 50,
          lineHeight: 1.35,
          letterSpacing: 0,
          color: COLORS.caption,
          textAlign: 'center',
          background: COLORS.captionShade,
          padding: '10px 34px 14px',
          borderRadius: 14,
          whiteSpace: 'pre-line',
          textShadow: '0 2px 8px rgba(0,0,0,0.6)',
          maxWidth: 1500,
        }}
      >
        {cue.text}
      </div>
    </div>
  );
};
