import React from "react";
import { interpolate, useCurrentFrame } from "remotion";
import { theme } from "../theme";
import { OVERLAP } from "../timing";
import { CL } from "./Motion";

/** Scene wrapper: eased enter (opacity + slide + scale) and a faster exit during the overlap. */
export const SceneShell: React.FC<{ duration: number; first?: boolean; last?: boolean; children?: React.ReactNode }> = ({
  duration,
  first,
  last,
  children,
}) => {
  const frame = useCurrentFrame();
  const enter = first ? 1 : interpolate(frame, [0, 14], [0, 1], { easing: theme.ease.out, ...CL });
  const exit = last ? 0 : interpolate(frame, [duration - OVERLAP, duration - 1], [0, 1], { easing: theme.ease.in, ...CL });
  return (
    <div
      style={{
        position: "absolute",
        inset: 0,
        opacity: enter * (1 - exit),
        transform: `translateX(${(1 - enter) * 70 - exit * 90}px) scale(${0.97 + enter * 0.03 + exit * 0.02})`,
      }}
    >
      {children}
    </div>
  );
};
