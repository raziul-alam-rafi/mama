import React from "react";
import {theme} from "../theme";
import {E} from "../events";
import {Leader, Pill, baseText, clamp01, lerp, useFx} from "../ui";

const CY = 520;

const sinePath = (x0: number, x1: number, phase: number, amp: number) => {
  let d = "";
  for (let x = x0; x <= x1; x += 6) {
    const y = CY + Math.sin((x - x0) / 17 + phase) * amp;
    d += `${x === x0 ? "M" : "L"} ${x} ${y.toFixed(1)} `;
  }
  return d;
};

// stepped electrical trace (distinct from the smooth light wave)
const STEPS = [0, -70, 30, -40, 60, -20, -80, 40, 10, -55];
const tracePath = (x0: number, x1: number, shift: number) => {
  const w = 52;
  let d = "";
  let x = x0 - (shift % (w * STEPS.length)) - w;
  let i = 0;
  while (x < x1 + w) {
    const y = CY + STEPS[i % STEPS.length];
    d += `${d ? "L" : "M"} ${x} ${y} L ${x + w} ${y} `;
    x += w;
    i++;
  }
  return d;
};

const BOX0 = 280;
const BOX1 = 640;
const BOX_Y = 540;
const INNER = 120;

export const SceneElectric: React.FC<{dur: number}> = () => {
  const {frame, ramp, pop} = useFx();
  const ev = E.electric;

  const wavesIn = pop(ev.waves, theme.spring.smooth);
  const neq = pop(ev.notEq, theme.spring.bouncy);
  const neqOut = 1 - ramp(ev.box - 2, 10, theme.ease.in);
  const boxP = pop(ev.box, theme.spring.bouncy);
  const zoom = ramp(ev.zoomIn, 40, theme.ease.inOut);
  const sideOut = 1 - ramp(ev.zoomIn, 16, theme.ease.in);
  const interior = ramp(ev.interior, 18);
  const boxSize = lerp(BOX0, BOX1, zoom);
  const qPulse = 1 + 0.06 * Math.sin(frame / 5);
  const breathe = 0.5 + 0.5 * Math.sin(frame / 14);
  const phase = -frame * 0.28;

  const bx = 960 - boxSize / 2;
  const by = BOX_Y - boxSize / 2;

  // photodiode block inside the pixel
  const pdW = 400;
  const pdH = 170;
  const pdX = 960 - pdW / 2;
  const pdY = BOX_Y - 60;
  const pdP = pop(ev.photodiode - 10, theme.spring.bouncy);
  const L = pdY - (by + 30);

  return (
    <>
      <svg width={1920} height={1080} style={{position: "absolute", inset: 0}}>
        <defs>
          <clipPath id="traceClip">
            <rect x={frame >= ev.box ? 1100 : 1220} y={CY - 140} width={720} height={280} />
          </clipPath>
          <filter id="wGlow" x="-10%" y="-40%" width="120%" height="180%">
            <feGaussianBlur stdDeviation="5" />
          </filter>
        </defs>

        <g opacity={sideOut * Math.min(1, wavesIn)} transform={`translate(0 ${lerp(30, 0, Math.min(1, wavesIn))})`}>
          {/* light: smooth blue wave */}
          <path d={sinePath(110, frame >= ev.box ? 820 : 700, phase, 52)} fill="none" stroke={theme.colors.primary} strokeWidth={10} opacity={0.4} filter="url(#wGlow)" />
          <path d={sinePath(110, frame >= ev.box ? 820 : 700, phase, 52)} fill="none" stroke={theme.colors.primary} strokeWidth={5} strokeLinecap="round" />
          {/* electricity: stepped amber trace */}
          <g clipPath="url(#traceClip)">
            <path d={tracePath(1000, 1810, frame * 1.6)} fill="none" stroke={theme.colors.accent} strokeWidth={10} opacity={0.3} filter="url(#wGlow)" />
            <path d={tracePath(1000, 1810, frame * 1.6)} fill="none" stroke={theme.colors.accent} strokeWidth={5} strokeLinejoin="round" />
          </g>
        </g>

        {/* pixel box */}
        <g transform={`translate(${bx} ${by})`} opacity={Math.min(1, boxP)}>
          <rect width={boxSize} height={boxSize} rx={lerp(46, 40, zoom)} fill={`rgba(${theme.rgb.primary},0.35)`} stroke={theme.colors.cellEdge} strokeWidth={3} />
          <rect x={4} y={4} width={boxSize - 8} height={boxSize - 8} rx={36} fill={theme.colors.panelDeep} opacity={interior} />
        </g>

        {/* interior: simplified single-pixel cross-section */}
        <g opacity={interior}>
          {Array.from({length: 5}).map((_, k) => {
            const x = 960 - 120 + k * 60;
            const t = (((frame - ev.interior) * 7 + k * 53) % L + L) % L;
            const y = by + 30 + t;
            return (
              <g key={k} opacity={clamp01(t / 30) * clamp01((L - t) / 24)}>
                <line x1={x} x2={x} y1={y - 26} y2={y} stroke={theme.colors.primary} strokeWidth={4} strokeLinecap="round" opacity={0.6} />
                <circle cx={x} cy={y} r={6} fill={theme.colors.text} />
              </g>
            );
          })}
          <rect x={bx + 14} y={pdY + pdH + 22} width={boxSize - 28} height={by + boxSize - (pdY + pdH + 22) - 14} rx={20} fill={`rgba(${theme.rgb.primary},0.10)`} stroke={theme.colors.panelEdge} strokeWidth={2} />
          <line x1={bx + 14} x2={bx + boxSize - 14} y1={pdY - 22} y2={pdY - 22} stroke={theme.colors.panelEdge} strokeWidth={2} strokeDasharray="4 10" />
          <rect
            x={pdX}
            y={pdY}
            width={pdW}
            height={pdH}
            rx={26}
            fill={`rgba(${theme.rgb.accent},${0.34 + 0.14 * breathe})`}
            stroke={theme.colors.accent}
            strokeWidth={4}
            opacity={Math.min(1, pdP)}
            style={{filter: `drop-shadow(0 0 ${22 + 14 * breathe}px ${theme.colors.amberGlow})`}}
          />
          <Leader x1={pdX + pdW + 6} y1={pdY + pdH / 2} x2={1440} y2={pdY + pdH / 2} at={ev.photodiode + 4} />
        </g>
      </svg>

      {/* ≠ between light wave and electrical trace */}
      <div
        style={{
          ...baseText,
          position: "absolute",
          left: 960,
          top: CY,
          transform: `translate(-50%, -50%) scale(${lerp(0.4, 1, Math.min(1.15, neq))})`,
          opacity: Math.min(1, neq) * neqOut * sideOut,
          fontSize: 150,
          fontWeight: 700,
          color: theme.colors.accent,
        }}
      >
        ≠
      </div>
      <Pill x={410} y={690} at={ev.waves + 6} text="আলো" tone="light" size={44} out={ev.zoomIn} />
      <Pill x={1510} y={690} at={ev.waves + 12} text="বৈদ্যুতিক সংকেত" tone="amber" size={44} out={ev.zoomIn} />

      {/* "?" in the pixel */}
      <div
        style={{
          ...baseText,
          position: "absolute",
          left: 960,
          top: BOX_Y,
          transform: `translate(-50%, -50%) scale(${qPulse * lerp(1, 0.4, zoom)})`,
          opacity: Math.min(1, pop(ev.question, theme.spring.bouncy)) * (1 - ramp(ev.zoomIn + 10, 12, theme.ease.in)),
          fontSize: 190,
          fontWeight: 700,
          color: theme.colors.accent,
        }}
      >
        ?
      </div>
      <Pill x={960} y={830} at={ev.question + 4} text="কীভাবে?" tone="light" size={54} out={ev.zoomIn} />

      <Pill x={1620} y={pdY + pdH / 2} at={ev.photodiode} text="Photodiode" tone="amber" size={52} />
      <div
        style={{
          ...baseText,
          position: "absolute",
          left: 0,
          right: 0,
          top: 975,
          textAlign: "center",
          fontSize: 28,
          fontWeight: 400,
          color: theme.colors.textDim,
          opacity: interior,
        }}
      >
        সরলীকৃত চিত্র
      </div>
    </>
  );
};
