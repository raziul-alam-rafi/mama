import React from "react";
import { interpolate, spring, useCurrentFrame, useVideoConfig } from "remotion";
import { theme } from "../theme";
import { beat } from "../cues";
import { Apple, CameraSide } from "../art/Art";
import { Ray, prog, Pt } from "../draw";
import { Sfx, WordReveal } from "../components/Common";

const c = theme.colors;
const APPLE = { x: 350, y: 702, r: 140 };
const CAM = { x: 1120, y: 470, s: 1.55 };
const GLASS = { x: CAM.x + 28 * CAM.s, y: CAM.y + 150 * CAM.s };

export const Hook: React.FC<{ from: number }> = ({ from }) => {
  const frame = useCurrentFrame();
  const { fps } = useVideoConfig();
  const tA = beat(from, 1);
  const tX = beat(from, 1, "সরাসরি দেখতে");
  const tB = beat(from, 2, "শুধুমাত্র আলো");
  const tRed = beat(from, 2, "লাল");

  const pApple = spring({ frame: frame - 2, fps, config: theme.spring.smooth });
  const pCam = spring({ frame: frame - 8, fps, config: theme.spring.smooth });
  const float = Math.sin(frame / 30) * 5;

  // sight line (what the camera does NOT do)
  const sight = prog(frame, tA + 14, 34, theme.ease.inOut);
  const sightFade = 1 - prog(frame, tB - 2, 9, theme.ease.in);
  const xP = spring({ frame: frame - (tX + 4), fps, config: theme.spring.bouncy });
  const mid = (GLASS.x - 24 + APPLE.x + APPLE.r + 6) / 2;

  // light rays from apple to lens
  const rays: Pt[][] = [-2, -1, 0, 1, 2].map((k) => {
    const th = (k * 17 * Math.PI) / 180;
    return [
      { x: APPLE.x + APPLE.r * Math.cos(th) * 0.95, y: APPLE.y + APPLE.r * Math.sin(th) * 0.95 },
      { x: GLASS.x - 4, y: GLASS.y + k * 32 },
    ];
  });

  const glow = interpolate(frame, [tRed, tRed + 8, tRed + 40], [0, 1, 0.35], { easing: theme.ease.out, extrapolateLeft: "clamp", extrapolateRight: "clamp" });
  const hit = interpolate(frame, [tB, tB + 4, tB + 24], [0, 1, 0], { extrapolateLeft: "clamp", extrapolateRight: "clamp", easing: theme.ease.out });

  return (
    <>
      <svg width={1920} height={1080} style={{ position: "absolute", inset: 0 }}>
        <g transform={`translate(${APPLE.x} ${APPLE.y + float}) scale(${interpolate(pApple, [0, 1], [0.7, 1])})`} opacity={pApple}>
          <Apple r={APPLE.r} glow={Math.max(glow, 0.15)} id="h-ap" />
        </g>
        <g transform={`translate(${CAM.x} ${CAM.y - float * 0.6}) scale(${CAM.s})`} opacity={pCam}>
          <CameraSide glass={hit} />
        </g>
        {/* the "direct seeing" idea — struck out */}
        <g opacity={sightFade}>
          <path d={`M${GLASS.x - 26} ${GLASS.y} L${GLASS.x - 26 + (APPLE.x + APPLE.r + 10 - GLASS.x + 26) * sight} ${GLASS.y}`} stroke={c.textDim} strokeWidth={4} strokeDasharray="14 12" strokeLinecap="round" fill="none" />
          <g transform={`translate(${mid} ${GLASS.y}) scale(${xP})`}>
            <circle r={40} fill={c.bgAlt} stroke={c.appleLight} strokeWidth={4} />
            <path d="M-17 -17 L17 17 M17 -17 L-17 17" stroke={c.appleLight} strokeWidth={7} strokeLinecap="round" />
          </g>
        </g>
        {/* real mechanism: light travelling from the apple into the lens */}
        {rays.map((pts, i) => (
          <Ray key={i} pts={pts} p={prog(frame, tB + i * 3, 22, theme.ease.out)} frame={frame} phase={i * 0.17} speed={0.012} opacity={0.5} />
        ))}
      </svg>
      <div style={{ position: "absolute", left: 0, right: 0, top: 120, display: "flex", justifyContent: "center" }}>
        <div style={{ position: "relative", height: 150, width: 1700 }}>
          <div style={{ position: "absolute", inset: 0, display: "flex", justifyContent: "center" }}>
            <WordReveal text="Camera বস্তুকে সরাসরি দেখে না" delay={tA} size={104} align="center" exitAt={tB - 4} />
          </div>
          <div style={{ position: "absolute", inset: 0, display: "flex", justifyContent: "center" }}>
            {frame >= tB - 2 && <WordReveal text="দেখে শুধু *আলো*" delay={tB - 2 - 0} size={116} align="center" hi={c.accent} />}
          </div>
        </div>
      </div>
      <Sfx name="pop" at={tA + 2} vol={0.3} />
      <Sfx name="click" at={tX + 4} vol={0.3} />
      <Sfx name="whoosh" at={tB} vol={0.26} />
      <Sfx name="thud" at={tB + 2} vol={0.22} />
    </>
  );
};
