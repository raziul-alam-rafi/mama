import React from "react";
import {AbsoluteFill} from "remotion";
import {Chip, Pop, Ray, Sfx, Words, clamp01, useAnim} from "../anim";
import {Channel, chColor, chName, theme} from "../theme";

const CX = [560, 960, 1360];
const CH: Channel[] = ["R", "G", "B"];
const OFFS = [-80, -27, 27, 80];
const Y_TOP = 250;
const Y_FILTER = 652;
const Y_WELL = 720;

// Scene 2 - side cutaway: white light hits R / G / B filters, only the filter colour enters each photosite.
export const S2: React.FC = () => {
  const a = useAnim();
  const slab = a.sp(0.15);
  const bar = a.prog(0.9, 1.5, theme.ease.out);

  return (
    <AbsoluteFill>
      <Sfx name="whoosh_swipe" at={0.05} vol={0.22} />
      <Sfx name="pop" at={0.5} vol={0.24} />
      <Sfx name="click" at={2.1} vol={0.22} rate={1.05} />

      <div style={{position: "absolute", left: 140, top: 64}}>
        <Words text="লাল, সবুজ ও নীল আলোর filter" at={0.1} highlight={["filter"]} />
      </div>

      <svg width={1920} height={1080} style={{position: "absolute", inset: 0}}>
        <defs>
          <linearGradient id="s2slab" x1="0" y1="0" x2="0" y2="1">
            <stop offset="0" stopColor={theme.colors.surfaceHi} />
            <stop offset="1" stopColor={theme.colors.surface} />
          </linearGradient>
          <linearGradient id="s2light" x1="0" y1="0" x2="1" y2="0">
            <stop offset="0" stopColor={theme.colors.text} stopOpacity={0} />
            <stop offset="0.5" stopColor={theme.colors.text} stopOpacity={0.95} />
            <stop offset="1" stopColor={theme.colors.text} stopOpacity={0} />
          </linearGradient>
          {CH.map((c) => (
            <linearGradient key={c} id={`s2f${c}`} x1="0" y1="0" x2="0" y2="1">
              <stop offset="0" stopColor={chColor[c]} stopOpacity={0.95} />
              <stop offset="1" stopColor={chColor[c]} stopOpacity={0.7} />
            </linearGradient>
          ))}
          {CH.map((c) => (
            <radialGradient key={c} id={`s2g${c}`} cx="0.5" cy="0.2" r="0.8">
              <stop offset="0" stopColor={chColor[c]} stopOpacity={0.9} />
              <stop offset="1" stopColor={chColor[c]} stopOpacity={0} />
            </radialGradient>
          ))}
        </defs>

        {/* light source bar */}
        <g opacity={bar} style={{transformOrigin: "960px 214px", transform: `scaleX(${0.4 + 0.6 * bar})`}}>
          <rect x={330} y={204} width={1260} height={20} rx={10} fill="url(#s2light)" style={{filter: `drop-shadow(0 0 16px ${theme.colors.glow})`}} />
        </g>

        {/* sensor slab */}
        <g opacity={clamp01(slab * 1.5)} transform={`translate(0 ${(1 - slab) * 60})`}>
          <rect x={330} y={Y_WELL} width={1260} height={200} rx={26} fill="url(#s2slab)" stroke={theme.colors.line} strokeWidth={2} />
          {CX.map((cx, i) => {
            const glow = a.prog(2.3 + i * 0.1, 3.1 + i * 0.1) * (0.8 + 0.2 * Math.sin(a.t * 2.4 + i));
            return (
              <g key={i}>
                <rect x={cx - 130} y={Y_WELL - 1} width={260} height={142} rx={16} fill={theme.colors.well} />
                <rect x={cx - 130} y={Y_WELL - 1} width={260} height={142} rx={16} fill={`url(#s2g${CH[i]})`} opacity={glow} />
              </g>
            );
          })}
        </g>

        {/* filters drop in */}
        {CX.map((cx, i) => {
          const p = a.sp(0.4 + i * 0.15, theme.spring.drop);
          const sa = 1.3 + i * 0.18; // ray start
          const arrive = sa + 0.7;
          const flash = a.ease(arrive, arrive + 0.15, 0, 1) * (1 - a.ease(arrive + 0.15, arrive + 0.7, 0, 1));
          return (
            <g key={i} opacity={clamp01(p * 1.6)} transform={`translate(0 ${-110 * (1 - p)})`}>
              <rect x={cx - 134} y={Y_FILTER} width={268} height={60} rx={12} fill={`url(#s2f${CH[i]})`} stroke="rgba(255,255,255,0.5)" strokeWidth={2} style={{filter: `drop-shadow(0 0 ${12 + 26 * flash}px ${chColor[CH[i]]})`}} />
              <rect x={cx - 120} y={Y_FILTER + 8} width={150} height={8} rx={4} fill="#FFFFFF" opacity={0.35} />
              <rect x={cx - 134} y={Y_FILTER} width={268} height={60} rx={12} fill="#FFFFFF" opacity={0.35 * flash} />
            </g>
          );
        })}

        {/* rays: white above the filter, filter colour below it */}
        {CX.map((cx, i) =>
          OFFS.map((o, k) => {
            const sa = 1.3 + i * 0.18 + k * 0.05;
            const pw = a.prog(sa, sa + 0.7, theme.ease.out);
            const pc = a.prog(sa + 0.68, sa + 1.05, theme.ease.out);
            return (
              <g key={`${i}-${k}`}>
                <Ray x1={cx + o} y1={Y_TOP} x2={cx + o} y2={Y_FILTER} color={theme.colors.text} p={pw} w={6} opacity={0.9} />
                <Ray x1={cx + o} y1={Y_FILTER + 60} x2={cx + o} y2={Y_WELL + 120} color={chColor[CH[i]]} p={pc} w={7} />
              </g>
            );
          })
        )}
      </svg>

      <Pop at={0.9} x={30} y={0} style={{position: "absolute", left: 1620, top: 170}}>
        <Chip size={theme.size.small} dot={theme.colors.text}>আলো</Chip>
      </Pop>

      {CX.map((cx, i) => (
        <Pop key={i} at={0.7 + i * 0.15} y={30} style={{position: "absolute", left: cx - 170, top: 950, width: 340, display: "flex", justifyContent: "center"}}>
          <Chip dot={chColor[CH[i]]}>{chName[CH[i]]} filter</Chip>
        </Pop>
      ))}
    </AbsoluteFill>
  );
};
