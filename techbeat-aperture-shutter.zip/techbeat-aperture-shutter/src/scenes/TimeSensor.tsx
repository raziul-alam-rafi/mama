import React from "react";
import { AbsoluteFill } from "remotion";
import { theme } from "../theme";
import { useScene } from "../SceneContext";
import { Chip, ip, clamp01, Entrance } from "../components/Motion";
import { SensorGrid } from "../components/SensorGrid";
import { Iris } from "../components/Iris";
import { Sfx } from "../components/Sfx";

const Ring: React.FC<{ size: number; p: number }> = ({ size, p }) => {
  const r = size / 2 - 12, C = 2 * Math.PI * r;
  return (
    <svg width={size} height={size} viewBox={`0 0 ${size} ${size}`}>
      <circle cx={size / 2} cy={size / 2} r={r} fill={theme.colors.bgAlt} stroke={theme.colors.line} strokeWidth={12} />
      <circle cx={size / 2} cy={size / 2} r={r} fill="none" stroke={theme.colors.accent} strokeWidth={12} strokeLinecap="round" strokeDasharray={C} strokeDashoffset={C * (1 - p)} transform={`rotate(-90 ${size / 2} ${size / 2})`} />
      {Array.from({ length: 12 }).map((_, i) => {
        const a = (i / 12) * Math.PI * 2;
        return <line key={i} x1={size / 2 + Math.sin(a) * (r - 26)} y1={size / 2 - Math.cos(a) * (r - 26)} x2={size / 2 + Math.sin(a) * (r - 38)} y2={size / 2 - Math.cos(a) * (r - 38)} stroke={theme.colors.textDim} strokeWidth={4} strokeLinecap="round" />;
      })}
      <line x1={size / 2} y1={size / 2} x2={size / 2 + Math.sin(p * Math.PI * 2) * (r - 34)} y2={size / 2 - Math.cos(p * Math.PI * 2) * (r - 34)} stroke={theme.colors.text} strokeWidth={7} strokeLinecap="round" />
      <circle cx={size / 2} cy={size / 2} r={9} fill={theme.colors.text} />
    </svg>
  );
};

// Scene 5 · Amount vs duration (cue 6): light amount (beam density) and exposure time (timer) both fill the sensor pixels.
export const TimeSensor: React.FC = () => {
  const S = useScene();
  const f = S.frame;
  const c6 = Math.max(S.cue(6), 0);
  const fAmount = S.word(6, "কতটুকু");
  const fTime = S.word(6, "কতক্ষণ");
  const fSensor = S.word(6, "Sensor");
  const end = S.cueEnd(6) - 14;

  const gridIn = ip(f, [c6 + 2, c6 + 26], [0, 1]);
  const amount = ip(f, [fAmount, fAmount + 34], [0, 1]);
  const ring = ip(f, [fTime, end], [0, 1], theme.ease.soft);
  const dens = 4 + Math.round(amount * 9);
  const tilt = `perspective(1700px) rotateX(58deg) rotateZ(-14deg)`;
  const level = (c: number, r: number) => clamp01(ring * 0.92 + Math.sin(c * 1.7 + r * 0.9) * 0.08 * ring) * (0.28 + 0.72 * amount);

  return (
    <AbsoluteFill>
      {/* amount: left chip with mini iris */}
      <div style={{ position: "absolute", left: 130, top: 120, display: "flex", alignItems: "center", gap: 24 }}>
        <Entrance delay={fAmount - 4} y={20}>
          <div style={{ display: "flex", alignItems: "center", gap: 20 }}>
            <Iris size={120} open={0.4 + 0.6 * amount} glow={0.7} uid="t6" />
            <Chip text="কতটুকু আলো" tone="primary" size={56} delay={0} />
          </div>
        </Entrance>
      </div>

      {/* light beams falling onto the sensor */}
      <svg width="1920" height="1080" style={{ position: "absolute", left: 0, top: 0 }}>
        {Array.from({ length: dens }).map((_, i) => {
          const x = 600 + (i + 0.5) * (720 / dens);
          const lead = ip(f, [fAmount + i * 3, fAmount + i * 3 + 24], [0, 1], theme.ease.out);
          return (
            <g key={i} opacity={lead * 0.95}>
              <line x1={x} y1={300} x2={x + (960 - x) * 0.05} y2={300 + 470 * lead} stroke={theme.colors.light} strokeWidth={4} strokeOpacity={0.4} strokeLinecap="round" />
              <line x1={x} y1={300} x2={x + (960 - x) * 0.05} y2={300 + 470 * lead} stroke={theme.colors.light} strokeWidth={5} strokeDasharray="14 30" strokeDashoffset={-(f * 7) - i * 9} strokeLinecap="round" />
            </g>
          );
        })}
      </svg>

      <div style={{ position: "absolute", left: 960 - 392, top: 520, opacity: gridIn, transform: `translateY(${(1 - gridIn) * 40}px)` }}>
        <div style={{ transform: tilt, transformOrigin: "50% 50%", filter: "drop-shadow(0 40px 40px rgba(0,0,0,0.5))" }}>
          <SensorGrid cols={14} rows={9} cell={56} level={level} />
        </div>
      </div>

      {/* time: right ring */}
      <div style={{ position: "absolute", left: 1370, top: 130, opacity: ip(f, [fTime - 6, fTime + 14], [0, 1]), transform: `scale(${0.85 + 0.15 * ip(f, [fTime - 6, fTime + 18], [0, 1])})` }}>
        <Ring size={230} p={ring} />
      </div>
      <div style={{ position: "absolute", left: 1370, top: 380 }}>
        <Chip text="কতক্ষণ" tone="accent" size={56} delay={fTime - 2} />
      </div>
      <div style={{ position: "absolute", left: 130, top: 880 }}>
        <Chip text="Sensor" tone="signal" size={50} delay={fSensor - 2} />
      </div>

      <Sfx name="pop" at={c6 + 4} />
      <Sfx name="whoosh" at={fAmount - 4} vol={0.7} />
      <Sfx name="click" at={fTime - 2} />
      <Sfx name="chime" at={fSensor} vol={0.9} />
    </AbsoluteFill>
  );
};
