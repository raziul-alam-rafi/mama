import React from "react";
import {interpolate} from "remotion";
import {theme} from "../theme";
import {Elem, focusX, LensShape, Ray, traceRay} from "./Optics";
import {SensorBar} from "./Art";

/**
 * Simplified camera-lens cutaway: 4 optical elements (convex, convex, concave, convex)
 * in a barrel, then the camera body with the image sensor at the focal plane.
 * Powers were tuned so parallel rays genuinely converge on the sensor (paraxial model).
 * Base coordinates: optical axis at y = 0.
 */
export const ELEMS_BASE: Elem[] = [
  {x: 620, power: 1 / 700, kind: "convex", h: 120, w: 20},
  {x: 740, power: 1 / 1400, kind: "convex", h: 118, w: 14},
  {x: 860, power: -1 / 500, kind: "concave", h: 116, w: 12},
  {x: 1010, power: 1 / 1000, kind: "convex", h: 110, w: 16},
];
export const FOCUS = focusX(ELEMS_BASE);
export const BARREL = {x0: 560, x1: 1070, h: 150};
export const BODY = {x0: 1070, x1: 1500, h: 215};
const WALL = 26;
const MID = 815;

export const LensRig: React.FC<{
  id: string; k: number; tx: number; ty: number;
  reveal: number; // 0..1 cutaway reveal
  assemble: number[]; // per element 0..1 (0 = exploded apart)
  heights: number[]; // incoming parallel ray heights
  rayP: number[]; // per ray draw progress
  startX: number;
  sensorGlow: number; // 0..1
  rayWidth?: number;
}> = ({id, k, tx, ty, reveal, assemble, heights, rayP, startX, sensorGlow, rayWidth = 3}) => {
  const clipH = reveal * 240;
  return (
    <g transform={`translate(${tx} ${ty}) scale(${k})`}>
      <defs>
        <clipPath id={`cut-${id}`}>
          <rect x={Math.min(startX, BARREL.x0) - 20} y={-clipH} width={BODY.x1 + 60 - Math.min(startX, BARREL.x0) + 20} height={2 * clipH} />
        </clipPath>
      </defs>
      <g clipPath={`url(#cut-${id})`}>
        {/* camera body + lens barrel (cut open) */}
        <rect x={BODY.x0} y={-BODY.h} width={BODY.x1 - BODY.x0} height={2 * BODY.h} rx={26} fill={theme.colors.housing}
          stroke={theme.colors.panelEdge} strokeWidth={4} />
        <rect x={BODY.x0} y={-BODY.h} width={BODY.x1 - BODY.x0} height={WALL} fill="url(#hatch)" />
        <rect x={BODY.x0} y={BODY.h - WALL} width={BODY.x1 - BODY.x0} height={WALL} fill="url(#hatch)" />
        <rect x={BARREL.x0} y={-BARREL.h} width={BARREL.x1 - BARREL.x0 + 14} height={2 * BARREL.h} rx={14}
          fill={theme.colors.housing} stroke={theme.colors.panelEdge} strokeWidth={4} />
        <rect x={BARREL.x0} y={-BARREL.h} width={BARREL.x1 - BARREL.x0 + 14} height={WALL} fill="url(#hatch)" />
        <rect x={BARREL.x0} y={BARREL.h - WALL} width={BARREL.x1 - BARREL.x0 + 14} height={WALL} fill="url(#hatch)" />
        {/* optical axis */}
        <line x1={BARREL.x0 - 40} x2={FOCUS + 60} y1={0} y2={0} stroke={theme.colors.panelEdge} strokeWidth={2} strokeDasharray="14 12" />
        {/* elements (exploded → assembled) */}
        {ELEMS_BASE.map((e, i) => {
          const a = assemble[i] ?? 1;
          const dx = (e.x - MID) * 0.9 * (1 - a);
          return <LensShape key={i} x={e.x + dx} cy={0} h={e.h} w={e.w} kind={e.kind} opacity={Math.min(1, a * 1.6)} />;
        })}
        {/* image sensor at the focal plane */}
        <SensorBar x={FOCUS} cy={0} h={110} glow={sensorGlow > 0.5} />
      </g>
      {/* light rays — drawn only when the elements are in place */}
      {heights.map((h, i) => (
        <Ray key={i} pts={traceRay(h, 0, startX, ELEMS_BASE, FOCUS, 0)} p={rayP[i] ?? 0} width={rayWidth} />
      ))}
      {sensorGlow > 0 && (
        <g filter="url(#glow)">
          <circle cx={FOCUS} cy={0} r={interpolate(sensorGlow, [0, 1], [2, 11])} fill={theme.colors.accent} />
          <circle cx={FOCUS} cy={0} r={interpolate(sensorGlow, [0, 1], [8, 34])} fill="none" stroke={theme.colors.accent}
            strokeWidth={3} opacity={1 - sensorGlow * 0.7} />
        </g>
      )}
    </g>
  );
};
