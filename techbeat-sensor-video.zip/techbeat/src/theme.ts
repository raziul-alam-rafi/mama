// theme.ts — single source of truth. No hex colors / easings / springs in components.
import {Easing} from "remotion";
import {fontFamily} from "./fonts";

export const theme = {
  colors: {
    bg: "#0B1020",
    bgAlt: "#131B36",
    primary: "#4F8CFF", // light / optics / main system
    accent: "#FFB84D", // selected component / electrical
    text: "#F4F7FF",
    textDim: "#97A4C6",
    panel: "#151E3D",
    panelDeep: "#0F1630",
    panelEdge: "rgba(140,170,255,0.28)",
    body: "rgba(79,140,255,0.07)",
    bodyEdge: "#5C7BC4",
    lensFill: "rgba(79,140,255,0.18)",
    lensEdge: "#9CC0FF",
    cell: "rgba(79,140,255,0.14)",
    cellEdge: "rgba(79,140,255,0.55)",
    glow: "rgba(79,140,255,0.45)",
    amberGlow: "rgba(255,184,77,0.45)",
    shadow: "rgba(2,5,15,0.55)",
  },
  rgb: {primary: "79,140,255", accent: "255,184,77", text: "244,247,255"},
  fonts: {
    display: `"${fontFamily}", "Hind Siliguri", "Noto Sans Bengali", sans-serif`,
  },
  radius: {pill: 999, card: 28},
  ease: {
    out: Easing.bezier(0.16, 1, 0.3, 1),
    inOut: Easing.bezier(0.83, 0, 0.17, 1),
    in: Easing.bezier(0.7, 0, 0.84, 0),
    soft: Easing.bezier(0.45, 0, 0.15, 1),
  },
  spring: {
    snappy: {damping: 14, stiffness: 160, mass: 0.6},
    smooth: {damping: 20, stiffness: 90, mass: 1},
    bouncy: {damping: 11, stiffness: 170, mass: 0.7},
  },
} as const;
