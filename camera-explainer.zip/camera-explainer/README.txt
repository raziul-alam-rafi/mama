npm install
npx remotion studio
npx remotion render src/index.ts Main out/video.mp4

public/voiceover.mp3 রাখলে Studio প্রিভিউতে ভয়েসওভার বাজবে (রেন্ডারে যুক্ত করতে src/Main.tsx-এ VOICEOVER.includeInRender = true)।
SFX আবার তৈরি করতে: npm run sfx
