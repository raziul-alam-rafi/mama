// Scene 3 (cues 4-5) — Every pixel holds a digital number; colour needs the neighbours too.
import React from "react";
import { AbsoluteFill } from "remotion";
import { theme } from "../theme";
import { T } from "../timing";
import { along, bin4, clamp, hexToRgb, mixRgb, prog, progIO, rgbCss, RGB } from "../util";
import { bayerCh, rawBlock } from "../sceneImage";
import { Defs } from "../components/Defs";
import { useClock, popAt } from "../components/clock";

export const G3 = { cols: 12, rows: 7, cell: 84, gap: 6, x: 130, y: 288 };
const chHex = [theme.colors.chR, theme.colors.chG, theme.colors.chB];

export const cellRaw = (col: number, row: number): RGB => rawBlock((col + 0.5) / G3.cols, (row + 0.5) / G3.rows, 0.8 / G3.cols, 0.8 / G3.rows);
export const grayColor = (col: number, row: number): RGB => {
  const l = clamp((cellRaw(col, row).reduce((a, b, i) => a + b * [0.2126, 0.7152, 0.0722][i], 0)) / 0.55);
  return mixRgb([0.1, 0.14, 0.28], [0.88, 0.92, 1], l);
};
export const mosaicColor = (col: number, row: number): RGB => {
  const ch = bayerCh(row, col);
  const v = clamp(cellRaw(col, row)[ch] / 0.7);
  return mixRgb([0.07, 0.1, 0.2], hexToRgb(chHex[ch]), 0.25 + 0.75 * v);
};
const cx = (col: number) => G3.x + col * (G3.cell + G3.gap);
const cy = (row: number) => G3.y + row * (G3.cell + G3.gap);

export const Scene3: React.FC = () => {
  const { f, fps, at } = useClock();
  const c = theme.colors;
  const gw = G3.cols * G3.cell + (G3.cols - 1) * G3.gap;
  const gh = G3.rows * G3.cell + (G3.rows - 1) * G3.gap;

  const tPix = at(T("Pixel"), 4);
  const tLight = at(T("আলোর পরিমাণ"), 6);
  const tDig = at(T("Digital তথ্য"), 6);
  const tBayer = at(T("কিন্তু রঙিন"), 8);
  const tNeigh = at(T("পাশের"), 6);
  const tTogether = at(T("একসঙ্গে"), 6);
  const tAnalyse = at(T("বিশ্লেষণ"), 6);
  const tHop = at(T("হয়।", 2) , 0); // end of the sentence about analysing

  // wipe from grey (light amounts) to the colour-filter mosaic
  const wipe = prog(f, tBayer, tBayer + 54, theme.ease.inOut);
  const mixAt = (col: number, row: number) => {
    const d = (col / (G3.cols - 1) + row / (G3.rows - 1)) / 2;
    return clamp((wipe * 1.35 - 0.1 - d * 0.35) / 0.2);
  };

  // phase A: the pixel in focus hops
  const focusList: [number, number, number][] = [[6, 3, tPix + 14], [3, 2, tLight], [8, 4, tDig]];
  let focus = focusList[0];
  focusList.forEach((fl) => { if (f >= fl[2]) focus = fl; });
  const phaseA = 1 - prog(f, tNeigh - 10, tNeigh + 4, theme.ease.in);
  const phaseC = prog(f, tNeigh - 2, tNeigh + 16, theme.ease.out);

  // phase C: the 3x3 analysis window hops
  const winList: [number, number, number][] = [[6, 3, tNeigh], [8, 2, tAnalyse + 22], [4, 4, tAnalyse + 44], [9, 5, tAnalyse + 66]];
  let win = winList[0];
  winList.forEach((w) => { if (f >= w[2]) win = w; });
  const winPop = popAt(f, fps, win[2] - 2, theme.spring.snappy);

  const panelX = 1300, panelW = 490;
  const pulse = 0.5 + 0.5 * Math.sin(f / 6);

  return (
    <AbsoluteFill>
      <svg width="1920" height="1080" style={{ position: "absolute", inset: 0 }}>
        <Defs />
        {/* ---------------- pixel grid ---------------- */}
        <rect x={G3.x - 26} y={G3.y - 26} width={gw + 52} height={gh + 52} rx={30} fill={c.bgAlt} stroke={c.line} strokeWidth={3} opacity={prog(f, 0, 16)} filter="url(#fShadow)" />
        {Array.from({ length: G3.cols * G3.rows }).map((_, i) => {
          const col = i % G3.cols, row = Math.floor(i / G3.cols);
          const pop = popAt(f, fps, 2 + Math.hypot(col - 5.5, row - 3) * 3, theme.spring.snappy);
          const m = mixAt(col, row);
          const colr = mixRgb(grayColor(col, row), mosaicColor(col, row), m);
          const inWin = f >= tNeigh && Math.abs(col - win[0]) <= 1 && Math.abs(row - win[1]) <= 1;
          const isCenter = col === win[0] && row === win[1];
          const neighPulse = inWin && !isCenter ? 0.5 + 0.5 * Math.sin(f / 5 + col + row) : 0;
          return (
            <g key={i} transform={`translate(${cx(col) + G3.cell / 2} ${cy(row) + G3.cell / 2}) scale(${0.55 + 0.45 * pop})`} opacity={Math.min(1, pop * 1.5)}>
              <rect x={-G3.cell / 2} y={-G3.cell / 2} width={G3.cell} height={G3.cell} rx={11} fill={rgbCss(colr)} stroke="rgba(255,255,255,0.10)" strokeWidth={1.5} />
              <rect x={-G3.cell / 2} y={-G3.cell / 2} width={G3.cell} height={G3.cell} rx={11} fill="url(#gSheen)" />
              {neighPulse > 0 && <rect x={-G3.cell / 2} y={-G3.cell / 2} width={G3.cell} height={G3.cell} rx={11} fill="#fff" opacity={0.18 * neighPulse * winPop} />}
            </g>
          );
        })}
        {/* focus ring (phase A) */}
        <rect x={cx(focus[0]) - 6} y={cy(focus[1]) - 6} width={G3.cell + 12} height={G3.cell + 12} rx={16} fill="none" stroke={c.primary} strokeWidth={5} filter="url(#fGlow)" opacity={phaseA * popAt(f, fps, focus[2] - 2)} />
        {/* analysis window (phase C) */}
        <rect x={cx(win[0] - 1) - 8} y={cy(win[1] - 1) - 8} width={3 * G3.cell + 2 * G3.gap + 16} height={3 * G3.cell + 2 * G3.gap + 16} rx={20} fill="none" stroke={c.primary} strokeWidth={5} filter="url(#fGlow)" opacity={phaseC * winPop} />

        {/* ---------------- legend ---------------- */}
        <g opacity={prog(f, tBayer + 6, tBayer + 22)} transform={`translate(${G3.x} ${G3.y + gh + 58})`}>
          {[["লাল", c.chR], ["সবুজ", c.chG], ["নীল", c.chB]].map(([t, col], i) => (
            <g key={i} transform={`translate(${i * 170} 0)`}>
              <rect width={34} height={34} rx={9} fill={col} />
              <text x={48} y={27} fontFamily={theme.fonts.main} fontWeight={600} fontSize={28} fill={c.text}>{t}</text>
            </g>
          ))}
        </g>

        {/* ---------------- right panel: phase A card ---------------- */}
        <g opacity={phaseA * prog(f, tPix + 6, tPix + 24)} transform={`translate(${panelX} ${300 + (1 - prog(f, tPix + 6, tPix + 30)) * 24})`}>
          <rect width={panelW} height={510} rx={30} fill="url(#gPanel)" stroke={c.line} strokeWidth={3} filter="url(#fShadow)" />
          <rect width={panelW} height={510} rx={30} fill="url(#gSheen)" />
          <text x={36} y={64} fontFamily={theme.fonts.main} fontWeight={700} fontSize={36} fill={c.text}>একটি Pixel</text>
          {(() => {
            const g = grayColor(focus[0], focus[1]);
            const l = clamp(cellRaw(focus[0], focus[1]).reduce((a, b, i) => a + b * [0.2126, 0.7152, 0.0722][i], 0) / 0.55);
            const lightP = prog(f, focus[2], focus[2] + 22);
            const digP = prog(f, focus[2] + 14, focus[2] + 30);
            return (
              <g>
                <rect x={36} y={100} width={150} height={150} rx={22} fill={rgbCss(g)} stroke="#fff" strokeOpacity={0.25} strokeWidth={2} />
                <text x={36} y={296} fontFamily={theme.fonts.main} fontWeight={600} fontSize={28} fill={c.accent}>আলোর পরিমাণ</text>
                <rect x={36} y={312} width={418} height={22} rx={11} fill={c.bg} />
                <rect x={36} y={312} width={418 * l * lightP} height={22} rx={11} fill="url(#gAmber)" filter="url(#fGlow)" />
                <text x={36} y={392} fontFamily={theme.fonts.main} fontWeight={600} fontSize={28} fill={c.primary}>Digital তথ্য</text>
                <g opacity={digP} transform={`translate(0 ${(1 - digP) * 12})`}>
                  {bin4(l).split("").map((b, i) => (
                    <g key={i} transform={`translate(${36 + i * 74} 408)`}>
                      <rect width={62} height={52} rx={12} fill={c.bg} stroke={c.primary} strokeWidth={2.5} />
                      <text x={31} y={39} textAnchor="middle" fontFamily={theme.fonts.main} fontWeight={700} fontSize={34} fill={c.primary}>{b}</text>
                    </g>
                  ))}
                </g>
                {/* arrow from the pixel to the card */}
                <path d={`M-14 ${cy(focus[1]) + G3.cell / 2 - 300} C-80 ${cy(focus[1]) + G3.cell / 2 - 300} -40 175 36 175`} fill="none" stroke={c.primary} strokeWidth={0} />
              </g>
            );
          })()}
        </g>
        {/* line from focused pixel to card */}
        <path d={`M${cx(focus[0]) + G3.cell + 6} ${cy(focus[1]) + G3.cell / 2} C ${panelX - 40} ${cy(focus[1]) + G3.cell / 2}, ${panelX - 60} 380, ${panelX} 380`} fill="none" stroke={c.primary} strokeWidth={3} strokeDasharray="8 8" opacity={phaseA * 0.8 * prog(f, tPix + 10, tPix + 28)} />

        {/* ---------------- right panel: phase C 3x3 patch ---------------- */}
        <g opacity={phaseC} transform={`translate(${panelX} ${300 + (1 - phaseC) * 24})`}>
          <rect width={panelW} height={560} rx={30} fill="url(#gPanel)" stroke={c.line} strokeWidth={3} filter="url(#fShadow)" />
          <rect width={panelW} height={560} rx={30} fill="url(#gSheen)" />
          {(() => {
            const P = { cell: 118, gap: 10 };
            const px0 = (panelW - (3 * P.cell + 2 * P.gap)) / 2, py0 = 96;
            const cc = (i: number, j: number): [number, number] => [px0 + i * (P.cell + P.gap) + P.cell / 2, py0 + j * (P.cell + P.gap) + P.cell / 2];
            const together = prog(f, tTogether, tTogether + 16);
            const scan = prog(f, tAnalyse, tAnalyse + 28, theme.ease.inOut);
            const hopFlash = 1 - prog(f, win[2], win[2] + 12);
            const cells: React.ReactNode[] = [];
            for (let j = 0; j < 3; j++)
              for (let i = 0; i < 3; i++) {
                const col = clamp(win[0] + i - 1, 0, G3.cols - 1), row = clamp(win[1] + j - 1, 0, G3.rows - 1);
                const [x, y] = cc(i, j);
                const pp = popAt(f, fps, win[2] + (i + j) * 2, theme.spring.snappy);
                cells.push(
                  <g key={i + "-" + j} transform={`translate(${x} ${y}) scale(${0.7 + 0.3 * pp})`} opacity={Math.min(1, pp * 1.5)}>
                    <rect x={-P.cell / 2} y={-P.cell / 2} width={P.cell} height={P.cell} rx={16} fill={rgbCss(mosaicColor(col, row))} stroke={i === 1 && j === 1 ? "#fff" : "rgba(255,255,255,0.12)"} strokeWidth={i === 1 && j === 1 ? 4 : 1.5} />
                    <rect x={-P.cell / 2} y={-P.cell / 2} width={P.cell} height={P.cell} rx={16} fill="url(#gSheen)" />
                  </g>,
                );
              }
            const [mx, my] = cc(1, 1);
            const links: React.ReactNode[] = [];
            for (let j = 0; j < 3; j++)
              for (let i = 0; i < 3; i++) {
                if (i === 1 && j === 1) continue;
                const [x, y] = cc(i, j);
                const t = ((f - tTogether + (i * 3 + j) * 4) % 36) / 36;
                const [dx, dy] = along([[x, y], [mx, my]], theme.ease.soft(t));
                links.push(
                  <g key={"l" + i + j} opacity={together}>
                    <line x1={x} y1={y} x2={mx} y2={my} stroke="#fff" strokeOpacity={0.35} strokeWidth={3} strokeDasharray="4 8" />
                    <circle cx={dx} cy={dy} r={7} fill="#fff" filter="url(#fGlow)" opacity={1 - t * 0.5} />
                  </g>,
                );
              }
            return (
              <g>
                <text x={36} y={64} fontFamily={theme.fonts.main} fontWeight={700} fontSize={36} fill={c.text}>পাশের Pixel</text>
                {cells}
                {links}
                <circle cx={mx} cy={my} r={P.cell * 0.68} fill="none" stroke={c.primary} strokeWidth={4} opacity={together * (0.5 + 0.5 * pulse)} filter="url(#fGlow)" />
                {/* analysis sweep */}
                <rect x={px0 + scan * (3 * P.cell + 2 * P.gap) - 8} y={py0 - 14} width={16} height={3 * P.cell + 2 * P.gap + 28} rx={8} fill={c.primary} opacity={0.85 * Math.sin(Math.PI * scan)} filter="url(#fGlow)" />
                <g opacity={prog(f, tAnalyse, tAnalyse + 14)} transform={`translate(${panelW / 2 - 100} 490)`}>
                  <rect width={200} height={52} rx={26} fill={c.bg} stroke={c.primary} strokeWidth={2.5} />
                  <circle cx={34} cy={25} r={11} fill="none" stroke={c.primary} strokeWidth={4} />
                  <line x1={42} y1={33} x2={52} y2={43} stroke={c.primary} strokeWidth={4} strokeLinecap="round" />
                  <text x={66} y={35} fontFamily={theme.fonts.main} fontWeight={600} fontSize={28} fill={c.text}>বিশ্লেষণ</text>
                </g>
                <rect width={panelW} height={560} rx={30} fill="#fff" opacity={0.06 * hopFlash} />
              </g>
            );
          })()}
        </g>
      </svg>
    </AbsoluteFill>
  );
};
