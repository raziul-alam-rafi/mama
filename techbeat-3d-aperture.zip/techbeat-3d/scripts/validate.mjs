// Fails loudly if a required file is missing (no silently incomplete renders).
import fs from "node:fs";
const required = [
  "src/data/cues.json", "public/music/ambient_pad.wav",
  "public/sfx/whoosh.wav", "public/sfx/click.wav", "public/sfx/iris_motor.wav",
  "public/sfx/shimmer.wav", "public/sfx/sweep_up.wav", "public/sfx/sweep_down.wav",
];
const missing = required.filter((f) => !fs.existsSync(f));
if (missing.length) {
  console.error("MISSING required files:\n  " + missing.join("\n  ") + "\nRun: npm run prepare:srt && npm run sfx");
  process.exit(1);
}
if (!fs.existsSync("node_modules/remotion")) { console.error("Dependencies not installed. Run: npm run setup"); process.exit(1); }
const cfg = fs.readFileSync("src/config.ts", "utf8");
console.log(/VOICEOVER_FILE: string \| null = null/.test(cfg)
  ? "NOTE: no voiceover configured. Output has music + SFX only. See README to add voiceover."
  : "Voiceover configured.");
const vo = cfg.match(/VOICEOVER_FILE: string \| null = "([^"]+)"/);
if (vo && !fs.existsSync("public/" + vo[1])) { console.error("Voiceover file public/" + vo[1] + " not found"); process.exit(1); }
console.log("validate OK");
