import React from "react";
import { theme } from "../theme";

export const gearPath = (cx: number, cy: number, r: number, teeth: number, depth = 0.18) => {
  const pts: string[] = [];
  const n = teeth * 4;
  for (let i = 0; i < n; i++) {
    const a = (i / n) * Math.PI * 2;
    const rr = i % 4 === 1 || i % 4 === 2 ? r : r * (1 - depth);
    pts.push(`${(cx + Math.cos(a) * rr).toFixed(2)},${(cy + Math.sin(a) * rr).toFixed(2)}`);
  }
  return `M${pts.join("L")}Z`;
};

export const Gear: React.FC<{ size: number; teeth?: number; rot?: number; color?: string; style?: React.CSSProperties }> =
({ size, teeth = 12, rot = 0, color = theme.colors.hero, style }) => (
  <svg width={size} height={size} viewBox="0 0 100 100" style={{ transform: `rotate(${rot}deg)`, ...style }}>
    <path d={gearPath(50, 50, 46, teeth)} fill={`${color}33`} stroke={color} strokeWidth={2.5} strokeLinejoin="round" />
    <circle cx={50} cy={50} r={14} fill={theme.colors.bg} stroke={color} strokeWidth={2.5} />
  </svg>
);

export const Check: React.FC<{ size: number; progress: number; color?: string }> = ({ size, progress, color = theme.colors.ok }) => (
  <svg width={size} height={size} viewBox="0 0 48 48">
    <circle cx={24} cy={24} r={21} fill={`${color}22`} stroke={color} strokeWidth={3} opacity={Math.min(1, progress * 3)} />
    <path d="M13 25 L21 33 L35 16" fill="none" stroke={color} strokeWidth={5} strokeLinecap="round" strokeLinejoin="round"
      pathLength={1} strokeDasharray={1} strokeDashoffset={1 - progress} />
  </svg>
);

export const ThumbUp: React.FC<{ size: number; color?: string }> = ({ size, color = theme.colors.text }) => (
  <svg width={size} height={size} viewBox="0 0 48 48" fill="none" stroke={color} strokeWidth={3} strokeLinejoin="round" strokeLinecap="round">
    <path d="M6 22 h8 v20 h-8 z" />
    <path d="M14 23 L22 6 c4 0 6 3 5 8 l-1 6 h14 c3 0 5 2 4.4 5 l-3 14 c-.5 2.2 -2.2 3 -4.4 3 H14" />
  </svg>
);

export const PhoneCamIcon: React.FC<{ size: number; color?: string }> = ({ size, color = theme.colors.text }) => (
  <svg width={size} height={size} viewBox="0 0 48 48" fill="none" stroke={color} strokeWidth={3} strokeLinejoin="round">
    <rect x={13} y={4} width={22} height={40} rx={5} />
    <circle cx={24} cy={16} r={5} />
    <circle cx={24} cy={16} r={1.8} fill={color} />
    <path d="M21 38 h6" strokeLinecap="round" />
  </svg>
);
