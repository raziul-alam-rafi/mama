import React from "react";
import {Audio, Sequence, staticFile} from "remotion";
import {SFX_ON} from "../config";
import {theme, SfxName} from "../theme";

/** One sound effect, starting 2 frames BEFORE the visual lands (`at` = scene-local frame). */
export const Sfx: React.FC<{at: number; name: SfxName; rate?: number; vol?: number}> = ({
  at, name, rate = 1, vol = 1,
}) => {
  if (!SFX_ON) return null;
  return (
    <Sequence from={Math.max(0, at - 2)} durationInFrames={45} layout="none">
      <Audio src={staticFile(`sfx/${name}.wav`)} volume={theme.sfx[name] * vol} playbackRate={rate} />
    </Sequence>
  );
};
