import React from "react";
import { theme } from "../theme";

const c = theme.colors;

/** Apple, centered at (0,0) with radius ~r. Draw inside <g transform=translate(...)>. */
export const Apple: React.FC<{ r?: number; glow?: number; blur?: number; id?: string }> = ({ r = 110, glow = 0, blur = 0, id = "ap" }) => {
  const s = r / 110;
  return (
    <g transform={`scale(${s})`} filter={blur ? `url(#${id}-blur)` : undefined}>
      <defs>
        <radialGradient id={`${id}-g`} cx="38%" cy="32%" r="75%">
          <stop offset="0%" stopColor={c.appleLight} />
          <stop offset="45%" stopColor={c.apple} />
          <stop offset="100%" stopColor={c.appleDark} />
        </radialGradient>
        <filter id={`${id}-blur`} x="-100%" y="-100%" width="300%" height="300%"><feGaussianBlur stdDeviation={blur} /></filter>
      </defs>
      {glow > 0 && <circle r={150} fill={c.apple} opacity={0.22 * glow} />}
      <path d="M0 -78 C 30 -112, 108 -100, 108 -8 C 108 62, 60 112, 28 108 C 12 106, 8 100, 0 100 C -8 100, -12 106, -28 108 C -60 112, -108 62, -108 -8 C -108 -100, -30 -112, 0 -78 Z" fill={`url(#${id}-g)`} />
      <path d="M0 -76 C 2 -100, 10 -118, 26 -130" fill="none" stroke="#5A3A22" strokeWidth={9} strokeLinecap="round" />
      <path d="M14 -104 C 40 -140, 80 -138, 96 -118 C 70 -88, 36 -88, 14 -104 Z" fill={c.leaf} />
      <ellipse cx={-52} cy={-30} rx={16} ry={30} fill="#FFFFFF" opacity={0.22} transform="rotate(18 -52 -30)" />
    </g>
  );
};

/** Camera side silhouette facing LEFT. Local box ≈ 0..440 × 0..290; lens front glass center at (24,150). */
export const CameraSide: React.FC<{ glass?: number }> = ({ glass = 0 }) => (
  <g>
    <defs>
      <linearGradient id="cs-body" x1="0" y1="0" x2="0" y2="1">
        <stop offset="0%" stopColor={c.surfaceHi} /><stop offset="100%" stopColor={c.surface} />
      </linearGradient>
      <linearGradient id="cs-barrel" x1="0" y1="0" x2="0" y2="1">
        <stop offset="0%" stopColor="#2F4A86" /><stop offset="50%" stopColor="#1B2E5C" /><stop offset="100%" stopColor="#14224A" />
      </linearGradient>
      <radialGradient id="cs-glass" cx="30%" cy="35%" r="80%">
        <stop offset="0%" stopColor="#CFE6FF" /><stop offset="55%" stopColor={c.glass} /><stop offset="100%" stopColor="#35599A" />
      </radialGradient>
    </defs>
    <path d="M150 52 L190 20 H300 L330 52" fill={c.surface} stroke={c.line} strokeWidth={3} />
    <rect x={120} y={48} width={320} height={210} rx={28} fill="url(#cs-body)" stroke={c.line} strokeWidth={3} />
    <rect x={366} y={80} width={60} height={150} rx={22} fill={c.bgAlt} opacity={0.7} />
    <circle cx={250} cy={40} r={11} fill={c.line} />
    <rect x={36} y={78} width={104} height={144} rx={16} fill="url(#cs-barrel)" stroke={c.line} strokeWidth={3} />
    {[62, 92, 122].map((x) => <line key={x} x1={x} y1={84} x2={x} y2={216} stroke={c.line} strokeWidth={2.5} opacity={0.8} />)}
    <ellipse cx={30} cy={150} rx={20} ry={66} fill="url(#cs-glass)" stroke="#6C9BE0" strokeWidth={3} />
    <ellipse cx={25} cy={128} rx={6} ry={22} fill="#FFFFFF" opacity={0.5 + 0.4 * glass} />
  </g>
);

/** Human eye, centered at (0,0), width ≈ 220 */
export const Eye: React.FC<{ look?: number }> = ({ look = 0 }) => (
  <g>
    <defs>
      <radialGradient id="eye-iris" cx="50%" cy="50%" r="60%"><stop offset="0%" stopColor="#7FB6FF" /><stop offset="100%" stopColor="#2A5FB0" /></radialGradient>
      <clipPath id="eye-clip"><path d="M-110 0 C -60 -72, 60 -72, 110 0 C 60 72, -60 72, -110 0 Z" /></clipPath>
    </defs>
    <path d="M-110 0 C -60 -72, 60 -72, 110 0 C 60 72, -60 72, -110 0 Z" fill="#F2F6FF" stroke={c.line} strokeWidth={3} />
    <g clipPath="url(#eye-clip)">
      <circle cx={-30 + look * 0} cy={0} r={44} fill="url(#eye-iris)" />
      <circle cx={-34} cy={0} r={19} fill={c.ink} />
      <circle cx={-44} cy={-12} r={7} fill="#fff" opacity={0.9} />
    </g>
  </g>
);

/** Sensor plate (vertical), centered at (0,0), height h. Pixel rows drawn as thin lines. */
export const SensorPlate: React.FC<{ h?: number; w?: number; reveal?: number }> = ({ h = 360, w = 34, reveal = 1 }) => (
  <g opacity={reveal}>
    <rect x={-w / 2} y={-h / 2} width={w} height={h} rx={7} fill={c.surface} stroke={c.primary} strokeWidth={3} />
    {Array.from({ length: Math.floor(h / 18) }).map((_, i) => (
      <line key={i} x1={-w / 2 + 6} x2={w / 2 - 6} y1={-h / 2 + 12 + i * 18} y2={-h / 2 + 12 + i * 18} stroke={c.line} strokeWidth={2} />
    ))}
  </g>
);
