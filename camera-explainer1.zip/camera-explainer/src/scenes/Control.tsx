import React from "react";
import { interpolate, spring, useCurrentFrame, useVideoConfig } from "remotion";
import { theme } from "../theme";
import { beat } from "../cues";
import { Apple } from "../art/Art";
import { Ray, prog, Pt, traceThin } from "../draw";
import { Label, Sfx, WordReveal } from "../components/Common";

const c = theme.colors;
// left panel: no control  |  right panel: light controlled → focused, inverted image
const L = { x: 80, y: 250, w: 840, h: 640 };
const R = { x: 980, y: 250, w: 860, h: 640 };
const AY = 590; // optical axis (both panels)
const AL = { x: 220, r: 46 };
const SL = { x: 840 }; // left sensor
const AR = { x: 1100, r: 46 };
const U = 250, V = 400; // object & image distance
const LENS = { x: AR.x + U, f: (U * V) / (U + V) };
const SR = { x: LENS.x + V };

const biconvex = (x: number, y: number, H: number, b: number) => `M${x} ${y - H} Q${x + 2 * b} ${y} ${x} ${y + H} Q${x - 2 * b} ${y} ${x} ${y - H} Z`;

export const Control: React.FC<{ from: number }> = ({ from }) => {
  const frame = useCurrentFrame();
  const { fps } = useVideoConfig();
  const tHead = beat(from, 7);
  const tBad = beat(from, 7, "পাওয়া যাবে না");
  const tGoal = beat(from, 7, "প্রথম কাজ");
  const tCtrl = beat(from, 8, "নিয়ন্ত্রণ করা");
  const tClear = beat(from, 8, "পরিষ্কার ছবি");

  const pL = spring({ frame: frame - 6, fps, config: theme.spring.smooth });
  const pR = spring({ frame: frame - tGoal, fps, config: theme.spring.smooth });
  const pLens = spring({ frame: frame - tCtrl, fps, config: theme.spring.bouncy });
  const pBadX = spring({ frame: frame - (tBad + 6), fps, config: theme.spring.bouncy });
  const pOk = spring({ frame: frame - (tClear + 14), fps, config: theme.spring.bouncy });
  const imgP = spring({ frame: frame - (tClear + 4), fps, config: theme.spring.smooth });

  // LEFT: every object point reaches every sensor point
  const crossL: Pt[][] = [];
  [-34, 0, 34].forEach((sy) => [-130, -65, 0, 65, 130].forEach((dy) => crossL.push([{ x: AL.x + 40, y: AY + sy }, { x: SL.x - 14, y: AY + dy }])));
  // RIGHT: thin-lens trace from three points of the apple → converge on the sensor (inverted)
  const lenses = [{ x: LENS.x, f: LENS.f, ya: AY }];
  const srcs = [-36, 0, 36];
  const bundles: Pt[][][] = srcs.map((sy) => [-84, 0, 84].map((h) => {
    const start = { x: AR.x, y: AY + sy }; // point on the object plane
    const slope = (AY + h - start.y) / (LENS.x - start.x);
    return traceThin(start, slope, lenses, SR.x);
  }));
  const pDots = spring({ frame: frame - (tCtrl + 34), fps, config: theme.spring.bouncy });

  const mag = V / U;

  return (
    <>
      <svg width={1920} height={1080} style={{ position: "absolute", inset: 0 }}>
        <defs>
          <filter id="c-smear" x="-60%" y="-60%" width="220%" height="220%"><feGaussianBlur stdDeviation="22" /></filter>
        </defs>
        {/* panels */}
        <g opacity={pL}><rect x={L.x} y={L.y} width={L.w} height={L.h} rx={30} fill={c.bgAlt} opacity={0.82} stroke={c.line} strokeWidth={3} /></g>
        <g opacity={pR}><rect x={R.x} y={R.y} width={R.w} height={R.h} rx={30} fill={c.bgAlt} opacity={0.82} stroke={c.primary} strokeWidth={3} /></g>

        {/* LEFT — uncontrolled */}
        <g opacity={pL}>
          <g transform={`translate(${AL.x} ${AY})`}><Apple r={AL.r} glow={0.2} id="c-apl" /></g>
          <g transform={`translate(${SL.x} ${AY})`}>
            <rect x={-17} y={-170} width={34} height={340} rx={7} fill={c.surface} stroke={c.line} strokeWidth={3} />
            <ellipse rx={64} ry={120} cx={-2} fill={c.apple} opacity={0.65} filter="url(#c-smear)" />
          </g>
        </g>
        {crossL.map((pts, i) => (
          <Ray key={"l" + i} pts={pts} p={prog(frame, 14 + (i % 5) * 2, 26)} frame={frame} packet={false} opacity={0.3} width={2} />
        ))}
        <g transform={`translate(${L.x + L.w - 70} ${L.y + 62}) scale(${pBadX})`}>
          <circle r={34} fill={c.bgAlt} stroke={c.appleLight} strokeWidth={4} />
          <path d="M-13 -13 L13 13 M13 -13 L-13 13" stroke={c.appleLight} strokeWidth={6} strokeLinecap="round" />
        </g>

        {/* RIGHT — controlled */}
        <g opacity={pR}>
          <g transform={`translate(${SR.x} ${AY})`}>
            <rect x={-17} y={-170} width={34} height={340} rx={7} fill={c.surface} stroke={c.primary} strokeWidth={3} />
          </g>
        </g>
        {/* lens (glass shape) */}
        <g opacity={pLens} transform={`translate(${LENS.x} ${AY}) scale(${interpolate(pLens, [0, 1], [0.6, 1])} 1) translate(${-LENS.x} ${-AY})`}>
          <path d={biconvex(LENS.x, AY, 118, 20)} fill={c.glass} fillOpacity={0.28} stroke={c.glass} strokeWidth={3.5} />
        </g>
        {bundles.map((b, k) => b.map((pts, j) => (
          <Ray key={`r${k}-${j}`} pts={pts} p={prog(frame, tCtrl + 4 + k * 4 + j * 2, 28)} frame={frame} packet={j === 1} pulses={1} phase={k * 0.2} opacity={0.6} width={2.6} />
        )))}
        {srcs.map((sy, k) => (
          <circle key={"d" + k} cx={SR.x} cy={AY - (sy * V) / U} r={9 * pDots} fill={c.accent} opacity={pDots * (1 - imgP)} />
        ))}
        <g opacity={pR}><g transform={`translate(${AR.x} ${AY})`}><Apple r={AR.r} glow={0.2} id="c-apr" /></g></g>
        {/* inverted, sharp image on the sensor (rotated 180°, magnified by v/u) */}
        <g transform={`translate(${SR.x} ${AY}) rotate(180) scale(${mag * imgP})`} opacity={imgP}>
          <Apple r={AR.r} id="c-img" />
        </g>
        <g transform={`translate(${R.x + R.w - 70} ${R.y + 62}) scale(${pOk})`}>
          <circle r={34} fill={c.bgAlt} stroke={c.primary} strokeWidth={4} />
          <path d="M-14 1 L-4 12 L15 -11" fill="none" stroke={c.primary} strokeWidth={7} strokeLinecap="round" strokeLinejoin="round" />
        </g>
      </svg>
      <div style={{ position: "absolute", left: 90, top: 60 }}>
        <WordReveal text="আলোকে *নিয়ন্ত্রণ* করাই প্রথম কাজ" delay={tHead} size={84} hi={c.primary} />
      </div>
      <Label text="নিয়ন্ত্রণ ছাড়া" x={L.x + 150} y={L.y + 54} delay={tBad} size={40} tone="plain" dim />
      <Label text="ঝাপসা" x={SL.x} y={AY + 218} delay={tBad + 10} color={c.appleLight} />
      <Label text="নিয়ন্ত্রিত আলো" x={R.x + 160} y={R.y + 54} delay={tGoal + 6} size={40} tone="plain" color={c.primary} />
      <Label text="পরিষ্কার ছবি" x={SR.x} y={AY + 218} delay={tClear + 8} color={c.primary} />
      <Sfx name="pop" at={tHead + 2} vol={0.28} />
      <Sfx name="click" at={tBad + 8} vol={0.28} />
      <Sfx name="whoosh" at={tGoal} vol={0.24} />
      <Sfx name="chime" at={tCtrl} vol={0.24} />
      <Sfx name="click" at={tClear + 16} vol={0.3} rate={1.06} />
    </>
  );
};
