import React from 'react';
import {AbsoluteFill, useCurrentFrame} from 'remotion';
import {theme} from '../theme';

export const BgMesh: React.FC = () => {
  const f = useCurrentFrame();
  return (
    <AbsoluteFill style={{background: theme.colors.bg}}>
      <div style={{position: 'absolute', width: 1300, height: 1300, borderRadius: '50%', top: -500, left: -300 + Math.sin(f / 55) * 50, filter: 'blur(60px)', background: `radial-gradient(circle, ${theme.colors.primary}33, transparent 62%)`}} />
      <div style={{position: 'absolute', width: 900, height: 900, borderRadius: '50%', bottom: -420, right: -250 - Math.cos(f / 70) * 40, filter: 'blur(70px)', background: `radial-gradient(circle, ${theme.colors.accent}1f, transparent 65%)`}} />
    </AbsoluteFill>
  );
};

export const Grade: React.FC = () => (
  <AbsoluteFill style={{pointerEvents: 'none'}}>
    <AbsoluteFill style={{backgroundColor: theme.colors.primary, mixBlendMode: 'soft-light', opacity: 0.12}} />
  </AbsoluteFill>
);

export const Grain: React.FC = () => {
  const f = useCurrentFrame();
  const noise = `url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='220' height='220'%3E%3Cfilter id='n'%3E%3CfeTurbulence type='fractalNoise' baseFrequency='0.9' numOctaves='2'/%3E%3C/filter%3E%3Crect width='220' height='220' filter='url(%23n)' opacity='0.5'/%3E%3C/svg%3E")`;
  return <AbsoluteFill style={{pointerEvents: 'none', backgroundImage: noise, backgroundSize: '220px', backgroundPosition: `${(f * 7) % 220}px ${(f * 13) % 220}px`, opacity: 0.04, mixBlendMode: 'overlay'}} />;
};

export const Vignette: React.FC = () => (
  <AbsoluteFill style={{pointerEvents: 'none', background: 'radial-gradient(ellipse at center, transparent 58%, rgba(0,0,0,0.25) 100%)'}} />
);
