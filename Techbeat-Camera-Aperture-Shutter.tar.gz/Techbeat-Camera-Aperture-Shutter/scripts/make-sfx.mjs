// Deterministic synthesized SFX kit -> public/sfx/*.wav (48kHz, 16-bit, mono). Original audio, no licensing issues.
import fs from 'node:fs';
const SR = 48000;
let seed = 12345;
const rnd = () => ((seed = (seed * 1664525 + 1013904223) >>> 0) / 4294967296) * 2 - 1;
const TAU = Math.PI * 2;
const clamp01 = (x) => Math.max(0, Math.min(1, x));
const env = (t, d, a, r) => Math.min(clamp01(t / a), clamp01((d - t) / r));
const make = (dur, fn) => { const n = Math.floor(dur * SR); const b = new Float32Array(n); for (let i = 0; i < n; i++) b[i] = fn(i / SR, dur); return b; };
const norm = (b, peak = 0.7) => { let m = 0; for (const v of b) m = Math.max(m, Math.abs(v)); const g = m ? peak / m : 1; return b.map((v) => v * g); };
const save = (name, b) => {
  const n = b.length, buf = Buffer.alloc(44 + n * 2);
  buf.write('RIFF', 0); buf.writeUInt32LE(36 + n * 2, 4); buf.write('WAVEfmt ', 8);
  buf.writeUInt32LE(16, 16); buf.writeUInt16LE(1, 20); buf.writeUInt16LE(1, 22);
  buf.writeUInt32LE(SR, 24); buf.writeUInt32LE(SR * 2, 28); buf.writeUInt16LE(2, 32); buf.writeUInt16LE(16, 34);
  buf.write('data', 36); buf.writeUInt32LE(n * 2, 40);
  for (let i = 0; i < n; i++) buf.writeInt16LE(Math.round(Math.max(-1, Math.min(1, b[i])) * 32767), 44 + i * 2);
  fs.mkdirSync(new URL('../public/sfx/', import.meta.url), { recursive: true });
  fs.writeFileSync(new URL(`../public/sfx/${name}`, import.meta.url), buf);
  console.log('wrote', name, (n / SR).toFixed(2) + 's');
};
// servo/whirr sweep with 8 small blade "ticks"
const iris = (from, to) => {
  let ph = 0, lp = 0;
  return norm(make(2.0, (t, d) => {
    const f = from + (to - from) * (t / d);
    ph += (TAU * f) / SR; lp += 0.05 * (rnd() - lp);
    const tickT = (t / d) * 8, tick = Math.exp(-((tickT % 1) * 60)) * rnd() * 0.5;
    return env(t, d, 0.08, 0.15) * (0.5 * Math.sin(ph) + 0.25 * Math.sin(ph * 2.01) + 1.2 * lp + tick);
  }), 0.6);
};
save('iris_close.wav', iris(420, 250));
save('iris_open.wav', iris(250, 420));
let lp2 = 0;
save('intro_whoosh.wav', norm(make(1.2, (t, d) => {
  const c = 0.01 + 0.25 * Math.sin((Math.PI * t) / d) ** 2; lp2 += c * (rnd() - lp2);
  return env(t, d, 0.3, 0.5) * lp2;
}), 0.6));
save('sensor_glow.wav', norm(make(1.5, (t, d) => env(t, d, 0.12, 0.8) * Math.exp(-t * 1.5) * (Math.sin(TAU * 880 * t) + 0.5 * Math.sin(TAU * 1320 * t + 1) + 0.25 * Math.sin(TAU * 1760 * t))), 0.5));
save('pad.wav', norm(make(15, (t, d) => env(t, d, 1.0, 2.0) * (
  Math.sin(TAU * 110 * t) * (0.6 + 0.4 * Math.sin(TAU * 0.1 * t)) +
  0.7 * Math.sin(TAU * 164.81 * t + 0.5) * (0.6 + 0.4 * Math.sin(TAU * 0.13 * t + 1)) +
  0.5 * Math.sin(TAU * 220.4 * t) * (0.6 + 0.4 * Math.sin(TAU * 0.07 * t + 2)))), 0.5));
