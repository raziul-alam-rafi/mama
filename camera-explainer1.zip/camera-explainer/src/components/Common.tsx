import React from "react";
import { AbsoluteFill, Audio, Sequence, interpolate, spring, staticFile, useCurrentFrame, useVideoConfig } from "remotion";
import { theme } from "../theme";

/* ---------- Layer 1: animated background mesh + blueprint grid ---------- */
export const BgMesh: React.FC = () => {
  const frame = useCurrentFrame();
  const d1 = Math.sin(frame / 55) * 50, d2 = Math.cos(frame / 70) * 40;
  const c = theme.colors;
  return (
    <AbsoluteFill style={{ background: `linear-gradient(180deg, ${c.bg}, ${c.bgAlt})` }}>
      <div style={{ position: "absolute", width: 1300, height: 1300, borderRadius: "50%", top: -560, left: -320 + d1, filter: "blur(60px)", background: `radial-gradient(circle, ${c.primary}2E, transparent 62%)` }} />
      <div style={{ position: "absolute", width: 1000, height: 1000, borderRadius: "50%", bottom: -480, right: -260 - d2, filter: "blur(70px)", background: `radial-gradient(circle, ${c.accent}1C, transparent 65%)` }} />
      <svg width="100%" height="100%" style={{ position: "absolute", inset: 0, opacity: 0.5 }}>
        <defs>
          <pattern id="bp" width="60" height="60" patternUnits="userSpaceOnUse">
            <path d="M60 0H0V60" fill="none" stroke={c.line} strokeWidth="1" opacity="0.28" />
          </pattern>
        </defs>
        <rect width="100%" height="100%" fill="url(#bp)" />
      </svg>
    </AbsoluteFill>
  );
};

/* ---------- Layers 4-5: grade, grain, vignette ---------- */
export const Grade: React.FC = () => (
  <AbsoluteFill style={{ pointerEvents: "none" }}>
    <AbsoluteFill style={{ backgroundColor: theme.colors.primary, mixBlendMode: "soft-light", opacity: 0.16 }} />
    <AbsoluteFill style={{ background: "linear-gradient(180deg, rgba(0,0,0,0.12), transparent 28%, transparent 72%, rgba(0,0,0,0.22))" }} />
  </AbsoluteFill>
);

export const Grain: React.FC = () => {
  const frame = useCurrentFrame();
  const noise = `url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='220' height='220'%3E%3Cfilter id='n'%3E%3CfeTurbulence type='fractalNoise' baseFrequency='0.9' numOctaves='2'/%3E%3C/filter%3E%3Crect width='220' height='220' filter='url(%23n)' opacity='0.5'/%3E%3C/svg%3E")`;
  return (
    <AbsoluteFill style={{ pointerEvents: "none", backgroundImage: noise, backgroundSize: "220px", backgroundPosition: `${(frame * 7) % 220}px ${(frame * 13) % 220}px`, opacity: 0.05, mixBlendMode: "overlay" }} />
  );
};

export const Vignette: React.FC = () => (
  <AbsoluteFill style={{ pointerEvents: "none", background: "radial-gradient(ellipse at center, transparent 56%, rgba(0,0,0,0.30) 100%)" }} />
);

/* ---------- Entrance (opacity + rise + scale) ---------- */
export const Entrance: React.FC<{ delay?: number; children: React.ReactNode; style?: React.CSSProperties; from?: number }> = ({ delay = 0, children, style, from = 36 }) => {
  const frame = useCurrentFrame();
  const { fps } = useVideoConfig();
  const p = spring({ frame: frame - delay, fps, config: theme.spring.smooth });
  return (
    <div style={{ opacity: p, transform: `translateY(${interpolate(p, [0, 1], [from, 0])}px) scale(${interpolate(p, [0, 1], [0.95, 1])})`, ...style }}>{children}</div>
  );
};

/* ---------- Word-by-word reveal. Splits ONLY on spaces. *word* = highlighted keyword ---------- */
export const WordReveal: React.FC<{
  text: string; delay?: number; per?: number; size?: number; color?: string; hi?: string;
  align?: "flex-start" | "center" | "flex-end"; exitAt?: number; weight?: number; maxWidth?: number;
}> = ({ text, delay = 0, per = theme.timing.staggerWord, size = 96, color = theme.colors.text, hi = theme.colors.primary, align = "flex-start", exitAt, weight = 700, maxWidth }) => {
  const frame = useCurrentFrame();
  const { fps } = useVideoConfig();
  const words = text.split(" ");
  const ex = exitAt === undefined ? 0 : interpolate(frame, [exitAt, exitAt + 9], [0, 1], { easing: theme.ease.in, extrapolateLeft: "clamp", extrapolateRight: "clamp" });
  return (
    <div style={{ display: "flex", flexWrap: "wrap", columnGap: size * 0.28, rowGap: 0, justifyContent: align, maxWidth, fontFamily: theme.fonts.display, fontWeight: weight, fontSize: size, lineHeight: 1.32, letterSpacing: 0, color, opacity: 1 - ex, transform: `translateY(${-24 * ex}px)` }}>
      {words.map((raw, i) => {
        const key = raw.startsWith("*") && raw.endsWith("*");
        const w = key ? raw.slice(1, -1) : raw;
        const d = delay + i * per;
        const p = spring({ frame: frame - d, fps, config: theme.spring.snappy });
        const sweep = key ? interpolate(frame, [d + 5, d + 15], [0, 1], { easing: theme.ease.out, extrapolateLeft: "clamp", extrapolateRight: "clamp" }) : 0;
        return (
          <span key={i} style={{ position: "relative", display: "inline-block", opacity: p, transform: `translateY(${interpolate(p, [0, 1], [34, 0])}px) scale(${interpolate(p, [0, 1], [0.92, 1])})`, color: key ? hi : color }}>
            {w}
            {key && <span style={{ position: "absolute", left: 0, bottom: size * 0.06, height: Math.max(5, size * 0.055), width: `${sweep * 100}%`, borderRadius: 4, background: hi, opacity: 0.9 }} />}
          </span>
        );
      })}
    </div>
  );
};

/* ---------- Small caption / label chip ---------- */
export const Label: React.FC<{ text: string; x: number; y: number; delay?: number; size?: number; color?: string; dim?: boolean; anchor?: "start" | "middle" | "end"; tone?: "plain" | "chip" }> = ({ text, x, y, delay = 0, size = 34, color = theme.colors.text, dim, anchor = "middle", tone = "chip" }) => {
  const frame = useCurrentFrame();
  const { fps } = useVideoConfig();
  const p = spring({ frame: frame - delay, fps, config: theme.spring.snappy });
  const tx = anchor === "middle" ? "-50%" : anchor === "end" ? "-100%" : "0%";
  return (
    <div style={{ position: "absolute", left: x, top: y, transform: `translate(${tx}, -50%) translateY(${interpolate(p, [0, 1], [14, 0])}px) scale(${interpolate(p, [0, 1], [0.92, 1])})`, opacity: p, fontFamily: theme.fonts.body, fontWeight: 500, fontSize: size, lineHeight: 1.3, color: dim ? theme.colors.textDim : color, whiteSpace: "nowrap", padding: tone === "chip" ? "6px 20px 10px" : 0, borderRadius: 14, background: tone === "chip" ? `${theme.colors.bgAlt}E6` : "transparent", border: tone === "chip" ? `1px solid ${theme.colors.line}` : "none" }}>{text}</div>
  );
};

/* ---------- Scene shell: exit animation (faster than entrance) ---------- */
export const SceneShell: React.FC<{ children: React.ReactNode; dur: number }> = ({ children, dur: durationInFrames }) => {
  const frame = useCurrentFrame();
  const n = theme.timing.exitFrames;
  const e = interpolate(frame, [durationInFrames - n, durationInFrames - 1], [0, 1], { easing: theme.ease.in, extrapolateLeft: "clamp", extrapolateRight: "clamp" });
  return <AbsoluteFill style={{ opacity: 1 - e * 0.9, transform: `scale(${1 + e * 0.02})` }}>{children}</AbsoluteFill>;
};

/* ---------- SFX: short UI sounds, played early so they feel synced ---------- */
export type SfxName = "pop" | "click" | "whoosh" | "chime" | "thud" | "tick";
const SFX_LEN: Record<SfxName, number> = { pop: 14, click: 8, whoosh: 26, chime: 24, thud: 14, tick: 6 };
export const Sfx: React.FC<{ name: SfxName; at: number; vol?: number; rate?: number }> = ({ name, at, vol = 0.28, rate = 1 }) => {
  if (!theme.flags.sfx) return null;
  return (
    <Sequence from={Math.max(0, at - 2)} durationInFrames={SFX_LEN[name] + 6} layout="none">
      <Audio src={staticFile(`sfx/${name}.wav`)} volume={vol} playbackRate={rate} />
    </Sequence>
  );
};
