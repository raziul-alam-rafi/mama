import React from "react";
import * as R from "remotion";
import { Audio, Sequence, staticFile } from "remotion";
import { SFX_ENABLED, VOICEOVER } from "../config";
import { FPS } from "../theme";

/** public/voiceover.mp3 — Studio-তে থাকলে বাজে, না থাকলে নীরবে বাদ। রেন্ডারে ডিফল্টে বন্ধ (src/config.ts) */
export const PreviewAudio: React.FC = () => {
  const env = (R as any).getRemotionEnvironment?.();
  const rendering: boolean = env ? Boolean(env.isRendering) : false;
  if (rendering ? !VOICEOVER.render : !VOICEOVER.studio) return null;
  if (!rendering) {
    try {
      const files: { name: string }[] | undefined = (R as any).getStaticFiles?.();
      if (files && !files.some((f) => f.name === "voiceover.mp3")) return null;
    } catch {
      return null;
    }
  }
  return <Audio src={staticFile("voiceover.mp3")} volume={1} />;
};

// সাউন্ডের বেস ভলিউম (সংযত 0.2–0.35; সবগুলো একই RMS-এ নরমালাইজড) ও দৈর্ঘ্য (সেকেন্ড)
const KIT = {
  pop: { vol: 0.3, dur: 0.34 },
  click: { vol: 0.26, dur: 0.18 },
  whoosh: { vol: 0.3, dur: 0.72 },
  "whoosh-soft": { vol: 0.24, dur: 0.5 },
  chime: { vol: 0.26, dur: 0.46 },
  thud: { vol: 0.28, dur: 0.32 },
} as const;
export type SfxName = keyof typeof KIT;

/** `at` = এই Sequence-এর লোকাল ফ্রেম। `n` পরপর একই সাউন্ডে সামান্য pitch/volume ভ্যারিয়েশন দেয় */
export const Sfx: React.FC<{ name: SfxName; at: number; n?: number }> = ({ name, at, n = 0 }) => {
  if (!SFX_ENABLED) return null;
  const k = KIT[name];
  const rate = 1 + (((n * 37) % 7) - 3) * 0.018;
  const vol = k.vol * (1 + (((n * 53) % 5) - 2) * 0.04);
  const from = Math.max(0, Math.round(at));
  return (
    <Sequence from={from} durationInFrames={Math.ceil((k.dur / rate) * FPS) + 3} layout="none">
      <Audio src={staticFile(`sfx/${name}.wav`)} volume={vol} playbackRate={rate} />
    </Sequence>
  );
};
