import React from "react";
import { theme } from "./theme";
import { clampOpts, hash } from "./fx";

const C = theme.colors;

/** নেগেটিভ চার্জ: নীল গোলক + মাইনাস */
export const Electron: React.FC<{ x: number; y: number; r?: number; o?: number; glow?: boolean }> = ({
  x,
  y,
  r = 14,
  o = 1,
  glow = true,
}) => (
  <g transform={`translate(${x} ${y})`} opacity={o}>
    {glow ? <circle r={r * 2.1} fill={C.primary} opacity={0.2} /> : null}
    <circle r={r} fill={C.primary} stroke={C.text} strokeWidth={1.5} strokeOpacity={0.55} />
    <rect x={-r * 0.5} y={-r * 0.11} width={r} height={r * 0.22} rx={r * 0.1} fill={C.bg} />
  </g>
);

/** পজিটিভ hole: ফাঁকা রিং + প্লাস */
export const Hole: React.FC<{ x: number; y: number; r?: number; o?: number }> = ({ x, y, r = 14, o = 1 }) => (
  <g transform={`translate(${x} ${y})`} opacity={o}>
    <circle r={r} fill={C.bg} stroke={C.text} strokeWidth={3} />
    <rect x={-r * 0.5} y={-r * 0.11} width={r} height={r * 0.22} rx={r * 0.1} fill={C.text} />
    <rect x={-r * 0.11} y={-r * 0.5} width={r * 0.22} height={r} rx={r * 0.1} fill={C.text} />
  </g>
);

/** ফোটন: তরঙ্গ-প্যাকেট। rot ডিগ্রিতে চলার দিক (০° = ডানে) */
export const Photon: React.FC<{
  x: number;
  y: number;
  rot?: number;
  len?: number;
  amp?: number;
  phase?: number;
  o?: number;
  color?: string;
  scale?: number;
}> = ({ x, y, rot = 0, len = 96, amp = 12, phase = 0, o = 1, color = C.accent, scale = 1 }) => {
  const N = 48;
  let d = "";
  for (let i = 0; i <= N; i++) {
    const t = i / N;
    const env = Math.sin(Math.PI * t);
    const px = (t - 0.5) * len;
    const py = amp * env * Math.sin(t * Math.PI * 2 * 3 + phase);
    d += (i === 0 ? "M" : "L") + px.toFixed(1) + " " + py.toFixed(1) + " ";
  }
  return (
    <g transform={`translate(${x} ${y}) rotate(${rot}) scale(${scale})`} opacity={o}>
      <circle r={len * 0.34} fill={color} opacity={0.16} />
      <path d={d} fill="none" stroke={color} strokeWidth={11} strokeLinecap="round" opacity={0.22} />
      <path d={d} fill="none" stroke={color} strokeWidth={4.5} strokeLinecap="round" />
    </g>
  );
};

/** সিলিকন ল্যাটিস: পরমাণু + বন্ড */
export const Lattice: React.FC<{
  x0: number;
  y0: number;
  cols: number;
  rows: number;
  gap: number;
  r: number;
  o?: number;
}> = ({ x0, y0, cols, rows, gap, r, o = 1 }) => {
  const els: React.ReactNode[] = [];
  for (let j = 0; j < rows; j++) {
    for (let i = 0; i < cols; i++) {
      const cx = x0 + i * gap;
      const cy = y0 + j * gap;
      if (i < cols - 1)
        els.push(
          <line key={`h${i}-${j}`} x1={cx} y1={cy} x2={cx + gap} y2={cy} stroke={C.panelLine} strokeWidth={Math.max(3, r * 0.28)} />
        );
      if (j < rows - 1)
        els.push(
          <line key={`v${i}-${j}`} x1={cx} y1={cy} x2={cx} y2={cy + gap} stroke={C.panelLine} strokeWidth={Math.max(3, r * 0.28)} />
        );
    }
  }
  for (let j = 0; j < rows; j++)
    for (let i = 0; i < cols; i++)
      els.push(
        <g key={`a${i}-${j}`}>
          <circle cx={x0 + i * gap} cy={y0 + j * gap} r={r} fill={C.siliconHi} stroke={C.panelLine} strokeWidth={2} />
          <circle cx={x0 + i * gap - r * 0.3} cy={y0 + j * gap - r * 0.3} r={r * 0.32} fill={C.text} opacity={0.14} />
        </g>
      );
  return <g opacity={o}>{els}</g>;
};

/** পিক্সেল-কূপ: charge জমার বাকেট। level 0..1 */
export const PixelWell: React.FC<{
  x: number; // বাম-উপর কোণ
  y: number;
  w: number;
  h: number;
  level: number;
  cols?: number;
  rows?: number;
  o?: number;
  tint?: string;
}> = ({ x, y, w, h, level, cols = 6, rows = 10, o = 1, tint = C.primary }) => {
  const pad = 14;
  const cw = (w - pad * 2) / cols;
  const ch = (h - pad * 2) / rows;
  const r = Math.min(cw, ch) * 0.36;
  const N = cols * rows;
  const dots: React.ReactNode[] = [];
  for (let k = 0; k < N; k++) {
    const row = Math.floor(k / cols);
    const col = k % cols;
    const s = Math.min(1, Math.max(0, level * N - k));
    if (s <= 0.01) continue;
    const cx = x + pad + cw * (col + 0.5) + (hash(k, 1) - 0.5) * cw * 0.2;
    const cy = y + h - pad - ch * (row + 0.5) + (hash(k, 2) - 0.5) * ch * 0.2;
    dots.push(<Electron key={k} x={cx} y={cy} r={r * s} glow={false} />);
  }
  const surf = y + h - pad - (h - pad * 2) * level;
  return (
    <g opacity={o}>
      <rect x={x} y={y} width={w} height={h} rx={26} fill={C.panel} stroke={C.panelLine} strokeWidth={3} />
      <rect x={x + 6} y={y + h - pad - (h - pad * 2) * level} width={w - 12} height={(h - pad * 2) * level + pad - 6} rx={18} fill={tint} opacity={0.14} />
      {level > 0.02 ? <line x1={x + 10} x2={x + w - 10} y1={surf} y2={surf} stroke={tint} strokeWidth={3} opacity={0.7} /> : null}
      {dots}
    </g>
  );
};

/** প্রগতি 0..1 থেকে সীমাবদ্ধ মান */
export const clamp01 = (v: number) => Math.min(1, Math.max(0, v));
export { clampOpts };
