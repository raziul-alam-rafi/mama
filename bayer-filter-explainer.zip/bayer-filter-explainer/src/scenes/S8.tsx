import React from "react";
import {AbsoluteFill} from "remotion";
import {Pop, Sfx, Words, clamp01, useAnim} from "../anim";
import {bayerAt, chColor, theme} from "../theme";

const COLS = 16;
const ROWS = 9;
const CELL = 120;

// Scene 8 - the question: a raw single-colour mosaic and the open problem.
export const S8: React.FC = () => {
  const a = useAnim();
  const panel = a.sp(0.2, theme.spring.smooth);
  const q = a.sp(0.35, theme.spring.bouncy);
  const glow = 0.6 + 0.4 * Math.sin(a.t * 4);

  return (
    <AbsoluteFill>
      <Sfx name="whoosh_swipe" at={0.05} vol={0.22} />
      <Sfx name="thud" at={0.35} vol={0.26} />
      <Sfx name="chime" at={0.7} vol={0.24} />

      {Array.from({length: ROWS * COLS}).map((_, i) => {
        const r = Math.floor(i / COLS);
        const c = i % COLS;
        const ch = bayerAt(r, c);
        const dist = Math.hypot(c - COLS / 2 + 0.5, r - ROWS / 2 + 0.5);
        const p = a.sp(dist * 0.03, theme.spring.snappy);
        const lum = 0.35 + 0.65 * (0.5 + 0.5 * Math.sin(c * 0.55 + r * 0.35 + a.t * 0.6));
        return (
          <div key={i} style={{position: "absolute", left: c * CELL, top: r * CELL, width: CELL, height: CELL, padding: 6, opacity: clamp01(p * 1.5)}}>
            <div style={{width: "100%", height: "100%", borderRadius: 14, background: chColor[ch], opacity: 0.55 * lum, transform: `scale(${0.7 + 0.3 * p})`}} />
          </div>
        );
      })}

      <AbsoluteFill style={{alignItems: "center", justifyContent: "center"}}>
        <div
          style={{
            width: 1260,
            padding: "36px 40px 44px",
            borderRadius: theme.radius.card + 8,
            background: "rgba(11,16,32,0.9)",
            border: `2px solid ${theme.colors.cardLine}`,
            boxShadow: `0 40px 100px -20px ${theme.colors.shadow}`,
            opacity: clamp01(panel * 1.5),
            transform: `scale(${0.92 + 0.08 * panel})`,
            display: "flex",
            flexDirection: "column",
            alignItems: "center",
          }}
        >
          <div style={{fontFamily: theme.fonts.display, fontWeight: 700, fontSize: 250, lineHeight: 1.05, color: theme.colors.amber, textShadow: `0 0 ${40 + 30 * glow}px ${theme.colors.amberGlow}`, transform: `scale(${0.5 + 0.5 * q})`, opacity: clamp01(q * 1.5)}}>?</div>
          <Words text="সম্পূর্ণ রঙিন ছবি তৈরি হয় কিভাবে?" at={0.3} per={3} size={70} align="center" highlight={["রঙিন"]} hlColor={theme.colors.hero} />
        </div>
      </AbsoluteFill>
    </AbsoluteFill>
  );
};
