import {useLayoutEffect} from 'react';
import {useThree} from '@react-three/fiber';
import * as THREE from 'three';
import {RoomEnvironment} from 'three/examples/jsm/environments/RoomEnvironment.js';
import {LIGHT} from '../../config/theme';

/**
 * Offline image-based lighting: a procedural studio environment baked with PMREM.
 * No HDRI download needed. (Swap for a real HDRI in public/environments/ for a higher-quality look.)
 */
export const EnvironmentSetup: React.FC = () => {
  const {gl, scene} = useThree();
  useLayoutEffect(() => {
    const pmrem = new THREE.PMREMGenerator(gl);
    const rt = pmrem.fromScene(new RoomEnvironment(), 0.04);
    scene.environment = rt.texture;
    scene.environmentIntensity = LIGHT.envIntensity;
    scene.fog = new THREE.FogExp2(0x2a2a3d, 0.0030);
    return () => {
      scene.environment = null;
      rt.dispose();
      pmrem.dispose();
    };
  }, [gl, scene]);
  return null;
};
