import React from "react";
import {AbsoluteFill} from "remotion";
import {Chip, Pop, Sfx, Words, clamp01, useAnim} from "../anim";
import {bayerAt, chColor, theme} from "../theme";

const COLS = 8;
const ROWS = 6;
const CELL = 104;
const TILE = 94;
const OX = 130;
const OY = 290;
const UX = 1280;
const UY = 400;
const UC = 150;
const HL_C = 2;
const HL_R = 2;

const Tile: React.FC<{ch: "R" | "G" | "B"; size: number; scale?: number; dim?: number; glow?: number}> = ({ch, size, scale = 1, dim = 1, glow = 0}) => {
  const col = chColor[ch];
  return (
    <div
      style={{
        width: size,
        height: size,
        borderRadius: theme.radius.tile + 2,
        opacity: dim,
        transform: `scale(${scale})`,
        background: `linear-gradient(145deg, ${col}, ${col}B8)`,
        border: "2px solid rgba(255,255,255,0.4)",
        boxShadow: `0 0 ${glow}px ${col}`,
      }}
    >
      <div style={{width: "100%", height: "34%", borderRadius: `${theme.radius.tile}px ${theme.radius.tile}px 40px 40px`, background: "rgba(255,255,255,0.18)"}} />
    </div>
  );
};

// Scene 5 - top-down colour filter mosaic: green tiles outnumber red and blue.
export const S5: React.FC = () => {
  const a = useAnim();
  const dimK = a.prog(2.3, 3.0);
  const pulse = 0.5 + 0.5 * Math.sin(a.t * 3.2);
  const unit = a.sp(2.7, theme.spring.snappy);
  const link = a.prog(2.8, 3.5, theme.ease.out);

  return (
    <AbsoluteFill>
      <Sfx name="whoosh_swipe" at={0.05} vol={0.22} />
      <Sfx name="pop" at={0.5} vol={0.24} rate={1.02} />
      <Sfx name="click" at={2.4} vol={0.22} />
      <Sfx name="pop" at={2.9} vol={0.22} rate={1.06} />

      <div style={{position: "absolute", left: 140, top: 64, width: 1640}}>
        <Words text="লাল ও নীলের চেয়ে সবুজ filter বেশি" at={0.1} highlight={["সবুজ"]} hlColor={theme.colors.green} />
      </div>

      {Array.from({length: ROWS * COLS}).map((_, i) => {
        const r = Math.floor(i / COLS);
        const c = i % COLS;
        const ch = bayerAt(r, c);
        const p = a.sp(0.4 + (r + c) * 0.06, theme.spring.snappy);
        const isG = ch === "G";
        const dim = 1 - (isG ? 0 : 0.72) * dimK;
        return (
          <div key={i} style={{position: "absolute", left: OX + c * CELL, top: OY + r * CELL, opacity: clamp01(p * 1.6), transform: `scale(${0.6 + 0.4 * p})`}}>
            <Tile ch={ch} size={TILE} dim={dim} scale={isG ? 1 + 0.02 * pulse * dimK : 1} glow={isG ? 26 * dimK * (0.5 + 0.5 * pulse) : 0} />
          </div>
        );
      })}

      <svg width={1920} height={1080} style={{position: "absolute", inset: 0, pointerEvents: "none"}}>
        <rect
          x={OX + HL_C * CELL - 6}
          y={OY + HL_R * CELL - 6}
          width={2 * CELL + 2}
          height={2 * CELL + 2}
          rx={20}
          fill="none"
          stroke={theme.colors.amber}
          strokeWidth={5}
          opacity={link}
          style={{filter: `drop-shadow(0 0 12px ${theme.colors.amber})`}}
        />
        <line
          x1={OX + (HL_C + 2) * CELL - 4}
          y1={OY + (HL_R + 1) * CELL}
          x2={OX + (HL_C + 2) * CELL - 4 + (UX - 30 - (OX + (HL_C + 2) * CELL - 4)) * link}
          y2={OY + (HL_R + 1) * CELL + (UY + UC - (OY + (HL_R + 1) * CELL)) * link}
          stroke={theme.colors.amber}
          strokeWidth={4}
          strokeDasharray="12 12"
          strokeDashoffset={-a.frame * 1.5}
          strokeLinecap="round"
        />
      </svg>

      <div style={{position: "absolute", left: UX, top: UY - 105, opacity: clamp01(unit * 1.5)}}>
        <Chip size={theme.size.small}>এই বিন্যাস</Chip>
      </div>
      <div style={{position: "absolute", left: UX, top: UY, width: UC * 2 + 12, height: UC * 2 + 12, opacity: clamp01(unit * 1.5), transform: `scale(${0.85 + 0.15 * unit})`, transformOrigin: "left top"}}>
        {([["R", 0, 0], ["G", 1, 0], ["G", 0, 1], ["B", 1, 1]] as const).map(([ch, cx, cy], i) => {
          const isG = ch === "G";
          return (
            <div key={i} style={{position: "absolute", left: cx * (UC + 12), top: cy * (UC + 12)}}>
              <Tile ch={ch} size={UC} dim={1 - (isG ? 0 : 0.6) * dimK} scale={isG ? 1 + 0.02 * pulse * dimK : 1} glow={isG ? 30 * dimK * (0.5 + 0.5 * pulse) : 0} />
            </div>
          );
        })}
      </div>
      <Pop at={3.5} y={20} style={{position: "absolute", left: UX, top: UY + UC * 2 + 60}}>
        <Chip dot={theme.colors.green}>সবুজ filter বেশি</Chip>
      </Pop>
    </AbsoluteFill>
  );
};
