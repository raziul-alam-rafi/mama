import React from "react";
import { Audio, Sequence, staticFile } from "remotion";
import { sfxEvents } from "../beats";

/** The limited SFX kit (public/sfx/*.wav) placed on main entries, reveals and scene transitions. */
export const Sfx: React.FC = () => (
  <>
    {sfxEvents.map((e, i) => (
      <Sequence key={`${e.file}-${i}`} from={e.frame} durationInFrames={e.length}>
        <Audio src={staticFile(`sfx/${e.file}.wav`)} volume={e.volume} playbackRate={e.rate ?? 1} />
      </Sequence>
    ))}
  </>
);
