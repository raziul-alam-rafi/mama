// Deterministic SFX synthesis -> public/sfx/*.wav (16-bit mono, 44.1kHz). No downloads.
import fs from "node:fs";
import path from "node:path";
const SR = 44100;
let seed = 1234567;
const rnd = () => ((seed = (seed * 1664525 + 1013904223) >>> 0) / 4294967296) * 2 - 1;
const N = (sec) => Math.floor(sec * SR);
const clamp = (x, a, b) => Math.max(a, Math.min(b, x));

const lowpass = (buf, fc) => {
  const a = 1 - Math.exp((-2 * Math.PI * fc) / SR);
  let y = 0;
  for (let i = 0; i < buf.length; i++) { y += a * (buf[i] - y); buf[i] = y; }
  return buf;
};
const highpass = (buf, fc) => {
  const a = Math.exp((-2 * Math.PI * fc) / SR);
  let px = 0, py = 0;
  for (let i = 0; i < buf.length; i++) { const x = buf[i]; py = a * (py + x - px); px = x; buf[i] = py; }
  return buf;
};
// tiny, quiet reverb (3 combs) - short tail
const reverb = (buf, mix = 0.1) => {
  const out = new Float32Array(buf.length + N(0.06));
  out.set(buf);
  for (const [d, g] of [[0.021, 0.32], [0.034, 0.24], [0.047, 0.18]]) {
    const o = N(d);
    for (let i = 0; i < buf.length; i++) out[i + o] += buf[i] * g * mix * 3;
  }
  return out;
};
const env = (i, len, atk, tau) => {
  const t = i / SR;
  const a = clamp(t / atk, 0, 1);
  return Math.sin((a * Math.PI) / 2) * Math.exp(-t / tau) * (i > len - N(0.01) ? clamp((len - i) / N(0.01), 0, 1) : 1);
};
// state-variable band-pass noise sweep
const sweep = (len, f0, f1, q, shape) => {
  const out = new Float32Array(len);
  let low = 0, band = 0;
  for (let i = 0; i < len; i++) {
    const u = i / len;
    const fc = f0 * Math.pow(f1 / f0, shape(u));
    const f = 2 * Math.sin((Math.PI * fc) / SR);
    const x = rnd();
    low += f * band;
    const high = x - low - q * band;
    band += f * high;
    out[i] = band;
  }
  return out;
};

const make = {
  pop() {
    const len = N(0.2); const b = new Float32Array(len); let ph = 0;
    for (let i = 0; i < len; i++) {
      const t = i / SR; const f = 170 + 420 * Math.exp(-t / 0.028);
      ph += (2 * Math.PI * f) / SR;
      b[i] = Math.sin(ph) * env(i, len, 0.004, 0.05);
    }
    return reverb(lowpass(b, 5200), 0.08);
  },
  click() {
    const len = N(0.12); const b = new Float32Array(len);
    for (let i = 0; i < len; i++) {
      const t = i / SR;
      b[i] = rnd() * Math.exp(-t / 0.006) * 0.9 + Math.sin(2 * Math.PI * 2300 * t) * Math.exp(-t / 0.012) * 0.35;
    }
    return lowpass(highpass(b, 1800), 7000);
  },
  whoosh_soft() {
    const len = N(0.5);
    const b = sweep(len, 380, 2100, 1.1, (u) => u * u * (3 - 2 * u));
    for (let i = 0; i < len; i++) { const u = i / len; b[i] *= Math.pow(Math.sin(Math.PI * Math.pow(u, 0.8)), 2); }
    return reverb(lowpass(b, 5000), 0.08);
  },
  whoosh_swipe() {
    const len = N(0.65);
    const b = sweep(len, 500, 3200, 0.9, (u) => 1 - Math.pow(1 - u, 2));
    for (let i = 0; i < len; i++) { const u = i / len; b[i] *= Math.pow(Math.sin(Math.PI * Math.pow(u, 0.7)), 2); }
    return reverb(lowpass(b, 5500), 0.1);
  },
  chime() {
    const len = N(0.43); const b = new Float32Array(len);
    const partials = [[880, 1, 0.16], [1318.5, 0.5, 0.12], [1760, 0.22, 0.09], [2217, 0.08, 0.06]];
    for (let i = 0; i < len; i++) {
      const t = i / SR; let s = 0;
      for (const [f, a, tau] of partials) s += Math.sin(2 * Math.PI * f * t) * a * Math.exp(-t / tau);
      b[i] = s * clamp(t / 0.004, 0, 1) * (i > len - N(0.05) ? clamp((len - i) / N(0.05), 0, 1) : 1);
    }
    return reverb(lowpass(b, 6000), 0.12);
  },
  thud() {
    const len = N(0.3); const b = new Float32Array(len); let ph = 0;
    for (let i = 0; i < len; i++) {
      const t = i / SR; const f = 48 + 60 * Math.exp(-t / 0.05);
      ph += (2 * Math.PI * f) / SR;
      b[i] = Math.sin(ph) * env(i, len, 0.006, 0.09);
    }
    return lowpass(b, 400);
  },
};
// peak cap + RMS target so every sound sits at the same perceived level
const TARGET_RMS = 0.11, PEAK_CAP = 0.89;
const dir = path.resolve("public/sfx"); fs.mkdirSync(dir, { recursive: true });
const report = [];
for (const [name, fn] of Object.entries(make)) {
  const buf = fn();
  let peak = 0, sum = 0;
  for (const v of buf) { peak = Math.max(peak, Math.abs(v)); sum += v * v; }
  const rms = Math.sqrt(sum / buf.length);
  const gain = Math.min(TARGET_RMS / rms, PEAK_CAP / peak);
  const pcm = Buffer.alloc(44 + buf.length * 2);
  pcm.write("RIFF", 0); pcm.writeUInt32LE(36 + buf.length * 2, 4); pcm.write("WAVEfmt ", 8);
  pcm.writeUInt32LE(16, 16); pcm.writeUInt16LE(1, 20); pcm.writeUInt16LE(1, 22);
  pcm.writeUInt32LE(SR, 24); pcm.writeUInt32LE(SR * 2, 28); pcm.writeUInt16LE(2, 32); pcm.writeUInt16LE(16, 34);
  pcm.write("data", 36); pcm.writeUInt32LE(buf.length * 2, 40);
  let clipped = 0, fp = 0, fs2 = 0;
  for (let i = 0; i < buf.length; i++) {
    const v = buf[i] * gain; if (Math.abs(v) >= 0.999) clipped++;
    fp = Math.max(fp, Math.abs(v)); fs2 += v * v;
    pcm.writeInt16LE(Math.round(clamp(v, -1, 1) * 32767), 44 + i * 2);
  }
  fs.writeFileSync(path.join(dir, name + ".wav"), pcm);
  report.push({ name, dur_s: +(buf.length / SR).toFixed(3), peak_dBFS: +(20 * Math.log10(fp)).toFixed(1), rms_dBFS: +(20 * Math.log10(Math.sqrt(fs2 / buf.length))).toFixed(1), clipped });
}
console.table(report);
