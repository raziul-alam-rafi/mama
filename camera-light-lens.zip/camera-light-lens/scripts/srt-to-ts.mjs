// script.srt → src/script.srt.ts  (SRT বদলালে একবার চালান: node scripts/srt-to-ts.mjs)
import fs from "node:fs";
const t = fs.readFileSync(new URL("../script.srt", import.meta.url), "utf8").replace(/\r/g, "");
fs.writeFileSync(
  new URL("../src/script.srt.ts", import.meta.url),
  "// Auto-generated from script.srt  (node scripts/srt-to-ts.mjs)\nexport const SRT = " + JSON.stringify(t) + ";\n"
);
console.log("OK");
