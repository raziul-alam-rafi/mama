import React, { useEffect, useState } from "react";
import { AbsoluteFill, Sequence, continueRender, delayRender, interpolate, useCurrentFrame } from "remotion";
import { theme } from "./theme";
import { SCENES } from "./cues";
import { loadFonts } from "./fonts";
import { BgMesh, Grade, Grain, SceneShell, Sfx, Vignette } from "./components/Common";
import { PreviewAudio } from "./components/PreviewAudio";
import { Hook } from "./scenes/Hook";
import { Sunlight } from "./scenes/Sunlight";
import { Problem } from "./scenes/Problem";
import { Control } from "./scenes/Control";
import { LensScene } from "./scenes/LensScene";
import { Elements } from "./scenes/Elements";

const MAP: Record<string, React.FC<{ from: number }>> = {
  hook: Hook, sunlight: Sunlight, problem: Problem, control: Control, lens: LensScene, elements: Elements,
};

/** diagonal band that sweeps across; the cut happens while it covers the frame */
const Wipe: React.FC<{ at: number }> = ({ at }) => {
  const frame = useCurrentFrame();
  const n = theme.timing.wipeFrames;
  const x = interpolate(frame, [at - n / 2, at + n / 2], [-3300, 3300], { easing: theme.ease.inOut, extrapolateLeft: "clamp", extrapolateRight: "clamp" });
  if (frame < at - n / 2 - 1 || frame > at + n / 2 + 1) return null;
  return (
    <AbsoluteFill style={{ overflow: "hidden", pointerEvents: "none" }}>
      <div style={{ position: "absolute", top: -200, left: "50%", width: 2800, height: 1500, marginLeft: -1400, transform: `translateX(${x}px) skewX(-16deg)`, background: `linear-gradient(90deg, ${theme.colors.primary} 0, ${theme.colors.primary} 10px, ${theme.colors.bgAlt} 10px, ${theme.colors.bg} 100%)`, boxShadow: `-30px 0 80px ${theme.colors.glow}` }} />
    </AbsoluteFill>
  );
};

export const Main: React.FC = () => {
  const [handle] = useState(() => delayRender("fonts"));
  useEffect(() => { loadFonts().finally(() => continueRender(handle)); }, [handle]);
  return (
    <AbsoluteFill style={{ background: theme.colors.bg, fontFamily: theme.fonts.body }}>
      <BgMesh />
      {SCENES.map((s) => {
        const Scene = MAP[s.key];
        return (
          <Sequence key={s.key} from={s.from} durationInFrames={s.dur} name={s.key}>
            <SceneShell dur={s.dur}><Scene from={s.from} /></SceneShell>
          </Sequence>
        );
      })}
      {SCENES.slice(1).map((s) => (
        <React.Fragment key={"w" + s.key}>
          <Wipe at={s.from} />
          <Sfx name="whoosh" at={s.from - theme.timing.wipeFrames / 2 - 2} vol={0.22} rate={0.98} />
        </React.Fragment>
      ))}
      <Grade />
      <Grain />
      <Vignette />
      <PreviewAudio />
    </AbsoluteFill>
  );
};
