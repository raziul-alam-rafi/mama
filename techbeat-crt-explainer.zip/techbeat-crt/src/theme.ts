// theme.ts — single source of truth: colors, fonts, easing, spring presets.
import { Easing } from "remotion";
import { FONT_STACK } from "./fonts";

export const theme = {
  colors: {
    bg: "#0B1020",
    bgAlt: "#141C36",
    hero: "#4F8CFF", // hero blue
    accent: "#FFB84D", // amber
    text: "#F4F7FF",
    textDim: "#9AA6C7",
    glow: "rgba(79,140,255,0.45)",
    glowAccent: "rgba(255,184,77,0.45)",
  },
  // Real-world material colors of the machines (NOT recolored to the brand palette)
  objects: {
    casing: "#34363b",
    casingHi: "#585b63",
    casingLo: "#1b1c1f",
    glass: "#8fb0b3",
    pcb: "#2f6b3f",
    pcbDark: "#22502f",
    copper: "#c07a3c",
    metal: "#b5bbc4",
    metalDark: "#6c727c",
    cameraBody: "#2b2e35",
    wall: "#d6cab4",
    roof: "#8a3b2e",
    grass: "#3f9b46",
    grassDark: "#2f7d39",
    pitch: "#d8c08a",
    red: "#d8362f",
  },
  fonts: { display: FONT_STACK },
  ease: {
    out: Easing.bezier(0.16, 1, 0.3, 1),
    inOut: Easing.bezier(0.83, 0, 0.17, 1),
    in: Easing.bezier(0.7, 0, 0.84, 0),
  },
  spring: {
    snappy: { damping: 14, stiffness: 160, mass: 0.6 },
    smooth: { damping: 20, stiffness: 90, mass: 1 },
    bouncy: { damping: 11, stiffness: 170, mass: 0.7 },
  },
} as const;
