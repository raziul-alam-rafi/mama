import React, { createContext, useContext } from "react";
import { spring, useCurrentFrame, useVideoConfig } from "remotion";
import { theme } from "../theme";

const SceneFromCtx = createContext<number>(0);
export const SceneClockProvider = SceneFromCtx.Provider;

/** Local frame inside a scene + helpers that map absolute SRT seconds to local frames. */
export function useClock() {
  const f = useCurrentFrame();
  const { fps, durationInFrames } = useVideoConfig();
  const from = useContext(SceneFromCtx);
  return {
    f,
    fps,
    from,
    dur: durationInFrames,
    abs: f + from,
    /** local frame at which absolute second `sec` happens (optionally `lead` frames earlier). */
    at: (sec: number, lead = 0) => Math.round(sec * fps) - from - lead,
  };
}

/** Spring 0→1 that starts at frame `start`. Safe for negative frames. */
export function usePop(start: number, cfg: { damping: number; stiffness: number; mass: number } = theme.spring.snappy) {
  const { f, fps } = useClock();
  if (f < start) return 0;
  return spring({ frame: f - start, fps, config: cfg });
}

/** Non-hook spring helper for loops. */
export const popAt = (f: number, fps: number, start: number, cfg: { damping: number; stiffness: number; mass: number } = theme.spring.snappy) =>
  f < start ? 0 : spring({ frame: f - start, fps, config: cfg });
