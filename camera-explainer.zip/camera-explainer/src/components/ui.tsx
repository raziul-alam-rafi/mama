import React from "react";
import {
  AbsoluteFill,
  interpolate,
  spring,
  useCurrentFrame,
  useVideoConfig,
} from "remotion";
import { theme, alpha } from "../theme";

export const clampX = { extrapolateLeft: "clamp", extrapolateRight: "clamp" } as const;

/** সবসময় ক্ল্যাম্প + ইজিং সহ interpolate */
export const ease = (
  frame: number,
  range: number[],
  out: number[],
  easing: (t: number) => number = theme.ease.out,
) => interpolate(frame, range, out, { easing, ...clampX });

export const useSpr = (delay: number, config: object = theme.spring.smooth) => {
  const frame = useCurrentFrame();
  const { fps } = useVideoConfig();
  return spring({ frame: frame - delay, fps, config });
};

/** প্রিমিয়াম এন্ট্রি: opacity + translateY + scale (একসাথে ৩টি) */
export const Pop: React.FC<{
  delay?: number;
  y?: number;
  from?: number;
  cfg?: object;
  style?: React.CSSProperties;
  children?: React.ReactNode;
}> = ({ delay = 0, y = 34, from = 0.94, cfg = theme.spring.smooth, style, children }) => {
  const p = useSpr(delay, cfg);
  return (
    <div
      style={{
        opacity: Math.min(1, Math.max(0, p * 1.3)),
        transform: `translateY(${interpolate(p, [0, 1], [y, 0])}px) scale(${interpolate(p, [0, 1], [from, 1])})`,
        ...style,
      }}
    >
      {children}
    </div>
  );
};

/** শব্দ ধরে স্ট্যাগার্ড রিভিল — শব্দ-বিভাজন শুধু স্পেসে, অক্ষর ভাঙা নয় */
export const WordReveal: React.FC<{
  text: string;
  delay?: number;
  per?: number;
  size: number;
  weight?: number;
  color?: string;
  hi?: number[];
  hiColor?: string;
  glow?: boolean;
  justify?: "center" | "flex-start";
  gap?: number;
}> = ({
  text,
  delay = 0,
  per = 4,
  size,
  weight = 700,
  color = theme.colors.text,
  hi = [],
  hiColor = theme.colors.hero,
  glow = false,
  justify = "center",
  gap = 26,
}) => {
  const frame = useCurrentFrame();
  const { fps } = useVideoConfig();
  return (
    <div
      style={{
        display: "flex",
        flexWrap: "wrap",
        justifyContent: justify,
        columnGap: gap,
        rowGap: 4,
        fontSize: size,
        fontWeight: weight,
        lineHeight: 1.4,
        letterSpacing: 0,
        color,
      }}
    >
      {text.split(" ").map((w, i) => {
        const p = spring({
          frame: frame - delay - i * per,
          fps,
          config: theme.spring.snappy,
        });
        const isHi = hi.includes(i);
        return (
          <span
            key={i}
            style={{
              display: "inline-block",
              opacity: Math.min(1, Math.max(0, p * 1.4)),
              transform: `translateY(${interpolate(p, [0, 1], [34, 0])}px) scale(${interpolate(p, [0, 1], [0.9, 1])})`,
              color: isHi ? hiColor : color,
              textShadow: isHi && glow ? `0 0 38px ${alpha(hiColor, 0.55)}` : undefined,
            }}
          >
            {w}
          </span>
        );
      })}
    </div>
  );
};

/** কাঁচ-ধাঁচের প্যানেল */
export const Glass: React.FC<{
  style?: React.CSSProperties;
  children?: React.ReactNode;
}> = ({ style, children }) => (
  <div
    style={{
      background: `linear-gradient(180deg, ${alpha(theme.colors.panel, 0.9)}, ${alpha(theme.colors.bgAlt, 0.82)})`,
      border: `1.5px solid ${theme.colors.lineSoft}`,
      borderRadius: theme.radius,
      boxSizing: "border-box",
      boxShadow: `${theme.shadow}, inset 0 1px 0 ${alpha(theme.colors.text, 0.1)}`,
      ...style,
    }}
  >
    {children}
  </div>
);

/** ছোট লেবেল-ক্যাপসুল */
export const Tag: React.FC<{
  text: string;
  delay?: number;
  color?: string;
  size?: number;
  dim?: boolean;
}> = ({ text, delay = 0, color = theme.colors.text, size = 34, dim = false }) => (
  <Pop delay={delay} y={16} from={0.9} cfg={theme.spring.snappy}>
    <div
      style={{
        display: "inline-block",
        padding: "6px 24px 10px",
        borderRadius: 999,
        fontSize: size,
        fontWeight: 600,
        lineHeight: 1.45,
        letterSpacing: 0,
        color,
        background: alpha(theme.colors.bgAlt, 0.92),
        border: `1.5px solid ${dim ? theme.colors.lineSoft : alpha(color, 0.55)}`,
        whiteSpace: "nowrap",
      }}
    >
      {text}
    </div>
  </Pop>
);

/** সিনের মোড়ক: শেষের ৮ ফ্রেমে দ্রুত এক্সিট (এন্ট্রির চেয়ে দ্রুত) */
export const SceneShell: React.FC<{ children?: React.ReactNode }> = ({ children }) => {
  const frame = useCurrentFrame();
  const { durationInFrames: d } = useVideoConfig();
  const o = ease(frame, [d - 8, d - 1], [1, 0], theme.ease.in);
  const s = ease(frame, [d - 8, d - 1], [1, 1.035], theme.ease.in);
  return (
    <AbsoluteFill style={{ opacity: o, transform: `scale(${s})` }}>{children}</AbsoluteFill>
  );
};

/* ---------- গ্লোবাল লেয়ার ---------- */

export const BgMesh: React.FC = () => {
  const frame = useCurrentFrame();
  const d1 = Math.sin(frame / 55) * 60;
  const d2 = Math.cos(frame / 70) * 46;
  const grid = alpha(theme.colors.text, 0.045);
  return (
    <AbsoluteFill style={{ background: theme.colors.bg }}>
      <div
        style={{
          position: "absolute",
          width: 1300,
          height: 1300,
          borderRadius: "50%",
          top: -560,
          left: -320 + d1,
          filter: "blur(50px)",
          background: `radial-gradient(circle, ${alpha(theme.colors.hero, 0.2)}, transparent 62%)`,
        }}
      />
      <div
        style={{
          position: "absolute",
          width: 1000,
          height: 1000,
          borderRadius: "50%",
          bottom: -470,
          right: -260 - d2,
          filter: "blur(70px)",
          background: `radial-gradient(circle, ${alpha(theme.colors.accent, 0.1)}, transparent 65%)`,
        }}
      />
      <AbsoluteFill
        style={{
          backgroundImage: `linear-gradient(${grid} 1px, transparent 1px), linear-gradient(90deg, ${grid} 1px, transparent 1px)`,
          backgroundSize: "80px 80px",
          backgroundPosition: `${-frame * 0.25}px ${-frame * 0.12}px`,
        }}
      />
    </AbsoluteFill>
  );
};

export const Grade: React.FC = () => (
  <AbsoluteFill style={{ pointerEvents: "none" }}>
    <AbsoluteFill
      style={{ backgroundColor: theme.colors.hero, mixBlendMode: "soft-light", opacity: 0.16 }}
    />
    <AbsoluteFill
      style={{
        background:
          "linear-gradient(180deg, rgba(0,0,0,0.14), transparent 26%, transparent 74%, rgba(0,0,0,0.22))",
      }}
    />
  </AbsoluteFill>
);

export const Grain: React.FC = () => {
  const frame = useCurrentFrame();
  const noise = `url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='220' height='220'%3E%3Cfilter id='n'%3E%3CfeTurbulence type='fractalNoise' baseFrequency='0.9' numOctaves='2'/%3E%3C/filter%3E%3Crect width='220' height='220' filter='url(%23n)' opacity='0.5'/%3E%3C/svg%3E")`;
  return (
    <AbsoluteFill
      style={{
        pointerEvents: "none",
        backgroundImage: noise,
        backgroundSize: "220px",
        backgroundPosition: `${(frame * 7) % 220}px ${(frame * 13) % 220}px`,
        opacity: 0.06,
        mixBlendMode: "overlay",
      }}
    />
  );
};

export const Vignette: React.FC = () => (
  <AbsoluteFill
    style={{
      pointerEvents: "none",
      background: "radial-gradient(ellipse at center, transparent 54%, rgba(0,0,0,0.34) 100%)",
    }}
  />
);

/* ---------- পথ-সহায়ক ---------- */
export type Pt = [number, number];
export const polyLen = (pts: Pt[]) =>
  pts.reduce((s, p, i) => (i ? s + Math.hypot(p[0] - pts[i - 1][0], p[1] - pts[i - 1][1]) : 0), 0);
export const pointAt = (pts: Pt[], t: number): Pt => {
  const total = polyLen(pts);
  let target = Math.max(0, Math.min(1, t)) * total;
  for (let i = 1; i < pts.length; i++) {
    const seg = Math.hypot(pts[i][0] - pts[i - 1][0], pts[i][1] - pts[i - 1][1]);
    if (target <= seg || i === pts.length - 1) {
      const u = seg === 0 ? 0 : Math.min(1, target / seg);
      return [pts[i - 1][0] + (pts[i][0] - pts[i - 1][0]) * u, pts[i - 1][1] + (pts[i][1] - pts[i - 1][1]) * u];
    }
    target -= seg;
  }
  return pts[pts.length - 1];
};
export const toD = (pts: Pt[]) => pts.map((p, i) => `${i ? "L" : "M"}${p[0]} ${p[1]}`).join(" ");

/** pathLength=1 কৌশলে "আঁকা হচ্ছে" ইফেক্ট */
export const Draw: React.FC<{
  d: string;
  p: number;
  stroke: string;
  w?: number;
  fill?: string;
  dash?: string;
  op?: number;
}> = ({ d, p, stroke, w = 2, fill = "none", dash, op = 1 }) => (
  <path
    d={d}
    pathLength={1}
    fill={fill}
    fillOpacity={Math.max(0, Math.min(1, p))}
    stroke={stroke}
    strokeWidth={w}
    strokeLinecap="round"
    strokeLinejoin="round"
    strokeDasharray={dash ?? "1 1"}
    strokeDashoffset={dash ? 0 : 1 - Math.max(0, Math.min(1, p))}
    opacity={dash ? Math.max(0, Math.min(1, p)) * op : op}
  />
);
