// Bengali-safe display font. Loaded through @remotion/google-fonts (bundled with
// the npm package; the font file itself is fetched once and cached by Remotion).
import { loadFont } from "@remotion/google-fonts/HindSiliguri";

const { fontFamily } = loadFont("normal", {
  weights: ["400", "500", "700"],
  subsets: ["bengali", "latin"],
});

export const FONT_STACK = `${fontFamily}, "Hind Siliguri", "Noto Sans Bengali", sans-serif`;
