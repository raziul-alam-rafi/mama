import React from "react";
import { AbsoluteFill } from "remotion";
import { theme } from "../theme";
import { useScene } from "../SceneContext";
import { Card, Chip, ip, clamp01, Entrance, WordReveal } from "../components/Motion";
import { Runner } from "../components/Runner";
import { Iris } from "../components/Iris";
import { ShutterFront } from "../components/ShutterFront";
import { Sfx } from "../components/Sfx";
import { FPS } from "../config";

// stage geometry (card-local px) and run timing (seconds)
const X0 = 120, X1 = 1080, GROUND = 440, V = 470, SCALE = 1.45;
const TC = (X1 - X0) / V; // crossing time
const CYC = TC + 0.6;
const DL = 1.0, DS = 0.04; // long / short exposure durations (s)
const TL0 = 0.35, TS0 = 0.9; // window start inside the crossing (s)
const NG = 11;

// map stage → photo-frame coordinates
const FK = 0.7;
const fx = (x: number) => -40 + (x - 120) * FK;
const fy = (y: number) => 285 + (y - GROUND) * FK;

const PhotoBg: React.FC<{ w: number; h: number }> = ({ w, h }) => (
  <>
    <rect width={w} height={h} fill={theme.colors.panel} />
    <rect y={fy(GROUND)} width={w} height={h - fy(GROUND)} fill={theme.colors.bgAlt} />
    <line x1={0} x2={w} y1={fy(GROUND)} y2={fy(GROUND)} stroke={theme.colors.line} strokeWidth={3} />
  </>
);

// Scene 9 · Moving child (cues 12–15): long exposure smears motion, short exposure freezes it; then Aperture = amount, Shutter = time.
export const ChildRecap: React.FC = () => {
  const S = useScene();
  const f = S.frame;
  const c12 = Math.max(S.cue(12), 0);
  const fRun0 = c12 + 8;
  const cycF = CYC * FPS;
  const fLong = S.word(12, "সংগ্রহের");
  const fShortW = S.word(13, "সময়টা");
  const fBlur = S.word(13, "ঝাপসা");
  const fSharp = S.word(14, "স্পষ্টভাবে");
  const fRecap = S.word(14, "অর্থাৎ");
  const fShutterW = S.word(15, "Shutter");
  const fAmount = S.word(14, "Aperture");
  const fTimeW = S.word(15, "কতক্ষণ");

  const kL = Math.ceil((fLong - fRun0) / cycF);
  const kS = Math.max(kL + 1, Math.ceil((fShortW - fRun0) / cycF));
  const cycStart = (k: number) => fRun0 + k * cycF;
  const wL0 = cycStart(kL) + TL0 * FPS, wS0 = cycStart(kS) + TS0 * FPS;

  // runner clock
  const rel = Math.max(0, f - fRun0) / FPS;
  const k = Math.floor(rel / CYC);
  const tt = rel - k * CYC;
  const vis = f >= fRun0 && tt <= TC;
  const rx = X0 + V * tt;
  const rOp = clamp01(Math.min(tt / 0.25, (TC - tt) / 0.25));

  const stage1 = 1 - ip(f, [fRecap - 12, fRecap + 2], [0, 1]);
  const stageIn = ip(f, [c12, c12 + 22], [0, 1]);

  // ghosts for an exposure window
  const ghosts = (kk: number, t0: number, D: number, w0: number) =>
    Array.from({ length: NG }).map((_, j) => {
      const tg = t0 + (j * D) / (NG - 1);
      return { x: X0 + V * tg, t: tg + kk * CYC, on: f >= w0 + (j * D * FPS) / (NG - 1) };
    });
  const gL = ghosts(kL, TL0, DL, wL0);
  const gS = ghosts(kS, TS0, DS, wS0);
  const showL = f < fSharp + 10;
  const showS = f >= wS0 - 4 && f < fSharp + 18;

  // exposure bar (maps one crossing)
  const modeS = f >= cycStart(kS) - 12;
  const bx0 = 80, bx1 = 1100;
  const bx = (t: number) => bx0 + (t / TC) * (bx1 - bx0);
  const wStart = modeS ? TS0 : TL0, wDur = modeS ? DS : DL;
  const barOn = f >= (modeS ? cycStart(kS) - 12 : cycStart(kL) - 6);
  const activeWin = modeS ? f >= wS0 && f <= wS0 + DS * FPS + 3 : f >= wL0 && f <= wL0 + DL * FPS;
  const wW = Math.max(10, bx(wStart + wDur) - bx(wStart));

  const photoA = ip(f, [fBlur - 4, fBlur + 18], [0, 1]);
  const photoB = ip(f, [fSharp - 2, fSharp + 18], [0, 1]);

  // recap stage
  const rOpen = 0.65 + 0.35 * Math.sin(f / 22);
  const tr = Math.max(0, f - fTimeW) % 90;
  const sp1 = ip(tr, [8, 22], [0, 1]);
  const sp2 = ip(tr, [48, 62], [0, 1]);

  return (
    <AbsoluteFill>
      <div style={{ opacity: stage1 }}>
        {/* running stage */}
        <Card x={70} y={170} w={1200} h={560} delay={c12} border={theme.colors.line}>
          <svg width={1200} height={560}>
            <line x1={60} x2={1140} y1={GROUND} y2={GROUND} stroke={theme.colors.line} strokeWidth={4} />
            {Array.from({ length: 22 }).map((_, i) => (
              <line key={i} x1={80 + i * 50} x2={96 + i * 50} y1={GROUND + 34} y2={GROUND + 34} stroke={theme.colors.line} strokeWidth={4} strokeLinecap="round" />
            ))}
            {showL && gL.map((g, i) => g.on && (
              <Runner key={`l${i}`} x={g.x} y={GROUND} s={SCALE} t={g.t} color={theme.colors.accent} opacity={0.32} />
            ))}
            {showS && gS.map((g, i) => g.on && i % 5 === 0 && (
              <Runner key={`s${i}`} x={g.x} y={GROUND} s={SCALE} t={g.t} color={theme.colors.signal} opacity={0.45} />
            ))}
            {vis && <Runner x={rx} y={GROUND} s={SCALE} t={rel} color={theme.colors.text} opacity={rOp} />}
          </svg>
        </Card>

        {/* exposure bar */}
        <Card x={70} y={760} w={1200} h={190} delay={c12 + 6} border={theme.colors.line}>
          <div style={{ position: "absolute", left: 40, top: 22 }}>
            <Chip text={modeS ? "খুব কম সময়" : "বেশি সময়"} tone={modeS ? "signal" : "accent"} size={40} delay={0} />
          </div>
          <svg width={1200} height={190} style={{ opacity: barOn ? 1 : 0.0 }}>
            <rect x={bx0} y={118} width={bx1 - bx0} height={26} rx={13} fill={theme.colors.bgAlt} stroke={theme.colors.line} strokeWidth={3} />
            <rect x={bx(wStart)} y={118} width={wW} height={26} rx={13} fill={modeS ? theme.colors.signal : theme.colors.accent} opacity={activeWin ? 1 : 0.55} />
            {vis && <circle cx={bx(tt)} cy={131} r={14} fill={theme.colors.text} />}
          </svg>
        </Card>

        {/* photo frames */}
        <Card x={1310} y={170} w={540} h={340} delay={fBlur - 8} border={theme.colors.accent} style={{ opacity: photoA }}>
          <svg width={540} height={340}>
            <PhotoBg w={540} h={340} />
            <defs>
              <filter id="blurA"><feGaussianBlur stdDeviation="2.4" /></filter>
            </defs>
            <g filter="url(#blurA)">
              {gL.map((g, i) => (
                <Runner key={i} x={fx(g.x)} y={fy(GROUND)} s={SCALE * FK} t={g.t} color={theme.colors.accent} opacity={0.34} />
              ))}
            </g>
          </svg>
          <div style={{ position: "absolute", left: 20, top: 16 }}>
            <Chip text="ঝাপসা" tone="accent" size={36} delay={fBlur} />
          </div>
        </Card>
        <Card x={1310} y={560} w={540} h={340} delay={fSharp - 8} border={theme.colors.signal} style={{ opacity: photoB }}>
          <svg width={540} height={340}>
            <PhotoBg w={540} h={340} />
            {gS.filter((_, i) => i === Math.floor(NG / 2)).map((g, i) => (
              <Runner key={i} x={fx(g.x)} y={fy(GROUND)} s={SCALE * FK} t={g.t} color={theme.colors.text} opacity={1} />
            ))}
          </svg>
          <div style={{ position: "absolute", left: 20, top: 16 }}>
            <Chip text="স্পষ্ট" tone="signal" size={36} delay={fSharp} />
          </div>
        </Card>
      </div>

      {/* recap */}
      <Card x={230} y={210} w={690} h={700} delay={fAmount - 6} border={theme.colors.primary}>
        <div style={{ position: "absolute", left: 0, right: 0, top: 60, display: "flex", justifyContent: "center" }}>
          <Iris size={390} open={rOpen} glow={0.85} highlight uid="rc" />
        </div>
        <div style={{ position: "absolute", left: 0, right: 0, top: 450, display: "flex", justifyContent: "center", fontFamily: theme.fonts.display, fontWeight: 700, fontSize: 88, color: theme.colors.primarySoft }}>Aperture</div>
        <div style={{ position: "absolute", left: 0, right: 0, top: 590, display: "flex", justifyContent: "center" }}>
          <Chip text="আলো প্রবেশের পরিমাণ" tone="primary" size={42} delay={fAmount + 6} />
        </div>
      </Card>
      <Card x={1000} y={210} w={690} h={700} delay={fShutterW - 6} border={theme.colors.accent}>
        <div style={{ position: "absolute", left: 95, top: 110 }}>
          <ShutterFront w={500} h={310} p1={sp1} p2={sp2} uid="rc" />
        </div>
        <div style={{ position: "absolute", left: 0, right: 0, top: 450, display: "flex", justifyContent: "center", fontFamily: theme.fonts.display, fontWeight: 700, fontSize: 88, color: theme.colors.accent }}>Shutter</div>
        <div style={{ position: "absolute", left: 0, right: 0, top: 590, display: "flex", justifyContent: "center" }}>
          <Chip text="কতক্ষণ আলো সংগ্রহ" tone="accent" size={42} delay={fTimeW} />
        </div>
      </Card>

      <Sfx name="pop" at={c12 + 2} />
      <Sfx name="click" at={wL0 - 2} />
      <Sfx name="pop" at={fBlur - 8} rate={0.94} />
      <Sfx name="click" at={wS0 - 2} rate={1.12} />
      <Sfx name="pop" at={fSharp - 8} rate={1.08} />
      <Sfx name="whoosh" at={fRecap - 10} vol={0.8} />
      <Sfx name="chime" at={fAmount} />
      <Sfx name="chime" at={fShutterW} rate={1.12} />
    </AbsoluteFill>
  );
};
