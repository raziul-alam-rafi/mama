import React from "react";
import { Audio, Sequence, interpolate, staticFile, useVideoConfig } from "remotion";
import { SFX } from "./timeline";
import { cues, MUSIC_FILE, MUSIC_BASE_VOLUME, MUSIC_DUCKED_VOLUME, VOICEOVER_FILE } from "../config";

/** Music volume as a function of time: ducked while narration is spoken, smooth 0.35 s ramps. */
const musicVolume = (t: number, total: number) => {
  let duck = 0;
  for (const c of cues.cues) {
    const d = interpolate(t, [c.start - 0.35, c.start, c.end, c.end + 0.35], [0, 1, 1, 0], {
      extrapolateLeft: "clamp", extrapolateRight: "clamp",
    });
    duck = Math.max(duck, d);
  }
  const base = MUSIC_BASE_VOLUME + (MUSIC_DUCKED_VOLUME - MUSIC_BASE_VOLUME) * duck;
  const fade = interpolate(t, [0, 1.5, total - 1.5, total], [0, 1, 1, 0], {
    extrapolateLeft: "clamp", extrapolateRight: "clamp",
  });
  return base * fade;
};

export const AudioTrack: React.FC = () => {
  const { fps, durationInFrames } = useVideoConfig();
  const total = durationInFrames / fps;
  return (
    <>
      {VOICEOVER_FILE ? <Audio src={staticFile(VOICEOVER_FILE)} volume={1} /> : null}
      <Audio src={staticFile(MUSIC_FILE)} volume={(f) => musicVolume(f / fps, total)} />
      {SFX.map((s, i) => {
        const from = Math.max(0, Math.round(s.at * fps));
        const dur = Math.max(1, Math.round(s.duration * fps));
        const fi = (s.fadeIn ?? 0.01) * fps, fo = (s.fadeOut ?? 0.04) * fps;
        return (
          <Sequence key={i} from={from} durationInFrames={dur} layout="none">
            <Audio
              src={staticFile(s.file)}
              volume={(f) => s.volume * interpolate(f, [0, fi, dur - fo, dur], [0, 1, 1, 0], {
                extrapolateLeft: "clamp", extrapolateRight: "clamp",
              })}
            />
          </Sequence>
        );
      })}
    </>
  );
};
