export type SceneProps = {
  dur: number; // scene length (frames)
  cs: number; // cue start (local frame)
  cd: number; // cue duration (frames)
};
export const makeQ = (cs: number, cd: number) => (f: number) =>
  Math.round(cs + f * cd);
