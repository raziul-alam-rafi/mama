import React from "react";
import { AbsoluteFill, useCurrentFrame } from "remotion";
import { theme, alpha } from "../theme";
import { Draw, Glass, Pop, SceneShell, WordReveal, ease } from "../components/ui";
import { Iris } from "../components/Cutaway";
import { at } from "../timing";
import type { Sfx } from "../sfx";

const K = 5;
const T = theme.colors;
const TW = 500;
const TH = 230;
const NAMES = ["Lens", "Aperture", "Sensor", "Processor", "Display"];
const POS = [
  [170, 270],
  [710, 270],
  [1250, 270],
  [440, 540],
  [980, 540],
];

// cue ৮-এ পাঁচ আইটেম সমান ব্যবধানে; cue ৯-এ সমাপ্তি
const TILE = [0.04, 0.22, 0.4, 0.58, 0.76].map((v) => at(K, 8, v));
const BANNER = at(K, 8, 0.9);
const OUT = at(K, 9, 0.3);
const FIN = at(K, 9, 0.44);

export const sfx: Sfx[] = [
  { f: 4, s: "pop", v: 0.26 },
  ...TILE.map((t, i): Sfx => ({ f: t + 12, s: "click", r: 0.96 + i * 0.04 })),
  { f: BANNER, s: "pop", v: 0.26, r: 1.1 },
  { f: OUT, s: "whoosh", v: 0.2 },
  { f: FIN + 10, s: "chime", v: 0.3 },
];

const Glyph: React.FC<{ i: number }> = ({ i }) => {
  const s = { stroke: T.text, strokeWidth: 3, fill: "none", strokeLinejoin: "round" as const };
  return (
    <svg width={104} height={104} viewBox="0 0 100 100" style={{ flexShrink: 0 }}>
      {i === 0 && (
        <>
          <path d="M50 12 Q78 50 50 88 Q22 50 50 12 Z" {...s} fill={alpha(T.hero, 0.25)} />
          <path d="M4 36 H34 M4 50 H28 M4 64 H34" stroke={T.accent} strokeWidth={3} strokeLinecap="round" />
        </>
      )}
      {i === 2 && (
        <>
          {Array.from({ length: 16 }, (_, n) => (
            <rect key={n} x={14 + (n % 4) * 18} y={14 + Math.floor(n / 4) * 18} width={14} height={14} rx={2} fill={alpha(T.hero, 0.25 + ((n * 7) % 5) * 0.15)} stroke={T.line} />
          ))}
        </>
      )}
      {i === 3 && (
        <>
          <rect x={22} y={22} width={56} height={56} rx={8} {...s} fill={alpha(T.panel, 0.9)} />
          <rect x={36} y={36} width={28} height={28} rx={3} stroke={T.hero} strokeWidth={3} fill={alpha(T.hero, 0.3)} />
          {[32, 50, 68].map((p) => (
            <path key={p} d={`M${p} 10 V22 M${p} 78 V90 M10 ${p} H22 M78 ${p} H90`} stroke={T.line} strokeWidth={3} />
          ))}
        </>
      )}
      {i === 4 && (
        <>
          <rect x={10} y={20} width={80} height={52} rx={6} {...s} fill={alpha(T.hero, 0.18)} />
          <path d="M20 62 L40 42 L54 56 L64 48 L80 62 Z" fill={alpha(T.text, 0.55)} />
          <path d="M38 82 H62" stroke={T.line} strokeWidth={4} strokeLinecap="round" />
        </>
      )}
    </svg>
  );
};

const Check: React.FC<{ p: number }> = ({ p }) => (
  <svg width={80} height={80} viewBox="-40 -40 80 80" style={{ flexShrink: 0 }}>
    <circle r={30} fill={alpha(T.hero, 0.18 * p)} stroke={p > 0 ? T.hero : T.lineSoft} strokeWidth={3.5} />
    <Draw d="M-14 2 L-4 13 L15 -10" p={p} stroke={T.text} w={6} />
  </svg>
);

export const Outro: React.FC = () => {
  const f = useCurrentFrame();
  const tilesOut = ease(f, [OUT, OUT + 10], [1, 0], theme.ease.in);
  const irisOpen = ease(f, [FIN, FIN + 36], [0, 1], theme.ease.out);
  const irisRot = ease(f, [FIN, FIN + 44], [0, 60], theme.ease.out);
  return (
    <SceneShell>
      {/* সম্পূর্ণ মেকানিজম — রিক্যাপ গ্রিড */}
      <div style={{ opacity: tilesOut, transform: `translateY(${(1 - tilesOut) * -30}px)` }}>
        <AbsoluteFill style={{ alignItems: "center", paddingTop: 62 }}>
          <WordReveal text="সম্পূর্ণ মেকানিজম" size={96} hi={[1]} glow delay={4} per={5} />
        </AbsoluteFill>
        {NAMES.map((n, i) => {
          const d = TILE[i];
          const tick = ease(f, [d + 12, d + 24], [0, 1]);
          return (
            <div key={n} style={{ position: "absolute", left: POS[i][0], top: POS[i][1] }}>
              <Pop delay={d} y={44}>
                <Glass style={{ width: TW, height: TH, display: "flex", alignItems: "center", justifyContent: "space-between", padding: "0 30px" }}>
                  <div style={{ display: "flex", alignItems: "center", columnGap: 22 }}>
                    {i === 1 ? <Iris size={104} open={0.55} /> : <Glyph i={i} />}
                    <span style={{ fontSize: 50, fontWeight: 700, lineHeight: 1.4, letterSpacing: 0, color: T.text }}>{n}</span>
                  </div>
                  <Check p={tick} />
                </Glass>
              </Pop>
            </div>
          );
        })}
        <div style={{ position: "absolute", top: 830, width: "100%", display: "flex", justifyContent: "center" }}>
          <WordReveal text="পানির মতো পরিষ্কার" size={84} hi={[2]} hiColor={T.hero} glow delay={BANNER} per={5} />
        </div>
      </div>

      {/* সমাপ্তি: আইরিস খুলছে + "চলুন শুরু করা যাক" */}
      {f >= FIN - 4 && (
        <AbsoluteFill style={{ alignItems: "center" }}>
          <div style={{ marginTop: 150 }}>
            <Pop delay={FIN - 2} y={30} from={0.8} cfg={theme.spring.bouncy}>
              <div style={{ filter: `drop-shadow(0 0 ${Math.round(36 * irisOpen)}px ${T.glowHero})` }}>
                <Iris size={400} open={irisOpen} rot={irisRot} />
              </div>
            </Pop>
          </div>
          <div style={{ marginTop: 40 }}>
            <WordReveal text="চলুন শুরু করা যাক" size={132} hi={[1]} glow delay={FIN + 8} per={5} />
          </div>
        </AbsoluteFill>
      )}
    </SceneShell>
  );
};
