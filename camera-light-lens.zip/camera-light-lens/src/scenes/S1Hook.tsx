// সিন ১ — হুক (Kinetic Typography + লেন্স ভিজ্যুয়াল) · cue 1–2
import React from "react";
import { AbsoluteFill, interpolate, useCurrentFrame } from "remotion";
import { Beam, RayLayer } from "../components/Rays";
import { CrossIcon, CubeIcon, LensFront } from "../components/Icons";
import { Breathe, Chip, Enter, Strike, Words, useExit, usePop, useProgress } from "../components/Primitives";
import { Sfx } from "../components/audio";
import { at } from "../timeline";
import { theme } from "../theme";

const c = theme.colors;
const SI = 0;
const LENS = { x: 1350, y: 560, size: 620 };
const CUBE = { x: 1745, y: 200, size: 140 };
// লেন্স-কিনারা থেকে কিউব পর্যন্ত দৃষ্টিরেখা (ইউনিট-ভেক্টর থেকে হিসাব)
const dx = CUBE.x - LENS.x, dy = CUBE.y - LENS.y, dl = Math.hypot(dx, dy);
const ux = dx / dl, uy = dy / dl;
const SIGHT_A = [LENS.x + ux * (LENS.size / 2 + 8), LENS.y + uy * (LENS.size / 2 + 8)] as const;
const SIGHT_B = [CUBE.x - ux * (CUBE.size * 0.62), CUBE.y - uy * (CUBE.size * 0.62)] as const;
const SIGHT_MID = [(SIGHT_A[0] + SIGHT_B[0]) / 2, (SIGHT_A[1] + SIGHT_B[1]) / 2] as const;

export const S1Hook: React.FC = () => {
  const frame = useCurrentFrame();
  // --- সময় (সবই SRT থেকে) ---
  const tCamera = at(SI, 1, "Camera");
  const tObject = at(SI, 1, "বস্তুকে");
  const tStrike = at(SI, 1, "সরাসরি");
  const tOnly = at(SI, 2, "শুধুমাত্র");
  const tLight = at(SI, 2, "আলো");
  const tEye = at(SI, 2, "চোখের");
  // বিট A "পায় না"-র পর, "আমাদের চোখের মতো…" শুরুর আগে বেরিয়ে যায়
  const exitA = tEye - theme.timing.exit - 2;

  const lens = usePop(0, theme.spring.bouncy);
  const cube = usePop(tObject, theme.spring.snappy);
  const cubeExit = useExit(exitA);
  const sight = useProgress(tObject + 4, 18, theme.ease.inOut);
  const cross = useProgress(tStrike, 12);
  const sightExit = useExit(exitA);
  const lightGlow = usePop(tLight, theme.spring.bouncy);

  // আলোর রশ্মি — ডান দিক থেকে লেন্সে ঢোকে
  const ys = [130, 260, 390, 520, 650, 780, 910];
  const rays = ys.map((y0, i) => {
    const p = useProgress(tOnly + i * theme.timing.stagger, 26, theme.ease.out);
    return { p, from: [1990, y0] as const, to: [LENS.x + 30, LENS.y + (y0 - LENS.y) * 0.1] as const };
  });

  return (
    <AbsoluteFill>
      {/* স্তর: রশ্মি (লেন্সের নিচে) */}
      <RayLayer>
        {rays.map((r, i) => (
          <Beam key={i} id={`s1-ray-${i}`} pts={[r.from, r.to]} p={r.p} width={5} />
        ))}
        {/* "বস্তু"-র দিকে দেখার ডটেড লাইন — ক্রস দিয়ে কাটা */}
        <line
          x1={SIGHT_A[0]} y1={SIGHT_A[1]} x2={SIGHT_B[0]} y2={SIGHT_B[1]}
          stroke={c.textDim} strokeWidth={4} strokeDasharray="4 16" strokeLinecap="round"
          opacity={sight * (1 - sightExit)}
          pathLength={1}
        />
      </RayLayer>

      {/* লেন্স */}
      <div style={{ position: "absolute", left: LENS.x - LENS.size / 2, top: LENS.y - LENS.size / 2 }}>
        <div style={{ opacity: Math.min(1, lens), transform: `scale(${interpolate(lens, [0, 1], [0.6, 1])}) rotate(${interpolate(lens, [0, 1], [-40, 0])}deg)` }}>
          <Breathe amp={1.2}>
            <LensFront size={LENS.size} uid="s1" />
          </Breathe>
        </div>
      </div>

      {/* কিউব = "বস্তু" */}
      <div style={{ position: "absolute", left: CUBE.x - CUBE.size / 2, top: CUBE.y - CUBE.size / 2, opacity: Math.min(1, cube) * (1 - cubeExit), transform: `scale(${interpolate(cube, [0, 1], [0.6, 1]) * (1 - cubeExit * 0.1)})` }}>
        <Breathe amp={1.4} phase={1}>
          <CubeIcon size={CUBE.size} />
        </Breathe>
      </div>
      <div
        style={{
          position: "absolute", left: SIGHT_MID[0] - 40, top: SIGHT_MID[1] - 40,
          opacity: cross * (1 - sightExit), transform: `scale(${interpolate(cross, [0, 1], [0.5, 1])})`,
        }}
      >
        <CrossIcon size={80} p={cross} />
      </div>

      {/* বাঁ দিক — বিট A */}
      <div style={{ position: "absolute", left: theme.margin, top: 0, bottom: 0, width: 1000, display: "flex", flexDirection: "column", justifyContent: "center", gap: 30 }}>
        <Enter delay={0} exitAt={exitA} y={30}>
          <Chip text="প্রথমেই বুঝে নেওয়া যাক" size={38} tone="primary" />
        </Enter>
        <Words text="Camera" delay={tCamera} size={176} exitAt={exitA} wordStyle={() => ({ letterSpacing: 0 })} />
        <div style={{ display: "flex", alignItems: "center", columnGap: 40 }}>
          <Enter delay={tObject} exitAt={exitA} preset={theme.spring.snappy} y={34}>
            <div style={{ fontFamily: theme.fonts.display, fontWeight: theme.weight.heavy, fontSize: 132, lineHeight: 1.22, color: c.text, letterSpacing: 0 }}>
              <Strike delay={tStrike}>বস্তু</Strike>
            </div>
          </Enter>
          <Words text="দেখে না" delay={tObject + theme.timing.word} size={132} exitAt={exitA} />
        </div>
      </div>

      {/* বাঁ দিক — বিট B */}
      <div style={{ position: "absolute", left: theme.margin, top: 0, bottom: 0, width: 1000, display: "flex", flexDirection: "column", justifyContent: "center", gap: 18 }}>
        <Enter delay={tEye} y={26}>
          <Chip text="চোখের মতো ক্যামেরাও" size={38} tone="accent" />
        </Enter>
        <Words text="দেখে শুধু" delay={tOnly} size={124} color={c.textDim} />
        <Enter delay={tLight} preset={theme.spring.bouncy} y={50} scaleFrom={0.8}>
          <div style={{ filter: `drop-shadow(0 0 ${40 * lightGlow}px ${c.accentGlow})` }}>
            <div
              style={{
                fontFamily: theme.fonts.display, fontWeight: theme.weight.heavy, fontSize: 270, lineHeight: 1.2, letterSpacing: 0,
                backgroundImage: `linear-gradient(100deg, ${c.white}, ${c.accent} 70%)`, WebkitBackgroundClip: "text", backgroundClip: "text", color: "transparent",
                display: "inline-block",
              }}
            >
              আলো
            </div>
          </div>
        </Enter>
      </div>

      {/* সাউন্ড */}
      <Sfx name="thud" at={2} />
      <Sfx name="whoosh-soft" at={tCamera - 2} />
      <Sfx name="pop" at={tObject - 2} n={1} />
      <Sfx name="click" at={tStrike} />
      <Sfx name="whoosh-soft" at={tOnly - 2} n={2} />
      <Sfx name="chime" at={tLight - 2} />
      <Sfx name="pop" at={tEye - 2} n={2} />
    </AbsoluteFill>
  );
};
