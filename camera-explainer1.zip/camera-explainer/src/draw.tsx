// Small SVG/ray helpers shared by all scenes.
import React from "react";
import { interpolate } from "remotion";
import { theme } from "./theme";

export type Pt = { x: number; y: number };

export const clamp01 = (v: number) => Math.max(0, Math.min(1, v));
export const prog = (frame: number, start: number, dur: number, ease: (t: number) => number = theme.ease.out) =>
  interpolate(frame, [start, start + dur], [0, 1], { easing: ease, extrapolateLeft: "clamp", extrapolateRight: "clamp" });

const segLens = (pts: Pt[]) => pts.slice(1).map((p, i) => Math.hypot(p.x - pts[i].x, p.y - pts[i].y));
export const pathD = (pts: Pt[]) => pts.map((p, i) => `${i ? "L" : "M"}${p.x.toFixed(1)} ${p.y.toFixed(1)}`).join(" ");

/** polyline slice between normalized lengths s0..s1 */
export const slicePath = (pts: Pt[], s0: number, s1: number): Pt[] => {
  const lens = segLens(pts);
  const total = lens.reduce((a, b) => a + b, 0);
  const a = clamp01(s0) * total, b = clamp01(s1) * total;
  const out: Pt[] = [];
  let acc = 0;
  for (let i = 0; i < lens.length; i++) {
    const l0 = acc, l1 = acc + lens[i];
    acc = l1;
    if (l1 < a || l0 > b) continue;
    const at = (d: number): Pt => {
      const t = lens[i] === 0 ? 0 : (d - l0) / lens[i];
      return { x: pts[i].x + (pts[i + 1].x - pts[i].x) * t, y: pts[i].y + (pts[i + 1].y - pts[i].y) * t };
    };
    if (!out.length) out.push(at(Math.max(a, l0)));
    out.push(at(Math.min(b, l1)));
  }
  return out;
};

/** Light ray: draws progressively (p 0..1) and carries travelling light packets (pulse). */
export const Ray: React.FC<{
  pts: Pt[]; p: number; frame: number; pulses?: number; speed?: number; phase?: number;
  width?: number; opacity?: number; color?: string; packet?: boolean;
}> = ({ pts, p, frame, pulses = 2, speed = 0.011, phase = 0, width = 3, opacity = 0.55, color = theme.colors.accent, packet = true }) => {
  if (p <= 0.001) return null;
  const shown = slicePath(pts, 0, p);
  if (shown.length < 2) return null;
  return (
    <g>
      <path d={pathD(shown)} fill="none" stroke={color} strokeWidth={width} strokeLinecap="round" strokeLinejoin="round" opacity={opacity} />
      {packet && p > 0.98 &&
        Array.from({ length: pulses }).map((_, k) => {
          const s = (((frame * speed + phase + k / pulses) % 1) + 1) % 1;
          const seg = slicePath(pts, s - 0.1, s);
          if (seg.length < 2) return null;
          return <path key={k} d={pathD(seg)} fill="none" stroke={color} strokeWidth={width * 1.9} strokeLinecap="round" strokeLinejoin="round" opacity={0.95} style={{ filter: `drop-shadow(0 0 5px ${theme.colors.rayGlow})` }} />;
        })}
    </g>
  );
};

/** Paraxial thin-lens ray trace (screen coords, y down). lenses sorted by x. */
export type ThinLens = { x: number; f: number; ya: number };
export const traceThin = (start: Pt, slope: number, lenses: ThinLens[], endX: number): Pt[] => {
  const pts: Pt[] = [{ ...start }];
  let x = start.x, y = start.y, m = slope;
  for (const L of lenses) {
    if (L.x <= x) continue;
    y += m * (L.x - x); x = L.x;
    pts.push({ x, y });
    m = m - (y - L.ya) / L.f;
  }
  pts.push({ x: endX, y: y + m * (endX - x) });
  return pts;
};

/** back focal plane position (paraxial) for parallel input along the axis */
export const backFocus = (lenses: ThinLens[], ya: number): number => {
  const h = 40; let y = ya + h, m = 0, x = lenses[0].x;
  for (const L of lenses) { y += m * (L.x - x); x = L.x; m = m - (y - L.ya) / L.f; }
  return x + (-(y - ya) / m);
};
