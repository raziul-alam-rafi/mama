import React from 'react';
import {AbsoluteFill, Sequence, useCurrentFrame, useVideoConfig} from 'remotion';
import {ThreeCanvas} from '@remotion/three';
import {theme} from '../theme';
import {apertureRadius} from '../timeline';
import {passFraction} from '../three/optics';
import {CameraRig} from '../three/CameraRig';
import {IrisBlades} from '../three/IrisBlades';
import {LensBarrel} from '../three/LensBarrel';
import {LightBeam} from '../three/LightBeam';
import {SensorPlate} from '../three/SensorPlate';
import {BgMesh, Grade, Grain, Vignette} from '../components/Overlays';
import {Caption} from '../components/Caption';
import {SfxTrack} from '../components/SfxTrack';

export const ApertureProto: React.FC = () => {
  const frame = useCurrentFrame();
  const {fps, width, height} = useVideoConfig();
  const t = frame / fps;
  const r = apertureRadius(t);
  const s = (sec: number) => Math.round(sec * fps);

  return (
    <AbsoluteFill style={{backgroundColor: theme.colors.bg}}>
      <BgMesh />
      <ThreeCanvas width={width} height={height} camera={{fov: 38, near: 0.1, far: 100, position: [-12, 1.6, 0]}}>
        <CameraRig />
        <ambientLight intensity={0.7} />
        <directionalLight position={[-6, 8, -4]} intensity={1.6} />
        <directionalLight position={[6, 2, 6]} intensity={0.6} color={theme.colors.primary} />
        <LensBarrel />
        <IrisBlades radius={r} />
        <LightBeam radius={r} t={t} />
        <SensorPlate fraction={passFraction(r)} />
      </ThreeCanvas>
      <Sequence from={s(0.5)} durationInFrames={s(2.5)}><Caption title="Aperture" sub="Wide open" /></Sequence>
      <Sequence from={s(3)} durationInFrames={s(5)}><Caption title="Smaller opening" sub="Less light reaches the sensor" /></Sequence>
      <Sequence from={s(8)} durationInFrames={s(7)}><Caption title="Wider opening" sub="More light reaches the sensor" /></Sequence>
      <Grade />
      <Grain />
      <Vignette />
      <SfxTrack />
    </AbsoluteFill>
  );
};
