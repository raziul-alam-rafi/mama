import React from "react";
import { Audio, Sequence, staticFile } from "remotion";

export type SfxName = "pop" | "click" | "tick" | "whoosh" | "chime" | "thud";

// restrained levels (0.2–0.35) so the voice-over is never covered
const BASE: Record<SfxName, number> = { pop: 0.3, click: 0.3, tick: 0.2, whoosh: 0.28, chime: 0.28, thud: 0.3 };

/** plays a short sound at scene-local frame `at` (2–3 frames before the visual lands) */
export const Sfx: React.FC<{ name: SfxName; at: number; vol?: number; rate?: number }> = ({ name, at, vol = 1, rate = 1 }) => {
  if (at < 0) return null;
  return (
    <Sequence from={Math.round(at)} layout="none">
      <Audio src={staticFile(`sfx/${name}.wav`)} volume={Math.min(0.35, BASE[name] * vol)} playbackRate={rate} />
    </Sequence>
  );
};
