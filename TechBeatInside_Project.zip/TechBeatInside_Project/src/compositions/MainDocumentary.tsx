import React from 'react';
import {AbsoluteFill, useVideoConfig} from 'remotion';
import {ThreeCanvas} from '@remotion/three';
import * as THREE from 'three';
import {COLORS, LIGHT} from '../config/theme';
import {Captions} from '../components/Captions';
import {Dip, ExplainerTag, Grade, PreviewAudio} from '../components/Overlays';
import {World} from '../scenes/World';

export const MainDocumentary: React.FC = () => {
  const {width, height} = useVideoConfig();
  return (
    <AbsoluteFill style={{background: COLORS.ink}}>
      <ThreeCanvas
        width={width}
        height={height}
        camera={{fov: 40, near: 0.1, far: 2300, position: [201.9, 1.55, 3.0]}}
        gl={{
          antialias: true,
          toneMapping: THREE.ACESFilmicToneMapping,
          toneMappingExposure: LIGHT.exposure,
        }}
      >
        <World />
      </ThreeCanvas>
      <Grade />
      <ExplainerTag />
      <Captions />
      <Dip />
      <PreviewAudio />
    </AbsoluteFill>
  );
};
