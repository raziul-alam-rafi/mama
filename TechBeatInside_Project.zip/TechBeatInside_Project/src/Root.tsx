import React from 'react';
import {Composition} from 'remotion';
import {FPS, HEIGHT, WIDTH} from './config/theme';
import {MainDocumentary} from './compositions/MainDocumentary';
import {TOTAL_FRAMES} from './subtitles/subtitles';

export const RemotionRoot: React.FC = () => (
  <Composition
    id="Main"
    component={MainDocumentary}
    durationInFrames={TOTAL_FRAMES}
    fps={FPS}
    width={WIDTH}
    height={HEIGHT}
  />
);
