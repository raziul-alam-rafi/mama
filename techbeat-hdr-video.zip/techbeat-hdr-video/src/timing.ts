// সময়ের একমাত্র উৎস: SRT (src/script.ts)। হাতে বসানো কোনো সময় নেই।
import { CUES } from "./script";

export const FPS = 30;
export const WIDTH = 1920;
export const HEIGHT = 1080;
/** ভিজ্যুয়াল সংশ্লিষ্ট কথার এত ফ্রেম আগে ঢোকে (৪–৬) */
export const LEAD = 5;
/** সিনের মাঝে ক্রসফেডের জন্য ওভারল্যাপ */
export const OVERLAP = 10;

export const toFrame = (s: number) => Math.round(s * FPS);
export const cueStart = (n: number) => toFrame(CUES[n - 1].start);
export const cueEnd = (n: number) => toFrame(CUES[n - 1].end);
export const TOTAL_FRAMES = Math.ceil(CUES[CUES.length - 1].end * FPS);

/** cue-র ভেতরে কোনো বাক্যাংশ কখন শুরু — অক্ষর-অনুপাতে অনুমান (cue-র সীমা SRT-র) */
export const at = (n: number, phrase: string) => {
  const c = CUES[n - 1];
  const i = c.text.indexOf(phrase);
  if (i < 0) throw new Error(`cue ${n}-এ "${phrase}" পাওয়া যায়নি`);
  return toFrame(c.start + (i / c.text.length) * (c.end - c.start));
};

// সিনের সীমা = cue-র সীমা (LEAD ফ্রেম আগে)
const cueBoundaries = [3, 5, 7, 8, 9, 10, 11, 13, 14];
export const BOUNDS: number[] = [0, ...cueBoundaries.map((n) => cueStart(n) - LEAD), TOTAL_FRAMES];
export const SCENE_COUNT = BOUNDS.length - 1;

/** সিনের লোকাল ফ্রেমে ভিজ্যুয়াল-ঢোকার সময় (কথার LEAD আগে) */
export const makeT = (idx: number) => (n: number, phrase?: string) =>
  (phrase ? at(n, phrase) : cueStart(n)) - LEAD - BOUNDS[idx];
