import React from "react";
import { AbsoluteFill } from "remotion";
import { theme } from "../theme";
import { useScene } from "../SceneContext";
import { Chip, ip, keys, mono, WordReveal, Entrance } from "../components/Motion";
import { LensCutaway, lensPx } from "../components/LensCutaway";
import { G, irisHalf } from "../components/optics";
import { Sfx } from "../components/Sfx";

// Scene 2 · Aperture definition (cues 2–3): exploded lens assembles, iris highlighted, light path is limited by the opening.
export const ApertureDef: React.FC = () => {
  const S = useScene();
  const f = S.frame;
  const c2 = Math.max(S.cue(2), 0);
  const W = 1640, LEFT = 140, TOP = 300;

  const parts = ip(f, [c2 + 2, c2 + 22], [0, 1]);
  const explode = ip(f, [c2 + 16, c2 + 70], [1, 0]);
  const fIris = S.word(2, "ব্যবস্থা");
  const fRay = S.word(2, "আলো");
  const fWay = S.word(3, "আকার");
  const fSmall = S.word(3, "ছোট");
  const fBig = S.word(3, "বড়");
  const prog = ip(f, [fRay, fRay + 54], [0, 1], theme.ease.soft);
  const [k0, k1, k2, k3, k4] = mono([c2, S.cue(3) + 10, fSmall, fBig + 6, S.cueEnd(3) - 12], 6);
  const open = keys(f, [k0, k1, k2, k3, k4], [0.72, 0.72, 0.1, 1.0, 0.62]);
  const measure = ip(f, [fWay, fWay + 14], [0, 1]);
  const hi = f >= fIris;

  const irisTop = lensPx(G.XI, -208, W);
  const barrel = lensPx(60, -208, W);

  return (
    <AbsoluteFill>
      <div style={{ position: "absolute", left: 140, top: 96 }}>
        <WordReveal text="Aperture" delay={c2 + 2} per={5} size={112} color={theme.colors.primarySoft} />
      </div>
      <div style={{ position: "absolute", left: LEFT, top: TOP }}>
        <LensCutaway width={W} open={open} prog={prog} explode={explode} parts={parts} highlightIris={hi} measure={measure} uid="ap" />
        <div style={{ position: "absolute", left: barrel.x, top: barrel.y - 74 }}>
          <Chip text="লেন্সের ভেতরে" tone="dim" delay={c2 + 52} />
        </div>
        <div style={{ position: "absolute", left: irisTop.x - 120, top: irisTop.y - 78 }}>
          <Chip text="Aperture" tone="accent" delay={fIris} />
        </div>
        <div style={{ position: "absolute", left: irisTop.x - 150, top: lensPx(0, 262, W).y + 14, opacity: measure }}>
          <Chip text="আলো যাওয়ার পথ" tone="accent" size={40} delay={fWay} />
        </div>
      </div>
      <Sfx name="pop" at={c2 + 18} />
      <Sfx name="chime" at={fIris + 1} />
      <Sfx name="whoosh" at={fRay - 4} vol={0.8} />
      <Sfx name="click" at={fSmall + 2} />
      <Sfx name="click" at={fBig + 2} rate={1.08} />
    </AbsoluteFill>
  );
};
