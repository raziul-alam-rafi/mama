# Techbeat 3D Aperture (Windows / macOS / Linux)

Remotion + Three.js + React Three Fiber. সব স্ক্রিপ্ট Node.js-এ লেখা, তাই Windows CMD-তে `bash` লাগে না।

## ⚠️ বর্তমান অবস্থা (সততার সাথে)
- **Linux-এ যাচাই হয়েছে:** SRT parsing, SFX/music তৈরি, `master` (আসল ffmpeg), স্ক্রিপ্টগুলোর যুক্তি (নকল `npx` দিয়ে)।
- **Windows-এ এখনও চালানো হয়নি** (আমার কাছে Windows নেই)। এবং Remotion/Three.js-এর আসল render কোথাও যাচাই হয়নি।
  প্রথম রানে error এলে লেখাটা (বা `out\glprobe_*.log`) পাঠান।

## ০. আগে যা লাগবে
- **Node.js 18 বা নতুন (LTS)**: https://nodejs.org থেকে নামান। CMD-তে দেখুন: `node -v`
- ইন্টারনেট (প্রথমবার package ও Chrome নামাতে)
- (ঐচ্ছিক, শুধু `master`-এর জন্য) ffmpeg: `winget install Gyan.FFmpeg`, তারপর CMD বন্ধ করে নতুন করে খুলুন

## ১. ফাইল খোলা (Windows 10/11-এ `tar` বিল্ট-ইন)
ছোট পথে রাখুন (যেমন `C:\work`), লম্বা পথে Windows-এ সমস্যা হয়:
```cmd
cd C:\work
tar -xzf Techbeat-3D-Aperture-Windows.tar.gz
cd Techbeat-3D-Aperture
```

## ২. ইনস্টল
```cmd
npm run setup
```

## ৩. WebGL পরীক্ষা (একবার)
```cmd
npm run gl-check
```
প্রতিটি GL backend-এর জন্য `OK` বা `FAIL` লাইন দেখাবে, প্রথম যেটা চলে সেটা `.glmode` ফাইলে সেভ হবে।
পরের সব কমান্ড ওটা নিজে ব্যবহার করবে।

## ৪. মূল ফ্রেম দেখা (ভিডিওর আগে ছবি দেখুন)
```cmd
npm run stills
```
`out\check_*.png` ছবিগুলো খুলে দেখুন।

## ৫. টেস্ট রেন্ডার (প্রথম ৩ সেকেন্ড, দ্রুত)
```cmd
npm run render:test -- --frames=0-89
```
ফলাফল: `out\aperture_raw.mp4`

## ৬. সম্পূর্ণ রেন্ডার (১৮.৮ সেকেন্ড, ৫৬৪ ফ্রেম)
```cmd
npm run render:test
```
ধীর বা মেমরি কম হলে: `npm run render:test -- --concurrency=1`

## ৭. Loudness (-14 LUFS), ঐচ্ছিক
```cmd
npm run master
```
ফলাফল: `out\aperture_final.mp4`

## অন্যান্য কমান্ড
| কমান্ড | কাজ |
|---|---|
| `npm run studio` | ব্রাউজারে preview |
| `npm run prepare:srt` | SRT → `src\data\cues.json` |
| `npm run sfx` | SFX/music আবার তৈরি |
| `npm run validate` | প্রয়োজনীয় ফাইল আছে কিনা |

## Voiceover
SRT শুধু সময়ের তথ্য। আপনার রেকর্ডিং `public\voiceover.mp3`-এ রেখে `src\config.ts`-এ
`VOICEOVER_FILE = "voiceover.mp3"` দিন। Music প্রতিটি cue-র সময় আপনা-আপনি নিচে নামে।

## সময় ঠিক করা
SRT-এ ৩টি বড় cue; ভেতরের দৃশ্যের মুহূর্ত অনুমান। শুধু `src\scenes\aperture\timeline.ts` বদলান।

## সমস্যা হলে
- `gl-check`-এ সব `FAIL`: `out\glprobe_*.log` সব পাঠান, সাথে `npx remotion versions`।
- `npm run setup` ব্যর্থ: ইন্টারনেট/proxy দেখুন, error লেখাটা পাঠান।
- `master`-এ "ffmpeg not found": ওপরের winget কমান্ড, অথবা এই ধাপ বাদ দিন (`aperture_raw.mp4` সঠিক ভিডিও)।
