import React from 'react';
import {AbsoluteFill, Audio, getRemotionEnvironment, getStaticFiles, interpolate, staticFile, useCurrentFrame} from 'remotion';
import {COLORS, PLAY_VOICEOVER_IN_RENDER, SHOW_EXPLAINER_TAGS, VOICEOVER_FILE} from '../config/theme';
import {ANCHORS, shotAt} from '../three/cameras/shots';
import {BN_FONT} from './Fonts';

/** Vignette + gentle film grain (seeded by frame => deterministic). */
export const Grade: React.FC = () => {
  const frame = useCurrentFrame();
  return (
    <AbsoluteFill style={{pointerEvents: 'none'}}>
      <AbsoluteFill
        style={{background: 'radial-gradient(ellipse at center, rgba(0,0,0,0) 55%, rgba(0,0,0,0.5) 100%)'}}
      />
      <svg width="100%" height="100%" style={{position: 'absolute', inset: 0, opacity: 0.06, mixBlendMode: 'overlay'}}>
        <filter id="grain">
          <feTurbulence type="fractalNoise" baseFrequency="0.9" numOctaves="2" seed={frame % 64} stitchTiles="stitch" />
        </filter>
        <rect width="100%" height="100%" filter="url(#grain)" />
      </svg>
    </AbsoluteFill>
  );
};

/** Short dip-to-black that hides the one hard cut (living room -> stadium). */
export const Dip: React.FC = () => {
  const frame = useCurrentFrame();
  const cut = ANCHORS.B;
  const a = interpolate(frame, [cut - 5, cut, cut + 6], [0, 1, 0], {
    extrapolateLeft: 'clamp',
    extrapolateRight: 'clamp',
  });
  return <AbsoluteFill style={{background: COLORS.ink, opacity: a, pointerEvents: 'none'}} />;
};

/** Marks non-physical overlays so viewers can tell explanation from reality. */
export const ExplainerTag: React.FC = () => {
  const frame = useCurrentFrame();
  if (!SHOW_EXPLAINER_TAGS) return null;
  const id = shotAt(frame).id;
  const text =
    id === 'D'
      ? 'ব্যাখ্যামূলক চিত্র — ছবি → বৈদ্যুতিক সংকেত'
      : id === 'E' || id === 'F'
        ? 'ব্যাখ্যামূলক চিত্র — সংকেত ও রেডিও তরঙ্গ (চোখে দেখা যায় না)'
        : null;
  if (!text) return null;
  return (
    <div
      style={{
        position: 'absolute',
        left: 56,
        top: 48,
        fontFamily: BN_FONT,
        fontWeight: 500,
        fontSize: 28,
        letterSpacing: 0,
        color: COLORS.tag,
        background: 'rgba(5,12,20,0.55)',
        border: `1px solid ${COLORS.signal}55`,
        padding: '6px 18px 9px',
        borderRadius: 999,
      }}
    >
      {text}
    </div>
  );
};

/** Plays public/audio/voiceover.mp3 if it exists; silently skipped otherwise. */
export const PreviewAudio: React.FC = () => {
  const isRendering = getRemotionEnvironment().isRendering;
  if (isRendering && !PLAY_VOICEOVER_IN_RENDER) return null;
  let exists = false;
  try {
    exists = getStaticFiles().some((f) => f.name === VOICEOVER_FILE);
  } catch {
    exists = false;
  }
  return exists ? <Audio src={staticFile(VOICEOVER_FILE)} /> : null;
};
