import React, { useEffect, useState } from "react";
import { Audio, continueRender, delayRender, getRemotionEnvironment, staticFile } from "remotion";
import { theme } from "../theme";

/** Plays public/voiceover.mp3 if it exists. Flags in theme.flags: previewVoiceover (Studio), renderVoiceover (MP4 render, default OFF). */
export const PreviewAudio: React.FC = () => {
  const env = getRemotionEnvironment();
  const wanted = env.isRendering ? theme.flags.renderVoiceover : theme.flags.previewVoiceover;
  const [ok, setOk] = useState(false);
  const [handle] = useState(() => (wanted ? delayRender("voiceover check") : null));
  useEffect(() => {
    if (!wanted || handle === null) return;
    let alive = true;
    fetch(staticFile("voiceover.mp3"), { method: "HEAD" })
      .then((r) => { const t = r.headers.get("content-type") ?? ""; if (alive) setOk(r.ok && /audio|mpeg|octet/i.test(t)); })
      .catch(() => undefined)
      .finally(() => continueRender(handle));
    return () => { alive = false; };
  }, [wanted, handle]);
  if (!wanted || !ok) return null;
  return <Audio src={staticFile("voiceover.mp3")} volume={1} />;
};
