// make-sfx.mjs — ক্লিন UI/মোশন-গ্রাফিক্স SFX সিন্থেসাইজ (কোনো ডাউনলোড নেই, সম্পূর্ণ ডিটারমিনিস্টিক)
// চালানো: node scripts/make-sfx.mjs   →  public/sfx/*.wav
import fs from "node:fs";
import path from "node:path";
import { fileURLToPath } from "node:url";

const SR = 44100;
const OUT = path.join(path.dirname(fileURLToPath(import.meta.url)), "..", "public", "sfx");
fs.mkdirSync(OUT, { recursive: true });

// ---------- helpers ----------
let seed = 1337;
const rnd = () => {
  seed = (seed * 1664525 + 1013904223) >>> 0;
  return seed / 0xffffffff * 2 - 1;
};
const buf = (sec) => new Float32Array(Math.ceil(sec * SR));

// RBJ biquad (per-sample retunable)
function biquad(type, f, q) {
  const w = (2 * Math.PI * f) / SR, cw = Math.cos(w), sw = Math.sin(w), al = sw / (2 * q);
  let b0, b1, b2, a0 = 1 + al, a1 = -2 * cw, a2 = 1 - al;
  if (type === "lp") { b0 = (1 - cw) / 2; b1 = 1 - cw; b2 = (1 - cw) / 2; }
  else if (type === "hp") { b0 = (1 + cw) / 2; b1 = -(1 + cw); b2 = (1 + cw) / 2; }
  else { b0 = al; b1 = 0; b2 = -al; } // bp (constant 0 dB peak)
  return { b0: b0 / a0, b1: b1 / a0, b2: b2 / a0, a1: a1 / a0, a2: a2 / a0 };
}
function filterSweep(x, type, fAt, q) {
  const y = new Float32Array(x.length);
  let x1 = 0, x2 = 0, y1 = 0, y2 = 0, c = biquad(type, fAt(0), q);
  for (let i = 0; i < x.length; i++) {
    if (i % 32 === 0) c = biquad(type, fAt(i / x.length), q);
    const o = c.b0 * x[i] + c.b1 * x1 + c.b2 * x2 - c.a1 * y1 - c.a2 * y2;
    x2 = x1; x1 = x[i]; y2 = y1; y1 = o; y[i] = o;
  }
  return y;
}
const lp = (x, f, q = 0.707) => filterSweep(x, "lp", () => f, q);
const hp = (x, f, q = 0.707) => filterSweep(x, "hp", () => f, q);

// খুব ছোট reverb (Schroeder: 4 comb + 2 allpass), wet কম
function tinyVerb(x, wet = 0.1, tail = 0.12) {
  const out = new Float32Array(x.length + Math.ceil(tail * SR));
  const src = new Float32Array(out.length); src.set(x);
  const combs = [0.0297, 0.0371, 0.0411, 0.0437].map((s) => Math.round(s * SR));
  const acc = new Float32Array(out.length);
  for (const d of combs) {
    const line = new Float32Array(out.length);
    for (let i = 0; i < out.length; i++) {
      line[i] = src[i] + (i >= d ? line[i - d] * 0.55 : 0);
      acc[i] += line[i] / combs.length;
    }
  }
  for (const d of [Math.round(0.005 * SR), Math.round(0.0017 * SR)]) {
    const ap = new Float32Array(out.length);
    for (let i = 0; i < out.length; i++) {
      const xd = i >= d ? acc[i - d] : 0, yd = i >= d ? ap[i - d] : 0;
      ap[i] = -0.5 * acc[i] + xd + 0.5 * yd;
    }
    acc.set(ap);
  }
  for (let i = 0; i < out.length; i++) out[i] = src[i] + acc[i] * wet;
  return out;
}
// নরম attack + দ্রুত decay envelope
const env = (t, atk, tau) => Math.min(1, t / atk) * Math.exp(-Math.max(0, t - atk) / tau);
// শেষ ২০ms-এ fade-out যাতে টানা কাট/ক্লিক না হয়
function endFade(x, ms = 20) {
  const n = Math.min(x.length, Math.round((ms / 1000) * SR));
  for (let i = 0; i < n; i++) x[x.length - 1 - i] *= i / n;
  return x;
}

// ---------- sounds ----------
function pop() {
  const x = buf(0.22); let ph = 0;
  for (let i = 0; i < x.length; i++) {
    const t = i / SR, f = 190 + 560 * Math.exp(-t / 0.022); // দ্রুত নিচে নামা pitch
    ph += (2 * Math.PI * f) / SR;
    x[i] = (Math.sin(ph) + 0.18 * Math.sin(2 * ph)) * env(t, 0.004, 0.05);
  }
  return tinyVerb(lp(x, 4200), 0.08);
}
function click() {
  const x = buf(0.1);
  for (let i = 0; i < x.length; i++) x[i] = rnd() * env(i / SR, 0.0008, 0.011);
  const body = hp(x, 2400, 0.8);
  // ছোট টোনাল "টিক"
  for (let i = 0; i < body.length; i++) body[i] += 0.25 * Math.sin(2 * Math.PI * 2100 * (i / SR)) * env(i / SR, 0.0008, 0.008);
  return tinyVerb(lp(body, 9000), 0.06, 0.08);
}
function whooshCore(sec, f0, f1, q, peakAt = 0.45) {
  const n = buf(sec);
  for (let i = 0; i < n.length; i++) n[i] = rnd();
  const swept = filterSweep(n, "bp", (u) => f0 * Math.pow(f1 / f0, u), q);
  for (let i = 0; i < swept.length; i++) {
    const u = i / swept.length;
    const fade = u < peakAt ? Math.pow(Math.sin((u / peakAt) * Math.PI / 2), 2) : Math.pow(Math.cos(((u - peakAt) / (1 - peakAt)) * Math.PI / 2), 2);
    swept[i] *= fade;
  }
  return endFade(swept, 25);
}
const whoosh = () => tinyVerb(lp(whooshCore(0.6, 380, 3400, 1.1), 7500), 0.1);
const whooshSoft = () => tinyVerb(lp(whooshCore(0.38, 700, 2300, 1.3, 0.4), 6500), 0.08);
function chime() {
  const x = buf(0.36);
  const partials = [[1, 1, 0.2], [2.01, 0.34, 0.13], [2.76, 0.16, 0.08], [4.07, 0.07, 0.05]];
  for (let i = 0; i < x.length; i++) {
    const t = i / SR; let s = 0;
    for (const [r, a, tau] of partials) s += a * Math.sin(2 * Math.PI * 988 * r * t) * env(t, 0.004, tau);
    x[i] = s;
  }
  return tinyVerb(lp(endFade(x, 40), 7000), 0.14, 0.1);
}
function thud() {
  const x = buf(0.32); let ph = 0;
  for (let i = 0; i < x.length; i++) {
    const t = i / SR, f = 48 + 40 * Math.exp(-t / 0.05);
    ph += (2 * Math.PI * f) / SR;
    x[i] = Math.sin(ph) * env(t, 0.009, 0.085);
  }
  return lp(endFade(x, 40), 320);
}

// ---------- normalize: সব সাউন্ড একই RMS স্তরে, peak সীমিত ----------
const TARGET_RMS = 0.1, PEAK_MAX = 0.85;
function normalize(x) {
  let sum = 0, cnt = 0, peak = 0;
  for (const v of x) { peak = Math.max(peak, Math.abs(v)); }
  const gate = peak * 0.05;
  for (const v of x) if (Math.abs(v) > gate) { sum += v * v; cnt++; }
  let g = TARGET_RMS / Math.sqrt(sum / Math.max(1, cnt));
  if (peak * g > PEAK_MAX) g = PEAK_MAX / peak;
  return x.map((v) => v * g);
}
function writeWav(name, x) {
  const data = Buffer.alloc(x.length * 2);
  for (let i = 0; i < x.length; i++) data.writeInt16LE(Math.max(-32767, Math.min(32767, Math.round(x[i] * 32767))), i * 2);
  const h = Buffer.alloc(44);
  h.write("RIFF", 0); h.writeUInt32LE(36 + data.length, 4); h.write("WAVE", 8); h.write("fmt ", 12);
  h.writeUInt32LE(16, 16); h.writeUInt16LE(1, 20); h.writeUInt16LE(1, 22); h.writeUInt32LE(SR, 24);
  h.writeUInt32LE(SR * 2, 28); h.writeUInt16LE(2, 32); h.writeUInt16LE(16, 34); h.write("data", 36); h.writeUInt32LE(data.length, 40);
  fs.writeFileSync(path.join(OUT, name + ".wav"), Buffer.concat([h, data]));
}

const kit = { pop, click, whoosh, "whoosh-soft": whooshSoft, chime, thud };
for (const [name, fn] of Object.entries(kit)) {
  seed = 1337 + name.length * 17;
  writeWav(name, normalize(fn()));
  console.log("wrote", name);
}
