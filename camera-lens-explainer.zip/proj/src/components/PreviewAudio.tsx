import React from "react";
import {Audio, getRemotionEnvironment, getStaticFiles, staticFile} from "remotion";
import {VOICEOVER_IN_RENDER, VOICEOVER_PREVIEW_ON} from "../config";

/** Plays public/voiceover.mp3 in Studio when the file exists; silently skipped otherwise. Off in renders by default. */
export const PreviewAudio: React.FC = () => {
  if (!VOICEOVER_PREVIEW_ON) return null;
  let rendering = false;
  try {
    rendering = getRemotionEnvironment().isRendering;
  } catch {
    rendering = false;
  }
  if (rendering && !VOICEOVER_IN_RENDER) return null;
  let exists = false;
  try {
    exists = getStaticFiles().some((f) => f.name === "voiceover.mp3");
  } catch {
    exists = false;
  }
  if (!exists) return null;
  return <Audio src={staticFile("voiceover.mp3")} />;
};
