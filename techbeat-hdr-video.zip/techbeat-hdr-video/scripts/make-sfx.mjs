// পরিষ্কার UI-ধাঁচের SFX সিন্থেসাইজ (সব নির্ধারিত/ডিটারমিনিস্টিক): pop, click, whoosh, chime, thud
// চালান: node scripts/make-sfx.mjs  → public/sfx/*.wav (44.1kHz, 16-bit, মনো)
import fs from "node:fs";
const SR = 44100;
const out = new URL("../public/sfx/", import.meta.url);
fs.mkdirSync(out, { recursive: true });

let seed = 1234567;
const rnd = () => ((seed = (seed * 1664525 + 1013904223) >>> 0) / 4294967296) * 2 - 1;

const lowpass = (x, fc) => { const a = Math.exp(-2 * Math.PI * fc / SR); let y = 0; return x.map((v) => (y = (1 - a) * v + a * y)); };
const highpass = (x, fc) => { const lp = lowpass(x, fc); return x.map((v, i) => v - lp[i]); };
const bandpassSweep = (x, f0, f1) => { // সুইপিং ব্যান্ডপাস (state-variable)
  let low = 0, band = 0; const q = 0.35;
  return x.map((v, i) => {
    const f = f0 * Math.pow(f1 / f0, i / x.length);
    const g = 2 * Math.sin(Math.PI * f / SR);
    low += g * band; const high = v - low - q * band; band += g * high; return band;
  });
};
const env = (n, a, d) => Array.from({ length: n }, (_, i) => { const t = i / SR; return Math.min(1, t / a) * Math.exp(-t / d); });
const reverb = (x, amt = 0.12) => { // খুব ছোট রিভার্ব
  const y = x.slice(); for (const [ms, g] of [[19, 0.5], [31, 0.35], [47, 0.25]]) { const d = Math.floor(ms * SR / 1000); for (let i = d; i < y.length; i++) y[i] += x[i - d] * g * amt * 3; } return y;
};
const fade = (x, ms = 8) => { const n = Math.floor(ms * SR / 1000); return x.map((v, i) => v * Math.min(1, i / n, (x.length - i) / n)); };
const norm = (x, peak = 0.6) => { const m = Math.max(...x.map(Math.abs)); return x.map((v) => (v / m) * peak); };
const write = (name, x) => {
  const buf = Buffer.alloc(44 + x.length * 2);
  buf.write("RIFF", 0); buf.writeUInt32LE(36 + x.length * 2, 4); buf.write("WAVEfmt ", 8); buf.writeUInt32LE(16, 16); buf.writeUInt16LE(1, 20); buf.writeUInt16LE(1, 22);
  buf.writeUInt32LE(SR, 24); buf.writeUInt32LE(SR * 2, 28); buf.writeUInt16LE(2, 32); buf.writeUInt16LE(16, 34); buf.write("data", 36); buf.writeUInt32LE(x.length * 2, 40);
  x.forEach((v, i) => buf.writeInt16LE(Math.round(Math.max(-1, Math.min(1, v)) * 32767), 44 + i * 2));
  fs.writeFileSync(new URL(name, out), buf);
};

// pop: দ্রুত নিচে নামা pitch-সহ sine + ছোট envelope (~0.18s)
{ const n = Math.floor(0.2 * SR), e = env(n, 0.004, 0.045); let ph = 0;
  const x = e.map((v, i) => { const t = i / SR; const f = 180 + 520 * Math.exp(-t / 0.025); ph += 2 * Math.PI * f / SR; return Math.sin(ph) * v; });
  write("pop.wav", fade(norm(reverb(lowpass(x, 3800), 0.08)))); }
// click: high-pass করা ছোট noise burst (~0.07s)
{ const n = Math.floor(0.09 * SR), e = env(n, 0.0008, 0.011);
  const x = highpass(Array.from({ length: n }, () => rnd()), 1800).map((v, i) => v * e[i]);
  write("click.wav", fade(norm(lowpass(x, 7000), 0.55), 3)); }
// whoosh: band-pass noise sweep, fade in/out (~0.6s)
{ const n = Math.floor(0.6 * SR);
  const noise = Array.from({ length: n }, () => rnd());
  const sw = bandpassSweep(noise, 350, 3200).map((v, i) => { const t = i / n; return v * Math.sin(Math.PI * Math.pow(t, 0.8)) ; });
  write("whoosh.wav", fade(norm(reverb(lowpass(sw, 5000), 0.06), 0.55), 20)); }
// chime: নরম ওভারটোনসহ ছোট decay (~0.5s)
{ const n = Math.floor(0.5 * SR), e = env(n, 0.006, 0.11);
  const parts = [[880, 1], [1318.5, 0.45], [1760, 0.22], [2637, 0.1]];
  const x = Array.from({ length: n }, (_, i) => { const t = i / SR; return parts.reduce((s, [f, a]) => s + a * Math.sin(2 * Math.PI * f * t) * Math.exp(-t * f / 900), 0) * e[i]; });
  write("chime.wav", fade(norm(reverb(lowpass(x, 5200), 0.12)), 10)); }
// thud: খুব হালকা সফট থাড (সংযত, ~0.3s)
{ const n = Math.floor(0.32 * SR), e = env(n, 0.006, 0.07); let ph = 0;
  const x = e.map((v, i) => { const t = i / SR; const f = 48 + 70 * Math.exp(-t / 0.04); ph += 2 * Math.PI * f / SR; return Math.sin(ph) * v; });
  write("thud.wav", fade(norm(lowpass(x, 420), 0.6), 12)); }
console.log("SFX তৈরি");
