// Scene 1 (cue 1) — HOOK. "Digital Processing" + the sensor's pixel wells holding charge.
import React from "react";
import { AbsoluteFill } from "remotion";
import { theme } from "../theme";
import { T } from "../timing";
import { clamp, hash, prog, progIO } from "../util";
import { rawLuma } from "../sceneImage";
import { Defs } from "../components/Defs";
import { Words } from "../components/Words";
import { useClock, popAt } from "../components/clock";

export const COLS = 8;
export const ROWS = 4;
export const wellLevel = (col: number, row: number) => {
  const l = rawLuma((col + 0.5) / COLS, (row + 0.5) / ROWS, 0.9 / COLS, 0.9 / ROWS);
  return clamp(0.14 + (clamp((l - 0.08) / 0.5)) * 0.8, 0.12, 0.95);
};

/** One pixel well: a glass "bucket" with amber charge inside. fill 0..1 multiplies the level. */
export const Well: React.FC<{ x: number; y: number; size: number; level: number; fill: number; idx: number; f: number; pop?: number; ring?: number }> = ({ x, y, size, level, fill, idx, f, pop = 1, ring = 0 }) => {
  const c = theme.colors;
  const pad = size * 0.1;
  const innerW = size - pad * 2;
  const innerH = size - pad * 2;
  const h = innerH * level * fill;
  const n = Math.round(level * 5) + 2;
  return (
    <g transform={`translate(${x + size / 2} ${y + size / 2}) scale(${0.6 + 0.4 * pop}) translate(${-size / 2} ${-size / 2})`} opacity={Math.min(1, pop * 1.5)}>
      <rect width={size} height={size} rx={size * 0.15} fill="url(#gPanel)" stroke={ring > 0 ? c.primary : c.line} strokeWidth={ring > 0 ? 4 : 2} />
      <rect x={pad} y={pad} width={innerW} height={innerH} rx={size * 0.09} fill={c.bg} opacity={0.75} />
      {h > 1 && (
        <>
          <rect x={pad} y={pad + innerH - h} width={innerW} height={h} rx={size * 0.07} fill="url(#gAmber)" opacity={0.92} />
          <rect x={pad} y={pad + innerH - h} width={innerW} height={Math.min(4, h)} rx={2} fill="#FFE2A8" opacity={0.85} />
        </>
      )}
      {fill > 0.35 &&
        Array.from({ length: n }).map((_, k) => {
          const px = pad + 5 + hash(idx * 17 + k * 3.3) * (innerW - 10);
          const py0 = pad + innerH - 6 - hash(idx * 7 + k * 5.1) * Math.max(4, h - 10);
          const py = py0 + Math.sin(f / 9 + k * 2 + idx) * 2.5;
          return <circle key={k} cx={px} cy={py} r={size * 0.04} fill="#FFF1CF" opacity={0.9 * clamp((fill - 0.35) * 3)} />;
        })}
      <rect width={size} height={size} rx={size * 0.15} fill="url(#gSheen)" />
    </g>
  );
};

export const Scene1: React.FC = () => {
  const { f, fps, at, dur } = useClock();
  const c = theme.colors;
  const CELL = 112, GAP = 14;
  const gw = COLS * CELL + (COLS - 1) * GAP;
  const gh = ROWS * CELL + (ROWS - 1) * GAP;
  const gx = 960 - gw / 2;
  const gy = 640 - gh / 2;

  const tTitle = at(T("Digital"), 6);
  const tFill = at(T("সেন্সরে"), 4);
  const tCharge = at(T("চার্জের"), 6);
  const tOut = at(T("প্রথমে"), 4);
  const push = 1 + 0.035 * progIO(f, 0, dur);
  const float = Math.sin(f / 30) * 3;
  const busP = prog(f, tOut, tOut + 24, theme.ease.inOut);
  const labelP = popAt(f, fps, at(T("সেন্সরে"), 10), theme.spring.smooth);
  const chargeP = popAt(f, fps, tCharge, theme.spring.bouncy);

  return (
    <AbsoluteFill style={{ transform: `scale(${push})` }}>
      <svg width="1920" height="1080" style={{ position: "absolute", inset: 0 }}>
        <Defs />
        <g transform={`translate(0 ${float})`}>
          {/* sensor slab behind the wells */}
          <rect x={gx - 34} y={gy - 34} width={gw + 68} height={gh + 68} rx={34} fill={c.bgAlt} stroke={c.line} strokeWidth={3} opacity={0.9 * prog(f, 0, 16)} filter="url(#fShadow)" />
          {Array.from({ length: ROWS * COLS }).map((_, i) => {
            const col = i % COLS, row = Math.floor(i / COLS);
            const delay = (col + row) * 2;
            const pop = popAt(f, fps, 3 + delay, theme.spring.snappy);
            const fill = prog(f, tFill + (col + row) * 3, tFill + (col + row) * 3 + 46, theme.ease.out);
            return <Well key={i} idx={i} x={gx + col * (CELL + GAP)} y={gy + row * (CELL + GAP)} size={CELL} level={wellLevel(col, row)} fill={fill} f={f} pop={pop} />;
          })}
          {/* tags */}
          <g transform={`translate(${gx} ${gy - 78}) scale(${0.9 + 0.1 * labelP})`} opacity={labelP}>
            <rect width={188} height={46} rx={23} fill={c.panel} stroke={c.line} strokeWidth={2} />
            <circle cx={26} cy={23} r={7} fill={c.primary} />
            <text x={46} y={31} fontFamily={theme.fonts.main} fontWeight={600} fontSize={26} fill={c.text}>সেন্সর · Pixel</text>
          </g>
          <g transform={`translate(${gx + gw - 196} ${gy - 78}) scale(${0.9 + 0.1 * chargeP})`} opacity={chargeP}>
            <rect width={196} height={46} rx={23} fill={c.panel} stroke={c.accent} strokeWidth={2} />
            <circle cx={26} cy={23} r={8} fill={c.accent} filter="url(#fGlow)" />
            <text x={46} y={31} fontFamily={theme.fonts.main} fontWeight={600} fontSize={26} fill={c.text}>জমা চার্জ</text>
          </g>
          {/* readout hint: a data line leaves the sensor to the right */}
          <g opacity={busP}>
            <line x1={gx + gw + 40} x2={gx + gw + 40 + 380 * busP} y1={gy + gh / 2} y2={gy + gh / 2} stroke={c.accent} strokeWidth={6} strokeLinecap="round" strokeDasharray="4 16" filter="url(#fGlow)" />
            <path d={`M${gx + gw + 40 + 380 * busP} ${gy + gh / 2 - 16} l22 16 l-22 16`} fill="none" stroke={c.accent} strokeWidth={6} strokeLinecap="round" strokeLinejoin="round" />
          </g>
        </g>
      </svg>
      <div style={{ position: "absolute", left: 0, right: 0, top: 128 }}>
        <Words text="Digital Processing" start={tTitle} per={6} size={150} gradientWords={[1]} exitAt={tOut + 2} />
      </div>
    </AbsoluteFill>
  );
};
