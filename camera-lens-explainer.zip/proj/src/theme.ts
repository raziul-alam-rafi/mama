// theme.ts — single source of truth: colors, fonts, easings, springs, SFX levels.
// Colour scheme: "Midnight Optics" (user-selected #1).
import {Easing} from "remotion";
import {loadFont} from "@remotion/google-fonts/HindSiliguri";

// Hind Siliguri: clean Bengali conjuncts; bundled through @remotion/google-fonts.
const {fontFamily} = loadFont("normal", {
  weights: ["500", "700"],
  subsets: ["bengali", "latin", "latin-ext"],
});

export const theme = {
  colors: {
    bg: "#0B1220",
    bgAlt: "#101A2E",
    panel: "#16233A",
    panelEdge: "#2A3E5E",
    hero: "#4FC3F7", // light rays (the hero of this video)
    accent: "#FFB547", // focus point, sensor, highlights
    text: "#EAF2FF",
    textDim: "#8FA3BF",
    glow: "rgba(79, 195, 247, 0.45)",
    accentGlow: "rgba(255, 181, 71, 0.40)",
    // scene art (the apple / tree of the narration)
    apple: "#E5484D",
    appleDark: "#A82A33",
    leaf: "#3FB67A",
    leafDark: "#23805A",
    trunk: "#8B6B4A",
    glassFill: "rgba(79, 195, 247, 0.14)",
    glassEdge: "rgba(180, 230, 255, 0.85)",
    housing: "#0E1A30",
  },
  fonts: {display: fontFamily, body: fontFamily},
  weight: {heavy: 700, normal: 500},
  radius: 28,
  shadow: "0 30px 70px -20px rgba(0,0,0,0.65)",
  stroke: {thin: 2, base: 3, bold: 5},
  ease: {
    out: Easing.bezier(0.16, 1, 0.3, 1), // entrances
    inOut: Easing.bezier(0.83, 0, 0.17, 1), // moves
    in: Easing.bezier(0.7, 0, 0.84, 0), // exits only
    soft: Easing.bezier(0.45, 0, 0.2, 1), // mechanical movement
  },
  spring: {
    snappy: {damping: 14, stiffness: 160, mass: 0.6},
    smooth: {damping: 20, stiffness: 90, mass: 1},
    bouncy: {damping: 11, stiffness: 170, mass: 0.7},
  },
  // Restrained SFX levels (0.2–0.35); VO is never covered.
  sfx: {pop: 0.26, click: 0.34, whoosh: 0.24, chime: 0.28, thud: 0.22},
} as const;

export type SfxName = keyof typeof theme.sfx;
