export type SfxKind = "pop" | "click" | "whoosh" | "chime" | "thud";
/** frame = সিনের লোকাল ফ্রেম (ভিজ্যুয়াল নামার ফ্রেম); Main এটা ৩ ফ্রেম আগে বাজায় */
export type SfxEvent = { kind: SfxKind; frame: number; vol?: number; rate?: number };

export const SFX_FILE: Record<SfxKind, string> = {
  pop: "sfx/pop.wav", click: "sfx/click.wav", whoosh: "sfx/whoosh.wav", chime: "sfx/chime.wav", thud: "sfx/thud.wav",
};
/** সংযত বেস ভলিউম (০.২–০.৩৫); ভয়েসওভার ঢাকে না */
export const SFX_VOL: Record<SfxKind, number> = { pop: 0.3, click: 0.28, whoosh: 0.24, chime: 0.26, thud: 0.22 };
export const SFX_EARLY = 3;
