# Sources actually consulted (web search, Nov 2026)

Only the pages below were read. Nothing else is claimed as "researched".

## Broadcast chain (studio -> transmitter -> antenna -> receiver)
- Airchain / transmission chain — https://en.wikipedia.org/wiki/Airchain
  (signal path from cameras through processing to transmitter, feedline and antenna)
- Basic television system lecture (Daffodil Intl. Univ.) — https://elearn.daffodilvarsity.edu.bd/mod/resource/view.php?id=55986
  (transmitter-side entities have receiver-side counterparts; signal voltage follows brightness)
- Television transmitter & receiver unit notes — https://coursecontent.indusuni.ac.in/wp-content/uploads/sites/8/2020/03/Unit-1-6.pdf
  (scanning, sync/blanking, composite video; image source -> transmitter -> antenna -> receiver)
- Broadcasting study guide (air-chain steps) — https://www.remnote.com/learn/arts-and-humanities/performing-arts-and-media/cultural-studies/broadcasting/broadcasting-study-guide

## Yagi-Uda rooftop TV antenna
- https://en.wikipedia.org/wiki/Yagi%E2%80%93Uda_antenna (driven element, one reflector, directors; folded dipole for 300 ohm twin-lead; rooftop TV use)
- https://www.tutorialspoint.com/antenna_theory/yagi_uda_antenna_theory.htm (spacing table: reflector-dipole 0.35 lambda, dipole-director 0.125 lambda, director-director 0.2 lambda)
- https://www.electronics-notes.com/articles/antennas-propagation/yagi-uda-antenna-aerial/basics-overview.php (reflector ~5% longer than driven element; directors shorter)
- https://hackaday.com/2017/05/24/on-point-the-yagi-antenna (TV antennas often swept-back elements; element lengths 10-15% off ideal half-wave)
- https://rfessentials.com/resources/rf-glossary/yagi/ (TV antennas typically 10-15 elements)

## NOT researched (honest gaps)
- No reference photographs were collected (the sandbox could not download images).
- Studio camera, CRT cabinet, transmitter mast, stadium and house are generic, plausible designs built from
  general knowledge — NOT copies of a verified specific model. See technical-notes.md.
- No 3D assets / textures were downloaded; everything is procedural (no licensing issues, but not photoreal).
