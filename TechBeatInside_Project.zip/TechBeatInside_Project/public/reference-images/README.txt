Place reference-images assets here. See research/sources.md for licensing rules.
