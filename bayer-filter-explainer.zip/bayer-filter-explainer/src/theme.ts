// theme.ts - single source of truth. No hex colours / easings / springs in components.
import {Easing} from "remotion";
import {fontFamily} from "./fonts";

export const theme = {
  colors: {
    bg: "#0B1020",
    bgAlt: "#131C3A",
    surface: "#1A2447",
    surfaceHi: "#2A3A74",
    well: "#0D1430",
    line: "#3A4A86",
    hero: "#4F8CFF", // hero blue - UI emphasis
    amber: "#FFB84D", // accent
    text: "#F4F7FF",
    textDim: "#A3AED3",
    // colour-channel semantics (scientific, not decorative)
    red: "#FF5D6C",
    green: "#3FE08A",
    blue: "#3A6BFF",
    sample: "#B26BFF", // an example "full colour" used only in the before/after scene
    glow: "rgba(79,140,255,0.45)",
    amberGlow: "rgba(255,184,77,0.5)",
    card: "rgba(26,36,71,0.82)",
    cardLine: "rgba(255,255,255,0.14)",
    shadow: "rgba(0,0,0,0.45)",
  },
  fonts: {
    display: `${fontFamily}, "Noto Sans Bengali", "Hind Siliguri", sans-serif`,
  },
  radius: {card: 28, tile: 12, chip: 999},
  ease: {
    out: Easing.bezier(0.16, 1, 0.3, 1),
    inOut: Easing.bezier(0.83, 0, 0.17, 1),
    in: Easing.bezier(0.7, 0, 0.84, 0),
  },
  spring: {
    snappy: {damping: 14, stiffness: 160, mass: 0.6},
    smooth: {damping: 20, stiffness: 90, mass: 1},
    bouncy: {damping: 11, stiffness: 170, mass: 0.7},
    drop: {damping: 16, stiffness: 130, mass: 0.7},
  },
  size: {title: 76, label: 44, small: 36},
} as const;

export type Channel = "R" | "G" | "B";
export const chColor: Record<Channel, string> = {
  R: theme.colors.red,
  G: theme.colors.green,
  B: theme.colors.blue,
};
export const chName: Record<Channel, string> = {R: "লাল", G: "সবুজ", B: "নীল"};
// Standard RGGB colour filter array
export const bayerAt = (row: number, col: number): Channel =>
  row % 2 === 0 ? (col % 2 === 0 ? "R" : "G") : col % 2 === 0 ? "G" : "B";
