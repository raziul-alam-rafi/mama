import { run, readGlMode, mkdirOut, extraArgs } from "./lib.mjs";

const gl = readGlMode();
console.log("Using --gl=" + gl);
mkdirOut();
for (const f of [10, 45, 90, 140, 215, 260, 300, 345, 400, 470, 540]) {
  const r = run(`npx remotion still src/index.ts ApertureExplainer out/check_${f}.png --frame=${f} --gl=${gl} --timeout=120000 --overwrite ${extraArgs()}`);
  if (r.status !== 0) { console.error(`Still for frame ${f} failed (exit ${r.status}).`); process.exit(r.status); }
}
console.log("Stills in out/check_*.png");
