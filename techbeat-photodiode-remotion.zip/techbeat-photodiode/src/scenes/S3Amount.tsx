import React from "react";
import { useCurrentFrame, useVideoConfig } from "remotion";
import { theme } from "../theme";
import { FullSvg, P, SceneShell, Sfx, Tag, Title, Win, bnNumber, hash, lerp, sp } from "../fx";
import { Photon, PixelWell } from "../parts";
import { sceneTimes } from "../timeline";
import { cueEnd, cueStart, wordFrame } from "../srt";

const C = theme.colors;
const T0 = sceneTimes[2].from;
const t6 = cueStart(6) - T0;
const tGrid = wordFrame(6, "এক কোটি", 8) - T0;
const tEnd = cueEnd(6) - T0;

const BY = 400;
const BW = 300;
const BH = 480;

const Bucket: React.FC<{
  frame: number;
  cx: number;
  level: number;
  rain: number; // ফোটনের সংখ্যা
  cycle: number;
  salt: number;
}> = ({ frame, cx, level, rain, cycle, salt }) => {
  const ph: React.ReactNode[] = [];
  for (let i = 0; i < rain; i++) {
    const x = cx - BW / 2 + 28 + ((BW - 56) * (i + 0.5)) / rain;
    const off = Math.floor((((i * 5) % rain) / rain) * cycle + hash(i, salt) * 4);
    const t = ((frame + off) % cycle) / cycle;
    const fall = theme.ease.in(Math.min(1, t / 0.8));
    const y = lerp(250, BY + 6, fall);
    const o = t < 0.8 ? 1 : 1 - (t - 0.8) / 0.2;
    ph.push(<Photon key={i} x={x} y={y} rot={90} len={64} amp={8} phase={frame / 2.4 + i} o={o} scale={0.9} />);
  }
  return (
    <g>
      <PixelWell x={cx - BW / 2} y={BY} w={BW} h={BH} level={level} cols={6} rows={12} />
      {ph}
    </g>
  );
};

export const S3Amount: React.FC = () => {
  const frame = useCurrentFrame();
  const { fps } = useVideoConfig();

  const move = P(frame, t6 - 6, 26, theme.ease.inOut);
  const cxA = lerp(960, 560, move);
  const levelA = P(frame, 10, t6 - 24, theme.ease.soft) * 0.86;
  const popA = sp(frame, fps, 4, theme.spring.smooth);
  const popB = sp(frame, fps, t6 + 4, theme.spring.smooth);
  const levelB = P(frame, t6 + 12, 80, theme.ease.soft) * 0.22;

  const collapse = P(frame, tGrid - 4, 18, theme.ease.in);
  const bucketsO = (1 - collapse);
  const bucketsS = lerp(1, 0.3, collapse);

  // গ্রিড
  const cols = 16;
  const rows = 7;
  const cell = 70;
  const gap = 12;
  const gx0 = (theme.width - (cols * cell + (cols - 1) * gap)) / 2;
  const gy0 = 310;
  const gridT = frame - (tGrid + 2);
  const cells: React.ReactNode[] = [];
  if (gridT > -2) {
    for (let j = 0; j < rows; j++)
      for (let i = 0; i < cols; i++) {
        const d = Math.abs(i - (cols - 1) / 2) + Math.abs(j - (rows - 1) / 2);
        const s = Math.min(1, Math.max(0, gridT - d * 1.6) / 12);
        if (s <= 0) continue;
        const lv = 0.12 + hash(i + j * 31, 7) * 0.82;
        const x = gx0 + i * (cell + gap);
        const y = gy0 + j * (cell + gap);
        const ease = theme.ease.out(s);
        cells.push(
          <g key={`${i}-${j}`} transform={`translate(${x + cell / 2} ${y + cell / 2}) scale(${ease}) translate(${-cell / 2} ${-cell / 2})`} opacity={ease}>
            <rect width={cell} height={cell} rx={14} fill={C.panel} stroke={C.panelLine} strokeWidth={2.5} />
            <rect x={6} y={6 + (cell - 12) * (1 - lv * ease)} width={cell - 12} height={(cell - 12) * lv * ease} rx={9} fill={C.primary} opacity={0.9} />
          </g>
        );
      }
  }
  const count = lerp(0, 10000000, P(frame, tGrid + 6, 60, theme.ease.out));

  return (
    <SceneShell>
      <Win from={0} to={t6 + 6}>
        <Title text="আলো বেশি, charge বেশি" top={70} delay={4} highlight={{ 0: C.accent, 2: C.primary }} />
      </Win>
      <Win from={t6 - 2} to={tGrid + 2}>
        <Title text="আলো কম, charge কম" top={70} delay={8} highlight={{ 0: C.accent, 2: C.primary }} />
      </Win>
      <Win from={tGrid - 2} to={tEnd + 400}>
        <div
          style={{
            position: "absolute",
            left: 0,
            width: theme.width,
            top: 64,
            textAlign: "center",
            fontFamily: theme.fonts.main,
            lineHeight: 1.3,
            letterSpacing: 0,
          }}
        >
          <span style={{ fontSize: 130, fontWeight: 700, color: C.primary, fontVariantNumeric: "tabular-nums" }}>{bnNumber(count)}</span>
          <span style={{ fontSize: 64, fontWeight: 600, color: C.text, marginLeft: 28 }}>pixel</span>
        </div>
      </Win>

      <FullSvg>
        <g opacity={bucketsO * popA} transform={`translate(960 640) scale(${bucketsS}) translate(-960 -640)`}>
          <Bucket frame={frame} cx={cxA} level={levelA} rain={8} cycle={34} salt={1} />
          <g opacity={popB} transform={`translate(1360 ${BY + BH / 2}) scale(${lerp(0.9, 1, popB)}) translate(-1360 ${-(BY + BH / 2)})`}>
            <Bucket frame={frame} cx={1360} level={levelB} rain={3} cycle={58} salt={5} />
          </g>
        </g>
        {cells}
      </FullSvg>

      <Win from={14} to={tGrid - 6}>
        <Tag x={cxA} y={925} text="বেশি আলো" color={C.accent} delay={0} size={38} />
      </Win>
      <Win from={t6 + 14} to={tGrid - 6}>
        <Tag x={1360} y={925} text="কম আলো" color={C.accent} delay={0} size={38} />
      </Win>

      <Sfx at={8} name="whoosh" vol={0.22} />
      <Sfx at={10} name="pop" vol={0.26} />
      <Sfx at={t6 + 8} name="pop" vol={0.26} rate={1.08} />
      <Sfx at={tGrid} name="whoosh" vol={0.24} rate={1.1} />
      <Sfx at={tGrid + 24} name="pop" vol={0.22} rate={0.95} />
    </SceneShell>
  );
};
