import React, {createContext, useContext} from "react";
import {Audio, Easing, Sequence, interpolate, spring, staticFile, useCurrentFrame, useVideoConfig} from "remotion";
import {theme} from "./theme";

// Per-scene timing info. `lead` = seconds between sequence start and the first cue word;
// `span` = seconds covered by the scene's cue(s) (all taken from the SRT).
export type SceneInfo = {lead: number; span: number};
export const SceneCtx = createContext<SceneInfo>({lead: 0, span: 1});

type SpringCfg = {damping: number; stiffness: number; mass: number};

export const useAnim = () => {
  const frame = useCurrentFrame();
  const {fps, durationInFrames} = useVideoConfig();
  const info = useContext(SceneCtx);
  const t = frame / fps;
  /** seconds (scene-local) at a fraction f of the narrated span */
  const at = (f: number) => info.lead + f * info.span;
  const sp = (sec: number, cfg: SpringCfg = theme.spring.smooth) =>
    spring({frame: frame - Math.round(sec * fps), fps, config: cfg});
  const ease = (a: number, b: number, from: number, to: number, easing: (n: number) => number = theme.ease.out) =>
    interpolate(t, [a, b], [from, to], {easing, extrapolateLeft: "clamp", extrapolateRight: "clamp"});
  const prog = (a: number, b: number, easing: (n: number) => number = theme.ease.inOut) => ease(a, b, 0, 1, easing);
  const wave = (period: number, amp: number, phase = 0) => Math.sin((t * 2 * Math.PI) / period + phase) * amp;
  return {frame, fps, t, durationInFrames, at, sp, ease, prog, wave, ...info};
};

export const clamp01 = (n: number) => Math.max(0, Math.min(1, n));

/** Premium entrance: opacity + translate + scale together (spring). */
export const Pop: React.FC<{
  at: number;
  x?: number;
  y?: number;
  from?: number;
  cfg?: SpringCfg;
  style?: React.CSSProperties;
  children: React.ReactNode;
}> = ({at, x = 0, y = 36, from = 0.92, cfg = theme.spring.smooth, style, children}) => {
  const a = useAnim();
  const p = a.sp(at, cfg);
  return (
    <div
      style={{
        opacity: clamp01(p * 1.4),
        transform: `translate(${x * (1 - p)}px, ${y * (1 - p)}px) scale(${interpolate(p, [0, 1], [from, 1])})`,
        ...style,
      }}
    >
      {children}
    </div>
  );
};

/** Word-by-word staggered reveal. Splits on SPACES only (never inside Bengali words). */
export const Words: React.FC<{
  text: string;
  at: number;
  size?: number;
  color?: string;
  weight?: number;
  per?: number; // frames between words
  highlight?: string[]; // words that get a sweep pill
  hlColor?: string;
  align?: "flex-start" | "center" | "flex-end";
  style?: React.CSSProperties;
}> = ({text, at, size = theme.size.title, color = theme.colors.text, weight = 700, per = 4, highlight = [], hlColor = theme.colors.amber, align = "flex-start", style}) => {
  const a = useAnim();
  const words = text.split(" ");
  return (
    <div
      style={{
        display: "flex",
        flexWrap: "wrap",
        justifyContent: align,
        columnGap: Math.round(size * 0.28),
        fontFamily: theme.fonts.display,
        fontSize: size,
        fontWeight: weight,
        lineHeight: 1.3,
        letterSpacing: 0,
        color,
        ...style,
      }}
    >
      {words.map((w, i) => {
        const start = at + (i * per) / a.fps;
        const p = a.sp(start, theme.spring.snappy);
        const hl = highlight.includes(w);
        const sweep = hl ? a.ease(start + 0.2, start + 0.5, 0, 1) : 0;
        return (
          <span key={i} style={{position: "relative", display: "inline-block", opacity: clamp01(p * 1.5), transform: `translateY(${interpolate(p, [0, 1], [30, 0])}px)`}}>
            {hl && (
              <span
                style={{
                  position: "absolute",
                  left: -10,
                  right: -10,
                  bottom: 4,
                  height: Math.round(size * 0.14),
                  borderRadius: 8,
                  background: hlColor,
                  opacity: 0.9,
                  transformOrigin: "left center",
                  transform: `scaleX(${sweep})`,
                }}
              />
            )}
            <span style={{position: "relative"}}>{w}</span>
          </span>
        );
      })}
    </div>
  );
};

/** Pill label (glass card look, no backdrop-filter so renders are stable). */
export const Chip: React.FC<{
  children: React.ReactNode;
  dot?: string;
  size?: number;
  border?: string;
  style?: React.CSSProperties;
}> = ({children, dot, size = theme.size.label, border = theme.colors.cardLine, style}) => (
  <div
    style={{
      display: "inline-flex",
      alignItems: "center",
      gap: 16,
      padding: `${Math.round(size * 0.28)}px ${Math.round(size * 0.55)}px`,
      borderRadius: theme.radius.chip,
      background: theme.colors.card,
      border: `2px solid ${border}`,
      boxShadow: `0 18px 40px -12px ${theme.colors.shadow}`,
      fontFamily: theme.fonts.display,
      fontWeight: 700,
      fontSize: size,
      lineHeight: 1.25,
      letterSpacing: 0,
      color: theme.colors.text,
      whiteSpace: "nowrap",
      ...style,
    }}
  >
    {dot && <span style={{width: size * 0.5, height: size * 0.5, borderRadius: "50%", background: dot, boxShadow: `0 0 18px ${dot}`}} />}
    {children}
  </div>
);

export type SfxName = "pop" | "click" | "whoosh_soft" | "whoosh_swipe" | "chime" | "thud";

/** SFX hit, scene-local seconds. Starts 3 frames before the visual lands. Studio previews it too. */
export const Sfx: React.FC<{name: SfxName; at: number; vol?: number; rate?: number}> = ({name, at, vol = 0.3, rate = 1}) => {
  const {fps} = useVideoConfig();
  const from = Math.max(0, Math.round(at * fps) - 3);
  return (
    <Sequence from={from} durationInFrames={Math.ceil(fps * 0.9)} layout="none">
      <Audio src={staticFile(`sfx/${name}.wav`)} volume={vol} playbackRate={rate} />
    </Sequence>
  );
};

/** A glowing ray growing from (x1,y1) to (x2,y2) with flowing highlight dashes. p: 0..1 */
export const Ray: React.FC<{x1: number; y1: number; x2: number; y2: number; color: string; p: number; w?: number; opacity?: number}> = ({x1, y1, x2, y2, color, p, w = 7, opacity = 1}) => {
  const frame = useCurrentFrame();
  if (p <= 0.002) return null;
  const ex = x1 + (x2 - x1) * p;
  const ey = y1 + (y2 - y1) * p;
  return (
    <g style={{filter: `drop-shadow(0 0 7px ${color})`}} opacity={opacity}>
      <line x1={x1} y1={y1} x2={ex} y2={ey} stroke={color} strokeWidth={w} strokeLinecap="round" />
      <line x1={x1} y1={y1} x2={ex} y2={ey} stroke="#FFFFFF" strokeOpacity={0.75} strokeWidth={w * 0.32} strokeLinecap="round" strokeDasharray="12 26" strokeDashoffset={-frame * 3.2} />
    </g>
  );
};

export const easeOutBack = Easing.out(Easing.back(1.6));
