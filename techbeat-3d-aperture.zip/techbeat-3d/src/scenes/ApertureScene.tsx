import React from "react";
import { AbsoluteFill, useCurrentFrame, useVideoConfig } from "remotion";
import { loadFont } from "@remotion/google-fonts/NotoSansBengali";
import { Scene3D } from "../three/Scene3D";
import { AudioTrack } from "../audio/AudioTrack";
import { cameraAt, projectToScreen } from "../lib/camera";
import { Label, LabelDef } from "./Labels";
import { CAM_KEYS, T } from "./aperture/timeline";
import { theme } from "../theme";
import { SENSOR_X } from "../three/Rays";

const { fontFamily } = loadFont("normal", { weights: ["500", "700"], subsets: ["bengali", "latin"] });

export const ApertureScene: React.FC = () => {
  const frame = useCurrentFrame();
  const { fps, width, height } = useVideoConfig();
  const t = frame / fps;
  const cam = cameraAt(t, CAM_KEYS);
  const px = (w: [number, number, number]) => {
    const p = projectToScreen(cam, w, width, height);
    return [p.x, p.y] as [number, number];
  };

  // Label texts are explanatory tags; the narration itself is never altered.
  const labels: LabelDef[] = [
    { kind: "title", from: 0.14, to: 2.7, text: "Aperture", x: 130, y: 90 },
    { kind: "tag", from: 4.3, to: 6.9, text: "Aperture", anchor: px([0, 1.55, 0]), hero: true },
    { kind: "tag", from: 7.4, to: 12.1, text: "আলো যাওয়ার পথ", anchor: px([-4.4, 0.9, 0]) },
    { kind: "tag", from: 8.0, to: 18.6, text: "Sensor", anchor: px([SENSOR_X, 1.7, 0]) },
    { kind: "tag", from: 9.0, to: 10.4, text: "ছোট", anchor: px([0, -1.55, 0]) },
    { kind: "tag", from: 10.4, to: 11.8, text: "বড়", anchor: px([0, -1.55, 0]) },
    { kind: "card", from: T.bigStart + 0.3, to: T.bigEnd - 0.1, text: "বড় Aperture → বেশি আলো", y: 880 },
    { kind: "card", from: T.smallStart + 0.2, to: 18.6, text: "ছোট Aperture → কম আলো", y: 880 },
  ];

  const bg = `radial-gradient(ellipse at 30% 25%, ${theme.colors.bgAlt} 0%, ${theme.colors.bg} 70%)`;
  return (
    <AbsoluteFill style={{ background: bg }}>
      {/* layer 1: bg mesh above. layer 2: 3D */}
      <Scene3D t={t} cam={cam} width={width} height={height} />
      {/* layer 3: labels */}
      <AbsoluteFill>
        {labels.map((l, i) => <Label key={i} def={l} t={t} fps={fps} font={fontFamily} />)}
      </AbsoluteFill>
      {/* layer 4/5: gentle grade + vignette + static grain */}
      <AbsoluteFill style={{ background: "radial-gradient(ellipse at center, rgba(0,0,0,0) 55%, rgba(0,0,0,0.45) 100%)", pointerEvents: "none" }} />
      <AbsoluteFill style={{ opacity: 0.06, mixBlendMode: "overlay", pointerEvents: "none" }}>
        <svg width="100%" height="100%"><filter id="g"><feTurbulence type="fractalNoise" baseFrequency="0.9" numOctaves="2" seed="3" /></filter><rect width="100%" height="100%" filter="url(#g)" /></svg>
      </AbsoluteFill>
      <AudioTrack />
    </AbsoluteFill>
  );
};
