// theme.ts — সব রং, ইজিং, spring প্রিসেট ও ফন্ট এখানে। কম্পোনেন্টে সরাসরি হেক্স নয়।
import { Easing } from "remotion";
import { fontFamily } from "./font";

export const theme = {
  fps: 30,
  width: 1920,
  height: 1080,
  colors: {
    bg: "#0B1020",
    bgAlt: "#131B35",
    panel: "#18223F",
    panelLine: "#2C3B6B",
    silicon: "#1C2850",
    siliconHi: "#2B3D74",
    primary: "#4F8CFF", // hero: electron / charge
    accent: "#FFB84D", // photon / light
    text: "#F4F7FF",
    textDim: "#9FACD0",
    red: "#FF5C6C",
    green: "#46D39A",
    glowPrimary: "rgba(79,140,255,0.45)",
    glowAccent: "rgba(255,184,77,0.5)",
  },
  fonts: {
    main: `${fontFamily}, "Hind Siliguri", "Noto Sans Bengali", sans-serif`,
  },
  ease: {
    out: Easing.bezier(0.16, 1, 0.3, 1),
    inOut: Easing.bezier(0.83, 0, 0.17, 1),
    soft: Easing.bezier(0.45, 0, 0.25, 1),
    in: Easing.bezier(0.7, 0, 0.84, 0),
  },
  spring: {
    snappy: { damping: 14, stiffness: 160, mass: 0.6 },
    smooth: { damping: 20, stiffness: 90, mass: 1 },
    bouncy: { damping: 11, stiffness: 170, mass: 0.7 },
  },
  sizes: { title: 76, label: 40, small: 34 },
} as const;
