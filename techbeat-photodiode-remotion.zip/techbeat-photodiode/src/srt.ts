import { SRT_RAW } from "./srtData";
import { theme } from "./theme";

export type Cue = {
  n: number;
  startSec: number;
  endSec: number;
  start: number; // frame
  end: number; // frame
  text: string;
};

const toSec = (t: string) => {
  const m = t.trim().match(/(\d+):(\d+):(\d+)[,.](\d+)/);
  if (!m) throw new Error("Bad SRT time: " + t);
  return +m[1] * 3600 + +m[2] * 60 + +m[3] + +m[4] / 1000;
};

export const parseSrt = (raw: string): Cue[] =>
  raw
    .replace(/\r/g, "")
    .trim()
    .split(/\n\s*\n/)
    .map((block) => {
      const lines = block.split("\n");
      const n = parseInt(lines[0], 10);
      const [a, b] = lines[1].split("-->");
      const startSec = toSec(a);
      const endSec = toSec(b);
      return {
        n,
        startSec,
        endSec,
        start: Math.round(startSec * theme.fps),
        end: Math.round(endSec * theme.fps),
        text: lines.slice(2).join(" ").trim(),
      };
    });

export const cues = parseSrt(SRT_RAW);
export const TOTAL_FRAMES = cues[cues.length - 1].end;

/** cue-র শুরুর ফ্রেম (n = SRT-র ক্রমিক নম্বর, ১ থেকে) */
export const cueStart = (n: number) => cues[n - 1].start;
export const cueEnd = (n: number) => cues[n - 1].end;

/**
 * cue-র ভেতরে কোনো শব্দ কোন ফ্রেমে বলা হবে — অক্ষর-অনুপাতে অনুমান।
 * lead ফ্রেম আগে ফেরত দেয় (ভিজ্যুয়াল কথার আগে ঢুকবে)।
 */
export const wordFrame = (n: number, keyword: string, lead = 5) => {
  const c = cues[n - 1];
  const chars = [...c.text];
  const idx = c.text.indexOf(keyword);
  const cp = idx < 0 ? 0 : [...c.text.slice(0, idx)].length;
  const frac = idx < 0 ? 0 : cp / chars.length;
  return Math.round(c.start + frac * (c.end - c.start)) - lead;
};
