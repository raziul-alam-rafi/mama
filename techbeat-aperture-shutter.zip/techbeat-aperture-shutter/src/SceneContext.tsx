import React, { createContext, useContext } from "react";
import { useCurrentFrame } from "remotion";
import { cueEndF, cueStartF, wordF } from "./srt";
import { theme } from "./theme";

type Ctx = { from: number };
const C = createContext<Ctx>({ from: 0 });
export const SceneProvider: React.FC<{ from: number; children: React.ReactNode }> = ({ from, children }) => (
  <C.Provider value={{ from }}>{children}</C.Provider>
);

/** Scene-local frame helpers. All values derive from SRT; `lead` = visual enters earlier than speech. */
export const useScene = () => {
  const { from } = useContext(C);
  const frame = useCurrentFrame();
  const lead = theme.motion.lead;
  return {
    frame,
    from,
    /** local frame of cue start (minus lead) */
    cue: (n: number) => cueStartF(n) - from - lead,
    cueEnd: (n: number) => cueEndF(n) - from,
    /** local frame of a spoken word (minus lead) */
    word: (n: number, w: string, occ = 0) => wordF(n, w, occ) - from - lead,
    /** local frame of a spoken word, exact (no lead) — for sound cues */
    wordExact: (n: number, w: string, occ = 0) => wordF(n, w, occ) - from,
  };
};
