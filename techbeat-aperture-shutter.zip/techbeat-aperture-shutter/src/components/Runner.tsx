import React from "react";

/** running child silhouette. origin = feet on ground. t = seconds (drives the stride) */
export const Runner: React.FC<{ x: number; y: number; s?: number; t: number; color: string; opacity?: number }> = ({
  x, y, s = 1, t, color, opacity = 1,
}) => {
  const ph = t * Math.PI * 2 * 2.3;
  const hipF = 42 * Math.sin(ph), hipB = -42 * Math.sin(ph);
  const kneeF = -Math.max(0, 75 * Math.sin(ph + 0.9)) - 8, kneeB = -Math.max(0, 75 * Math.sin(ph + 0.9 + Math.PI)) - 8;
  const armF = -48 * Math.sin(ph), armB = 48 * Math.sin(ph);
  const sw = 13;
  const leg = (hip: number, knee: number) => (
    <g transform={`rotate(${hip})`}>
      <line x1={0} y1={0} x2={0} y2={46} stroke={color} strokeWidth={sw} strokeLinecap="round" />
      <g transform={`translate(0,46) rotate(${knee})`}>
        <line x1={0} y1={0} x2={0} y2={44} stroke={color} strokeWidth={sw - 1} strokeLinecap="round" />
      </g>
    </g>
  );
  const arm = (a: number) => (
    <g transform={`translate(0,-60) rotate(${a})`}>
      <line x1={0} y1={0} x2={0} y2={30} stroke={color} strokeWidth={sw - 2} strokeLinecap="round" />
      <g transform="translate(0,30) rotate(-70)">
        <line x1={0} y1={0} x2={0} y2={26} stroke={color} strokeWidth={sw - 3} strokeLinecap="round" />
      </g>
    </g>
  );
  return (
    <g transform={`translate(${x},${y - 92}) scale(${s})`} opacity={opacity}>
      {leg(hipB, kneeB)}
      <g transform="rotate(12)">
        {arm(armB)}
        <line x1={0} y1={0} x2={0} y2={-62} stroke={color} strokeWidth={sw + 6} strokeLinecap="round" />
        <circle cx={0} cy={-80} r={15} fill={color} />
        {arm(armF)}
      </g>
      {leg(hipF, kneeF)}
    </g>
  );
};
