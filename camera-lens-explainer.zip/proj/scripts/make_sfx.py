"""Synthesise a small, clean UI/motion-graphics SFX kit into public/sfx/.
Usage: python3 scripts/make_sfx.py   (needs numpy + scipy)"""
import os
import numpy as np
from scipy.io import wavfile
from scipy.signal import butter, sosfilt, fftconvolve

SR = 44100
OUT = os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "public", "sfx")
os.makedirs(OUT, exist_ok=True)
rng = np.random.default_rng(7)


def t_(d):
    return np.arange(int(SR * d)) / SR


def lp(x, f):
    return sosfilt(butter(2, f, "low", fs=SR, output="sos"), x)


def hp(x, f):
    return sosfilt(butter(2, f, "high", fs=SR, output="sos"), x)


def bp(x, lo, hi):
    return sosfilt(butter(2, [lo, hi], "band", fs=SR, output="sos"), x)


def env(n, attack, decay_tau):
    t = np.arange(n) / SR
    a = np.clip(t / attack, 0, 1) ** 2  # soft attack
    return a * np.exp(-t / decay_tau)


def tiny_reverb(x, mix=0.12):
    n = int(SR * 0.05)
    ir = rng.standard_normal(n) * np.exp(-np.arange(n) / (SR * 0.012))
    ir[0] = 0
    wet = fftconvolve(x, ir)[: len(x)]
    wet /= np.max(np.abs(wet)) + 1e-9
    return x + mix * wet * np.max(np.abs(x))


def finish(x, dur, name, peak=0.8, fade_ms=12):
    x = x[: int(SR * dur)].copy()
    n = int(SR * fade_ms / 1000)
    x[-n:] *= np.linspace(1, 0, n) ** 2
    x = tiny_reverb(x)[: int(SR * dur)]
    x = x / (np.max(np.abs(x)) + 1e-9) * peak
    wavfile.write(os.path.join(OUT, name), SR, (x * 32767).astype(np.int16))


# pop: sine with fast downward pitch + short envelope
d = 0.22
t = t_(d)
f = 180 + 360 * np.exp(-t / 0.03)
x = np.sin(2 * np.pi * np.cumsum(f) / SR) * env(len(t), 0.004, 0.05)
x += 0.25 * np.sin(2 * np.pi * np.cumsum(2 * f) / SR) * env(len(t), 0.004, 0.03)
finish(lp(x, 3800), d, "pop.wav")

# click: tiny high-passed noise burst + faint tone
d = 0.12
t = t_(d)
x = hp(rng.standard_normal(len(t)), 2200) * env(len(t), 0.001, 0.012)
x += 0.35 * np.sin(2 * np.pi * 1500 * t) * env(len(t), 0.001, 0.015)
finish(lp(x, 7000), d, "click.wav")

# whoosh: band-passed noise sweep (low -> high), fade in/out
d = 0.7
t = t_(d)
n = len(t)
noise = rng.standard_normal(n)
centers = np.geomspace(350, 3200, 7)
prog = t / d
x = np.zeros(n)
sweep = prog ** 0.8
for c in centers:
    band = bp(noise, c * 0.75, c * 1.3)
    pos = (np.log(c) - np.log(centers[0])) / (np.log(centers[-1]) - np.log(centers[0]))
    x += band * np.exp(-((sweep - pos) ** 2) / (2 * 0.17**2))
x *= np.sin(np.pi * prog) ** 2
finish(lp(x, 5000), d, "whoosh.wav", fade_ms=40)

# chime: soft pluck with gentle overtones, short decay
d = 0.5
t = t_(d)
x = np.zeros(len(t))
for fr, amp, tau in [(880, 1, 0.16), (1320, 0.35, 0.10), (1760, 0.12, 0.06)]:
    x += amp * np.sin(2 * np.pi * fr * t) * env(len(t), 0.004, tau)
finish(lp(x, 4500), d, "chime.wav")

# thud: very soft low thump for the hook / key message
d = 0.35
t = t_(d)
f = 48 + 60 * np.exp(-t / 0.05)
x = np.sin(2 * np.pi * np.cumsum(f) / SR) * env(len(t), 0.006, 0.09)
finish(lp(x, 220), d, "thud.wav", fade_ms=30)
print("ok")
