import React from "react";
import { Audio, getRemotionEnvironment, getStaticFiles, staticFile } from "remotion";

/** Studio প্রিভিউতে ভয়েসওভার বাজবে (public/voiceover.mp3 থাকলে) */
export const VOICEOVER_IN_PREVIEW = true;
/** রেন্ডারে ভয়েসওভার মেশাতে চাইলে true করুন (ডিফল্ট: বন্ধ) */
export const VOICEOVER_IN_RENDER = false;

export const PreviewAudio: React.FC = () => {
  const env = getRemotionEnvironment();
  if (env.isRendering) {
    return VOICEOVER_IN_RENDER ? <Audio src={staticFile("voiceover.mp3")} /> : null;
  }
  if (!VOICEOVER_IN_PREVIEW) return null;
  let exists = false;
  try {
    exists = getStaticFiles().some((f) => f.name === "voiceover.mp3");
  } catch {
    exists = false;
  }
  return exists ? <Audio src={staticFile("voiceover.mp3")} /> : null;
};
