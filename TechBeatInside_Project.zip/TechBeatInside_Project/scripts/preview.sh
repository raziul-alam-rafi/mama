#!/usr/bin/env sh
cd "$(dirname "$0")/.." || exit 1
npx remotion studio src/index.ts
