// AUTO-GENERATED from public/voiceover.srt by scripts/srt-to-cues.mjs — do not edit by hand.
export type Cue = { i: number; start: number; end: number; text: string };
export const cues: Cue[] = [
  {
    "i": 1,
    "start": 320,
    "end": 6460,
    "text": "ধরুন একটি torch দিয়ে অন্ধকারে কোনো কিছুর দিকে আলো ফেললেন। এখন অন্যদিকে আলো ফেলতে"
  },
  {
    "i": 2,
    "start": 6460,
    "end": 12200,
    "text": "চাইলে আপনাকে পুরো torch-টাই ঘুরাতে হবে। কিন্তু Starlink-এর dish-এ প্রতিবার পুরো"
  },
  {
    "i": 3,
    "start": 12200,
    "end": 18200,
    "text": "dish ঘুরানোর প্রয়োজন পড়ে না। এর ছোট ছোট antenna signal-এর মধ্যে সামান্য পরিবর্তন"
  },
  {
    "i": 4,
    "start": 18200,
    "end": 23100,
    "text": "ঘটিয়ে signal কোন দিকে যাবে তা ইলেকট্রনিক ভাবে নিয়ন্ত্রণ করা যায়। কারণ"
  },
  {
    "i": 5,
    "start": 23100,
    "end": 28960,
    "text": "satellite তো আর এক জায়গায় স্থির থাকে না। এটি পৃথিবীর চারপাশে প্রচণ্ড গতিতে ঘুরতে"
  },
  {
    "i": 6,
    "start": 28960,
    "end": 34300,
    "text": "থাকে। তাই dish-কে দ্রুত বদলে যাওয়া অবস্থানের সঙ্গে তাল মিলিয়ে যোগাযোগ বজায়"
  },
  {
    "i": 7,
    "start": 34300,
    "end": 41040,
    "text": "রাখতে হয়। তাহলে প্রশ্ন হলো এত দ্রুত গতির satellite থেকে আপনার device-এ internet আসে"
  },
  {
    "i": 8,
    "start": 41040,
    "end": 41740,
    "text": "ঠিক কিভাবে?"
  }
];
