// Switches. Edit freely.
/** Play public/voiceover.mp3 (if the file exists) inside Remotion Studio. */
export const VOICEOVER_PREVIEW_ON = true;
/** Keep voiceover OUT of rendered MP4 (default). Set true only if you want it baked in. */
export const VOICEOVER_IN_RENDER = false;
/** Master switch for the synthesized UI sound effects (they ARE rendered into the MP4). */
export const SFX_ON = true;
