// সিন ৬ — আলো বাঁকে → sensor-এ ফোকাস, তারপর Recap (Cross-section + Checklist Recap) · cue 11 + ক্লোজিং হোল্ড
import React from "react";
import { AbsoluteFill, interpolate } from "remotion";
import { Beam, RayLayer } from "../components/Rays";
import { ArrowIcon, CheckIcon, SensorIcon } from "../components/Icons";
import { Chip, Enter, Glass, Words, usePop, useProgress } from "../components/Primitives";
import { Sfx } from "../components/audio";
import { at } from "../timeline";
import { theme } from "../theme";

const c = theme.colors;
const SI = 5;
const FY = 500; // ফোকাস y
const X0 = 150, XS = 1500;
const EL_X = [690, 790, 890, 990];
const FRAC = [0.18, 0.4, 0.65, 0.9];
const YS = [290, 360, 430, 500, 570, 640, 710];
const SENSOR = { x: XS - 45, y: 270, w: 90, h: 460 };

const RECAP = ["আলো", "Lens", "sensor", "পরিষ্কার ছবি"];

export const S6Optics: React.FC = () => {
  const tEl = at(SI, 11, "element");
  const tLight = at(SI, 11, "আলোকে");
  const tBend = at(SI, 11, "বাঁকিয়ে");
  const tIn = at(SI, 11, "ভেতরে");
  const tSend = at(SI, 11, "পাঠায়");

  const elP = EL_X.map((_, i) => usePop(tEl + i * theme.timing.stagger, theme.spring.smooth));
  const rayP = YS.map((_, i) => useProgress(tLight + i * 3, 26));
  const bend = useProgress(tBend, 30, theme.ease.inOut);
  const sensorGlow = usePop(tIn, theme.spring.bouncy);
  const focal = usePop(tIn + 2, theme.spring.bouncy);
  const recapP = RECAP.map((_, i) => usePop(tIn + 6 + i * 6, theme.spring.snappy));
  const arrowP = RECAP.map((_, i) => useProgress(tIn + 12 + i * 6, 12));
  const check = useProgress(tIn + 6 + 3 * 6 + 8, 14);

  return (
    <AbsoluteFill>
      {/* শিরোনাম */}
      <div style={{ position: "absolute", top: 70, left: 0, right: 0, display: "flex", justifyContent: "center" }}>
        <Words text="আলোকে বাঁকিয়ে ভেতরে পাঠায়" delay={tBend} size={76} align="center" wordStyle={(w) => (w === "বাঁকিয়ে" ? { color: c.accent } : {})} />
      </div>

      {/* sensor */}
      <div style={{ position: "absolute", left: SENSOR.x, top: SENSOR.y, opacity: Math.min(1, elP[3]), transform: `translateX(${interpolate(elP[3], [0, 1], [50, 0])}px)` }}>
        <SensorIcon w={SENSOR.w} h={SENSOR.h} rows={12} uid="s6" glow={sensorGlow} />
      </div>

      {/* রশ্মি: সোজা → বাঁকা */}
      <RayLayer>
        {YS.map((y0, i) => {
          const pts: [number, number][] = [
            [X0, y0],
            [EL_X[0], y0],
            ...EL_X.slice(1).map((x, k) => [x, y0 + (FY - y0) * FRAC[k] * bend] as [number, number]),
            [EL_X[3] + 40, y0 + (FY - y0) * FRAC[3] * bend],
            [XS, y0 + (FY - y0) * bend],
          ];
          return <Beam key={i} id={`s6-r-${i}`} pts={pts} p={rayP[i]} width={5} fadeTail={false} />;
        })}
      </RayLayer>

      {/* optical element — কাচের স্তর */}
      {EL_X.map((x, i) => (
        <div
          key={i}
          style={{
            position: "absolute", left: x - 36, top: 250, width: 72, height: 500, borderRadius: "50%",
            background: `linear-gradient(90deg, rgba(255,255,255,0.22), ${c.primary}44 55%, rgba(255,255,255,0.08))`,
            border: `2.5px solid rgba(255,255,255,0.5)`, boxShadow: `0 0 50px ${c.glow}, inset 0 0 30px rgba(79,140,255,0.25)`,
            opacity: Math.min(1, elP[i]), transform: `scaleY(${interpolate(elP[i], [0, 1], [0.7, 1])})`,
          }}
        />
      ))}
      <div style={{ position: "absolute", left: EL_X[0] - 120, width: EL_X[3] - EL_X[0] + 240, top: 770, display: "flex", justifyContent: "center" }}>
        <Enter delay={tEl + 14} y={18}>
          <Chip text="optical element" size={36} tone="primary" />
        </Enter>
      </div>

      {/* ফোকাস বিন্দু */}
      <div
        style={{
          position: "absolute", left: XS - 22, top: FY - 22, width: 44, height: 44, borderRadius: "50%", background: c.white,
          boxShadow: `0 0 0 7px ${c.accent}, 0 0 60px 18px ${c.accentGlow}`, opacity: Math.min(1, focal) * bend, transform: `scale(${focal})`,
        }}
      />

      {/* রিক্যাপ */}
      <div style={{ position: "absolute", left: 0, right: 0, bottom: 82, display: "flex", justifyContent: "center", alignItems: "center", columnGap: 26 }}>
        {RECAP.map((t, i) => (
          <React.Fragment key={t}>
            <div style={{ opacity: Math.min(1, recapP[i]), transform: `translateY(${interpolate(recapP[i], [0, 1], [26, 0])}px) scale(${interpolate(recapP[i], [0, 1], [0.92, 1])})` }}>
              <Glass style={{ display: "flex", alignItems: "center", gap: 18, padding: "16px 34px 16px 22px", borderRadius: theme.radius.pill }}>
                <CheckIcon size={52} p={i === 3 ? check : 1} color={i === 3 ? c.accent : c.primary} />
                <div style={{ fontFamily: theme.fonts.display, fontWeight: theme.weight.heavy, fontSize: 50, lineHeight: 1.25, letterSpacing: 0, color: c.text }}>{t}</div>
              </Glass>
            </div>
            {i < RECAP.length - 1 && (
              <div style={{ opacity: arrowP[i] }}>
                <ArrowIcon size={56} p={arrowP[i]} />
              </div>
            )}
          </React.Fragment>
        ))}
      </div>

      <Sfx name="pop" at={tEl - 2} />
      <Sfx name="whoosh-soft" at={tBend - 3} n={5} />
      <Sfx name="chime" at={tIn - 1} n={3} />
      <Sfx name="pop" at={tIn + 4} n={5} />
      <Sfx name="click" at={tIn + 6 + 3 * 6 + 8} n={4} />
    </AbsoluteFill>
  );
};
