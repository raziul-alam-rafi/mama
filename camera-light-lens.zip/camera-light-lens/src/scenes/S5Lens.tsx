// সিন ৫ — Lens: সামনের দৃশ্য → "সাধারণ কাঁচ নয়" → একাধিক optical element (Glossy 3D Exploded View) · cue 9–10
import React from "react";
import { AbsoluteFill, interpolate, useCurrentFrame } from "remotion";
import { LensFront } from "../components/Icons";
import { Breathe, Chip, Enter, Strike, Sweep, Words, usePop, useProgress } from "../components/Primitives";
import { Sfx } from "../components/audio";
import { at } from "../timeline";
import { theme } from "../theme";

const c = theme.colors;
const SI = 4;
const G = { x: 520, y: 540, size: 640 };

// এক্সপ্লোডেড স্ট্যাকের কাচের ডিস্ক: পেছন থেকে সামনে
const DISCS = [
  { size: 600, tint: 0.16, ring: 0.2 },
  { size: 520, tint: 0.22, ring: 0.3 },
  { size: 440, tint: 0.28, ring: 0.36 },
  { size: 360, tint: 0.34, ring: 0.42 },
];

const Disc: React.FC<{ size: number; tint: number; ring: number; z: number; alpha: number }> = ({ size, tint, ring, z, alpha }) => (
  <div
    style={{
      position: "absolute", left: -size / 2, top: -size / 2, width: size, height: size, borderRadius: "50%",
      transform: `translateZ(${z}px)`, opacity: alpha,
      background: `radial-gradient(circle at 34% 28%, rgba(255,255,255,${tint + 0.18}), ${c.primary}${Math.round(tint * 255).toString(16).padStart(2, "0")} 46%, rgba(0,0,0,0.05) 100%)`,
      border: `3px solid rgba(255,255,255,${ring})`,
      boxShadow: `inset 0 0 60px rgba(79,140,255,0.25), 0 30px 60px -30px rgba(0,0,0,0.6)`,
    }}
  >
    <div style={{ position: "absolute", inset: size * 0.1, borderRadius: "50%", border: `2px solid rgba(255,255,255,${ring * 0.6})` }} />
    <div style={{ position: "absolute", left: size * 0.2, top: size * 0.14, width: size * 0.3, height: size * 0.09, borderRadius: size, background: "rgba(255,255,255,0.45)", transform: "rotate(-34deg)" }} />
  </div>
);

export const S5Lens: React.FC = () => {
  const frame = useCurrentFrame();
  const tImp = at(SI, 9, "গুরুত্বপূর্ণ");
  const tLens = at(SI, 9, "lens");
  const tFront = at(SI, 9, "সামনে");
  const tNot = at(SI, 10, "সাধারণ");
  const tMulti = at(SI, 10, "একাধিক");
  const tOpt = at(SI, 10, "optical");
  const exitA = tNot - theme.timing.exit - 2;

  const lensIn = usePop(0, theme.spring.bouncy);
  const pulse = useProgress(tLens, 26);
  const e = useProgress(tMulti, 34, theme.ease.inOut); // এক্সপ্লোড 0→1
  const swap = useProgress(tMulti - 6, 8);
  const lensAlpha = 1 - swap;
  const stackAlpha = swap;
  const glow = usePop(tLens, theme.spring.bouncy);

  return (
    <AbsoluteFill>
      {/* বাঁ: গ্রাফিক */}
      <div style={{ position: "absolute", left: G.x - G.size / 2, top: G.y - G.size / 2, width: G.size, height: G.size }}>
        {/* Lens উচ্চারণে রিং-পালস */}
        <div
          style={{
            position: "absolute", inset: -20, borderRadius: "50%", border: `4px solid ${c.primary}`,
            opacity: interpolate(pulse, [0, 0.2, 1], [0, 0.8, 0]), transform: `scale(${interpolate(pulse, [0, 1], [0.96, 1.22])})`,
          }}
        />
        <div style={{ opacity: Math.min(1, lensIn) * lensAlpha, transform: `scale(${interpolate(lensIn, [0, 1], [0.6, 1])} ) rotate(${interpolate(lensIn, [0, 1], [-50, 0])}deg)`, filter: `drop-shadow(0 0 ${50 * glow * lensAlpha}px ${c.glow})` }}>
          <Breathe amp={1}>
            <LensFront size={G.size} uid="s5" />
          </Breathe>
        </div>
        {/* এক্সপ্লোডেড স্ট্যাক (3D) */}
        <div style={{ position: "absolute", inset: 0, perspective: 1900, opacity: stackAlpha }}>
          <div
            style={{
              position: "absolute", left: "50%", top: "50%", transformStyle: "preserve-3d",
              transform: `rotateX(${10 * e}deg) rotateY(${-34 * e + Math.sin(frame / 36) * 3 * e}deg) scale(${interpolate(e, [0, 1], [1.04, 0.96])})`,
            }}
          >
            {DISCS.map((d, i) => (
              <Disc key={i} size={d.size} tint={d.tint} ring={d.ring} z={(i - 1.5) * 150 * e} alpha={1} />
            ))}
          </div>
        </div>
      </div>

      {/* ডান: বার্তা — বিট A */}
      <div style={{ position: "absolute", left: 1010, top: 0, bottom: 0, width: 800, display: "flex", flexDirection: "column", justifyContent: "center", gap: 16 }}>
        <Words text="গুরুত্বপূর্ণ অংশ" delay={tImp} size={84} color={c.textDim} exitAt={exitA} />
        <Enter delay={tLens} y={50} scaleFrom={0.82} preset={theme.spring.bouncy} exitAt={exitA}>
          <div style={{ filter: `drop-shadow(0 0 ${44 * glow}px ${c.glow})`, display: "inline-block" }}>
            <div
              style={{
                fontFamily: theme.fonts.display, fontWeight: theme.weight.heavy, fontSize: 330, lineHeight: 1.1, letterSpacing: 0,
                backgroundImage: `linear-gradient(100deg, ${c.white}, ${c.primary} 80%)`, WebkitBackgroundClip: "text", backgroundClip: "text", color: "transparent",
              }}
            >
              Lens
            </div>
          </div>
        </Enter>
        <Enter delay={tFront} y={26} exitAt={exitA}>
          <Chip text="ক্যামেরার সামনের কাঁচ" size={44} tone="dim" />
        </Enter>
      </div>

      {/* ডান: বার্তা — বিট B */}
      <div style={{ position: "absolute", left: 1010, top: 0, bottom: 0, width: 800, display: "flex", flexDirection: "column", justifyContent: "center", gap: 22 }}>
        <div style={{ display: "flex", alignItems: "center", columnGap: 30 }}>
          <Enter delay={tNot} y={30}>
            <div style={{ fontFamily: theme.fonts.display, fontWeight: theme.weight.heavy, fontSize: 104, lineHeight: 1.22, letterSpacing: 0, color: c.text }}>
              <Strike delay={tNot + 10}>সাধারণ কাঁচ</Strike>
            </div>
          </Enter>
          <Words text="নয়" delay={tNot + 10} size={104} color={c.accent} />
        </div>
        <Words text="একাধিক" delay={tMulti} size={188} />
        <Enter delay={tOpt} y={30}>
          <Sweep delay={tOpt + 4}>
            <span style={{ fontFamily: theme.fonts.display, fontWeight: theme.weight.heavy, fontSize: 108, lineHeight: 1.3, letterSpacing: 0, color: c.white, whiteSpace: "nowrap" }}>optical element</span>
          </Sweep>
        </Enter>
      </div>

      <Sfx name="whoosh-soft" at={tImp - 3} />
      <Sfx name="chime" at={tLens - 2} n={2} />
      <Sfx name="pop" at={tFront - 2} n={3} />
      <Sfx name="click" at={tNot + 10} n={3} />
      <Sfx name="whoosh-soft" at={tMulti - 4} n={4} />
      <Sfx name="pop" at={tOpt - 2} n={4} />
    </AbsoluteFill>
  );
};
