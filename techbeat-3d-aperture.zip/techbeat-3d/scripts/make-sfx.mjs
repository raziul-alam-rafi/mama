// Fully synthetic, deterministic SFX + music bed. No downloads, no third-party licences.
// Output: 48 kHz, 16-bit, mono WAV in public/sfx and public/music.
import fs from "node:fs";

const SR = 48000;
let seed = 12345;
const rnd = () => ((seed = (seed * 1664525 + 1013904223) >>> 0) / 4294967296) * 2 - 1;
const buf = (sec) => new Float32Array(Math.round(sec * SR));
const env = (i, n, a, r) => { // attack/release in seconds
  const t = i / SR, T = n / SR;
  return Math.min(1, t / a) * Math.min(1, (T - t) / r);
};
const smooth = (x) => x * x * (3 - 2 * x);

function normalize(b, peakDb = -3) {
  let p = 0; for (const v of b) p = Math.max(p, Math.abs(v));
  const g = p > 0 ? Math.pow(10, peakDb / 20) / p : 1;
  for (let i = 0; i < b.length; i++) b[i] *= g;
  return b;
}
function writeWav(path, b) {
  const n = b.length, data = Buffer.alloc(44 + n * 2);
  data.write("RIFF", 0); data.writeUInt32LE(36 + n * 2, 4); data.write("WAVE", 8);
  data.write("fmt ", 12); data.writeUInt32LE(16, 16); data.writeUInt16LE(1, 20); data.writeUInt16LE(1, 22);
  data.writeUInt32LE(SR, 24); data.writeUInt32LE(SR * 2, 28); data.writeUInt16LE(2, 32); data.writeUInt16LE(16, 34);
  data.write("data", 36); data.writeUInt32LE(n * 2, 40);
  for (let i = 0; i < n; i++) data.writeInt16LE(Math.round(Math.max(-1, Math.min(1, b[i])) * 32767), 44 + i * 2);
  fs.writeFileSync(path, data);
  console.log("wrote", path, (n / SR).toFixed(2) + "s");
}

// Camera / part movement: band-limited noise with rising then falling cutoff.
function whoosh(sec = 0.9) {
  const b = buf(sec); let lp1 = 0, lp2 = 0;
  for (let i = 0; i < b.length; i++) {
    const x = i / b.length;
    const cutoff = 0.02 + 0.30 * Math.sin(Math.PI * Math.pow(x, 0.8));
    lp1 += cutoff * (rnd() - lp1); lp2 += cutoff * (lp1 - lp2);
    b[i] = (lp1 - lp2) * 6 * Math.pow(Math.sin(Math.PI * x), 1.5);
  }
  return normalize(b, -6);
}
// Mechanical click: short noise burst + decaying 1.9 kHz / 780 Hz body.
function click(sec = 0.12) {
  const b = buf(sec);
  for (let i = 0; i < b.length; i++) {
    const t = i / SR, d = Math.exp(-t * 55);
    b[i] = (rnd() * 0.6 * Math.exp(-t * 180) + Math.sin(2 * Math.PI * 1900 * t) * 0.5 * d + Math.sin(2 * Math.PI * 780 * t) * 0.5 * Math.exp(-t * 35));
  }
  return normalize(b, -4);
}
// Iris motor: soft servo whirr, 1.4 s, matches one blade-travel.
function irisMotor(sec = 1.4) {
  const b = buf(sec); let lp = 0, ph = 0;
  for (let i = 0; i < b.length; i++) {
    const x = i / b.length, f = 150 + 90 * Math.sin(Math.PI * x);
    ph += (2 * Math.PI * f) / SR;
    lp += 0.08 * (rnd() - lp);
    const ratchet = 0.65 + 0.35 * Math.sin(2 * Math.PI * 36 * (i / SR));
    b[i] = (Math.sin(ph) * 0.45 + Math.sin(ph * 2) * 0.2 + lp * 0.6) * ratchet * env(i, b.length, 0.12, 0.2);
  }
  return normalize(b, -9);
}
// Explanatory "light on" shimmer (light itself is silent: this is an intentional cue).
function shimmer(sec = 1.4) {
  const b = buf(sec), freqs = [1318.5, 1760, 2349.3, 3136];
  for (let i = 0; i < b.length; i++) {
    const t = i / SR; let v = 0;
    freqs.forEach((f, k) => { v += Math.sin(2 * Math.PI * f * t + k) * (0.5 / (k + 1)) * (0.6 + 0.4 * Math.sin(2 * Math.PI * (5 + k) * t)); });
    b[i] = v * env(i, b.length, 0.08, 0.9);
  }
  return normalize(b, -9);
}
// Sweep up/down (more light / less light sensor cue).
function sweep(up = true, sec = 1.5) {
  const b = buf(sec); let ph = 0;
  for (let i = 0; i < b.length; i++) {
    const x = i / b.length, f = up ? 280 + 900 * smooth(x) : 1180 - 900 * smooth(x);
    ph += (2 * Math.PI * f) / SR;
    b[i] = (Math.sin(ph) * 0.6 + Math.sin(ph * 1.5) * 0.2) * env(i, b.length, 0.15, 0.6);
  }
  return normalize(b, -10);
}
// Ambient curiosity pad, 24 s: slow Am - F - C - G, soft sine stacks, gentle tremolo.
function musicBed(sec = 24) {
  const b = buf(sec);
  const chords = [[220, 261.63, 329.63], [174.61, 220, 261.63], [130.81, 196, 261.63], [196, 246.94, 293.66]];
  const per = 6;
  for (let i = 0; i < b.length; i++) {
    const t = i / SR, ci = Math.floor(t / per) % 4, local = (t % per) / per;
    const cf = Math.min(1, local * 6, (1 - local) * 6 + 0.35); // chord crossfade-ish
    let v = 0;
    for (const f of chords[ci]) {
      v += Math.sin(2 * Math.PI * f * t) * 0.3 + Math.sin(2 * Math.PI * f * 1.005 * t + 1) * 0.2;
      v += Math.sin(2 * Math.PI * f * 2 * t) * 0.05;
    }
    const bass = Math.sin(2 * Math.PI * (chords[ci][0] / 2) * t) * 0.4;
    const pulse = 0.85 + 0.15 * Math.sin(2 * Math.PI * (0.5) * t);
    b[i] = (v * 0.35 + bass * 0.5) * pulse * cf * env(i, b.length, 2.0, 3.0);
  }
  return normalize(b, -6);
}

fs.mkdirSync("public/sfx", { recursive: true });
fs.mkdirSync("public/music", { recursive: true });
writeWav("public/sfx/whoosh.wav", whoosh());
writeWav("public/sfx/click.wav", click());
writeWav("public/sfx/iris_motor.wav", irisMotor());
writeWav("public/sfx/shimmer.wav", shimmer());
writeWav("public/sfx/sweep_up.wav", sweep(true));
writeWav("public/sfx/sweep_down.wav", sweep(false));
writeWav("public/music/ambient_pad.wav", musicBed());
