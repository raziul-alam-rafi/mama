import React from "react";
import { AbsoluteFill, Audio, Sequence, getRemotionEnvironment, getStaticFiles, staticFile } from "remotion";
import { theme } from "./theme";
import { LEAD, SCENES } from "./timing";
import { BgMesh, Grade, Grain, Vignette, ease } from "./components/ui";
import { SfxTrack } from "./sfx";
import { Hook, sfx as s0 } from "./scenes/Hook";
import { Pipeline, sfx as s1 } from "./scenes/Pipeline";
import { Twist, sfx as s2 } from "./scenes/Twist";
import { Detect, sfx as s3 } from "./scenes/Detect";
import { Journey, sfx as s4 } from "./scenes/Journey";
import { Outro, sfx as s5 } from "./scenes/Outro";
import { useCurrentFrame } from "remotion";

const SCENE_COMPONENTS = [Hook, Pipeline, Twist, Detect, Journey, Outro];

// ভয়েসওভার প্রিভিউ: public/voiceover.mp3 থাকলে Studio-তে বাজবে, না থাকলে নীরবে বাদ।
// includeInRender = true করলে রেন্ডারেও ভয়েসওভার যুক্ত হবে (ডিফল্টে বন্ধ)।
export const VOICEOVER = { enabled: true, includeInRender: false, file: "voiceover.mp3" };

const PreviewAudio: React.FC = () => {
  if (!VOICEOVER.enabled) return null;
  if (getRemotionEnvironment().isRendering && !VOICEOVER.includeInRender) return null;
  let exists = false;
  try {
    exists = getStaticFiles().some((s) => s.name === VOICEOVER.file);
  } catch {
    exists = false;
  }
  return exists ? <Audio src={staticFile(VOICEOVER.file)} volume={1} /> : null;
};

// সিন কাটের ওপর মাস্ক-ওয়াইপ (কাট লুকানো থাকে ওয়াইপের পেছনে)
const Wipe: React.FC = () => {
  const f = useCurrentFrame();
  const R = ease(f, [0, 7], [-20, 1940], theme.ease.inOut);
  const L = ease(f, [7, 14], [-20, 1940], theme.ease.inOut);
  return (
    <AbsoluteFill>
      <div style={{ position: "absolute", top: 0, height: "100%", left: L, width: Math.max(0, R - L), background: theme.colors.bg }} />
      {f < 8 && (
        <div style={{ position: "absolute", top: 0, height: "100%", left: R - 4, width: 4, background: theme.colors.hero, boxShadow: `0 0 30px ${theme.colors.glowHero}` }} />
      )}
    </AbsoluteFill>
  );
};

export const Main: React.FC = () => (
  <AbsoluteFill style={{ background: theme.colors.bg, fontFamily: theme.fonts.main }}>
    <BgMesh />
    {SCENES.map((s, k) => {
      const C = SCENE_COMPONENTS[k];
      return (
        <Sequence key={k} from={s.from} durationInFrames={s.to - s.from}>
          <C />
        </Sequence>
      );
    })}
    {SCENES.slice(1).map((s, i) => (
      <Sequence key={`w${i}`} from={s.from - 7} durationInFrames={14}>
        <Wipe />
      </Sequence>
    ))}
    <Grade />
    <Grain />
    <Vignette />
    <SfxTrack events={[s0, s1, s2, s3, s4, s5]} />
    <PreviewAudio />
  </AbsoluteFill>
);
