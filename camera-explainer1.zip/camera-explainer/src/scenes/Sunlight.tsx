import React from "react";
import { interpolate, spring, useCurrentFrame, useVideoConfig } from "remotion";
import { theme } from "../theme";
import { beat } from "../cues";
import { Apple, CameraSide, Eye } from "../art/Art";
import { Ray, prog, Pt } from "../draw";
import { Label, Sfx, WordReveal } from "../components/Common";

const c = theme.colors;
const APPLE = { x: 700, y: 560, r: 112 };
const SUN = { x: 250, y: 190 };
const EYE = { x: 1560, y: 330, s: 1.15 };
const CAM = { x: 1230, y: 560, s: 1.1 };
const PUPIL = { x: EYE.x - 34 * EYE.s, y: EYE.y };
const GLASS = { x: CAM.x + 24 * CAM.s, y: CAM.y + 150 * CAM.s };

export const Sunlight: React.FC<{ from: number }> = ({ from }) => {
  const frame = useCurrentFrame();
  const { fps } = useVideoConfig();
  const tApple = beat(from, 3);
  const tSun = beat(from, 3, "সূর্যের আলো");
  const tRefl = beat(from, 3, "প্রতিফলিত");
  const tEye = beat(from, 4, "আপনার চোখে");
  const tCam = beat(from, 4, "ক্যামেরার ক্ষেত্রেও");

  const pApple = spring({ frame: frame - tApple, fps, config: theme.spring.smooth });
  const pSun = spring({ frame: frame - tSun, fps, config: theme.spring.bouncy });
  const pEye = spring({ frame: frame - tEye, fps, config: theme.spring.smooth });
  const pCam = spring({ frame: frame - tCam, fps, config: theme.spring.smooth });
  const float = Math.sin(frame / 30) * 4;
  const lit = interpolate(frame, [tSun + 18, tSun + 34], [0, 1], { easing: theme.ease.out, extrapolateLeft: "clamp", extrapolateRight: "clamp" });

  // sunlight → apple (incoming, parallel-ish)
  const sunRays: Pt[][] = [-2, -1, 0, 1, 2].map((k) => {
    const a = Math.atan2(APPLE.y - SUN.y, APPLE.x - SUN.x);
    const px = Math.cos(a + Math.PI / 2), py = Math.sin(a + Math.PI / 2);
    const target = { x: APPLE.x - 92 * Math.cos(a) + k * 30 * px * 0.9, y: APPLE.y - 92 * Math.sin(a) + k * 30 * py * 0.9 };
    return [{ x: SUN.x + 78 * Math.cos(a) + k * 30 * px, y: SUN.y + 78 * Math.sin(a) + k * 30 * py }, target];
  });
  // reflected light: apple → eye and apple → camera
  const toEye: Pt[][] = [-2, -1, 0, 1, 2].map((k) => [
    { x: APPLE.x + 82 + k * 4, y: APPLE.y - 40 + k * 18 },
    { x: PUPIL.x + 4, y: PUPIL.y + k * 5 },
  ]);
  const toCam: Pt[][] = [-2, -1, 0, 1, 2].map((k) => [
    { x: APPLE.x + 86 + k * 2, y: APPLE.y + 30 + k * 16 },
    { x: GLASS.x - 4, y: GLASS.y + k * 26 },
  ]);
  const scatter: Pt[][] = [-110, -70, -40, 180, 205, -150].map((deg) => {
    const th = (deg * Math.PI) / 180;
    return [{ x: APPLE.x + 100 * Math.cos(th), y: APPLE.y + 100 * Math.sin(th) }, { x: APPLE.x + 250 * Math.cos(th), y: APPLE.y + 250 * Math.sin(th) }];
  });

  return (
    <>
      <svg width={1920} height={1080} style={{ position: "absolute", inset: 0 }}>
        {/* sun */}
        <g transform={`translate(${SUN.x} ${SUN.y}) scale(${pSun})`} opacity={pSun}>
          {Array.from({ length: 12 }).map((_, i) => (
            <line key={i} x1={Math.cos((i * Math.PI) / 6) * 62} y1={Math.sin((i * Math.PI) / 6) * 62} x2={Math.cos((i * Math.PI) / 6) * 82} y2={Math.sin((i * Math.PI) / 6) * 82} stroke={c.accent} strokeWidth={6} strokeLinecap="round" transform={`rotate(${frame * 0.4})`} />
          ))}
          <circle r={48} fill={c.accent} />
        </g>
        {sunRays.map((pts, i) => (
          <Ray key={"s" + i} pts={pts} p={prog(frame, tSun + 6 + i * 3, 20)} frame={frame} phase={i * 0.2} opacity={0.55} />
        ))}
        {/* apple */}
        <g transform={`translate(${APPLE.x} ${APPLE.y + float}) scale(${interpolate(pApple, [0, 1], [0.7, 1])})`} opacity={pApple}>
          <Apple r={APPLE.r} glow={0.2 + lit * 0.5} id="s-ap" />
        </g>
        {/* reflected light scattering off the apple */}
        {scatter.map((pts, i) => (
          <Ray key={"sc" + i} pts={pts} p={prog(frame, tRefl + i * 3, 16)} frame={frame} packet={false} opacity={0.3} width={2} />
        ))}
        {toEye.map((pts, i) => (
          <Ray key={"e" + i} pts={pts} p={prog(frame, tRefl + 6 + i * 3, 26)} frame={frame} phase={i * 0.13} opacity={0.5} />
        ))}
        {/* eye */}
        <g transform={`translate(${EYE.x} ${EYE.y}) scale(${EYE.s * interpolate(pEye, [0, 1], [0.8, 1])})`} opacity={pEye}>
          <Eye />
        </g>
        {/* camera — same thing happens */}
        <g transform={`translate(${CAM.x} ${CAM.y - 14 * (1 - pCam)}) scale(${CAM.s})`} opacity={pCam}>
          <CameraSide glass={pCam} />
        </g>
        {toCam.map((pts, i) => (
          <Ray key={"c" + i} pts={pts} p={prog(frame, tCam + 8 + i * 3, 26)} frame={frame} phase={i * 0.11} opacity={0.5} />
        ))}
      </svg>
      <Label text="সূর্যের আলো" x={SUN.x} y={SUN.y - 112} delay={tSun + 6} />
      <Label text="লাল আপেল" x={APPLE.x} y={APPLE.y + 170} delay={tApple + 6} />
      <Label text="প্রতিফলিত আলো" x={1040} y={APPLE.y - 205} delay={tRefl + 8} color={c.accent} />
      <Label text="আপনার চোখ" x={EYE.x} y={EYE.y - 100} delay={tEye + 8} />
      <Label text="Camera" x={CAM.x + 230} y={CAM.y + 330} delay={tCam + 10} />
      <div style={{ position: "absolute", left: 110, bottom: 80 }}>
        {frame >= tCam - 2 && <WordReveal text="ক্যামেরার ক্ষেত্রেও *একই* ঘটনা" delay={tCam + 2} size={70} hi={c.primary} />}
      </div>
      <Sfx name="pop" at={tApple} vol={0.26} />
      <Sfx name="chime" at={tSun} vol={0.24} />
      <Sfx name="whoosh" at={tRefl} vol={0.24} />
      <Sfx name="pop" at={tEye} vol={0.26} rate={1.06} />
      <Sfx name="pop" at={tCam} vol={0.28} rate={0.94} />
    </>
  );
};
