import React from "react";
import { interpolate, spring, useCurrentFrame, useVideoConfig } from "remotion";
import { theme } from "../theme";
import { beat } from "../cues";
import { Apple, SensorPlate } from "../art/Art";
import { Ray, prog, Pt } from "../draw";
import { Label, Sfx, WordReveal } from "../components/Common";

const c = theme.colors;
const APPLE = { x: 520, y: 700, r: 104 };
const SENSOR = { x: 1330, y: 700, h: 440 };
const PANEL = { x: 1560, y: 490, w: 300, h: 420 };

export const Problem: React.FC<{ from: number }> = ({ from }) => {
  const frame = useCurrentFrame();
  const { fps } = useVideoConfig();
  const tHead = beat(from, 5);
  const tSpread = beat(from, 5, "অসংখ্য দিকে");
  const tSensor = beat(from, 6, "sensor");
  const tPanel = beat(from, 6, "ফেলা হয়");
  const tResult = beat(from, 6, "পরিষ্কার ছবি");

  const pApple = spring({ frame: frame - 2, fps, config: theme.spring.smooth });
  const pSensor = spring({ frame: frame - tSensor, fps, config: theme.spring.smooth });
  const pPanel = spring({ frame: frame - tPanel, fps, config: theme.spring.smooth });
  const pX = spring({ frame: frame - (tResult + 4), fps, config: theme.spring.bouncy });
  const float = Math.sin(frame / 28) * 4;

  // omnidirectional rays — 36 rays, revealed in groups (3 per 3 frames)
  const fan: Pt[][] = Array.from({ length: 36 }).map((_, i) => {
    const th = (i / 36) * Math.PI * 2 + 0.05;
    const len = (230 + ((i * 53) % 5) * 34) * (0.55 + 0.45 * Math.abs(Math.cos(th)));
    return [
      { x: APPLE.x + (APPLE.r - 4) * Math.cos(th), y: APPLE.y + (APPLE.r - 4) * Math.sin(th) },
      { x: APPLE.x + (APPLE.r - 4 + len) * Math.cos(th), y: APPLE.y + (APPLE.r - 4 + len) * Math.sin(th) },
    ];
  });
  // cross-hatch: every apple point reaches every sensor point (no lens)
  const srcY = [-62, 0, 62];
  const dstY = [-190, -95, 0, 95, 190];
  const cross: Pt[][] = [];
  srcY.forEach((sy) => dstY.forEach((dy) => cross.push([{ x: APPLE.x + 80, y: APPLE.y + sy * 0.9 }, { x: SENSOR.x - 18, y: SENSOR.y + dy }])));

  const fanFade = interpolate(frame, [tSensor - 6, tSensor + 10], [1, 0.12], { easing: theme.ease.inOut, extrapolateLeft: "clamp", extrapolateRight: "clamp" });

  return (
    <>
      <svg width={1920} height={1080} style={{ position: "absolute", inset: 0 }}>
        <defs>
          <filter id="smear" x="-50%" y="-50%" width="200%" height="200%"><feGaussianBlur stdDeviation="46" /></filter>
          <clipPath id="panel-clip"><rect x={PANEL.x} y={PANEL.y} width={PANEL.w} height={PANEL.h} rx={26} /></clipPath>
        </defs>
        <g opacity={fanFade}>
          {fan.map((pts, i) => (
            <Ray key={i} pts={pts} p={prog(frame, tSpread + Math.floor(i / 3) * 3, 22)} frame={frame} packet={i % 4 === 0} pulses={1} phase={i * 0.07} opacity={0.42} width={2.2} />
          ))}
        </g>
        <g transform={`translate(${APPLE.x} ${APPLE.y + float}) scale(${interpolate(pApple, [0, 1], [0.7, 1])})`} opacity={pApple}>
          <Apple r={APPLE.r} glow={0.4} id="p-ap" />
        </g>
        {cross.map((pts, i) => (
          <Ray key={"x" + i} pts={pts} p={prog(frame, tSensor + 4 + (i % 5) * 2, 24)} frame={frame} packet={false} opacity={0.34} width={2} />
        ))}
        <g transform={`translate(${SENSOR.x} ${SENSOR.y})`} opacity={pSensor}>
          <SensorPlate h={SENSOR.h} />
        </g>
        {/* result panel: what the sensor "sees" with uncontrolled light */}
        <g opacity={pPanel} transform={`translate(0 ${(1 - pPanel) * 30})`}>
          <rect x={PANEL.x} y={PANEL.y} width={PANEL.w} height={PANEL.h} rx={26} fill={c.bgAlt} stroke={c.line} strokeWidth={3} />
          <g clipPath="url(#panel-clip)">
            <g transform={`translate(${PANEL.x + PANEL.w / 2} ${PANEL.y + PANEL.h / 2 - 20})`} filter="url(#smear)" opacity={0.95}>
              <ellipse rx={150} ry={170} fill={c.apple} opacity={0.75} />
              <circle r={80} fill={c.appleLight} opacity={0.5} />
            </g>
          </g>
          <g transform={`translate(${PANEL.x + PANEL.w - 6} ${PANEL.y + 6}) scale(${pX})`}>
            <circle r={36} fill={c.bgAlt} stroke={c.appleLight} strokeWidth={4} />
            <path d="M-14 -14 L14 14 M14 -14 L-14 14" stroke={c.appleLight} strokeWidth={6} strokeLinecap="round" />
          </g>
        </g>
      </svg>
      <div style={{ position: "absolute", left: 110, top: 70 }}>
        <WordReveal text="*সমস্যা*" delay={tHead} size={168} hi={c.accent} />
      </div>
      <div style={{ position: "absolute", left: 120, top: 270 }}>
        {frame >= tSpread - 2 && <WordReveal text="আলো ছড়িয়ে পড়ে অসংখ্য দিকে" delay={tSpread} size={58} color={c.textDim} weight={500} />}
      </div>
      <Label text="sensor" x={SENSOR.x} y={SENSOR.y + 270} delay={tSensor + 8} />
      <Label text="পরিষ্কার ছবি নেই" x={PANEL.x + PANEL.w / 2} y={PANEL.y + PANEL.h + 54} delay={tResult + 2} color={c.appleLight} />
      <Sfx name="pop" at={tHead + 2} vol={0.3} />
      <Sfx name="whoosh" at={tSpread} vol={0.26} />
      <Sfx name="pop" at={tSensor} vol={0.26} rate={1.05} />
      <Sfx name="pop" at={tPanel} vol={0.24} rate={0.95} />
      <Sfx name="click" at={tResult + 6} vol={0.3} />
    </>
  );
};
