import React from "react";
import {AbsoluteFill, useCurrentFrame} from "remotion";
import {theme} from "../theme";

// Layer 1: animated mesh + faint blueprint grid (never a flat background)
export const BgMesh: React.FC = () => {
  const frame = useCurrentFrame();
  const d1 = Math.sin(frame / 55) * 50;
  const d2 = Math.cos(frame / 70) * 40;
  return (
    <AbsoluteFill style={{background: theme.colors.bg}}>
      <div
        style={{
          position: "absolute",
          width: 1300,
          height: 1300,
          borderRadius: "50%",
          top: -520,
          left: -340 + d1,
          filter: "blur(60px)",
          background: `radial-gradient(circle, rgba(${theme.rgb.primary},0.20), transparent 62%)`,
        }}
      />
      <div
        style={{
          position: "absolute",
          width: 1000,
          height: 1000,
          borderRadius: "50%",
          bottom: -480,
          right: -260 - d2,
          filter: "blur(70px)",
          background: `radial-gradient(circle, rgba(${theme.rgb.accent},0.09), transparent 65%)`,
        }}
      />
      <AbsoluteFill
        style={{
          backgroundImage: `linear-gradient(rgba(${theme.rgb.primary},0.05) 1px, transparent 1px), linear-gradient(90deg, rgba(${theme.rgb.primary},0.05) 1px, transparent 1px)`,
          backgroundSize: "64px 64px",
          backgroundPosition: `${frame * 0.15}px ${frame * 0.1}px`,
        }}
      />
    </AbsoluteFill>
  );
};

// Layer 4: color grade
export const Grade: React.FC = () => (
  <AbsoluteFill style={{pointerEvents: "none"}}>
    <AbsoluteFill
      style={{backgroundColor: theme.colors.primary, mixBlendMode: "soft-light", opacity: 0.12}}
    />
    <AbsoluteFill
      style={{
        background:
          "linear-gradient(180deg, rgba(0,0,0,0.10), transparent 28%, transparent 72%, rgba(0,0,0,0.18))",
      }}
    />
  </AbsoluteFill>
);

// Layer 5: grain + vignette
const noise = `url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='220' height='220'%3E%3Cfilter id='n'%3E%3CfeTurbulence type='fractalNoise' baseFrequency='0.9' numOctaves='2'/%3E%3C/filter%3E%3Crect width='220' height='220' filter='url(%23n)' opacity='0.5'/%3E%3C/svg%3E")`;
export const Grain: React.FC = () => {
  const frame = useCurrentFrame();
  return (
    <AbsoluteFill
      style={{
        pointerEvents: "none",
        backgroundImage: noise,
        backgroundSize: "220px",
        backgroundPosition: `${(frame * 7) % 220}px ${(frame * 13) % 220}px`,
        opacity: 0.04,
        mixBlendMode: "overlay",
      }}
    />
  );
};
export const Vignette: React.FC = () => (
  <AbsoluteFill
    style={{
      pointerEvents: "none",
      background: "radial-gradient(ellipse at center, transparent 58%, rgba(0,0,0,0.22) 100%)",
    }}
  />
);
