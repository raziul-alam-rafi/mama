import React from "react";
import { theme } from "../theme";

const c = theme.colors;
/** Shared SVG gradients + filters. Ids are identical in every scene (safe when scenes overlap). */
export const Defs: React.FC = () => (
  <defs>
    <linearGradient id="gAmber" x1="0" y1="1" x2="0" y2="0">
      <stop offset="0" stopColor={c.accentDeep} />
      <stop offset="1" stopColor={c.accent} />
    </linearGradient>
    <linearGradient id="gBlue" x1="0" y1="1" x2="0" y2="0">
      <stop offset="0" stopColor={c.primaryDeep} />
      <stop offset="1" stopColor={c.primary} />
    </linearGradient>
    <linearGradient id="gPanel" x1="0" y1="0" x2="0" y2="1">
      <stop offset="0" stopColor={c.panel2} />
      <stop offset="1" stopColor={c.panel} />
    </linearGradient>
    <linearGradient id="gSheen" x1="0" y1="0" x2="0" y2="1">
      <stop offset="0" stopColor="#fff" stopOpacity="0.16" />
      <stop offset="0.5" stopColor="#fff" stopOpacity="0.02" />
      <stop offset="1" stopColor="#fff" stopOpacity="0" />
    </linearGradient>
    <filter id="fGlow" x="-50%" y="-50%" width="200%" height="200%">
      <feGaussianBlur stdDeviation="8" result="b" />
      <feMerge><feMergeNode in="b" /><feMergeNode in="SourceGraphic" /></feMerge>
    </filter>
    <filter id="fSoftGlow" x="-80%" y="-80%" width="260%" height="260%">
      <feGaussianBlur stdDeviation="14" />
    </filter>
    <filter id="fShadow" x="-30%" y="-30%" width="160%" height="170%">
      <feDropShadow dx="0" dy="18" stdDeviation="16" floodColor="#000" floodOpacity="0.45" />
    </filter>
  </defs>
);
