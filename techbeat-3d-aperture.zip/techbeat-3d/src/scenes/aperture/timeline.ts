// Single source of truth for the aperture explainer's timing (seconds).
// Visuals AND audio read from here so they cannot drift apart.
// Phrase boundaries are ESTIMATED from the SRT (3 long cues, no audio supplied).
// If the real voiceover differs, edit ONLY the numbers in this file.
import { Key } from "../../lib/ease";
import { CamKey } from "../../lib/camera";

export const T = {
  assembleStart: 0.4, assembleEnd: 2.2, // exploded parts slide together
  cutawayStart: 2.5, cutawayEnd: 4.5, // barrel turns see-through, camera pushes in
  irisHighlightStart: 4.3, irisHighlightEnd: 6.9,
  raysOn: 7.0, // "আলো যাওয়ার পথ"
  rayRevealDur: 1.6,
  bigStart: 12.16, bigEnd: 15.2, // "Aperture বড় হলে বেশি আলো"
  smallStart: 15.3, // "ছোট হলে কম আলো"
};

export const IRIS_MIN = 0.3;
export const IRIS_MAX = 1.0;
/** Iris opening circumradius (world units) over time. 1.4 s per full blade travel. */
export const IRIS_KEYS: Key[] = [
  { t: 0, v: 0.62 }, { t: 9.0, v: 0.62 },
  { t: 10.4, v: IRIS_MIN }, // "ছোট" — closes
  { t: 11.8, v: IRIS_MAX }, // "বড়" — opens
  { t: 15.2, v: IRIS_MAX },
  { t: 16.6, v: IRIS_MIN }, // small aperture → less light
  { t: 99, v: IRIS_MIN },
];
export const IRIS_MOVES: [number, number][] = [[9.0, 10.4], [10.4, 11.8], [15.2, 16.6]];

export const CAM_KEYS: CamKey[] = [
  { t: 0.0, pos: [-7.5, 3.2, 10.5], look: [0.5, 0, 0], fov: 38 }, // establishing, 3/4 view
  { t: 2.5, pos: [-6.5, 2.6, 9.0], look: [0.5, 0, 0], fov: 38 },
  { t: 4.6, pos: [-3.4, 1.4, 4.8], look: [0, 0, 0], fov: 36 }, // push in: iris seen through glass
  { t: 6.9, pos: [-3.4, 1.4, 4.8], look: [0, 0, 0], fov: 36 }, // hold
  { t: 8.4, pos: [-0.6, 1.6, 13.2], look: [0.4, 0, 0], fov: 38 }, // pull back to side: light path
  { t: 12.2, pos: [-0.4, 1.3, 12.2], look: [0.8, 0, 0], fov: 38 },
  { t: 15.3, pos: [0.6, 1.2, 12.0], look: [1.2, 0, 0], fov: 38 },
  { t: 18.8, pos: [1.0, 1.1, 11.4], look: [1.4, 0, 0], fov: 38 }, // slow drift to the end
];

export const SPEECH_CUES_SEC = (cues: { start: number; end: number }[]) => cues.map((c) => [c.start, c.end] as const);
