// beats.ts — scene-local trigger frames (single source for visuals AND sound effects).
import { cue, localFrame, phraseMs, scenes, sec } from "./timing";

const [sHook, sCompare, sArray, sOrbit, sQuestion] = scenes;

export const hook = (() => {
  const t0 = localFrame(sHook, cue(1).start);
  return { s: sHook, t0, beam: t0 + 6, lit: t0 + 16, sub: localFrame(sHook, phraseMs(1, "কোনো কিছুর")) };
})();

export const compare = (() => {
  const t0 = localFrame(sCompare, cue(2).start);
  const tK = localFrame(sCompare, phraseMs(2, "কিন্তু"));
  return { s: sCompare, t0, tK, capL: t0 + 8, capR: tK + 10 };
})();

export const array = (() => {
  const t3 = localFrame(sArray, cue(3).start);
  const t4 = localFrame(sArray, cue(4).start);
  const tTitle = localFrame(sArray, phraseMs(3, "ছোট ছোট"));
  const tSig = localFrame(sArray, phraseMs(3, "signal-এর"));
  return { s: sArray, t3, t4, tTitle, tSig, beam: t4 + 6, title2: t4 + 3 };
})();

export const orbit = (() => {
  const t5 = localFrame(sOrbit, cue(5).start);
  const t6 = localFrame(sOrbit, cue(6).start);
  return {
    s: sOrbit,
    t5,
    t6,
    line2: localFrame(sOrbit, phraseMs(5, "এটি")),
    h6a: localFrame(sOrbit, phraseMs(6, "দ্রুত")),
    h6b: localFrame(sOrbit, phraseMs(6, "তাল মিলিয়ে")),
    lock: t6 + sec(0.9),
  };
})();

export const question = (() => {
  const t7 = localFrame(sQuestion, cue(7).start);
  const t8 = localFrame(sQuestion, cue(8).start);
  return {
    s: sQuestion,
    t7,
    t8,
    tQ: localFrame(sQuestion, phraseMs(7, "প্রশ্ন")),
    tTitle: localFrame(sQuestion, phraseMs(7, "এত দ্রুত")),
    tPath: localFrame(sQuestion, phraseMs(7, "থেকে")),
    tDevice: localFrame(sQuestion, phraseMs(7, "device-এ")),
  };
})();

// ---- SFX plan: only main entries, reveals and scene transitions -------------------------
export type SfxEvent = { frame: number; file: string; volume: number; rate?: number; length: number };

const ev = (s: { from: number }, local: number, file: string, volume: number, rate = 1, length = 22): SfxEvent => ({
  frame: Math.max(0, s.from + local - 2), // starts 2 frames before the visual lands
  file,
  volume,
  rate,
  length,
});

export const sfxEvents: SfxEvent[] = [
  // hook
  ev(hook.s, hook.t0, "thud", 0.3, 1, 14),
  ev(hook.s, hook.lit, "pop", 0.28, 1, 10),
  // compare
  ev(compare.s, 0, "swipe", 0.26, 1, 16),
  ev(compare.s, compare.t0 + 2, "pop", 0.28, 1, 10),
  ev(compare.s, compare.tK, "pop", 0.3, 1.08, 10),
  // phased array
  ev(array.s, 0, "swipe", 0.26, 0.96, 16),
  ev(array.s, array.tTitle, "whoosh", 0.24, 1, 20),
  ev(array.s, array.t4 + 2, "click", 0.3, 1, 6),
  ev(array.s, array.beam + 4, "chime", 0.24, 1, 16),
  // orbit
  ev(orbit.s, 0, "swipe", 0.26, 1.05, 16),
  ev(orbit.s, orbit.t5 + 2, "whoosh", 0.22, 0.95, 20),
  ev(orbit.s, orbit.t6 + 4, "pop", 0.28, 0.94, 10),
  ev(orbit.s, orbit.lock, "chime", 0.24, 1.12, 16),
  // question
  ev(question.s, 0, "swipe", 0.26, 0.98, 16),
  ev(question.s, question.tDevice, "pop", 0.28, 1.04, 10),
  ev(question.s, question.t8, "thud", 0.32, 0.92, 14),
];
