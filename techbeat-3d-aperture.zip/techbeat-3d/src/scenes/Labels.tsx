import React from "react";
import { spring } from "remotion";
import { theme } from "../theme";
import { seg } from "../lib/ease";

export interface LabelDef {
  from: number; to: number; text: string;
  kind: "title" | "tag" | "card";
  anchor?: [number, number]; // projected pixel position (tags)
  x?: number; y?: number; // fixed pixel position (title/card)
  hero?: boolean;
}

/** Enter: spring (opacity + translateY + scale). Exit: faster (0.25 s). */
export const Label: React.FC<{ def: LabelDef; t: number; fps: number; font: string }> = ({ def, t, fps, font }) => {
  if (t < def.from || t > def.to) return null;
  const p = spring({ frame: Math.round((t - def.from) * fps), fps, config: theme.spring.snappy });
  const out = 1 - seg(t, def.to - 0.25, def.to, theme.ease.in);
  const op = Math.min(1, p) * out;
  const common: React.CSSProperties = {
    position: "absolute", fontFamily: font, color: theme.colors.text, opacity: op,
    transform: `translateY(${(1 - p) * 24}px) scale(${0.92 + 0.08 * p})`, whiteSpace: "nowrap",
  };

  if (def.kind === "title") {
    return (
      <div style={{ ...common, left: def.x, top: def.y, fontSize: 140, fontWeight: 700, letterSpacing: "-0.03em", lineHeight: 1.05, textShadow: "0 6px 40px rgba(0,0,0,0.5)" }}>
        {def.text}
      </div>
    );
  }
  if (def.kind === "card") {
    return (
      <div style={{ ...common, left: 0, right: 0, top: def.y, display: "flex", justifyContent: "center" }}>
        <div style={{ padding: "22px 44px", fontSize: 58, fontWeight: 700, borderRadius: 22,
          background: "rgba(11,16,32,0.78)", border: `2px solid ${theme.colors.primary}`, boxShadow: `0 10px 50px rgba(0,0,0,0.45)` }}>
          {def.text}
        </div>
      </div>
    );
  }
  // tag with leader line to the anchored 3D point
  const [ax, ay] = def.anchor!;
  const LINE = 70;
  const x = Math.min(1920 - 140, Math.max(140, ax));
  const y = Math.min(1080 - 140, Math.max(160, ay));
  const accent = def.hero ? theme.colors.accent : theme.colors.primary;
  return (
    <div style={{ position: "absolute", left: 0, top: 0, opacity: op, fontFamily: font }}>
      <div style={{ position: "absolute", left: x - 1.5, top: y - LINE, width: 3, height: LINE, background: accent, transformOrigin: "bottom",
        transform: `scaleY(${p})` }} />
      <div style={{ position: "absolute", left: x - 8, top: y - 8, width: 16, height: 16, borderRadius: 8, background: accent }} />
      <div style={{ position: "absolute", left: x, top: y - LINE - 56, transform: `translateX(-50%) translateY(${(1 - p) * 16}px)`,
        padding: "8px 24px", fontSize: 40, fontWeight: 700, borderRadius: 14, color: theme.colors.text,
        background: "rgba(11,16,32,0.8)", border: `2px solid ${accent}`, whiteSpace: "nowrap" }}>
        {def.text}
      </div>
    </div>
  );
};
