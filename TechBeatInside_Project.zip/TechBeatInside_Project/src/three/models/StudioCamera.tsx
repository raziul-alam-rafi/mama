import React from 'react';
import * as THREE from 'three';
import {Beam, ContactShadow, RBox} from './parts';

type V3 = [number, number, number];

/**
 * Broadcast studio camera on a tripod, in the local frame +Z = lens direction.
 * Placed so the lens points toward -X (rotationY = -PI/2). Body centre ~1.55 m above ground.
 */
export const StudioCamera: React.FC<{position: V3; tally?: boolean}> = ({position, tally = true}) => {
  const paint = {color: '#24272d', roughness: 0.5, metalness: 0.35} as const;
  const rubber = {color: '#0d0d0f', roughness: 0.85, metalness: 0} as const;
  return (
    <group position={position} rotation={[0, -Math.PI / 2, 0]} name="Studio_Camera">
      <ContactShadow position={[0, 0.02, 0]} size={[3, 3]} />
      {/* tripod */}
      {[0, 120, 240].map((deg) => {
        const a = (deg * Math.PI) / 180;
        const foot: V3 = [Math.sin(a) * 0.8, 0.03, Math.cos(a) * 0.8 - 0.1];
        return (
          <React.Fragment key={deg}>
            <Beam a={[0, 1.18, -0.1]} b={foot} r={0.028}>
              <meshStandardMaterial color="#15171a" roughness={0.5} metalness={0.6} />
            </Beam>
            <mesh position={foot}>
              <sphereGeometry args={[0.04, 12, 8]} />
              <meshStandardMaterial {...rubber} />
            </mesh>
          </React.Fragment>
        );
      })}
      {/* head + wedge plate */}
      <mesh position={[0, 1.22, -0.1]}>
        <cylinderGeometry args={[0.12, 0.15, 0.1, 28]} />
        <meshStandardMaterial {...paint} />
      </mesh>
      {/* body */}
      <RBox size={[0.34, 0.36, 0.64]} radius={0.04} position={[0, 1.55, -0.12]} name="Camera_Body">
        <meshStandardMaterial {...paint} />
      </RBox>
      {/* rear electronics panel */}
      <RBox size={[0.3, 0.3, 0.05]} radius={0.01} position={[0, 1.55, -0.46]}>
        <meshStandardMaterial color="#17191d" roughness={0.6} metalness={0.4} />
      </RBox>
      <mesh position={[0.07, 1.5, -0.5]} rotation={[Math.PI / 2, 0, 0]} name="Signal_Cable_Connector">
        <cylinderGeometry args={[0.03, 0.03, 0.06, 18]} />
        <meshStandardMaterial color="#b8b8b8" metalness={1} roughness={0.25} />
      </mesh>
      {/* lens barrels */}
      <mesh position={[0, 1.57, 0.5]} rotation={[Math.PI / 2, 0, 0]} name="Lens_Barrel_1">
        <cylinderGeometry args={[0.135, 0.135, 0.46, 40]} />
        <meshStandardMaterial {...paint} />
      </mesh>
      <mesh position={[0, 1.57, 0.92]} rotation={[Math.PI / 2, 0, 0]} name="Lens_Barrel_2">
        <cylinderGeometry args={[0.165, 0.165, 0.4, 40]} />
        <meshStandardMaterial color="#1d2025" roughness={0.45} metalness={0.45} />
      </mesh>
      {[0.64, 0.8, 1.02].map((z, i) => (
        <mesh key={i} position={[0, 1.57, z]} rotation={[Math.PI / 2, 0, 0]}>
          <cylinderGeometry args={[0.172, 0.172, 0.07, 48]} />
          <meshStandardMaterial {...rubber} />
        </mesh>
      ))}
      {/* lens hood */}
      <mesh position={[0, 1.57, 1.28]} rotation={[Math.PI / 2, 0, 0]}>
        <cylinderGeometry args={[0.27, 0.185, 0.34, 56, 1, true]} />
        <meshStandardMaterial color="#080809" roughness={0.9} side={THREE.DoubleSide} />
      </mesh>
      {/* front glass elements */}
      <mesh position={[0, 1.57, 1.125]} name="Lens_Front_Element">
        <circleGeometry args={[0.15, 48]} />
        <meshPhysicalMaterial
          color="#0a1424"
          roughness={0.03}
          metalness={0.2}
          clearcoat={1}
          clearcoatRoughness={0.02}
          iridescence={1}
          iridescenceIOR={1.6}
          envMapIntensity={2.2}
        />
      </mesh>
      {[0.1, 0.125].map((r, i) => (
        <mesh key={i} position={[0, 1.57, 1.126 + i * 0.0006]} rotation={[0, 0, 0]}>
          <ringGeometry args={[r - 0.004, r, 48]} />
          <meshBasicMaterial color={i ? '#2b3b78' : '#6a2f86'} transparent opacity={0.5} />
        </mesh>
      ))}
      {/* viewfinder */}
      <RBox size={[0.22, 0.17, 0.3]} radius={0.03} position={[0.02, 1.84, -0.02]}>
        <meshStandardMaterial {...paint} />
      </RBox>
      <mesh position={[0.02, 1.84, -0.2]} rotation={[Math.PI / 2, 0, 0]}>
        <cylinderGeometry args={[0.1, 0.12, 0.1, 28, 1, true]} />
        <meshStandardMaterial {...rubber} side={THREE.DoubleSide} />
      </mesh>
      {/* top handle */}
      <Beam a={[-0.1, 1.74, 0.12]} b={[-0.1, 1.74, -0.3]} r={0.017}>
        <meshStandardMaterial {...paint} />
      </Beam>
      {/* tally light */}
      <mesh position={[0, 1.75, 0.3]}>
        <sphereGeometry args={[0.018, 12, 10]} />
        <meshBasicMaterial color={tally ? '#ff2a1c' : '#3a0a08'} toneMapped={false} />
      </mesh>
      {/* pan bar */}
      <Beam a={[0.1, 1.2, -0.12]} b={[0.35, 1.0, -0.95]} r={0.016}>
        <meshStandardMaterial {...paint} />
      </Beam>
      <mesh position={[0.35, 1.0, -0.95]}>
        <sphereGeometry args={[0.03, 12, 10]} />
        <meshStandardMaterial {...rubber} />
      </mesh>
    </group>
  );
};
