// Deterministic SFX synthesizer -> public/sfx/*.wav (16-bit, 44.1kHz, mono)
// Soft, short, modern UI sounds. No music, no voice.
import fs from "node:fs";
import path from "node:path";

const SR = 44100;
const OUT = path.resolve("public/sfx");
fs.mkdirSync(OUT, { recursive: true });

// seeded noise (deterministic)
let seed = 1337;
const rnd = () => {
  seed = (seed * 1664525 + 1013904223) >>> 0;
  return seed / 4294967296 * 2 - 1;
};

const buf = (sec) => new Float32Array(Math.ceil(sec * SR));
const lowpass = (x, fc) => {
  const a = 1 - Math.exp((-2 * Math.PI * fc) / SR);
  let y = 0;
  for (let i = 0; i < x.length; i++) { y += a * (x[i] - y); x[i] = y; }
  return x;
};
const highpass = (x, fc) => {
  const a = Math.exp((-2 * Math.PI * fc) / SR);
  let py = 0, px = 0;
  for (let i = 0; i < x.length; i++) {
    const y = a * (py + x[i] - px);
    px = x[i]; py = y; x[i] = y;
  }
  return x;
};
// RBJ band-pass biquad with time-varying centre frequency
const bandpassSweep = (x, f0, f1, q) => {
  let x1 = 0, x2 = 0, y1 = 0, y2 = 0;
  for (let i = 0; i < x.length; i++) {
    const t = i / x.length;
    const f = f0 * Math.pow(f1 / f0, t);
    const w = (2 * Math.PI * f) / SR;
    const alpha = Math.sin(w) / (2 * q);
    const b0 = alpha, b2 = -alpha, a0 = 1 + alpha;
    const a1 = -2 * Math.cos(w), a2 = 1 - alpha;
    const y = (b0 * x[i] + b2 * x2 - a1 * y1 - a2 * y2) / a0;
    x2 = x1; x1 = x[i]; y2 = y1; y1 = y; x[i] = y;
  }
  return x;
};
// very small reverb: two feedback combs, low mix
const tinyReverb = (x, mix = 0.12) => {
  const out = new Float32Array(x.length);
  const combs = [[0.0297, 0.28], [0.0371, 0.24]];
  out.set(x);
  for (const [d, g] of combs) {
    const n = Math.floor(d * SR);
    const c = new Float32Array(x.length);
    for (let i = 0; i < x.length; i++) {
      const fb = i >= n ? c[i - n] : 0;
      c[i] = x[i] + fb * g;
      out[i] += c[i] * mix;
    }
  }
  return out;
};
const normalize = (x, peak) => {
  let m = 0;
  for (const v of x) m = Math.max(m, Math.abs(v));
  const k = m > 0 ? peak / m : 1;
  for (let i = 0; i < x.length; i++) x[i] *= k;
  return x;
};
const fade = (x, inMs, outMs) => {
  const a = Math.floor((inMs / 1000) * SR), b = Math.floor((outMs / 1000) * SR);
  for (let i = 0; i < a && i < x.length; i++) x[i] *= i / a;
  for (let i = 0; i < b && i < x.length; i++) x[x.length - 1 - i] *= i / b;
  return x;
};

const sounds = {
  // soft pop: sine with fast downward pitch + small envelope
  pop() {
    const x = buf(0.22);
    let ph = 0;
    for (let i = 0; i < x.length; i++) {
      const t = i / SR;
      const f = 180 + 520 * Math.exp(-t * 38);
      ph += (2 * Math.PI * f) / SR;
      const env = (1 - Math.exp(-t * 900)) * Math.exp(-t * 20);
      x[i] = Math.sin(ph) * env;
    }
    return fade(lowpass(tinyReverb(x, 0.08), 5200), 1, 20);
  },
  // crisp click: high-passed short noise burst + tiny tonal tick
  click() {
    const x = buf(0.14);
    for (let i = 0; i < x.length; i++) {
      const t = i / SR;
      const n = rnd() * Math.exp(-t * 520);
      const tone = Math.sin(2 * Math.PI * 1900 * t) * Math.exp(-t * 420) * 0.5;
      x[i] = n + tone;
    }
    highpass(x, 1400);
    return fade(lowpass(tinyReverb(x, 0.06), 8000), 1, 25);
  },
  // gentle tick (quieter, higher) for timers
  tick() {
    const x = buf(0.1);
    for (let i = 0; i < x.length; i++) {
      const t = i / SR;
      x[i] = (rnd() * 0.6 + Math.sin(2 * Math.PI * 2600 * t)) * Math.exp(-t * 700);
    }
    highpass(x, 1800);
    return fade(lowpass(x, 7000), 1, 20);
  },
  // smooth whoosh: band-pass noise sweep with fade in/out
  whoosh() {
    const x = buf(0.62);
    for (let i = 0; i < x.length; i++) x[i] = rnd();
    bandpassSweep(x, 380, 2600, 0.9);
    for (let i = 0; i < x.length; i++) {
      const t = i / x.length;
      x[i] *= Math.pow(Math.sin(Math.PI * Math.pow(t, 0.8)), 1.6);
    }
    return fade(lowpass(tinyReverb(x, 0.1), 6000), 20, 120);
  },
  // soft chime/pluck with gentle overtones and short decay
  chime() {
    const x = buf(0.55);
    for (let i = 0; i < x.length; i++) {
      const t = i / SR;
      const env = (1 - Math.exp(-t * 700)) * Math.exp(-t * 7.5);
      const s =
        Math.sin(2 * Math.PI * 784 * t) +
        0.28 * Math.sin(2 * Math.PI * 1568 * t) * Math.exp(-t * 6) +
        0.1 * Math.sin(2 * Math.PI * 2352 * t) * Math.exp(-t * 11);
      x[i] = s * env;
    }
    return fade(lowpass(tinyReverb(x, 0.14), 6500), 2, 80);
  },
  // very soft thud for the hook (restrained)
  thud() {
    const x = buf(0.36);
    let ph = 0;
    for (let i = 0; i < x.length; i++) {
      const t = i / SR;
      const f = 48 + 70 * Math.exp(-t * 18);
      ph += (2 * Math.PI * f) / SR;
      const env = (1 - Math.exp(-t * 260)) * Math.exp(-t * 11);
      x[i] = Math.sin(ph) * env;
    }
    return fade(lowpass(x, 700), 4, 60);
  },
};

const report = [];
for (const [name, gen] of Object.entries(sounds)) {
  const x = normalize(gen(), 0.8); // common peak level for all sounds
  const pcm = Buffer.alloc(44 + x.length * 2);
  pcm.write("RIFF", 0); pcm.writeUInt32LE(36 + x.length * 2, 4); pcm.write("WAVE", 8);
  pcm.write("fmt ", 12); pcm.writeUInt32LE(16, 16); pcm.writeUInt16LE(1, 20);
  pcm.writeUInt16LE(1, 22); pcm.writeUInt32LE(SR, 24); pcm.writeUInt32LE(SR * 2, 28);
  pcm.writeUInt16LE(2, 32); pcm.writeUInt16LE(16, 34); pcm.write("data", 36);
  pcm.writeUInt32LE(x.length * 2, 40);
  let peak = 0, clipped = 0;
  for (let i = 0; i < x.length; i++) {
    const v = Math.max(-1, Math.min(1, x[i]));
    if (Math.abs(x[i]) >= 1) clipped++;
    peak = Math.max(peak, Math.abs(v));
    pcm.writeInt16LE(Math.round(v * 32767), 44 + i * 2);
  }
  fs.writeFileSync(path.join(OUT, `${name}.wav`), pcm);
  report.push({ name, sec: +(x.length / SR).toFixed(3), peak: +peak.toFixed(3), clipped });
}
console.table(report);
