import React from "react";
import {theme} from "../theme";
import {E} from "../events";
import {Pill, baseText, clamp01, lerp, useFx} from "../ui";
import {
  GridCells,
  PATCH_CELL,
  PATCH_TARGET,
  PATCH_ZOOM,
  cellCenter,
  lum,
  zoomTransform,
  FACE_X,
  FACE_Y,
  FACE_H,
} from "../components/sensor";

const WELL = 36 * PATCH_ZOOM; // 241.9 — identical to the zoomed cell from the previous scene
const PITCH = 40 * PATCH_ZOOM;
const COLS_IDX = [11, 12, 13];
const ROW = PATCH_CELL.r;
const WY = PATCH_TARGET.y;
const TOP = 150;
const SPEED = 9;

export const SceneLight: React.FC<{dur: number}> = ({dur}) => {
  const {frame, ramp, pop} = useFx();
  const ev = E.light;
  void dur;

  const patchC = cellCenter(PATCH_CELL.c, PATCH_CELL.r);
  const fade = ramp(ev.fadeNeighbors, 18);
  const wells = COLS_IDX.map((c, i) => ({
    c,
    i,
    cx: PATCH_TARGET.x + (c - PATCH_CELL.c) * PITCH,
    l: lum(c, ROW),
  }));
  const focus1 = frame >= ev.more;
  const focus3 = frame >= ev.less;
  const gaugeOpacity = [focus1 ? 1 : 0.55, focus1 && !focus3 ? 0.3 : 0.3, focus3 ? 1 : 0.3];
  gaugeOpacity[1] = frame >= ev.more ? 0.3 : 0.55;
  gaugeOpacity[0] = focus1 ? 1 : 0.55;
  gaugeOpacity[2] = focus3 ? 1 : frame >= ev.more ? 0.3 : 0.55;

  const cmp = ramp(ev.compare, 20, theme.ease.inOut);
  const cmpPop = pop(ev.compare + 8, theme.spring.bouncy);
  const gaugeY = WY + WELL / 2 + 38;

  return (
    <>
      <svg width={1920} height={1080} style={{position: "absolute", inset: 0}}>
        {/* the same mosaic zoom as the end of the previous scene */}
        <g transform={zoomTransform(PATCH_ZOOM, patchC, PATCH_TARGET)}>
          <rect x={FACE_X - 2} y={FACE_Y - 2} width={964} height={FACE_H + 4} rx={18} fill={theme.colors.panelDeep} stroke={theme.colors.panelEdge} strokeWidth={2} vectorEffect="non-scaling-stroke" />
          <GridCells
            fill={() => 1}
            opacity={(c, r) => (r === ROW && COLS_IDX.includes(c) ? 1 : 1 - fade)}
          />
        </g>

        {wells.map((w) => {
          const lanes = Math.round(3 + 8 * w.l);
          const start = ev.photons + w.i * 6;
          const on = clamp01((frame - start) / 14);
          const L = WY - WELL / 2 - TOP;
          const ringT = ramp(ev.detect + w.i * 8, 20);
          const g = Math.min(1, pop(ev.detect + w.i * 8 + 6, theme.spring.smooth)) * w.l;
          const barW = WELL;
          return (
            <g key={w.i}>
              {/* photons: more light = more photons */}
              {Array.from({length: lanes}).map((_, k) => {
                const x = w.cx - 100 + (k + 0.5) * (200 / lanes);
                const phase = (k * 137) % L;
                const t = (((frame - start) * SPEED + phase) % L + L) % L;
                const y = TOP + t;
                const a = clamp01(t / 40) * clamp01((L - t) / 30) * on;
                return (
                  <g key={k} opacity={a}>
                    <line x1={x} x2={x} y1={y - 28} y2={y} stroke={theme.colors.primary} strokeWidth={4} strokeLinecap="round" opacity={0.6} />
                    <circle cx={x} cy={y} r={5.5} fill={theme.colors.text} />
                  </g>
                );
              })}
              {/* detection ring */}
              {ringT > 0 && ringT < 1 && (
                <rect
                  x={w.cx - WELL / 2 - 22 * ringT}
                  y={WY - WELL / 2 - 22 * ringT}
                  width={WELL + 44 * ringT}
                  height={WELL + 44 * ringT}
                  rx={34 + 14 * ringT}
                  fill="none"
                  stroke={theme.colors.accent}
                  strokeWidth={4}
                  opacity={1 - ringT}
                />
              )}
              {/* response gauge */}
              <g opacity={gaugeOpacity[w.i] * ramp(ev.detect - 8, 12)}>
                <rect x={w.cx - barW / 2} y={gaugeY - 11} width={barW} height={22} rx={11} fill={theme.colors.panelDeep} stroke={theme.colors.panelEdge} strokeWidth={2} />
                <rect x={w.cx - barW / 2 + 3} y={gaugeY - 8} width={Math.max(0, (barW - 6) * g)} height={16} rx={8} fill={theme.colors.accent} />
              </g>
            </g>
          );
        })}

        {/* comparison bracket */}
        {cmp > 0.001 && <path
          d={`M ${wells[0].cx} ${gaugeY + 100} V ${gaugeY + 130} H ${wells[2].cx} V ${gaugeY + 100}`}
          fill="none"
          stroke={theme.colors.accent}
          strokeWidth={3}
          strokeLinecap="round"
          strokeLinejoin="round"
          pathLength={1}
          strokeDasharray={`${cmp} 2`}
        />}
      </svg>

      <div
        style={{
          ...baseText,
          position: "absolute",
          left: wells[0].cx - WELL / 2 - 210,
          top: gaugeY,
          transform: "translateY(-50%)",
          fontSize: 34,
          fontWeight: 600,
          color: theme.colors.textDim,
          opacity: ramp(ev.detect + 6, 14),
        }}
      >
        প্রতিক্রিয়া
      </div>

      <Pill x={wells[0].cx} y={gaugeY + 62} at={ev.more} text="বেশি আলো" tone="amber" size={36} />
      <Pill x={wells[2].cx} y={gaugeY + 62} at={ev.less} text="কম আলো" tone="light" size={36} />
      <div
        style={{
          ...baseText,
          position: "absolute",
          left: PATCH_TARGET.x,
          top: gaugeY + 130,
          transform: `translate(-50%, -50%) scale(${lerp(0.4, 1, Math.min(1.1, cmpPop))})`,
          opacity: Math.min(1, cmpPop),
          width: 70,
          height: 70,
          borderRadius: 999,
          background: theme.colors.bg,
          border: `3px solid ${theme.colors.accent}`,
          color: theme.colors.accent,
          fontSize: 46,
          fontWeight: 700,
          textAlign: "center",
          lineHeight: "62px",
        }}
      >
        ≠
      </div>
    </>
  );
};
