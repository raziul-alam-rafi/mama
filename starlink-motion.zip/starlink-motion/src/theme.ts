// theme.ts — single source of truth: colors, fonts, easings, spring presets.
// Colour scheme: "Torch Amber" (dark, warm). Components never inline hex values.
import { Easing } from "remotion";
import { loadFont } from "@remotion/google-fonts/HindSiliguri";

// Hind Siliguri: clean Bengali conjuncts + Latin. Loaded through @remotion/google-fonts.
const { fontFamily } = loadFont("normal", {
  weights: ["500", "600", "700"],
  subsets: ["bengali", "latin"],
});

export const theme = {
  colors: {
    bg: "#0D0B10",
    bgAlt: "#1A1520",
    surface: "#221C2A",
    surfaceHi: "#2E2638",
    border: "#FFF6E51F",
    primary: "#FFB020", // THE hero colour — one glowing element per frame
    accent: "#FF6B35",
    text: "#FFF6E5",
    textDim: "#FFF6E5A6",
    glow: "#FFB02073",
  },
  fonts: {
    display: `${fontFamily}, "Hind Siliguri", "Noto Sans Bengali", sans-serif`,
  },
  ease: {
    out: Easing.bezier(0.16, 1, 0.3, 1), // entrances
    inOut: Easing.bezier(0.83, 0, 0.17, 1), // big moves
    soft: Easing.bezier(0.45, 0, 0.55, 1), // gentle travel (satellite pass, sweeps)
    in: Easing.bezier(0.7, 0, 0.84, 0), // exits only
  },
  spring: {
    snappy: { damping: 14, stiffness: 160, mass: 0.6 },
    smooth: { damping: 20, stiffness: 90, mass: 1 },
    bouncy: { damping: 11, stiffness: 170, mass: 0.7 },
  },
  radius: { card: 36, pill: 999 },
  shadow: {
    card: "0 40px 80px -24px #000000A6",
    cardHero: "0 0 0 1.5px #FFB02066, 0 40px 80px -24px #000000A6",
  },
} as const;
