import React from 'react';
import {Composition} from 'remotion';
import {theme} from './theme';
import {PROTO_SECONDS} from './timeline';
import {ApertureProto} from './scenes/ApertureProto';
import {GlCheck} from './scenes/GlCheck';

const {width, height, fps} = theme.video;

export const RemotionRoot: React.FC = () => (
  <>
    <Composition id="ApertureProto" component={ApertureProto} durationInFrames={PROTO_SECONDS * fps} fps={fps} width={width} height={height} />
    <Composition id="GlCheck" component={GlCheck} durationInFrames={30} fps={fps} width={width} height={height} />
  </>
);
