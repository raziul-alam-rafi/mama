import React from "react";
import { theme, RGB } from "../theme";

/** exposure: আসল radiance × gain, 255-এ clip — ফলে উজ্জ্বল আকাশ সত্যিই সাদা হয় */
export const expose = (rgb: RGB, g: number) =>
  `rgb(${rgb.map((v) => Math.round(Math.min(255, Math.max(0, v * g)))).join(",")})`;

export const PHOTO_W = 640;
export const PHOTO_H = 360;
/** জানালার আয়তক্ষেত্র ও মুখের কেন্দ্র (ছবির নিজস্ব স্থানাঙ্কে) — callout-এর জন্য */
export const WIN = { x: 150, y: 28, w: 340, h: 236 };
export const FACE = { cx: 320, cy: 178, rx: 44, ry: 52 };
export const SUN = { cx: 420, cy: 95 };

/**
 * জানালার সামনে দাঁড়ানো মানুষের দৃশ্য।
 * gRoom = ঘরের ভেতরের (ছায়ার) অংশের exposure gain, gSky = জানালার বাইরের অংশের gain।
 * এক শটে দুটো সমান (g, g)। HDR-এ দুটো আলাদা অঞ্চল আলাদা ফ্রেম থেকে।
 */
export const PhotoContent: React.FC<{ uid: string; gRoom: number; gSky: number }> = ({ uid, gRoom, gSky }) => {
  const P = theme.photo;
  const r = (c: RGB) => expose(c, gRoom);
  const s = (c: RGB) => expose(c, gSky);
  return (
    <g>
      <defs>
        <linearGradient id={`${uid}-sky`} x1="0" y1="0" x2="0" y2="1">
          <stop offset="0" stopColor={s(P.skyTop)} />
          <stop offset="1" stopColor={s(P.skyBottom)} />
        </linearGradient>
        <radialGradient id={`${uid}-sun`}>
          <stop offset="0" stopColor={s(P.sun)} stopOpacity={1} />
          <stop offset="0.35" stopColor={s(P.sun)} stopOpacity={0.55} />
          <stop offset="1" stopColor={s(P.sun)} stopOpacity={0} />
        </radialGradient>
        <linearGradient id={`${uid}-wall`} x1="0" y1="0" x2="1" y2="0">
          <stop offset="0" stopColor={expose(P.wall, gRoom * 0.8)} />
          <stop offset="0.5" stopColor={r(P.wall)} />
          <stop offset="1" stopColor={expose(P.wall, gRoom * 0.75)} />
        </linearGradient>
        <clipPath id={`${uid}-win`}><rect x={WIN.x} y={WIN.y} width={WIN.w} height={WIN.h} /></clipPath>
      </defs>
      {/* ঘর */}
      <rect width={PHOTO_W} height={PHOTO_H} fill={`url(#${uid}-wall)`} />
      <rect y={300} width={PHOTO_W} height={60} fill={r(P.floor)} />
      {/* জানালার বাইরে */}
      <g clipPath={`url(#${uid}-win)`}>
        <rect x={WIN.x} y={WIN.y} width={WIN.w} height={WIN.h} fill={`url(#${uid}-sky)`} />
        <circle cx={SUN.cx} cy={SUN.cy} r={72} fill={`url(#${uid}-sun)`} />
        <circle cx={SUN.cx} cy={SUN.cy} r={24} fill={s(P.sun)} />
        <g fill={s(P.cloud)}>
          <ellipse cx={230} cy={92} rx={42} ry={14} /><ellipse cx={255} cy={80} rx={28} ry={14} /><ellipse cx={208} cy={85} rx={22} ry={11} />
          <ellipse cx={380} cy={150} rx={46} ry={13} /><ellipse cx={402} cy={140} rx={28} ry={12} />
        </g>
        <path d={`M${WIN.x} 214 C 200 188 250 196 300 208 C 360 190 420 196 ${WIN.x + WIN.w} 206 L ${WIN.x + WIN.w} 270 L ${WIN.x} 270 Z`} fill={s(P.hills)} />
        <path d={`M${WIN.x} 236 C 220 220 290 230 340 238 C 400 224 450 230 ${WIN.x + WIN.w} 240 L ${WIN.x + WIN.w} 270 L ${WIN.x} 270 Z`} fill={s(P.hills2)} />
      </g>
      {/* জানালার ফ্রেম */}
      <g fill="none" stroke={r(P.frame)}>
        <rect x={WIN.x} y={WIN.y} width={WIN.w} height={WIN.h} strokeWidth={10} />
        <line x1={320} y1={WIN.y} x2={320} y2={WIN.y + WIN.h} strokeWidth={7} />
        <line x1={WIN.x} y1={146} x2={WIN.x + WIN.w} y2={146} strokeWidth={7} />
      </g>
      <rect x={138} y={262} width={364} height={14} rx={3} fill={r(P.sill)} />
      {/* মানুষ */}
      <path d="M215 360 C 215 300 250 262 320 262 C 390 262 425 300 425 360 Z" fill={r(P.shirt)} />
      <rect x={302} y={222} width={36} height={46} rx={12} fill={r(P.neck)} />
      <ellipse cx={FACE.cx} cy={FACE.cy} rx={FACE.rx} ry={FACE.ry} fill={r(P.skin)} />
      <path d="M272 172 C 266 112 374 112 368 172 C 360 138 282 138 272 172 Z" fill={r(P.hair)} />
      <circle cx={305} cy={182} r={4.2} fill={r(P.eye)} /><circle cx={335} cy={182} r={4.2} fill={r(P.eye)} />
      <path d="M305 202 Q 320 213 335 202" fill="none" stroke={r(P.eye)} strokeWidth={3} strokeLinecap="round" />
    </g>
  );
};

/** স্বয়ংসম্পূর্ণ ছবি; width দিয়ে স্কেল (ভেক্টর, ঝাপসা হয় না) */
export const Photo: React.FC<{ uid: string; gRoom: number; gSky: number; width?: number; radius?: number; style?: React.CSSProperties }> =
({ uid, gRoom, gSky, width = PHOTO_W, radius = 18, style }) => (
  <svg viewBox={`0 0 ${PHOTO_W} ${PHOTO_H}`} width={width} height={(width * PHOTO_H) / PHOTO_W}
    style={{ display: "block", borderRadius: radius, ...style }}>
    <PhotoContent uid={uid} gRoom={gRoom} gSky={gSky} />
  </svg>
);

/** ফটোর গেইন প্রিসেট */
export const EXPO = { under: 0.26, mid: 0.5, over: 1.0, single: 0.6 } as const;
