import React from "react";
import { AbsoluteFill } from "remotion";
import { theme } from "../theme";
import { useScene } from "../SceneContext";
import { Chip, ip, mono, WordReveal, Entrance, clamp01 } from "../components/Motion";
import { FilmCamera } from "../components/FilmCamera";
import { Sfx } from "../components/Sfx";

const W = 1600, LEFT = 150, TOP = 205;
const px = (x: number, y: number) => ({ x: LEFT + ((x + 250) * W) / 1590, y: TOP + ((y + 360) * W) / 1590 });

// Scene 6 · Film camera shutter (cues 7–8): focal-plane curtains open → light reaches film → curtains close.
export const FilmShutter: React.FC = () => {
  const S = useScene();
  const f = S.frame;
  const c7 = Math.max(S.cue(7), 0);
  const fTitle = S.word(7, "Shutter");
  const fOld = S.word(7, "পুরনো");
  const fOpen = S.word(7, "খুলে");
  const fFilm = S.word(8, "ফিল্মের");
  const fClose = S.word(8, "বন্ধ");
  const fWin = S.word(8, "সময়টুকুর");
  const end = S.cueEnd(8) - 10;

  const assemble = ip(f, [c7 + 8, c7 + 70], [0, 1]);
  const p1 = ip(f, [fOpen - 4, fOpen + 24], [0, 1]);
  const p2 = ip(f, [fClose - 4, fClose + 24], [0, 1]);
  const prog = ip(f, [c7 + 66, c7 + 116], [0, 1], theme.ease.soft);

  // timeline: exposure window (open → close)
  const tA = fOpen - 6, tB = Math.max(fClose + 24, fWin);
  const tx0 = 980, tx1 = 1780, ty = 200;
  const mapX = (fr: number) => tx0 + clamp01((fr - (tA - 20)) / (end - (tA - 20))) * (tx1 - tx0);
  const winFrom = mapX(fOpen + 10);
  const winTo = mapX(Math.min(f, fClose + 12));
  const state = f < fOpen + 6 ? "বন্ধ" : f < fClose + 8 ? "খোলা" : "বন্ধ";

  const filmPx = px(1105, -255);
  return (
    <AbsoluteFill>
      <div style={{ position: "absolute", left: 140, top: 92 }}>
        <WordReveal text="Shutter" delay={Math.max(fTitle, c7)} per={5} size={104} color={theme.colors.accent} />
      </div>
      <div style={{ position: "absolute", left: 560, top: 118 }}>
        <Chip text="পুরনো ফিল্ম ক্যামেরা" tone="dim" size={40} delay={fOld} />
      </div>

      <div style={{ position: "absolute", left: LEFT, top: TOP }}>
        <FilmCamera width={W} p1={p1} p2={p2} prog={prog} assemble={assemble} uid="fs" />
      </div>

      {/* state chip + exposure timeline */}
      <div style={{ position: "absolute", left: 980, top: 96, opacity: ip(f, [fOpen - 20, fOpen - 6], [0, 1]) }}>
        <Chip text={`Shutter ${state}`} tone={state === "খোলা" ? "accent" : "dim"} size={40} delay={fOpen - 20} />
      </div>
      <svg width="1920" height="1080" style={{ position: "absolute", left: 0, top: 0, opacity: ip(f, [fOpen - 20, fOpen - 4], [0, 1]) }}>
        <rect x={tx0} y={ty - 9} width={tx1 - tx0} height={18} rx={9} fill={theme.colors.bgAlt} stroke={theme.colors.line} strokeWidth={2} />
        {winTo > winFrom && <rect x={winFrom} y={ty - 9} width={winTo - winFrom} height={18} rx={9} fill={theme.colors.accent} />}
        <circle cx={mapX(f)} cy={ty} r={13} fill={theme.colors.text} />
      </svg>
      <div style={{ position: "absolute", left: 980, top: 222, opacity: ip(f, [fWin, fWin + 12], [0, 1]) }}>
        <Chip text="আলো পড়ার সময়" tone="accent" size={36} delay={fWin} />
      </div>

      <div style={{ position: "absolute", left: filmPx.x - 40, top: filmPx.y - 4 }}>
        <Chip text="Film" tone="primary" size={38} delay={fFilm} />
      </div>

      <Sfx name="pop" at={c7 + 14} />
      <Sfx name="chime" at={fTitle} vol={0.8} />
      <Sfx name="click" at={fOpen} />
      <Sfx name="click" at={fClose + 4} rate={0.9} />
    </AbsoluteFill>
  );
};
