import React from "react";
import { useCurrentFrame, useVideoConfig } from "remotion";
import { theme } from "../theme";
import { T, cueStart } from "../timing";
import { prog } from "../util";

const STAGES = ["Sensor", "Readout", "ADC", "Pixel Data", "Demosaicing", "Image Processor", "Photo"];

/** Slim pipeline tracker at the top: tells the viewer where in the chain we are. */
export const StageRail: React.FC = () => {
  const f = useCurrentFrame();
  const { fps } = useVideoConfig();
  const starts = [T("Electronic") - 0.15, T("এরপর") - 0.15, cueStart(4) - 0.2, cueStart(6) - 0.15, cueStart(9) - 0.15, cueStart(12) - 0.15].map((s) => Math.round(s * fps));
  const pos = starts.reduce((acc, s) => acc + prog(f, s, s + 14, theme.ease.inOut), 0);
  const x0 = 560, x1 = 1360, y = 56;
  const xs = STAGES.map((_, i) => x0 + ((x1 - x0) * i) / (STAGES.length - 1));
  const px = x0 + ((x1 - x0) * pos) / (STAGES.length - 1);
  const label = STAGES[Math.min(STAGES.length - 1, Math.round(pos))];
  const enter = prog(f, 0, 18);
  return (
    <svg width="1920" height="1080" style={{ position: "absolute", inset: 0, pointerEvents: "none", opacity: enter }}>
      <line x1={x0} x2={x1} y1={y} y2={y} stroke={theme.colors.line} strokeWidth={3} strokeLinecap="round" />
      <line x1={x0} x2={px} y1={y} y2={y} stroke={theme.colors.primary} strokeWidth={3} strokeLinecap="round" />
      {xs.map((x, i) => (
        <circle key={i} cx={x} cy={y} r={6} fill={pos >= i - 0.02 ? theme.colors.primary : theme.colors.bg} stroke={pos >= i - 0.02 ? theme.colors.primary : theme.colors.line} strokeWidth={3} />
      ))}
      <circle cx={px} cy={y} r={11} fill={theme.colors.bg} stroke={theme.colors.accent} strokeWidth={4} />
      <text x={px} y={y + 44} textAnchor="middle" fontFamily={theme.fonts.main} fontWeight={600} fontSize={24} fill={theme.colors.text} opacity={0.92}>
        {label}
      </text>
    </svg>
  );
};
