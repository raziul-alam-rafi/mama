// Scene 4 — Hub & orbit (cues 5-6): the satellite races around the Earth, the dish keeps pace.
import React from "react";
import { AbsoluteFill, interpolate, spring, useCurrentFrame, useVideoConfig } from "remotion";
import { theme } from "../theme";
import { orbit as b } from "../beats";
import { WIDTH, HEIGHT, sec } from "../timing";
import { WordReveal } from "../components/Words";
import { CL, TimedBlock } from "../components/Motion";
import { DishShape, SatelliteShape } from "../components/Icons";

// ---- phase 1 geometry: Earth in the middle, tilted orbit ----
const E = { cx: 960, cy: 660, r: 140, rx: 720, ry: 170, tilt: (-8 * Math.PI) / 180 };
const orbitPt = (th: number) => {
  const ex = E.rx * Math.cos(th);
  const ey = E.ry * Math.sin(th);
  return {
    x: E.cx + ex * Math.cos(E.tilt) - ey * Math.sin(E.tilt),
    y: E.cy + ex * Math.sin(E.tilt) + ey * Math.cos(E.tilt),
    front: Math.sin(th) >= 0,
  };
};
const orbitPoly = (from: number, to: number) =>
  Array.from({ length: 61 }, (_, k) => {
    const p = orbitPt(from + ((to - from) * k) / 60);
    return `${p.x.toFixed(1)},${p.y.toFixed(1)}`;
  }).join(" ");

// ---- phase 2 geometry: dish on the ground, satellite crossing the sky ----
const DISH = { x: 960, y: 905, s: 0.9 };
const skyPt = (u: number) => ({ x: 220 + 1480 * u, y: 600 - 210 * Math.sin(Math.PI * u) });

export const OrbitScene: React.FC = () => {
  const frame = useCurrentFrame();
  const { fps } = useVideoConfig();
  const exitF = Math.round(fps * 0.3);

  // ---------- phase 1 ----------
  const p1 = Math.min(1, spring({ frame: frame - b.t5, fps, config: theme.spring.smooth }));
  const o1 = 1 - interpolate(frame, [b.t6, b.t6 + exitF], [0, 1], { easing: theme.ease.in, ...CL });
  const th = 0.6 + frame * 0.05;
  const sat = orbitPt(th);
  const trail = Array.from({ length: 12 }, (_, k) => ({ k, ...orbitPt(th - k * 0.055) }));
  const meridians = [0.2, 0.75, 1.3].map((o) => Math.abs(Math.cos(o + frame / 70)));

  // ---------- phase 2 ----------
  const p2 = Math.min(1, spring({ frame: frame - (b.t6 + 4), fps, config: theme.spring.smooth }));
  const u = interpolate(frame, [b.t6 + sec(0.3), b.t6 + sec(5.0)], [0, 1], { easing: theme.ease.soft, ...CL });
  const s2 = skyPt(u);
  const dishFace = { x: DISH.x, y: DISH.y - 150 * DISH.s };
  const ang = Math.atan2(s2.x - dishFace.x, dishFace.y - s2.y); // from vertical
  const len = Math.hypot(s2.x - dishFace.x, s2.y - dishFace.y);
  const lockP = interpolate(frame, [b.lock, b.lock + sec(0.5)], [0, 1], { easing: theme.ease.out, ...CL });
  const ringT = (frame % 36) / 36;
  const wave = (i: number, j: number) => 0.3 + 0.7 * (0.5 + 0.5 * Math.sin(frame / 5 - (i * (0.6 + Math.sin(ang)) + j * 0.5)));

  const earth = (
    <g>
      <defs>
        <radialGradient id="orbEarth" cx="38%" cy="32%" r="80%">
          <stop offset="0" stopColor={theme.colors.surfaceHi} />
          <stop offset="1" stopColor={theme.colors.bg} />
        </radialGradient>
        <clipPath id="orbClip">
          <circle cx={E.cx} cy={E.cy} r={E.r} />
        </clipPath>
      </defs>
      <circle cx={E.cx} cy={E.cy} r={E.r + 10} fill="none" stroke={theme.colors.accent} strokeWidth={10} opacity={0.12} />
      <circle cx={E.cx} cy={E.cy} r={E.r} fill="url(#orbEarth)" stroke={theme.colors.accent} strokeWidth={3} opacity={0.95} />
      <g clipPath="url(#orbClip)" stroke={theme.colors.border} strokeWidth={2} fill="none">
        {[-70, -20, 30, 80].map((dy) => (
          <line key={dy} x1={E.cx - E.r} x2={E.cx + E.r} y1={E.cy + dy} y2={E.cy + dy} />
        ))}
        {meridians.map((m, k) => (
          <ellipse key={k} cx={E.cx} cy={E.cy} rx={Math.max(4, E.r * m)} ry={E.r} />
        ))}
      </g>
    </g>
  );

  return (
    <AbsoluteFill>
      {/* headlines (top-centre) */}
      <div style={{ position: "absolute", left: 0, right: 0, top: 70, display: "flex", flexDirection: "column", alignItems: "center" }}>
        <TimedBlock to={b.t6 + 5} style={{ display: "flex", flexDirection: "column", alignItems: "center" }}>
          <WordReveal text="satellite স্থির থাকে না" delay={b.t5} size={112} align="center" marks={{ satellite: { color: theme.colors.accent } }} />
          <WordReveal
            text="পৃথিবীর চারপাশে প্রচণ্ড গতিতে"
            delay={b.line2}
            per={4}
            size={66}
            weight={600}
            align="center"
            color={theme.colors.textDim}
            marks={{ "প্রচণ্ড": { color: theme.colors.accent, pop: true }, "গতিতে": { color: theme.colors.accent, pop: true, underline: true, glow: true } }}
          />
        </TimedBlock>
        <div style={{ position: "absolute", top: 0, display: "flex", flexDirection: "column", alignItems: "center" }}>
          <WordReveal text="দ্রুত বদলে যাওয়া অবস্থান" delay={b.h6a} size={92} align="center" />
          <WordReveal
            text="তাল মিলিয়ে যোগাযোগ"
            delay={b.h6b}
            size={92}
            align="center"
            marks={{ "তাল": { color: theme.colors.accent, underline: true }, "মিলিয়ে": { color: theme.colors.accent, underline: true } }}
          />
        </div>
      </div>

      <svg width={WIDTH} height={HEIGHT} style={{ position: "absolute", left: 0, top: 0 }}>
        <defs>
          <linearGradient id="orbBeam" gradientUnits="userSpaceOnUse" x1={dishFace.x} y1={dishFace.y} x2={s2.x} y2={s2.y}>
            <stop offset="0" stopColor={theme.colors.primary} stopOpacity={0.9} />
            <stop offset="1" stopColor={theme.colors.primary} stopOpacity={0.25} />
          </linearGradient>
        </defs>

        {/* ===== phase 1 ===== */}
        {frame < b.t6 + exitF ? (
          <g opacity={Math.min(1, p1 * 1.4) * o1} transform={`translate(${(1 - p1) * 0} ${(1 - p1) * 40})`}>
            <polyline points={orbitPoly(Math.PI, 2 * Math.PI)} fill="none" stroke={theme.colors.textDim} strokeWidth={3} strokeDasharray="6 14" strokeLinecap="round" opacity={0.45} />
            {trail.filter((t) => !t.front).map((t) => (
              <circle key={`tb${t.k}`} cx={t.x} cy={t.y} r={13 * (1 - t.k / 12)} fill={theme.colors.primary} opacity={0.65 * (1 - t.k / 12)} />
            ))}
            {!sat.front ? (
              <g transform={`translate(${sat.x} ${sat.y}) scale(0.85)`}>
                <SatelliteShape />
              </g>
            ) : null}
            {earth}
            <polyline points={orbitPoly(0, Math.PI)} fill="none" stroke={theme.colors.textDim} strokeWidth={3} strokeDasharray="6 14" strokeLinecap="round" opacity={0.6} />
            {trail.filter((t) => t.front).map((t) => (
              <circle key={`tf${t.k}`} cx={t.x} cy={t.y} r={13 * (1 - t.k / 12)} fill={theme.colors.primary} opacity={0.65 * (1 - t.k / 12)} />
            ))}
            {sat.front ? (
              <g transform={`translate(${sat.x} ${sat.y}) scale(0.85)`}>
                <SatelliteShape />
              </g>
            ) : null}
          </g>
        ) : null}

        {/* ===== phase 2 ===== */}
        {frame >= b.t6 ? (
          <g opacity={Math.min(1, p2 * 1.4)} transform={`translate(0 ${(1 - p2) * 50})`}>
            {/* sky arc + earlier positions */}
            <polyline
              points={Array.from({ length: 41 }, (_, k) => {
                const q = skyPt(k / 40);
                return `${q.x.toFixed(1)},${q.y.toFixed(1)}`;
              }).join(" ")}
              fill="none"
              stroke={theme.colors.textDim}
              strokeWidth={3}
              strokeDasharray="6 14"
              strokeLinecap="round"
              opacity={0.4}
            />
            {Array.from({ length: 6 }, (_, k) => {
              const uu = u - (k + 1) * 0.07;
              if (uu <= 0) return null;
              const q = skyPt(uu);
              return <circle key={k} cx={q.x} cy={q.y} r={10 - k} fill={theme.colors.textDim} opacity={0.5 * (1 - k / 6)} />;
            })}

            {/* ground */}
            <path d={`M -200 1080 L -200 1000 Q 960 800 2120 1000 L 2120 1080 Z`} fill={theme.colors.surface} stroke={theme.colors.border} strokeWidth={2} />

            {/* tracking beam (dish stays still, beam follows the satellite) */}
            <g transform={`translate(${dishFace.x} ${dishFace.y}) rotate(${(ang * 180) / Math.PI})`}>
              <polygon points={`-14,0 14,0 4,${-len} -4,${-len}`} fill="url(#orbBeam)" opacity={0.9} />
            </g>
            <g transform={`translate(${s2.x} ${s2.y}) scale(0.8)`}>
              <SatelliteShape />
            </g>

            <g transform={`translate(${DISH.x} ${DISH.y}) scale(${DISH.s})`}>
              <DishShape dot={wave} ring={lockP > 0.01 ? ringT : 0} />
            </g>
          </g>
        ) : null}
      </svg>
    </AbsoluteFill>
  );
};
