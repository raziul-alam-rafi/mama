// সিন ৯ (cue 13): স্ক্রিনে পরিচিত পৃথিবী → ফোনের ভেতরের লুকানো মেকানিজম (Glossy UI → cutaway)
import React from "react";
import { useCurrentFrame } from "remotion";
import { theme } from "../theme";
import { makeT } from "../timing";
import { Entrance, SceneShell, Words, tween, useBreathe } from "../components/anim";
import { Gear } from "../components/icons";
import { ProcChip } from "../components/chip";
import { EXPO, Photo } from "../components/photo";
import { SfxEvent } from "../sfx";

const T = makeT(8);
const tPhone = 2;
const tScreen = T(13, "আপনি স্ক্রিনে");
const tWorld = T(13, "পরিচিত পৃথিবীটাকে");
const tHidden = T(13, "এমন আরও");
const tInside = T(13, "ভিতরে লুকিয়ে");

export const sfx09: SfxEvent[] = [
  { kind: "pop", frame: tPhone + 4 },
  { kind: "chime", frame: tScreen + 14, vol: 0.9 },
  { kind: "whoosh", frame: tHidden + 4, rate: 0.95, vol: 0.6 },
  { kind: "pop", frame: tHidden + 30, rate: 1.05 },
  { kind: "pop", frame: tInside + 6, rate: 0.95 },
];

const PX = 530, PY = 320, PW = 860, PH = 450; // ফোনের বডি (ল্যান্ডস্কেপ)
const SX = PX + 40, SY = PY + 35, SWD = 780, SHT = 380; // স্ক্রিন

export const Scene09: React.FC = () => {
  const frame = useCurrentFrame();
  const bob = useBreathe(44, 4);
  const sc = tween(frame, tScreen, tScreen + 20, 0, 1);
  const cut = tween(frame, tHidden, tHidden + 26, 0, 1, theme.ease.inOut);
  const topOut = tween(frame, tHidden - 4, tHidden + 8, 1, 0, theme.ease.in);
  const gA = frame * 1.6, gB = -frame * 1.6 * (14 / 10);
  const lens = 0.5 + 0.5 * Math.sin(frame / 12);

  return (
    <SceneShell>
      <div style={{ position: "absolute", left: 0, right: 0, top: 110, opacity: topOut }}>
        <Words text="স্ক্রিনে পরিচিত পৃথিবী" delay={tScreen} per={5} style={{ fontSize: 88 }} hl={{ পরিচিত: theme.colors.accent }} />
      </div>

      <Entrance delay={tPhone} y={60} style={{ position: "absolute", left: PX, top: PY + bob }}>
        <div style={{ width: PW, height: PH, borderRadius: 64, border: `5px solid ${cut > 0.5 ? theme.colors.hero : theme.colors.line}`, position: "relative",
          background: `linear-gradient(160deg, ${theme.colors.surfaceHi}, ${theme.colors.bg})`, boxShadow: `${theme.shadow.card}, 0 0 ${50 * cut}px ${theme.colors.glowHero}` }}>
          {/* ক্যামেরা-দ্বীপ (ফোনের পাশে) */}
          <div style={{ position: "absolute", left: 14, top: PH / 2 - 11, width: 12, height: 22, borderRadius: 6, background: theme.colors.line }} />
          {/* স্ক্রিন */}
          <div style={{ position: "absolute", left: SX - PX - 5, top: SY - PY - 5, width: SWD, height: SHT, borderRadius: 34, overflow: "hidden", background: theme.colors.black }}>
            <div style={{ opacity: sc * (1 - cut), transform: `scale(${1.04 - 0.04 * sc})` }}>
              <Photo uid="s9" gRoom={EXPO.over} gSky={EXPO.under} width={SWD} radius={0} />
            </div>
            {/* ভেতরের মেকানিজম */}
            <div style={{ position: "absolute", inset: 0, opacity: cut, background: `radial-gradient(circle at 50% 50%, ${theme.colors.surface}, ${theme.colors.black})` }}>
              <div style={{ position: "absolute", left: 120, top: 70 }}><Gear size={200} teeth={14} rot={gA} color={theme.colors.hero} /></div>
              <div style={{ position: "absolute", left: 276, top: 100 }}><Gear size={148} teeth={10} rot={gB + 18} color={theme.colors.accent} /></div>
              <div style={{ position: "absolute", left: 460, top: 105 }}><ProcChip size={170} active={0.5 + 0.5 * lens} /></div>
              <svg width={SWD} height={SHT} style={{ position: "absolute", inset: 0 }}>
                <path d="M 632 190 L 680 190" stroke={theme.colors.accent} strokeWidth={4} strokeDasharray="10 8" strokeDashoffset={-frame * 2} />
                {[0, 1, 2].map((i) => <circle key={i} cx={730} cy={190} r={52 - i * 15} fill={i === 2 ? theme.colors.hero : "none"} stroke={theme.colors.hero} strokeWidth={5} opacity={0.5 + 0.5 * (i === 2 ? lens : 1)} />)}
              </svg>
            </div>
          </div>
        </div>
      </Entrance>

      <div style={{ position: "absolute", left: 0, right: 0, top: 830 }}>
        <Words text="পরিচিত জিনিসের ভিতরে লুকিয়ে" delay={tInside} per={5} style={{ fontSize: 76 }} hl={{ লুকিয়ে: theme.colors.accent }} />
      </div>
    </SceneShell>
  );
};
