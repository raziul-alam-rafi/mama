import { Config } from "@remotion/cli/config";

Config.setVideoImageFormat("jpeg");
Config.setOverwriteOutput(true);
// NOTE: the OpenGL backend (--gl=...) is deliberately NOT set here.
// scripts/gl-check.sh tests which backend works on THIS machine and saves it to .glmode;
// scripts/stills.sh and scripts/render.sh pass it as --gl=<mode>.
