import React from "react";
import { AbsoluteFill, interpolate, spring, useCurrentFrame, useVideoConfig } from "remotion";
import { theme } from "../theme";
import { OVERLAP } from "../timing";

export const CL = { extrapolateLeft: "clamp", extrapolateRight: "clamp" } as const;

/** bezier ইজিং দিয়ে clamp-করা মান */
export const tween = (
  frame: number, from: number, to: number, a: number, b: number,
  easing: (t: number) => number = theme.ease.out,
) => interpolate(frame, [from, to], [a, b], { easing, ...CL });

/** spring 0→1 (delay ফ্রেম পরে) */
export const useSpringAt = (delay: number, config: { damping: number; stiffness: number; mass: number } = theme.spring.smooth) => {
  const frame = useCurrentFrame();
  const { fps } = useVideoConfig();
  return spring({ frame: frame - delay, fps, config });
};

/** ফেড + উঠে আসা + স্কেল — একসাথে তিনটি প্রপার্টি */
export const Entrance: React.FC<{
  delay?: number; y?: number; x?: number; scale?: number; style?: React.CSSProperties; children?: React.ReactNode;
  config?: { damping: number; stiffness: number; mass: number };
}> = ({ delay = 0, y = 36, x = 0, scale = 0.94, style, children, config }) => {
  const p = useSpringAt(delay, config ?? theme.spring.smooth);
  return (
    <div style={{
      opacity: Math.min(1, Math.max(0, p * 1.2)),
      transform: `translate(${interpolate(p, [0, 1], [x, 0])}px, ${interpolate(p, [0, 1], [y, 0])}px) scale(${interpolate(p, [0, 1], [scale, 1])})`,
      ...style,
    }}>{children}</div>
  );
};

/** শব্দ ধরে স্ট্যাগার্ড রিভিল — শুধু স্পেসে ভাঙে, অক্ষরে কখনো নয় */
export const Words: React.FC<{
  text: string; delay?: number; per?: number; style?: React.CSSProperties;
  hl?: Record<string, string>; justify?: "center" | "flex-start";
}> = ({ text, delay = 0, per = 4, style, hl = {}, justify = "center" }) => {
  const frame = useCurrentFrame();
  const { fps } = useVideoConfig();
  return (
    <div style={{
      display: "flex", flexWrap: "wrap", columnGap: 22, rowGap: 6, justifyContent: justify,
      fontFamily: theme.fonts.display, fontWeight: 700, letterSpacing: 0, lineHeight: 1.25,
      color: theme.colors.text, ...style,
    }}>
      {text.split(" ").map((w, i) => {
        const p = spring({ frame: frame - delay - i * per, fps, config: theme.spring.snappy });
        return (
          <span key={i} style={{
            display: "inline-block", opacity: Math.min(1, p * 1.3),
            transform: `translateY(${interpolate(p, [0, 1], [34, 0])}px) scale(${interpolate(p, [0, 1], [0.92, 1])})`,
            color: hl[w] ?? undefined,
          }}>{w}</span>
        );
      })}
    </div>
  );
};

/** সিনের খোলস: দ্রুত এন্ট্রি, ওভারল্যাপে এক্সিট (এন্ট্রির চেয়ে দ্রুত) */
export const SceneShell: React.FC<{ first?: boolean; last?: boolean; children: React.ReactNode }> = ({ first, last, children }) => {
  const frame = useCurrentFrame();
  const { durationInFrames } = useVideoConfig();
  const enter = first ? 1 : tween(frame, 0, 14, 0, 1);
  const exitLen = last ? 14 : OVERLAP;
  const endAt = last ? durationInFrames : durationInFrames - 1;
  const exit = tween(frame, endAt - exitLen, endAt, 1, 0, theme.ease.in);
  const sc = first ? 1 : tween(frame, 0, 18, 1.025, 1);
  return (
    <AbsoluteFill style={{ opacity: enter * exit, transform: `scale(${sc})` }}>{children}</AbsoluteFill>
  );
};

/** অলস অবস্থায় হালকা নড়াচড়া */
export const useBreathe = (period = 40, amp = 1) => {
  const frame = useCurrentFrame();
  return Math.sin(frame / period * Math.PI) * amp;
};
