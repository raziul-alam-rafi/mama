// সিন ৩ — সমস্যা: আলো সবদিকে ছড়ায়, নিয়ন্ত্রণ ছাড়া sensor-এ → ঝাপসা (Dark Tech ডায়াগ্রাম) · cue 5–6
import React from "react";
import { AbsoluteFill, interpolate } from "remotion";
import { Beam, RayLayer } from "../components/Rays";
import { AppleIcon, ArrowIcon, CrossIcon, SensorIcon } from "../components/Icons";
import { Breathe, Chip, Enter, Glass, Words, usePop, useProgress } from "../components/Primitives";
import { Sfx } from "../components/audio";
import { at } from "../timeline";
import { theme } from "../theme";

const c = theme.colors;
const SI = 2;
const APPLE = { x: 340, y: 620, size: 220 };
const SENSOR = { x: 1130, y: 300, w: 120, h: 640 };
const FAR_END = 640; // মাঝপথ পর্যন্ত যাওয়া রশ্মির শেষ x

// রশ্মি: ডান-মুখী ৭টি (sensor-এ পৌঁছায়) + সবদিকে ১১টি (মাঝপথে মিলিয়ে যায়)
const toRad = (d: number) => (d * Math.PI) / 180;
const RIGHT = [-21, -14, -7, 0, 7, 14, 21].map((a, i) => ({ a, i }));
const AROUND = [-150, -118, -86, -56, -34, 34, 56, 86, 118, 150, 180].map((a, i) => ({ a, i: i + 7 }));

const Result: React.FC<{ delay: number; crossDelay: number }> = ({ delay, crossDelay }) => {
  const cross = useProgress(crossDelay, 14);
  return (
    <Enter delay={delay} y={50} scaleFrom={0.9} preset={theme.spring.smooth}>
      <Glass style={{ width: 400, height: 420, overflow: "hidden" }}>
        {/* ঝাপসা "ছবি" */}
        <div style={{ position: "absolute", inset: 24, borderRadius: theme.radius.small, overflow: "hidden", background: `linear-gradient(160deg, ${c.bgAlt}, ${c.bgDeep})` }}>
          <div style={{ position: "absolute", inset: 0, filter: "blur(20px)", opacity: 0.95 }}>
            <div style={{ position: "absolute", left: 40, top: 30, width: 110, height: 110, borderRadius: "50%", background: c.accent, opacity: 0.8 }} />
            <div style={{ position: "absolute", left: 120, top: 120, width: 170, height: 170, borderRadius: "50%", background: c.apple }} />
            <div style={{ position: "absolute", left: 0, right: 0, bottom: 0, height: 90, background: c.primary, opacity: 0.45 }} />
          </div>
        </div>
        <div style={{ position: "absolute", right: 22, top: 22, transform: `scale(${interpolate(cross, [0, 1], [0.4, 1])})`, opacity: cross }}>
          <CrossIcon size={84} p={cross} />
        </div>
      </Glass>
    </Enter>
  );
};

export const S3Scatter: React.FC = () => {
  const tProb = at(SI, 5, "সমস্যা");
  const tObj = at(SI, 5, "বস্তু");
  const tMany = at(SI, 5, "অসংখ্য");
  const tSpread = at(SI, 5, "ছড়িয়ে");
  const tCtl = at(SI, 6, "নিয়ন্ত্রণ");
  const tSensor = at(SI, 6, "sensor");
  const tFall = at(SI, 6, "ফেলা");
  const tClear = at(SI, 6, "পরিষ্কার");

  const rayP = [...RIGHT, ...AROUND].map((r) => useProgress(tMany + r.i * theme.timing.stagger * 0.6, 22));
  const extP = RIGHT.map((r) => useProgress(tSensor + 8 + r.i * 3, 18));
  const hitP = RIGHT.map((r) => usePop(tFall + r.i * 3, theme.spring.snappy));
  const sensorIn = usePop(tSensor, theme.spring.smooth);
  const arrow = useProgress(tClear - 6, 16);

  const cx = APPLE.x, cy = APPLE.y;

  return (
    <AbsoluteFill>
      {/* শিরোনাম */}
      <div style={{ position: "absolute", left: theme.margin, top: 78, display: "flex", flexDirection: "column", gap: 20 }}>
        <Enter delay={tProb} y={24}>
          <Chip text="সমস্যা" size={42} tone="accent" />
        </Enter>
        <Words text="আলো ছড়িয়ে পড়ে" delay={tSpread} size={104} />
      </div>

      {/* রশ্মি */}
      <RayLayer>
        {[...RIGHT, ...AROUND].map((r, idx) => {
          const ang = toRad(r.a);
          const isRight = idx < RIGHT.length;
          const len = isRight ? (FAR_END - cx) / Math.cos(ang) : 260 + ((idx * 53) % 140);
          const mid: [number, number] = [cx + Math.cos(ang) * len, cy + Math.sin(ang) * len];
          return <Beam key={idx} id={`s3-r-${idx}`} pts={[[cx, cy], mid]} p={rayP[idx]} width={4} flow={false} opacity={isRight ? 1 : 0.85} />;
        })}
        {RIGHT.map((r, idx) => {
          const ang = toRad(r.a);
          const midX = FAR_END, midY = cy + Math.tan(ang) * (FAR_END - cx);
          const hitY = cy + Math.tan(ang) * (SENSOR.x - cx);
          return <Beam key={"e" + idx} id={`s3-e-${idx}`} pts={[[midX, midY], [SENSOR.x, hitY]]} p={extP[idx]} width={4} fadeTail={false} />;
        })}
        {/* sensor-এ আলো পড়ার বিন্দু */}
        {RIGHT.map((r, idx) => {
          const hitY = cy + Math.tan(toRad(r.a)) * (SENSOR.x - cx);
          return <circle key={"h" + idx} cx={SENSOR.x} cy={hitY} r={16 * hitP[idx]} fill={c.accent} opacity={0.95} />;
        })}
      </RayLayer>

      {/* আপেল (উৎস) */}
      <div style={{ position: "absolute", left: APPLE.x - APPLE.size / 2, top: APPLE.y - APPLE.size / 2 }}>
        <Enter delay={tObj} y={30} scaleFrom={0.7} preset={theme.spring.bouncy}>
          <Breathe><AppleIcon size={APPLE.size} uid="s3" /></Breathe>
        </Enter>
      </div>

      {/* sensor */}
      <div style={{ position: "absolute", left: SENSOR.x, top: SENSOR.y }}>
        <div style={{ opacity: Math.min(1, sensorIn), transform: `translateX(${interpolate(sensorIn, [0, 1], [90, 0])}px) scale(${interpolate(sensorIn, [0, 1], [0.94, 1])})` }}>
          <SensorIcon w={SENSOR.w} h={SENSOR.h} rows={14} uid="s3" glow={0.5} />
        </div>
      </div>
      <div style={{ position: "absolute", left: SENSOR.x - 70, top: SENSOR.y - 92, width: SENSOR.w + 140, display: "flex", justifyContent: "center" }}>
        <Enter delay={tSensor + 4} y={20}>
          <Chip text="sensor" size={44} tone="primary" />
        </Enter>
      </div>

      {/* নিয়ন্ত্রণ নেই */}
      <div style={{ position: "absolute", left: 470, top: 880, width: 560, display: "flex", justifyContent: "center" }}>
        <Enter delay={tCtl} y={26}>
          <Chip text="কোনো নিয়ন্ত্রণ নেই" size={44} tone="accent" />
        </Enter>
      </div>

      {/* ফল: ঝাপসা ছবি */}
      <div style={{ position: "absolute", left: 1318, top: 520, transform: `translateX(${interpolate(arrow, [0, 1], [-20, 0])}px)`, opacity: arrow }}>
        <ArrowIcon size={90} p={arrow} color={c.textDim} />
      </div>
      <div style={{ position: "absolute", left: 1420, top: 300 }}>
        <Result delay={tClear} crossDelay={tClear + 14} />
      </div>
      <div style={{ position: "absolute", left: 1420, top: 750, width: 400, display: "flex", justifyContent: "center" }}>
        <Enter delay={tClear + 18} y={20}>
          <Chip text="পরিষ্কার ছবি নয়" size={42} tone="accent" />
        </Enter>
      </div>

      <Sfx name="pop" at={tObj - 2} />
      <Sfx name="whoosh-soft" at={tMany - 3} n={1} />
      <Sfx name="whoosh-soft" at={tSpread - 3} n={3} />
      <Sfx name="pop" at={tSensor - 2} n={1} />
      <Sfx name="pop" at={tClear - 2} n={2} />
      <Sfx name="click" at={tClear + 12} n={2} />
    </AbsoluteFill>
  );
};
