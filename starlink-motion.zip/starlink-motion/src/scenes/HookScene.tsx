// Scene 1 — Hook (cue 1). Style: Kinetic Typography + line-drawn torch/beam metaphor.
import React from "react";
import { AbsoluteFill, spring, useCurrentFrame, useVideoConfig } from "remotion";
import { theme } from "../theme";
import { hook as b } from "../beats";
import { WIDTH, HEIGHT } from "../timing";
import { WordReveal } from "../components/Words";
import { Entrance } from "../components/Motion";
import { TorchShape } from "../components/Icons";

const TORCH = { x: 1180, y: 880, rot: 38, scale: 1.1 };
const BEAM_LEN = 600;

export const HookScene: React.FC = () => {
  const frame = useCurrentFrame();
  const { fps } = useVideoConfig();
  const pTorch = spring({ frame: frame - b.t0, fps, config: theme.spring.bouncy });
  const pBeam = spring({ frame: frame - b.beam, fps, config: theme.spring.smooth });
  const pLit = spring({ frame: frame - b.lit, fps, config: theme.spring.smooth });
  const wob = Math.sin(frame / 18) * 2.2; // idle breathing of the beam

  const rad = (TORCH.rot * Math.PI) / 180;
  const lens = { x: TORCH.x + 250 * TORCH.scale * Math.sin(rad), y: TORCH.y - 250 * TORCH.scale * Math.cos(rad) };
  const L = BEAM_LEN * Math.min(1, pBeam);
  const wFar = 26 + (190 - 26) * Math.min(1, pBeam);

  return (
    <AbsoluteFill>
      <svg width={WIDTH} height={HEIGHT} style={{ position: "absolute", left: 0, top: 0 }}>
        <defs>
          <linearGradient id="hookBeam" gradientUnits="userSpaceOnUse" x1={0} y1={0} x2={0} y2={-BEAM_LEN}>
            <stop offset="0" stopColor={theme.colors.primary} stopOpacity={0.9} />
            <stop offset="0.75" stopColor={theme.colors.primary} stopOpacity={0.22} />
            <stop offset="1" stopColor={theme.colors.primary} stopOpacity={0.06} />
          </linearGradient>
        </defs>

        {/* beam */}
        <g transform={`translate(${lens.x} ${lens.y}) rotate(${TORCH.rot + wob})`} opacity={Math.min(1, pBeam * 1.3)}>
          <polygon points={`-26,0 26,0 ${wFar},${-L} ${-wFar},${-L}`} fill="url(#hookBeam)" />
          {Array.from({ length: 14 }).map((_, i) => {
            const u = 0.1 + (((i * 37) % 100) / 100) * 0.82;
            const v = (((i * 61) % 100) / 100) * 1.7 - 0.85;
            if (u * BEAM_LEN > L) return null;
            const w = 26 + (190 - 26) * u;
            const x = v * w * 0.8 + Math.sin(frame / (30 + i * 2) + i) * 10;
            const y = -u * BEAM_LEN + Math.cos(frame / (40 + i) + i) * 8;
            return <circle key={i} cx={x} cy={y} r={2.5 + (i % 3)} fill={theme.colors.text} opacity={0.5 * pBeam} />;
          })}
        </g>

        {/* the thing in the dark: lit up once the beam reaches it */}
        <g transform="translate(1618 110)">
          <rect width={200} height={160} rx={22} fill={theme.colors.surface} stroke={theme.colors.border} strokeWidth={2} />
          <rect width={200} height={160} rx={22} fill={theme.colors.primary} opacity={pLit * 0.5} />
          <rect width={200} height={160} rx={22} fill="none" stroke={theme.colors.primary} strokeWidth={3} opacity={pLit} />
          {[0, 1, 2].map((k) => (
            <rect key={k} x={28 + k * 54} y={40} width={36} height={80} rx={8} fill={theme.colors.bg} opacity={0.55} />
          ))}
        </g>

        {/* torch */}
        <g
          transform={`translate(${TORCH.x} ${TORCH.y + (1 - Math.min(1, pTorch)) * 120 + Math.sin(frame / 30) * 3}) rotate(${TORCH.rot}) scale(${
            TORCH.scale * (0.9 + 0.1 * Math.min(1, pTorch))
          })`}
          opacity={Math.min(1, pTorch * 1.5)}
        >
          <TorchShape on={Math.min(1, pBeam)} />
        </g>
      </svg>

      {/* kinetic title block */}
      <div style={{ position: "absolute", left: 120, top: 190, width: 980 }}>
        <Entrance delay={b.t0} y={24}>
          <div style={{ fontFamily: theme.fonts.display, fontSize: 56, fontWeight: 600, color: theme.colors.accent, lineHeight: 1.3 }}>
            ধরুন…
          </div>
        </Entrance>
        <WordReveal text="অন্ধকারে" delay={b.t0 + 4} size={168} />
        <WordReveal
          text="একটি torch"
          delay={b.t0 + 12}
          size={168}
          marks={{ torch: { color: theme.colors.accent, underline: true } }}
        />
        <div style={{ marginTop: 26 }}>
          <WordReveal text="কোনো কিছুর দিকে আলো ফেললেন" delay={b.sub} per={3} size={56} weight={500} color={theme.colors.textDim} maxWidth={760} />
        </div>
      </div>
    </AbsoluteFill>
  );
};
