// Reads every WAV in public/sfx and reports duration, peak, loudness and clipping.
import fs from "node:fs";
const dir = new URL("../public/sfx/", import.meta.url);
let bad = 0;
console.log("file         dur(s)  peak(dBFS)  rms(dBFS)  clipped");
for (const f of fs.readdirSync(dir).filter((n) => n.endsWith(".wav")).sort()) {
  const b = fs.readFileSync(new URL(f, dir));
  const sr = b.readUInt32LE(24);
  const n = (b.length - 44) / 2;
  let peak = 0, clip = 0, sum = 0, act = 0;
  for (let i = 0; i < n; i++) {
    const v = b.readInt16LE(44 + i * 2);
    peak = Math.max(peak, Math.abs(v));
    if (Math.abs(v) >= 32767) clip++;
  }
  for (let i = 0; i < n; i++) {
    const v = b.readInt16LE(44 + i * 2);
    if (Math.abs(v) > 0.02 * peak) { sum += (v / 32768) ** 2; act++; }
  }
  const dur = n / sr;
  const db = (x) => (20 * Math.log10(Math.max(1e-9, x))).toFixed(1);
  const maxDur = f.startsWith("whoosh") || f.startsWith("swipe") ? 0.8 : 0.5;
  const ok = clip === 0 && dur <= maxDur && dur >= 0.05 && peak / 32768 <= 0.95;
  if (!ok) bad++;
  console.log(`${f.padEnd(12)} ${dur.toFixed(2).padStart(6)}  ${db(peak / 32768).padStart(10)}  ${db(Math.sqrt(sum / act)).padStart(9)}  ${String(clip).padStart(7)} ${ok ? "" : " <-- CHECK"}`);
}
console.log(bad ? `${bad} file(s) need attention` : "all SFX OK (no clipping, short, level-matched)");
