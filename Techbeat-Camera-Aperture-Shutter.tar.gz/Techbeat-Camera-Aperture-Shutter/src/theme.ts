// Single source of truth. Never inline colors/easings in components.
import {Easing} from 'remotion';

export const theme = {
  video: {width: 1920, height: 1080, fps: 30},
  colors: {
    bg: '#0B1020',
    primary: '#4F8CFF', // light rays
    accent: '#FFB84D', // hero: sensor glow only (max one hero element per frame)
    text: '#F4F7FF',
    textDim: '#9AA6C7',
    metal: '#2B3556',
    metalEdge: '#5B6A9A',
    glass: '#9CC4FF',
  },
  fonts: {display: 'Inter, "Segoe UI", system-ui, sans-serif'},
  ease: {
    out: Easing.bezier(0.16, 1, 0.3, 1),
    inOut: Easing.bezier(0.83, 0, 0.17, 1),
    in: Easing.bezier(0.7, 0, 0.84, 0),
  },
  spring: {
    snappy: {damping: 14, stiffness: 160, mass: 0.6},
    smooth: {damping: 20, stiffness: 90, mass: 1},
  },
} as const;
