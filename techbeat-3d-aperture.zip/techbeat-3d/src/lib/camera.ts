import * as THREE from "three";
import { seg, lerp3, Vec3 } from "./ease";
import { theme } from "../theme";

export interface CamKey { t: number; pos: Vec3; look: Vec3; fov: number }
export interface CamState { pos: Vec3; look: Vec3; fov: number }

/** Deterministic camera: pure function of time (seconds) and keyframes. */
export function cameraAt(t: number, keys: CamKey[]): CamState {
  if (t <= keys[0].t) return { pos: keys[0].pos, look: keys[0].look, fov: keys[0].fov };
  for (let i = 0; i < keys.length - 1; i++) {
    const a = keys[i], b = keys[i + 1];
    if (t <= b.t) {
      const p = seg(t, a.t, b.t, theme.ease.soft);
      return { pos: lerp3(a.pos, b.pos, p), look: lerp3(a.look, b.look, p), fov: a.fov + (b.fov - a.fov) * p };
    }
  }
  const l = keys[keys.length - 1];
  return { pos: l.pos, look: l.look, fov: l.fov };
}

/** Project a world point to pixel coordinates, using exactly the same camera as the 3D scene. */
export function projectToScreen(cam: CamState, world: Vec3, w: number, h: number) {
  const c = new THREE.PerspectiveCamera(cam.fov, w / h, 0.1, 100);
  c.position.set(...cam.pos);
  c.lookAt(new THREE.Vector3(...cam.look));
  c.updateMatrixWorld(true);
  c.updateProjectionMatrix();
  const v = new THREE.Vector3(...world).project(c);
  return { x: ((v.x + 1) / 2) * w, y: ((1 - v.y) / 2) * h, visible: v.z < 1 };
}
