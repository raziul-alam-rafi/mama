import React from "react";
import {AbsoluteFill} from "remotion";
import {Chip, Pop, Sfx, Words, clamp01, useAnim} from "../anim";
import {Channel, chColor, theme} from "../theme";

const CH: Channel[] = ["R", "G", "B"];
const VAL: Record<Channel, number> = {R: 0.78, G: 0.42, B: 0.96};
const PY = 240;
const PH = 640;
const BAR_H = 220;
const BASE = PY + 560;

// Scene 7 - before/after split: the full colour vs. what one pixel actually measures.
export const S7: React.FC = () => {
  const a = useAnim();
  const left = a.sp(0.15);
  const right = a.sp(1.5);
  const sw = a.sp(0.45, theme.spring.bouncy);
  const mid = a.prog(1.2, 1.9, theme.ease.out);
  const qPulse = 0.5 + 0.5 * Math.sin(a.t * 4);

  return (
    <AbsoluteFill>
      <Sfx name="whoosh_swipe" at={0.05} vol={0.22} />
      <Sfx name="pop" at={0.45} vol={0.24} rate={1.03} />
      <Sfx name="click" at={1.2} vol={0.22} />
      <Sfx name="pop" at={1.6} vol={0.24} rate={0.97} />
      <Sfx name="click" at={2.7} vol={0.22} rate={1.05} />

      <div style={{position: "absolute", left: 140, top: 64, width: 1640}}>
        <Words text="পুরো রং সরাসরি শনাক্ত হয় না" at={0.1} highlight={["শনাক্ত"]} />
      </div>

      {/* left: full colour */}
      <div style={{position: "absolute", left: 110, top: PY, width: 790, height: PH, borderRadius: theme.radius.card, background: theme.colors.card, border: `2px solid ${theme.colors.cardLine}`, boxShadow: `0 40px 80px -24px ${theme.colors.shadow}`, opacity: clamp01(left * 1.5), transform: `translateX(${(1 - left) * -60}px)`}}>
        <div style={{position: "absolute", left: 0, right: 0, top: 26, display: "flex", justifyContent: "center"}}>
          <Chip size={theme.size.small}>পূর্ণ রং</Chip>
        </div>
        <div style={{position: "absolute", left: 395 - 90, top: 112, width: 180, height: 180, borderRadius: "50%", background: theme.colors.sample, boxShadow: `0 0 70px ${theme.colors.sample}88`, transform: `scale(${sw})`}} />
        {CH.map((c, k) => {
          const g = a.sp(1.2 + k * 0.12, theme.spring.snappy);
          const x = 215 + k * 130;
          return (
            <div key={c}>
              <div style={{position: "absolute", left: x, top: 330, width: 70, height: BAR_H, borderRadius: 16, background: theme.colors.well, border: `2px solid ${theme.colors.line}`}} />
              <div style={{position: "absolute", left: x, top: 330 + BAR_H - BAR_H * VAL[c] * g, width: 70, height: Math.max(BAR_H * VAL[c] * g, 0.01), borderRadius: 16, background: chColor[c], boxShadow: `0 0 20px ${chColor[c]}`}} />
              <div style={{position: "absolute", left: x + 23, top: 330 + BAR_H + 28, width: 24, height: 24, borderRadius: "50%", background: chColor[c]}} />
            </div>
          );
        })}
      </div>

      {/* divider */}
      <div style={{position: "absolute", left: 958, top: PY + 30, width: 4, height: (PH - 60) * mid, borderRadius: 2, background: theme.colors.hero, boxShadow: `0 0 24px ${theme.colors.glow}`}} />
      <div style={{position: "absolute", left: 960 - 44, top: PY + PH / 2 - 44, width: 88, height: 88, borderRadius: "50%", background: theme.colors.bg, border: `3px solid ${theme.colors.amber}`, display: "flex", alignItems: "center", justifyContent: "center", color: theme.colors.amber, fontFamily: theme.fonts.display, fontWeight: 700, fontSize: 56, opacity: mid, transform: `scale(${0.6 + 0.4 * mid})`}}>
        ≠
      </div>

      {/* right: what one pixel measures */}
      <div style={{position: "absolute", left: 1020, top: PY, width: 790, height: PH, borderRadius: theme.radius.card, background: theme.colors.card, border: `2px solid ${theme.colors.cardLine}`, boxShadow: `0 40px 80px -24px ${theme.colors.shadow}`, opacity: clamp01(right * 1.5), transform: `translateX(${(1 - right) * 60}px)`}}>
        <div style={{position: "absolute", left: 0, right: 0, top: 26, display: "flex", justifyContent: "center"}}>
          <Chip size={theme.size.small}>একটি pixel যা শনাক্ত করে</Chip>
        </div>
        {/* one photosite with a red filter */}
        <div style={{position: "absolute", left: 395 - 100, top: 130, width: 200, height: 40, borderRadius: 12, background: `linear-gradient(180deg, ${theme.colors.red}, ${theme.colors.red}B0)`, border: "2px solid rgba(255,255,255,0.45)", boxShadow: `0 0 24px ${theme.colors.red}`}} />
        <div style={{position: "absolute", left: 395 - 100, top: 180, width: 200, height: 112, borderRadius: 16, background: theme.colors.well, border: `3px solid ${theme.colors.line}`}}>
          <div style={{position: "absolute", inset: 10, borderRadius: 10, background: theme.colors.red, opacity: 0.35 + 0.1 * qPulse}} />
        </div>
        {CH.map((c, k) => {
          const own = c === "R";
          const g = a.sp(2.6 + k * 0.5, theme.spring.snappy);
          const x = 215 + k * 130;
          return (
            <div key={c}>
              <div style={{position: "absolute", left: x, top: 330, width: 70, height: BAR_H, borderRadius: 16, background: theme.colors.well, border: `2px ${own ? "solid" : "dashed"} ${theme.colors.line}`}} />
              {own ? (
                <div style={{position: "absolute", left: x, top: 330 + BAR_H - BAR_H * VAL[c] * g, width: 70, height: Math.max(BAR_H * VAL[c] * g, 0.01), borderRadius: 16, background: chColor[c], boxShadow: `0 0 20px ${chColor[c]}`}} />
              ) : (
                <div style={{position: "absolute", left: x, top: 330 + BAR_H / 2 - 48, width: 70, textAlign: "center", fontFamily: theme.fonts.display, fontWeight: 700, fontSize: 84, lineHeight: 1.1, color: theme.colors.textDim, opacity: clamp01(g * 1.5) * (0.55 + 0.45 * qPulse), transform: `scale(${0.6 + 0.4 * g})`}}>?</div>
              )}
              <div style={{position: "absolute", left: x + 23, top: 330 + BAR_H + 28, width: 24, height: 24, borderRadius: "50%", background: chColor[c], opacity: own ? 1 : 0.5}} />
            </div>
          );
        })}
      </div>
    </AbsoluteFill>
  );
};
