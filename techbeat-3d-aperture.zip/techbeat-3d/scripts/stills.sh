#!/usr/bin/env bash
# Renders key frames for visual inspection (frame numbers @30fps).
set -euo pipefail
mkdir -p out
for f in 10 45 90 140 215 260 300 345 400 470 540; do
  npx remotion still src/index.ts ApertureExplainer out/check_$f.png --frame=$f --overwrite
done
echo "Stills in out/check_*.png"
