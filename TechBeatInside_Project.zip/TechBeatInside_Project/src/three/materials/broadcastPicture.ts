import {hash1, lerp, mulberry32} from '../../utils/math';

type Ctx = CanvasRenderingContext2D;

/** Procedural "cricket broadcast" picture. Fully deterministic per frame. */
export function drawCricket(ctx: Ctx, w: number, h: number, frame: number, crt = true) {
  const hor = h * 0.36;
  // sky
  const sky = ctx.createLinearGradient(0, 0, 0, hor);
  sky.addColorStop(0, '#16224a');
  sky.addColorStop(1, '#6d86b8');
  ctx.fillStyle = sky;
  ctx.fillRect(0, 0, w, hor);
  // stand + crowd
  ctx.fillStyle = '#2b2d3d';
  ctx.fillRect(0, hor * 0.45, w, hor * 0.55);
  const r = mulberry32(99);
  for (let i = 0; i < 900; i++) {
    ctx.fillStyle = `hsl(${Math.floor(r() * 360)},45%,${40 + r() * 30}%)`;
    ctx.fillRect(r() * w, hor * 0.48 + r() * hor * 0.5, 2, 2);
  }
  // outfield with mowing stripes (perspective)
  for (let i = 0; i < 14; i++) {
    const y0 = lerp(hor, h, (i / 14) ** 1.6);
    const y1 = lerp(hor, h, ((i + 1) / 14) ** 1.6);
    ctx.fillStyle = i % 2 ? '#2f7a35' : '#3a8c40';
    ctx.fillRect(0, y0, w, y1 - y0 + 1);
  }
  // pitch trapezoid
  const topW = w * 0.06;
  const botW = w * 0.34;
  const pTop = hor + h * 0.02;
  const pBot = h * 0.98;
  ctx.fillStyle = '#c9b28a';
  ctx.beginPath();
  ctx.moveTo(w / 2 - topW / 2, pTop);
  ctx.lineTo(w / 2 + topW / 2, pTop);
  ctx.lineTo(w / 2 + botW / 2, pBot);
  ctx.lineTo(w / 2 - botW / 2, pBot);
  ctx.closePath();
  ctx.fill();
  const sc = (y: number) => (y - pTop) / (pBot - pTop); // 0 far .. 1 near
  const wAt = (y: number) => lerp(topW, botW, sc(y));
  // creases
  ctx.fillStyle = '#f2f2ea';
  for (const yy of [pTop + (pBot - pTop) * 0.1, pBot - (pBot - pTop) * 0.12]) {
    ctx.fillRect(w / 2 - wAt(yy) / 2, yy, wAt(yy), Math.max(1.5, 3 * sc(yy)));
  }
  // stumps
  for (const yy of [pTop + (pBot - pTop) * 0.09, pBot - (pBot - pTop) * 0.14]) {
    const s = 0.4 + sc(yy) * 2.2;
    ctx.fillStyle = '#efe6c8';
    for (let k = -1; k <= 1; k++) ctx.fillRect(w / 2 + k * 4 * s - s, yy - 14 * s, 2 * s, 14 * s);
  }
  // bowler runs in, ball delivered, batsman
  const cyc = (frame * 0.011) % 1;
  const figure = (x: number, y: number, s: number, shirt: string) => {
    ctx.fillStyle = shirt;
    ctx.fillRect(x - 3 * s, y - 16 * s, 6 * s, 10 * s);
    ctx.fillStyle = '#d9a77e';
    ctx.beginPath();
    ctx.arc(x, y - 19 * s, 2.6 * s, 0, 6.3);
    ctx.fill();
    ctx.fillStyle = '#f4f4f4';
    ctx.fillRect(x - 3 * s, y - 6 * s, 2.2 * s, 7 * s);
    ctx.fillRect(x + 0.8 * s, y - 6 * s, 2.2 * s, 7 * s);
  };
  const by = lerp(pTop + 8, pBot - (pBot - pTop) * 0.22, Math.min(1, cyc * 1.6));
  figure(w / 2 + Math.sin(frame * 0.4) * 1.5, by, 0.5 + sc(by) * 1.8, '#1f5fbf');
  figure(w / 2 - 14, pBot - (pBot - pTop) * 0.1, 2.6, '#f4f4f4');
  // fielders
  for (let i = 0; i < 7; i++) {
    const fy = hor + 18 + hash1(i * 3.1) * (h - hor) * 0.7;
    const fx = hash1(i * 7.7) * w;
    if (Math.abs(fx - w / 2) < w * 0.2) continue;
    figure(fx, fy, 0.4 + sc(fy) * 1.2, '#e8e8e8');
  }
  // LIVE tag
  ctx.fillStyle = '#c4231f';
  ctx.fillRect(w * 0.04, h * 0.05, w * 0.15, h * 0.075);
  ctx.fillStyle = '#fff';
  ctx.font = `700 ${Math.round(h * 0.055)}px sans-serif`;
  ctx.textBaseline = 'middle';
  ctx.fillText('LIVE', w * 0.065, h * 0.088);
  if (crt) crtLook(ctx, w, h, frame);
}

function crtLook(ctx: Ctx, w: number, h: number, frame: number) {
  ctx.fillStyle = 'rgba(0,0,0,0.20)';
  for (let y = 0; y < h; y += 3) ctx.fillRect(0, y, w, 1);
  const rollY = ((frame * 4) % (h * 1.6)) - h * 0.3;
  const band = ctx.createLinearGradient(0, rollY, 0, rollY + h * 0.18);
  band.addColorStop(0, 'rgba(255,255,255,0)');
  band.addColorStop(0.5, 'rgba(255,255,255,0.045)');
  band.addColorStop(1, 'rgba(255,255,255,0)');
  ctx.fillStyle = band;
  ctx.fillRect(0, rollY, w, h * 0.18);
  const vg = ctx.createRadialGradient(w / 2, h / 2, h * 0.3, w / 2, h / 2, w * 0.75);
  vg.addColorStop(0, 'rgba(0,0,0,0)');
  vg.addColorStop(1, 'rgba(0,0,0,0.5)');
  ctx.fillStyle = vg;
  ctx.fillRect(0, 0, w, h);
}

/** The picture as "seen" by the camera sensor; lines below scan position are dimmed. */
export function drawSensorImage(ctx: Ctx, w: number, h: number, frame: number, scan: number) {
  drawCricket(ctx, w, h, frame, false);
  const y = scan * h;
  ctx.fillStyle = 'rgba(2,10,20,0.78)';
  ctx.fillRect(0, y, w, h - y);
  ctx.fillStyle = 'rgba(216,245,255,0.95)';
  ctx.fillRect(0, y - 1.5, w, 3);
  ctx.strokeStyle = 'rgba(90,209,255,0.9)';
  ctx.lineWidth = 3;
  ctx.strokeRect(1.5, 1.5, w - 3, h - 3);
}

/**
 * Video-signal trace for ONE scan line: horizontal sync pulse (below black level),
 * back porch, then active video whose voltage follows brightness along the line.
 */
export function drawSignalTrace(ctx: Ctx, w: number, h: number, scan: number, frame: number) {
  ctx.fillStyle = '#04141c';
  ctx.fillRect(0, 0, w, h);
  ctx.strokeStyle = 'rgba(90,209,255,0.14)';
  ctx.lineWidth = 1;
  for (let i = 1; i < 10; i++) {
    ctx.beginPath();
    ctx.moveTo((i * w) / 10, 0);
    ctx.lineTo((i * w) / 10, h);
    ctx.stroke();
  }
  for (let i = 1; i < 6; i++) {
    ctx.beginPath();
    ctx.moveTo(0, (i * h) / 6);
    ctx.lineTo(w, (i * h) / 6);
    ctx.stroke();
  }
  const black = h * 0.68;
  const white = h * 0.2;
  const syncLow = h * 0.9;
  const line = Math.floor(scan * 240);
  const syncEnd = w * 0.09;
  const activeStart = w * 0.15;
  const sample = (u: number) => {
    // brightness profile of a cricket-ground line: dim sky/crowd -> grass -> bright pitch -> grass
    const row = scan;
    let b = row < 0.36 ? 0.25 + 0.2 * hash1(u * 90 + line) : 0.42;
    if (row >= 0.36) {
      const pw = lerp(0.04, 0.17, (row - 0.36) / 0.64);
      if (Math.abs(u - 0.5) < pw) b = 0.78;
      b += 0.05 * hash1(Math.floor(u * 140) + line * 3);
    }
    return b;
  };
  ctx.strokeStyle = '#d8f5ff';
  ctx.shadowColor = '#5ad1ff';
  ctx.shadowBlur = 10;
  ctx.lineWidth = 3;
  ctx.beginPath();
  for (let x = 0; x <= w; x += 2) {
    let y = black;
    if (x < syncEnd) y = syncLow;
    else if (x < activeStart) y = black;
    else y = lerp(black, white, sample((x - activeStart) / (w - activeStart)));
    if (x === 0) ctx.moveTo(x, y);
    else ctx.lineTo(x, y);
  }
  ctx.stroke();
  ctx.shadowBlur = 0;
  ctx.fillStyle = 'rgba(159,227,255,0.9)';
  ctx.font = `600 ${Math.round(h * 0.075)}px sans-serif`;
  ctx.textBaseline = 'top';
  ctx.fillText('VIDEO SIGNAL  (one scan line)', w * 0.03, h * 0.04);
  ctx.strokeStyle = 'rgba(90,209,255,0.9)';
  ctx.lineWidth = 3;
  ctx.strokeRect(1.5, 1.5, w - 3, h - 3);
  void frame;
}
