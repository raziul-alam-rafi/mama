// postinstall: copy Hind Siliguri (Bengali + Latin) from the npm package into public/fonts
// so the video renders fully offline. If anything is missing, the bundled fallback font is used.
import fs from "node:fs";
import path from "node:path";
const src = path.resolve("node_modules/@fontsource/hind-siliguri/files");
const dst = path.resolve("public/fonts");
try {
  fs.mkdirSync(dst, { recursive: true });
  let n = 0;
  for (const f of fs.readdirSync(src)) {
    if (/^hind-siliguri-(bengali|latin)-(500|700)-normal\.woff2$/.test(f)) { fs.copyFileSync(path.join(src, f), path.join(dst, f)); n++; }
  }
  console.log(`[fonts] copied ${n} Hind Siliguri files`);
} catch (e) { console.warn("[fonts] Hind Siliguri not copied, fallback font will be used:", e.message); }
