// theme.ts — একমাত্র সত্য-উৎস: রং, ফন্ট, ইজিং, spring। কম্পোনেন্টে সরাসরি রঙের কোড নয়।
import { Easing } from "remotion";
import { loadFont } from "@remotion/google-fonts/HindSiliguri";

const { fontFamily } = loadFont("normal", {
  weights: ["500", "600", "700"],
  subsets: ["bengali", "latin"],
});

// "#rrggbb" ও "rgb(r,g,b)" দুটোই বোঝে (মিশ্রিত রঙের ওপর আবার মেশানো যায়)
const rgb = (h: string): number[] =>
  h.startsWith("#")
    ? [1, 3, 5].map((i) => parseInt(h.slice(i, i + 2), 16))
    : (h.match(/[\d.]+/g) as string[]).slice(0, 3).map(Number);
export const mix = (a: string, b: string, t: number) => {
  const A = rgb(a);
  const B = rgb(b);
  return `rgb(${A.map((v, i) => Math.round(v + (B[i] - v) * t)).join(",")})`;
};
export const alpha = (h: string, o: number) =>
  `${h}${Math.round(Math.max(0, Math.min(1, o)) * 255)
    .toString(16)
    .padStart(2, "0")}`;

// স্কিম ১ — Deep Navy Optics
const base = {
  bg: "#0A1224",
  bgAlt: "#111C36",
  panel: "#16254A",
  hero: "#38BDF8",
  accent: "#FBBF24",
  text: "#EAF2FF",
  textDim: "#8FA3C4",
};

export const theme = {
  colors: {
    ...base,
    line: alpha(base.text, 0.3),
    lineSoft: alpha(base.text, 0.13),
    glowHero: alpha(base.hero, 0.5),
    glowAccent: alpha(base.accent, 0.5),
  },
  // দৃশ্যপটের (মানুষ, গাছ, আকাশ) রং — স্কিম থেকেই মিশিয়ে নেওয়া
  world: {
    skyTop: mix(base.bgAlt, base.hero, 0.22),
    skyBottom: mix(base.bgAlt, base.hero, 0.7),
    sun: base.accent,
    hill: mix(base.bgAlt, base.hero, 0.16),
    ground: mix(base.bg, base.panel, 0.6),
    trunk: mix(base.bg, base.text, 0.14),
    canopy: mix(base.bgAlt, base.hero, 0.42),
    body: mix(base.panel, base.text, 0.28),
    face: mix(base.text, base.accent, 0.3),
    hair: base.bg,
  },
  fonts: { main: `${fontFamily}, "Hind Siliguri", sans-serif` },
  ease: {
    out: Easing.bezier(0.16, 1, 0.3, 1),
    inOut: Easing.bezier(0.83, 0, 0.17, 1),
    in: Easing.bezier(0.7, 0, 0.84, 0),
  },
  spring: {
    snappy: { damping: 14, stiffness: 160, mass: 0.6 },
    smooth: { damping: 20, stiffness: 90, mass: 1 },
    bouncy: { damping: 11, stiffness: 170, mass: 0.7 },
  },
  radius: 28,
  shadow: "0 30px 70px -22px rgba(0,0,0,0.65)",
} as const;
