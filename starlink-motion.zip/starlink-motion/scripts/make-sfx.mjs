// Synthesises a small, soft UI/motion-graphics SFX kit (16-bit mono WAV) into public/sfx/.
// No downloads, fully deterministic. Sounds: pop, click, whoosh, swipe, chime, thud.
import fs from "node:fs";

const SR = 44100;
const N = (s) => Math.round(s * SR);
let seed = 20261021;
const rnd = () => ((seed = (Math.imul(seed, 1664525) + 1013904223) >>> 0) / 4294967296) * 2 - 1;

const lowpass = (x, fc) => {
  const a = 1 - Math.exp((-2 * Math.PI * fc) / SR);
  let y = 0;
  return x.map((v) => (y += a * (v - y)));
};
const highpass = (x, fc) => {
  const l = lowpass(x, fc);
  return x.map((v, i) => v - l[i]);
};
const bandSweep = (x, f0, f1, Q) => {
  const y = new Float64Array(x.length);
  let x1 = 0, x2 = 0, y1 = 0, y2 = 0;
  for (let n = 0; n < x.length; n++) {
    const u = n / x.length;
    const f = f0 * Math.pow(f1 / f0, u * u * (3 - 2 * u));
    const w = (2 * Math.PI * f) / SR;
    const al = Math.sin(w) / (2 * Q);
    const cw = Math.cos(w);
    const a0 = 1 + al;
    const v = (al * x[n] - al * x2 + 2 * cw * y1 - (1 - al) * y2) / a0;
    x2 = x1; x1 = x[n]; y2 = y1; y1 = v;
    y[n] = v;
  }
  return y;
};
// very short, soft room: three feedback combs, low wet mix
const tinyReverb = (x, wet = 0.16) => {
  const delays = [N(0.029), N(0.037), N(0.043)];
  const gains = [0.3, 0.24, 0.2];
  const out = new Float64Array(x.length + N(0.05));
  for (let n = 0; n < out.length; n++) {
    let dry = n < x.length ? x[n] : 0;
    let acc = 0;
    delays.forEach((d, k) => { if (n >= d) acc += gains[k] * out[n - d]; });
    out[n] = dry + acc * wet * 3;
  }
  return out;
};
const fades = (x, inMs = 0.6, outMs = 14) => {
  const a = Math.max(1, Math.round((inMs / 1000) * SR));
  const b = Math.max(1, Math.round((outMs / 1000) * SR));
  return x.map((v, n) => v * Math.min(1, n / a) * Math.min(1, (x.length - 1 - n) / b));
};

const gen = (dur, fn) => {
  const out = new Float64Array(N(dur));
  for (let n = 0; n < out.length; n++) out[n] = fn(n / SR, n);
  return out;
};

const sounds = {
  // soft pop: sine with fast downward pitch glide + short envelope
  pop: () => {
    let ph = 0;
    const raw = gen(0.2, (t) => {
      ph += (2 * Math.PI * (170 + 380 * Math.exp(-t / 0.035))) / SR;
      return (Math.sin(ph) + 0.18 * Math.sin(2 * ph)) * (1 - Math.exp(-t / 0.002)) * Math.exp(-t / 0.055);
    });
    return tinyReverb(lowpass(raw, 3800), 0.1);
  },
  // crisp click: tiny high-passed noise burst + a hint of tone
  click: () => {
    const raw = gen(0.08, (t) => {
      const e = (1 - Math.exp(-t / 0.0005)) * Math.exp(-t / 0.0035);
      return rnd() * e + 0.35 * Math.sin(2 * Math.PI * 2200 * t) * (1 - Math.exp(-t / 0.0005)) * Math.exp(-t / 0.004);
    });
    return tinyReverb(lowpass(highpass(raw, 2200), 8000), 0.08);
  },
  // soft whoosh for text entry: band-passed noise sweep, fade in/out
  whoosh: () => {
    const dur = 0.55;
    const noise = gen(dur, () => rnd());
    const sw = bandSweep(noise, 260, 2600, 1.1);
    const env = gen(dur, (t) => Math.pow(Math.sin(Math.PI * Math.pow(t / dur, 0.78)), 1.8));
    return tinyReverb(lowpass(sw.map((v, i) => v * env[i]), 5500), 0.12);
  },
  // shorter, brighter swipe for scene transitions
  swipe: () => {
    const dur = 0.4;
    const noise = gen(dur, () => rnd());
    const sw = bandSweep(noise, 600, 3400, 1.4);
    const env = gen(dur, (t) => Math.pow(Math.sin(Math.PI * Math.pow(t / dur, 0.7)), 1.6));
    return tinyReverb(lowpass(sw.map((v, i) => v * env[i]), 6500), 0.1);
  },
  // chime: soft plucked partials with fast decay
  chime: () => {
    const partials = [[880, 1, 0.38], [1318.5, 0.45, 0.28], [1760, 0.3, 0.2], [2637, 0.12, 0.12]];
    const raw = gen(0.4, (t) => {
      let s = 0;
      for (const [f, a, d] of partials) s += a * Math.sin(2 * Math.PI * f * t) * Math.exp(-t / d);
      return s * (1 - Math.exp(-t / 0.003));
    });
    return tinyReverb(lowpass(raw, 6000), 0.18);
  },
  // restrained soft thud for the hook / key message
  thud: () => {
    let ph = 0;
    const raw = gen(0.32, (t) => {
      ph += (2 * Math.PI * (48 + 62 * Math.exp(-t / 0.05))) / SR;
      return Math.sin(ph) * (1 - Math.exp(-t / 0.006)) * Math.exp(-t / 0.11);
    });
    return tinyReverb(lowpass(raw, 700), 0.08);
  },
};

const TARGET_RMS = 0.14; // matched loudness across the kit
const PEAK_CAP = 0.9;

const writeWav = (file, x) => {
  const buf = Buffer.alloc(44 + x.length * 2);
  buf.write("RIFF", 0); buf.writeUInt32LE(36 + x.length * 2, 4); buf.write("WAVE", 8);
  buf.write("fmt ", 12); buf.writeUInt32LE(16, 16); buf.writeUInt16LE(1, 20); buf.writeUInt16LE(1, 22);
  buf.writeUInt32LE(SR, 24); buf.writeUInt32LE(SR * 2, 28); buf.writeUInt16LE(2, 32); buf.writeUInt16LE(16, 34);
  buf.write("data", 36); buf.writeUInt32LE(x.length * 2, 40);
  for (let i = 0; i < x.length; i++) buf.writeInt16LE(Math.max(-32767, Math.min(32767, Math.round(x[i] * 32767))), 44 + i * 2);
  fs.writeFileSync(file, buf);
};

const dir = new URL("../public/sfx/", import.meta.url);
fs.mkdirSync(dir, { recursive: true });
for (const [name, make] of Object.entries(sounds)) {
  seed = 20261021;
  let x = fades(make());
  let peak = 0, sum = 0, cnt = 0;
  for (const v of x) peak = Math.max(peak, Math.abs(v));
  for (const v of x) if (Math.abs(v) > 0.02 * peak) { sum += v * v; cnt++; }
  const rms = Math.sqrt(sum / Math.max(1, cnt));
  const gain = Math.min(PEAK_CAP / peak, TARGET_RMS / rms);
  x = x.map((v) => v * gain);
  writeWav(new URL(`${name}.wav`, dir), x);
}
console.log("sfx written:", Object.keys(sounds).join(", "));
