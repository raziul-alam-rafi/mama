import React from "react";
import { AbsoluteFill, Sequence } from "remotion";
import { PreviewAudio } from "./components/audio";
import { BgMesh, Grade, Grain, Vignette } from "./components/Layers";
import { SceneFrame, Wipe } from "./components/Primitives";
import { loadFonts } from "./fonts";
import { S1Hook } from "./scenes/S1Hook";
import { S2Apple } from "./scenes/S2Apple";
import { S3Scatter } from "./scenes/S3Scatter";
import { S4Control } from "./scenes/S4Control";
import { S5Lens } from "./scenes/S5Lens";
import { S6Optics } from "./scenes/S6Optics";
import { scenes } from "./timeline";
import { theme } from "./theme";

loadFonts();

const SCENE_COMPONENTS: React.FC[] = [S1Hook, S2Apple, S3Scatter, S4Control, S5Lens, S6Optics];

export const Main: React.FC = () => (
  <AbsoluteFill style={{ background: theme.colors.bg, fontFamily: theme.fonts.body }}>
    {/* স্তর ১: ব্যাকগ্রাউন্ড মেশ */}
    <BgMesh />
    <PreviewAudio />
    {/* স্তর ২–৩: সিনের অ্যাসেট + গ্রাফিক্স + টাইপ */}
    {scenes.map((s, i) => {
      const C = SCENE_COMPONENTS[i];
      if (!C) return null;
      return (
        <Sequence key={s.id} from={s.start} durationInFrames={s.duration}>
          <SceneFrame duration={s.duration}>
            <C />
          </SceneFrame>
        </Sequence>
      );
    })}
    {/* সিন ট্রানজিশন */}
    {scenes.slice(1).map((s, i) => (
      <Wipe key={s.id} boundary={s.start} index={i} />
    ))}
    {/* স্তর ৪: কালার গ্রেড · স্তর ৫: গ্রেইন + ভিনিয়েট */}
    <Grade />
    <Grain />
    <Vignette />
  </AbsoluteFill>
);
