import React from "react";
import {AbsoluteFill, spring, useCurrentFrame, useVideoConfig} from "remotion";
import {theme} from "../theme";
import {at, atEnd} from "../timeline";
import {SvgDefs} from "../components/Optics";
import {ELEMS_BASE, FOCUS, LensRig} from "../components/Rig";
import {Headlines, Tag} from "../components/Text";
import {Sfx} from "../components/Sfx";
import {prog} from "../components/util";

const SI = 0;
const AX = 650;
const HEIGHTS = [-105, -70, -35, 0, 35, 70, 105];

/** Scene 1 — cutaway of a multi-element camera lens; exploded parts assemble, then light is bent through them. */
export const S1Lens: React.FC = () => {
  const frame = useCurrentFrame();
  const {fps} = useVideoConfig();

  const tEl = at(SI, 1, "একাধিক");
  const tLabel = at(SI, 1, "Optical");
  const tHead2 = at(SI, 1, "আলোকে"); // headline follows the spoken words
  const tRays = tLabel + 18; // rays start once the labelled elements are in place (scene is short)
  const end = atEnd(SI, 1);

  const reveal = prog(frame, 3, 26, theme.ease.inOut);
  const assemble = ELEMS_BASE.map((_, i) =>
    spring({frame: frame - (tEl - 14) - i * 5, fps, config: theme.spring.smooth}),
  );
  const rayDur = 32;
  const rayP = HEIGHTS.map((_, i) => prog(frame, tRays + i * 2, rayDur, theme.ease.inOut));
  const tFocus = tRays + 6 * 2 + rayDur - 4;
  const glow = prog(frame, tFocus, 14);

  const bracket = prog(frame, tLabel - 4, 18);
  const bx0 = 600 + 170, bx1 = 1030 + 170, by = AX - 195;

  return (
    <AbsoluteFill>
      <svg width={1920} height={1080} viewBox="0 0 1920 1080" style={{position: "absolute", inset: 0}}>
        <SvgDefs />
        <LensRig
          id="s1" k={1} tx={170} ty={AX} reveal={reveal} assemble={assemble}
          heights={HEIGHTS} rayP={rayP} startX={-130} sensorGlow={glow}
        />
        {/* bracket over the optical elements */}
        <g opacity={bracket} filter="url(#glowSm)">
          <path d={`M ${bx0} ${by + 14} V ${by} H ${bx1} V ${by + 14}`} fill="none" stroke={theme.colors.accent}
            strokeWidth={theme.stroke.base} strokeLinecap="round" strokeDasharray="1200" strokeDashoffset={(1 - bracket) * 1200} />
          {ELEMS_BASE.map((e, i) => (
            <line key={i} x1={e.x + 170} x2={e.x + 170} y1={by + 14} y2={AX - e.h - 12} stroke={theme.colors.accent}
              strokeWidth={2} strokeDasharray="6 8" opacity={0.8} />
          ))}
        </g>
      </svg>

      <Headlines
        items={[
          {words: ["ক্যামেরার", "লেন্স"], from: 4, to: tHead2 - 2},
          {words: ["আলোকে", {t: "বাঁকিয়ে", color: theme.colors.accent}, "ভেতরে", "পাঠায়"], from: tHead2 - 2, to: end + 4},
        ]}
        size={92}
      />
      <Tag x={(bx0 + bx1) / 2} y={by - 44} text="Optical Element" accent delay={tLabel} size={38} />
      <Sfx at={3} name="thud" />
      <Sfx at={tEl} name="pop" />
      <Sfx at={tLabel} name="pop" rate={1.15} vol={0.8} />
      <Sfx at={tRays} name="whoosh" vol={0.55} />
      <Sfx at={tFocus} name="chime" />
    </AbsoluteFill>
  );
};
