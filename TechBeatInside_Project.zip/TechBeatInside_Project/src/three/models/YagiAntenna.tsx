import React from 'react';
import {COLORS} from '../../config/theme';
import {Beam} from './parts';

type V3 = [number, number, number];

/**
 * Rooftop Yagi-Uda TV antenna. Proportions follow research/component-reference.md:
 *  - reflector ~5% longer than the driven element, behind it
 *  - directors slightly shorter than the driven element, in front
 *  - driven element = folded dipole (twin-lead match)
 *  - reflector->dipole 0.35 lambda, dipole->director1 0.125 lambda, director spacing 0.2 lambda
 * with lambda = 2.0 (half-wave element = 1.0 in scene units / metres).
 * Local frame: boom along X, directors toward -X (toward the transmitter), elements horizontal along Z.
 */
const L = 1.0;
const ELEMENTS: {name: string; x: number; len: number}[] = [
  {name: 'Reflector', x: 0, len: 1.05 * L},
  {name: 'Director_1', x: -0.95, len: 0.94 * L},
  {name: 'Director_2', x: -1.35, len: 0.92 * L},
  {name: 'Director_3', x: -1.75, len: 0.9 * L},
  {name: 'Director_4', x: -2.15, len: 0.88 * L},
  {name: 'Director_5', x: -2.55, len: 0.86 * L},
  {name: 'Director_6', x: -2.95, len: 0.84 * L},
];
const DRIVEN_X = -0.7;

export const YagiAntenna: React.FC<{position: V3; excite?: number}> = ({position, excite = 0}) => {
  const alu = {color: '#c4cad1', metalness: 1, roughness: 0.28, envMapIntensity: 1.3} as const;
  const glow = excite;
  return (
    <group position={position} name="Yagi_Antenna">
      {/* boom */}
      <mesh position={[-1.5, 0, 0]} rotation={[0, 0, Math.PI / 2]} name="Boom">
        <cylinderGeometry args={[0.022, 0.022, 3.3, 16]} />
        <meshStandardMaterial color="#aeb4bb" metalness={1} roughness={0.35} envMapIntensity={1.2} />
      </mesh>
      {/* parasitic elements (solid rods) */}
      {ELEMENTS.map((e) => (
        <group key={e.name} position={[e.x, 0, 0]} name={e.name}>
          <mesh rotation={[Math.PI / 2, 0, 0]}>
            <cylinderGeometry args={[0.009, 0.009, e.len, 10]} />
            <meshStandardMaterial {...alu} />
          </mesh>
          <mesh>
            <boxGeometry args={[0.05, 0.05, 0.05]} />
            <meshStandardMaterial color="#222" roughness={0.7} />
          </mesh>
        </group>
      ))}
      {/* driven element: folded dipole (two rods + end bends) with insulated centre */}
      <group position={[DRIVEN_X, 0, 0]} name="Driven_Element_Folded_Dipole">
        {[-0.0275, 0.0275].map((dx) => (
          <mesh key={dx} position={[dx, 0, 0]} rotation={[Math.PI / 2, 0, 0]}>
            <cylinderGeometry args={[0.009, 0.009, 1.0 * L, 10]} />
            <meshStandardMaterial
              {...alu}
              emissive={COLORS.signal}
              emissiveIntensity={glow * 1.6}
            />
          </mesh>
        ))}
        {[-0.5, 0.5].map((z) => (
          <mesh key={z} position={[0, 0, z * L]} rotation={[0, Math.PI / 2, 0]}>
            <torusGeometry args={[0.0275, 0.009, 8, 16, Math.PI]} />
            <meshStandardMaterial {...alu} emissive={COLORS.signal} emissiveIntensity={glow * 1.6} />
          </mesh>
        ))}
        {/* feed block (plastic insulator) + twin-lead terminals */}
        <mesh position={[0, 0, 0]} name="Feed_Insulator">
          <boxGeometry args={[0.1, 0.07, 0.1]} />
          <meshStandardMaterial color="#17181a" roughness={0.6} />
        </mesh>
        <mesh position={[0, 0.06, 0]}>
          <boxGeometry args={[0.07, 0.05, 0.07]} />
          <meshStandardMaterial color="#17181a" roughness={0.6} />
        </mesh>
      </group>
      {/* boom-to-mast clamp */}
      <mesh position={[-1.3, -0.04, 0]}>
        <boxGeometry args={[0.16, 0.06, 0.1]} />
        <meshStandardMaterial color="#6d737b" metalness={0.9} roughness={0.45} />
      </mesh>
      {/* mast */}
      <Beam a={[-1.3, -0.08, 0.0]} b={[-1.3, -2.45, 0.0]} r={0.032}>
        <meshStandardMaterial color="#9aa0a7" metalness={1} roughness={0.4} envMapIntensity={1.1} />
      </Beam>
    </group>
  );
};
