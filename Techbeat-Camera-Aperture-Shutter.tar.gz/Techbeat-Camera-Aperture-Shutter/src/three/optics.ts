// Pure geometry shared by blades, rays and sensor so they can never disagree.
export const BLADES = 8;
export const BEAM_START_Z = -4; // where rays begin
export const BLADE_Z = 0; // aperture plane
export const SENSOR_Z = 3;

/** A ray at (x,y) passes iff it is inside ALL blade half-planes (inscribed octagon of radius r). */
export const passes = (x: number, y: number, r: number) => {
  for (let i = 0; i < BLADES; i++) {
    const th = (i * 2 * Math.PI) / BLADES;
    if (x * Math.cos(th) + y * Math.sin(th) >= r) return false;
  }
  return true;
};

export type RayDef = {x: number; y: number; phase: number};
const SPACING = 0.3;
const MAX_R = 1.75;
export const RAYS: RayDef[] = (() => {
  const out: RayDef[] = [];
  const n = Math.floor(MAX_R / SPACING);
  for (let ix = -n; ix <= n; ix++) {
    for (let iy = -n; iy <= n; iy++) {
      const x = ix * SPACING, y = iy * SPACING;
      if (Math.hypot(x, y) <= MAX_R) out.push({x, y, phase: (((ix + 9) * 7 + (iy + 9) * 13) % 10) / 10});
    }
  }
  return out;
})();

/** Fraction of rays reaching the sensor = proxy for light amount (area ~ r^2). */
export const passFraction = (r: number) => RAYS.filter((q) => passes(q.x, q.y, r)).length / RAYS.length;
