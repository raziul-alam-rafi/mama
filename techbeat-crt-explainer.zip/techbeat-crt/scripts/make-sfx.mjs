// Synthesizes a small, soft, UI-style SFX kit (16-bit mono WAV, 44.1 kHz) into public/sfx/.
// No dependencies. Re-run with:  npm run sfx
import { writeFileSync, mkdirSync } from "node:fs";
import { dirname, join } from "node:path";
import { fileURLToPath } from "node:url";

const SR = 44100;
const outDir = join(dirname(fileURLToPath(import.meta.url)), "..", "public", "sfx");
mkdirSync(outDir, { recursive: true });

let seed = 12345;
const rnd = () => ((seed = (seed * 1664525 + 1013904223) >>> 0) / 4294967296) * 2 - 1;
const buf = (sec) => new Float32Array(Math.floor(sec * SR));

// biquad filters
const biquad = (type, f0, q = 0.707) => {
  const w = (2 * Math.PI * f0) / SR, c = Math.cos(w), s = Math.sin(w), a = s / (2 * q);
  let b0, b1, b2, a0 = 1 + a, a1 = -2 * c, a2 = 1 - a;
  if (type === "lp") { b0 = (1 - c) / 2; b1 = 1 - c; b2 = (1 - c) / 2; }
  else if (type === "hp") { b0 = (1 + c) / 2; b1 = -(1 + c); b2 = (1 + c) / 2; }
  else { b0 = a; b1 = 0; b2 = -a; } // bp
  let x1 = 0, x2 = 0, y1 = 0, y2 = 0;
  const st = { b0, b1, b2, a0, a1, a2 };
  return (x) => {
    const y = (st.b0 * x + st.b1 * x1 + st.b2 * x2 - st.a1 * y1 - st.a2 * y2) / st.a0;
    x2 = x1; x1 = x; y2 = y1; y1 = y; return y;
  };
};
const setBq = (f, type, f0, q) => { /* re-create for sweeps */ return biquad(type, f0, q); };

const env = (i, n, att, dec) => {
  const t = i / SR;
  const a = Math.min(1, t / att);
  return a * Math.exp(-t * dec);
};

const tinyReverb = (b) => {
  const taps = [[Math.floor(0.021 * SR), 0.16], [Math.floor(0.034 * SR), 0.11], [Math.floor(0.047 * SR), 0.07]];
  const out = new Float32Array(b.length);
  for (let i = 0; i < b.length; i++) {
    let v = b[i];
    for (const [d, g] of taps) if (i - d >= 0) v += b[i - d] * g;
    out[i] = v;
  }
  return out;
};

const finish = (b, lpHz = 9000, peak = 0.9) => {
  const lp = biquad("lp", lpHz, 0.7);
  let o = new Float32Array(b.length);
  for (let i = 0; i < b.length; i++) o[i] = lp(b[i]);
  o = tinyReverb(o);
  // fades to avoid clicks
  const fi = Math.floor(0.002 * SR), fo = Math.floor(0.02 * SR);
  for (let i = 0; i < fi; i++) o[i] *= i / fi;
  for (let i = 0; i < fo; i++) o[o.length - 1 - i] *= i / fo;
  let m = 0;
  for (const v of o) m = Math.max(m, Math.abs(v));
  const g = m > 0 ? peak / m : 1;
  return o.map((v) => v * g);
};

const sounds = {};

// pop: sine with fast downward pitch + small envelope
sounds.pop = (() => {
  const b = buf(0.22); let ph = 0;
  for (let i = 0; i < b.length; i++) {
    const t = i / SR, f = 180 + 420 * Math.exp(-t * 26);
    ph += (2 * Math.PI * f) / SR;
    b[i] = Math.sin(ph) * env(i, b.length, 0.003, 22) + 0.15 * Math.sin(ph * 2) * env(i, b.length, 0.003, 40);
  }
  return finish(b, 7000);
})();

// click: high-passed short noise burst + faint tone
sounds.click = (() => {
  const b = buf(0.12), hp = biquad("hp", 2200, 0.8); let ph = 0;
  for (let i = 0; i < b.length; i++) {
    ph += (2 * Math.PI * 1500) / SR;
    b[i] = hp(rnd()) * env(i, b.length, 0.0008, 95) * 0.9 + 0.25 * Math.sin(ph) * env(i, b.length, 0.001, 70);
  }
  return finish(b, 8500);
})();

// tick: very small, quieter click
sounds.tick = (() => {
  const b = buf(0.07), hp = biquad("hp", 3000, 0.8); let ph = 0;
  for (let i = 0; i < b.length; i++) {
    ph += (2 * Math.PI * 2100) / SR;
    b[i] = hp(rnd()) * env(i, b.length, 0.0005, 150) * 0.6 + 0.4 * Math.sin(ph) * env(i, b.length, 0.0008, 120);
  }
  return finish(b, 9000);
})();

// whoosh: band-passed noise with a rising sweep, fade in/out
sounds.whoosh = (() => {
  const b = buf(0.7); let f1 = biquad("bp", 300, 0.9), lastF = 300;
  for (let i = 0; i < b.length; i++) {
    const t = i / b.length;
    const fc = 300 * Math.pow(8, t); // 300 -> 2400 Hz
    if (i % 64 === 0) { f1 = biquad("bp", fc, 0.9); lastF = fc; }
    const e = Math.pow(Math.sin(Math.PI * Math.min(1, t * 1.05)), 2);
    b[i] = f1(rnd()) * e * 2.2;
  }
  return finish(b, 6000);
})();

// chime: soft pluck with gentle overtones
sounds.chime = (() => {
  const b = buf(0.5);
  for (let i = 0; i < b.length; i++) {
    const t = i / SR;
    b[i] =
      (Math.sin(2 * Math.PI * 880 * t) * 1.0 +
        Math.sin(2 * Math.PI * 1318.5 * t) * 0.42 +
        Math.sin(2 * Math.PI * 2637 * t) * 0.12) * env(i, b.length, 0.004, 9);
  }
  return finish(b, 6500);
})();

// thud: restrained soft low hit (hook accent)
sounds.thud = (() => {
  const b = buf(0.4); let ph = 0;
  for (let i = 0; i < b.length; i++) {
    const t = i / SR, f = 46 + 70 * Math.exp(-t * 18);
    ph += (2 * Math.PI * f) / SR;
    b[i] = Math.sin(ph) * env(i, b.length, 0.008, 9);
  }
  return finish(b, 1400);
})();

function wav(samples) {
  const n = samples.length, out = Buffer.alloc(44 + n * 2);
  out.write("RIFF", 0); out.writeUInt32LE(36 + n * 2, 4); out.write("WAVE", 8);
  out.write("fmt ", 12); out.writeUInt32LE(16, 16); out.writeUInt16LE(1, 20); out.writeUInt16LE(1, 22);
  out.writeUInt32LE(SR, 24); out.writeUInt32LE(SR * 2, 28); out.writeUInt16LE(2, 32); out.writeUInt16LE(16, 34);
  out.write("data", 36); out.writeUInt32LE(n * 2, 40);
  for (let i = 0; i < n; i++) out.writeInt16LE(Math.max(-32768, Math.min(32767, Math.round(samples[i] * 32767))), 44 + i * 2);
  return out;
}

console.log("name      dur(s)  peak   clipped");
for (const [name, s] of Object.entries(sounds)) {
  let peak = 0, clipped = 0;
  for (const v of s) { peak = Math.max(peak, Math.abs(v)); if (Math.abs(v) >= 0.999) clipped++; }
  writeFileSync(join(outDir, name + ".wav"), wav(s));
  console.log(`${name.padEnd(9)} ${(s.length / SR).toFixed(2).padStart(5)}  ${peak.toFixed(3)}  ${clipped}`);
}
