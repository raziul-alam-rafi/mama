import { loadFont } from "@remotion/google-fonts/HindSiliguri";

// Hind Siliguri: যুক্তাক্ষর ঠিকঠাক আসে, 700 ওজন শিরোনামের জন্য।
export const { fontFamily } = loadFont("normal", {
  weights: ["500", "600", "700"],
  subsets: ["bengali", "latin"],
});
