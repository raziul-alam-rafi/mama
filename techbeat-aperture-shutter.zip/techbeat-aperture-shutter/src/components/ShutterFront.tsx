import React from "react";
import { theme } from "../theme";
import { lerp } from "./Motion";

/** curtain edge positions in ±180 units. p1 = first curtain opening, p2 = second curtain closing (0..1) */
export const shutterEdges = (p1: number, p2: number): [number, number] => [lerp(180, -180, p1), lerp(180, -180, p2)];

/** Focal-plane shutter seen from the front. Two curtains travel vertically; light passes through the gap. */
export const ShutterFront: React.FC<{ w: number; h: number; p1: number; p2: number; uid?: string; sensorLabel?: boolean }> = ({
  w, h, p1, p2, uid = "sf",
}) => {
  const [e1, e2] = shutterEdges(p1, p2);
  const Y = (v: number) => ((v + 180) / 360) * h;
  const open = e2 > e1;
  const frame = 14;
  const lines = (y0: number, y1: number) => {
    const out: React.ReactNode[] = [];
    for (let y = Math.ceil(y0 / 14) * 14; y < y1; y += 14) {
      out.push(<line key={y} x1={frame} x2={w - frame} y1={y} y2={y} stroke={theme.colors.bgAlt} strokeOpacity={0.55} strokeWidth={2} />);
    }
    return out;
  };
  const c1h = Y(e1), c2y = Y(e2);
  return (
    <svg width={w} height={h} viewBox={`0 0 ${w} ${h}`}>
      <defs>
        <linearGradient id={`${uid}-cur`} x1="0" y1="0" x2="1" y2="0">
          <stop offset="0" stopColor={theme.colors.metalDark} />
          <stop offset="0.5" stopColor={theme.colors.metal} />
          <stop offset="1" stopColor={theme.colors.metalDark} />
        </linearGradient>
        <clipPath id={`${uid}-win`}>
          <rect x={frame} y={frame} width={w - frame * 2} height={h - frame * 2} rx={8} />
        </clipPath>
      </defs>
      <rect width={w} height={h} rx={22} fill={theme.colors.panel} stroke={theme.colors.line} strokeWidth={3} />
      <g clipPath={`url(#${uid}-win)`}>
        <rect width={w} height={h} fill={theme.colors.bg} />
        {open && (
          <rect x={frame} y={Math.max(frame, c1h)} width={w - frame * 2} height={Math.max(0, Math.min(h, c2y) - Math.max(frame, c1h))} fill={theme.colors.light} opacity={0.92} />
        )}
        <rect x={frame} y={0} width={w - frame * 2} height={Math.max(0, c1h)} fill={`url(#${uid}-cur)`} />
        {lines(0, c1h)}
        <rect x={frame} y={c2y} width={w - frame * 2} height={Math.max(0, h - c2y)} fill={`url(#${uid}-cur)`} />
        {lines(c2y, h)}
        {open && <line x1={frame} x2={w - frame} y1={c1h} y2={c1h} stroke={theme.colors.accent} strokeWidth={4} />}
        {open && <line x1={frame} x2={w - frame} y1={c2y} y2={c2y} stroke={theme.colors.accent} strokeWidth={4} />}
      </g>
    </svg>
  );
};
