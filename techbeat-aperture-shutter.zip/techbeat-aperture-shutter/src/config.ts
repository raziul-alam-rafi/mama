// Switches for voice-over handling.
// public/voiceover.mp3 is played in Remotion Studio preview if the file exists.
export const PREVIEW_VOICEOVER = true; // Studio preview
export const RENDER_VOICEOVER = false; // final render (default: off — add in your editor)
export const VOICEOVER_FILE = "voiceover.mp3";

export const WIDTH = 1920;
export const HEIGHT = 1080;
export const FPS = 30;
