FreeSans.ttf, FreeSansBold.ttf — GNU FreeFont (GPLv3+ with font-embedding exception).
Optional drop-in: HindSiliguri-Bold.ttf, HindSiliguri-Regular.ttf (Google Fonts, OFL).
