// প্রতিটি SFX-এর দৈর্ঘ্য, peak (dBFS), clipping ও RMS যাচাই
import fs from "node:fs";
const dir = new URL("../public/sfx/", import.meta.url);
for (const f of fs.readdirSync(dir).filter((f) => f.endsWith(".wav")).sort()) {
  const b = fs.readFileSync(new URL(f, dir)); const n = (b.length - 44) / 2; let pk = 0, ss = 0, clip = 0;
  for (let i = 0; i < n; i++) { const v = b.readInt16LE(44 + i * 2) / 32768; pk = Math.max(pk, Math.abs(v)); ss += v * v; if (Math.abs(v) >= 0.999) clip++; }
  const dur = n / 44100;
  console.log(f.padEnd(12), `দৈর্ঘ্য ${dur.toFixed(2)}s`, `peak ${(20 * Math.log10(pk)).toFixed(1)}dBFS (${pk.toFixed(2)})`, `rms ${(20 * Math.log10(Math.sqrt(ss / n))).toFixed(1)}dB`, `clipping ${clip}`, dur > 0.8 ? "⚠ দীর্ঘ" : "ok");
}
