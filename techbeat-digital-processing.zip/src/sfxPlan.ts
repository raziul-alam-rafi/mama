// Sound-effect plan. Every time comes from the SRT anchors (T / cueStart) — nothing is hand-placed.
// Only main entrances, card/logo reveals, checks and scene transitions get a sound (not every staggered item).
import { T, cueStart } from "./timing";

export type SfxName = "pop" | "click" | "whoosh" | "chime" | "thud" | "tick";
export type SfxEvent = { sec: number; name: SfxName; vol: number; rate?: number };
// clip lengths in seconds (from scripts/make-sfx.mjs) — bounds each <Audio>.
export const SFX_LEN: Record<SfxName, number> = { pop: 0.22, click: 0.1, whoosh: 0.6, chime: 0.52, thud: 0.3, tick: 0.07 };

// base volumes (sounds are peak-normalised; these even out the perceived level and stay under the voice-over)
const V = { pop: 0.26, click: 0.34, whoosh: 0.28, chime: 0.28, thud: 0.24, tick: 0.3 };
const ev = (name: SfxName, sec: number, k = 1, rate = 1): SfxEvent => ({ sec, name, vol: +(V[name] * k).toFixed(3), rate });
const swipe = (cue: number) => ev("whoosh", cueStart(cue) - 0.16);

export const SFX_PLAN: SfxEvent[] = [
  // scene 1 — hook
  ev("thud", T("Digital") - 0.12),
  ev("pop", T("সেন্সরে") - 0.05),
  // scene 2 — readout, ADC, processor
  swipe(2),
  ev("click", T("Electronic") + 0.3),
  ev("pop", T("এরপর") - 0.25, 1, 1.04),
  ev("tick", T("Digital সংখ্যায়") - 0.05),
  ev("tick", T("Digital সংখ্যায়") + 0.45, 0.9, 1.08),
  ev("pop", T("করা") - 0.2, 1, 0.96),
  // scene 3 — pixel numbers, colour filter, neighbours
  swipe(4),
  ev("pop", T("Pixel") + 0.2, 0.9),
  ev("click", T("কিন্তু রঙিন") - 0.1),
  ev("pop", T("পাশের") - 0.1, 1, 1.05),
  ev("tick", T("একসঙ্গে") - 0.05),
  // scene 4 — Demosaicing
  swipe(6),
  ev("thud", T("Demosaicing") - 0.18, 1.1),
  ev("pop", T("ক্যামেরা আশেপাশের") - 0.1, 0.9),
  ev("click", T("অনুমান") - 0.1),
  ev("whoosh", T("রঙের নমুনা") - 0.1, 0.8),
  ev("chime", T("পূর্ণাঙ্গ রঙিন") - 0.15),
  // scene 5 — Image Processor
  swipe(9),
  ev("pop", T("Processor ছবির") - 0.05, 1, 0.97),
  ev("click", T("উজ্জ্বলতা") - 0.1),
  ev("click", T("Contrast") - 0.1, 0.9, 1.06),
  ev("pop", T("Noise") - 0.1, 0.9, 1.04),
  ev("click", T("উজ্জ্বল ও অন্ধকার") - 0.1),
  ev("chime", T("অর্থাৎ") + 0.35, 0.9),
  ev("click", T("চাপ") + 0.02, 1.05),
  // scene 6 — recap
  swipe(12),
  ev("pop", T("বরং") - 0.05, 0.9),
  ev("whoosh", T("বিপুল") - 0.2, 0.7),
  ev("tick", T("ব্যবহারযোগ্য") + 0.05, 1, 1.0),
  ev("tick", T("ব্যবহারযোগ্য") + 0.55, 0.95, 1.05),
  ev("tick", T("ব্যবহারযোগ্য") + 1.05, 0.95, 1.1),
  ev("tick", T("ব্যবহারযোগ্য") + 1.55, 0.95, 1.15),
  ev("chime", T("Smartphone") - 0.1),
  ev("pop", T("আরও এক ধাপ"), 0.9, 1.06),
];
