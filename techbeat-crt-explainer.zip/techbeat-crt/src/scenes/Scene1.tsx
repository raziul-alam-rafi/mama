// Scene 1 — HOOK. "টিভিতে ছবির তথ্য আসত কোথা থেকে? ... ক্রিকেট ম্যাচ"
// Style: Kinetic Typography + pseudo-3D CRT TV (static -> cricket picture).
import React from "react";
import { AbsoluteFill, useCurrentFrame } from "remotion";
import { theme } from "../theme";
import { BEATS } from "../timeline";
import { ip, Pop, Tag, WordReveal } from "../components/kit";
import { CRTTV, CricketField, StaticNoise } from "../components/objects";
import { SceneProps, makeQ } from "./types";

export const Scene1: React.FC<SceneProps> = ({ cs, cd }) => {
  const frame = useCurrentFrame();
  const q = makeQ(cs, cd);
  const reveal = q(BEATS.s1.reveal);
  const rot = ip(frame, [0, cs + cd], [-38, -30]);
  const float = Math.sin(frame / 30) * 6;
  const cricketO = ip(frame, [reveal, reveal + 12], [0, 1], theme.ease.out);
  const on = ip(frame, [reveal - 4, reveal + 16], [0.55, 1], theme.ease.out);
  return (
    <AbsoluteFill>
      {/* TV (right) */}
      <div
        style={{
          position: "absolute",
          left: 780,
          top: 190 + float,
        }}
      >
        <Pop delay={2} y={80} s={0.9}>
          <CRTTV
            rot={rot}
            on={on}
            scale={1.0}
            screen={
              <div style={{ position: "absolute", inset: 0 }}>
                <div style={{ position: "absolute", inset: 0, opacity: 1 - cricketO }}>
                  <StaticNoise />
                </div>
                <div style={{ position: "absolute", inset: 0, opacity: cricketO }}>
                  <CricketField t={Math.max(0, frame - reveal)} />
                </div>
              </div>
            }
          />
        </Pop>
      </div>

      {/* Kinetic headline (left) */}
      <div style={{ position: "absolute", left: 110, top: 250, width: 800 }}>
        <WordReveal
          text="ছবির তথ্য আসত কোথা থেকে?"
          delay={q(BEATS.s1.title)}
          per={5}
          size={118}
          highlight={[3, 4]}
        />
      </div>

      <div style={{ position: "absolute", left: 114, top: 760 }}>
        <Tag text="ক্রিকেট ম্যাচ" tone="accent" delay={reveal + 4} size={52} />
      </div>
    </AbsoluteFill>
  );
};
