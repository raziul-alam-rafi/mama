# Camera, Light & Lens — Remotion মোশন গ্রাফিক্স (1920×1080, 30fps)

    npm install
    npx remotion studio                                  # প্রিভিউ (কম্পোজিশন: Main)
    npx remotion render src/index.ts Main out/video.mp4  # MP4 রেন্ডার

- সময় সব `script.srt` থেকে আসে (`src/timeline.ts`)। SRT বদলালে: `node scripts/srt-to-ts.mjs`
- রং/ফন্ট/ইজিং: `src/theme.ts` (কালার স্কিম: Midnight Lens)
- ভয়েসওভার: `public/voiceover.mp3` রাখলে Studio-তে বাজবে; রেন্ডারে মেশাতে `src/config.ts`-এ `render: true`
- SFX: `public/sfx/*.wav` (পুনরায় বানাতে `npm run sfx`)
- ফন্ট: বান্ডলড GNU FreeFont (`public/fonts`)। আরও ভালো বাংলা হেভি-ওজনের জন্য `HindSiliguri-Bold.ttf` ও
  `HindSiliguri-Regular.ttf` ওই ফোল্ডারে রাখলেই সেটা আগে ব্যবহার হবে।
