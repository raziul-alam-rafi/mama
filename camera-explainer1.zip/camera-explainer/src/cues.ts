// Timing helpers — SRT (via cues.data.ts) is the ONLY time source.
import { CUES } from "./cues.data";
import { VIDEO, theme } from "./theme";

export type Cue = { id: number; start: number; end: number; text: string };
const list = CUES as unknown as Cue[];

export const cue = (id: number): Cue => {
  const c = list.find((x) => x.id === id);
  if (!c) throw new Error(`cue ${id} missing in SRT`);
  return c;
};

/** seconds at which `phrase` starts inside cue `id` (linear by character position within the cue) */
export const ph = (id: number, phrase: string): number => {
  const c = cue(id);
  const i = c.text.indexOf(phrase);
  if (i < 0) throw new Error(`phrase "${phrase}" not found in cue ${id}: ${c.text}`);
  return c.start + (i / c.text.length) * (c.end - c.start);
};

export const sec2f = (s: number) => Math.round(s * VIDEO.fps);

export type SceneDef = { key: string; from: number; dur: number };

const bounds: { key: string; firstCue: number }[] = [
  { key: "hook", firstCue: 1 },
  { key: "sunlight", firstCue: 3 },
  { key: "problem", firstCue: 5 },
  { key: "control", firstCue: 7 },
  { key: "lens", firstCue: 9 },
  { key: "elements", firstCue: 10 },
];

export const LAST_END = list[list.length - 1].end;
export const TOTAL_FRAMES = Math.ceil((LAST_END + theme.timing.tailSec) * VIDEO.fps);

export const SCENES: SceneDef[] = bounds.map((b, i) => {
  const from = i === 0 ? 0 : sec2f(cue(b.firstCue).start);
  const nextFrom = i === bounds.length - 1 ? TOTAL_FRAMES : sec2f(cue(bounds[i + 1].firstCue).start);
  return { key: b.key, from, dur: nextFrom - from };
});

/** frame (local to the scene starting at `sceneFrom`) at which something tied to `phrase` should appear */
export const beat = (sceneFrom: number, id: number, phrase?: string, lead = theme.timing.leadSec): number =>
  Math.max(0, sec2f((phrase ? ph(id, phrase) : cue(id).start) - lead) - sceneFrom);
