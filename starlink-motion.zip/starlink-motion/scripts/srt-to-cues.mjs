// SRT -> src/cues.ts. The SRT is the single source of timing truth.
import fs from "node:fs";
const srt = fs.readFileSync(new URL("../public/voiceover.srt", import.meta.url), "utf8").replace(/\r/g, "");
const ms = (h, m, s, f) => ((+h * 60 + +m) * 60 + +s) * 1000 + +f;
const cues = srt.trim().split(/\n\s*\n/).map((blk) => {
  const lines = blk.split("\n");
  const m = lines[1].match(/(\d+):(\d+):(\d+),(\d+)\s*-->\s*(\d+):(\d+):(\d+),(\d+)/);
  return {
    i: +lines[0],
    start: ms(m[1], m[2], m[3], m[4]),
    end: ms(m[5], m[6], m[7], m[8]),
    text: lines.slice(2).join(" ").replace(/\s+/g, " ").trim(),
  };
});
const out = `// AUTO-GENERATED from public/voiceover.srt by scripts/srt-to-cues.mjs — do not edit by hand.
export type Cue = { i: number; start: number; end: number; text: string };
export const cues: Cue[] = ${JSON.stringify(cues, null, 2)};
`;
fs.writeFileSync(new URL("../src/cues.ts", import.meta.url), out);
console.log(`wrote src/cues.ts (${cues.length} cues, ends at ${cues[cues.length - 1].end} ms)`);
