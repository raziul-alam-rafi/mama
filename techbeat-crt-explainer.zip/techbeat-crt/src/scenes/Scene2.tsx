// Scene 2 — "মাঠে যা ঘটছে ক্যামেরা সেই দৃশ্য ধারণ করছে"
// Style: Hub-and-spoke light capture. Stadium (tilted 2.5D card) -> light rays -> camera lens.
import React from "react";
import { AbsoluteFill, useCurrentFrame } from "remotion";
import { theme } from "../theme";
import { BEATS } from "../timeline";
import { ip, Pop, Tag } from "../components/kit";
import { CricketField, TVCamera } from "../components/objects";
import { SceneProps, makeQ } from "./types";

// Stage coordinates
const CAM_LEFT = 1090;
const CAM_TOP = 270;
const LENS: [number, number] = [CAM_LEFT + 58, CAM_TOP + 266];
const FIELD = { left: 90, top: 250, w: 840, h: 560 };

export const Scene2: React.FC<SceneProps> = ({ cs, cd }) => {
  const frame = useCurrentFrame();
  const q = makeQ(cs, cd);
  const raysAt = q(BEATS.s2.rays);
  const zoomAt = q(BEATS.s2.zoom);
  const rayP = ip(frame, [raysAt, raysAt + 22], [0, 1], theme.ease.out);
  const glow = ip(frame, [raysAt + 14, raysAt + 30], [0, 1], theme.ease.out);
  const zoom = ip(frame, [zoomAt, zoomAt + 40], [1, 1.35]);
  const sources: [number, number][] = [
    [FIELD.left + FIELD.w - 30, FIELD.top + 140],
    [FIELD.left + FIELD.w - 10, FIELD.top + 300],
    [FIELD.left + FIELD.w - 30, FIELD.top + 450],
  ];
  const tilt = ip(frame, [0, cs + cd], [16, 8]);
  return (
    <AbsoluteFill>
      {/* Stadium card */}
      <div
        style={{
          position: "absolute",
          left: FIELD.left,
          top: FIELD.top,
          width: FIELD.w,
          height: FIELD.h,
          perspective: 1800,
        }}
      >
        <Pop delay={q(BEATS.s2.field)} y={50} s={0.92}>
          <div
            style={{
              width: FIELD.w,
              height: FIELD.h,
              borderRadius: 30,
              overflow: "hidden",
              transform: `rotateY(${tilt}deg)`,
              boxShadow:
                "0 50px 90px -20px rgba(0,0,0,0.7), 0 0 0 3px rgba(255,255,255,0.08)",
            }}
          >
            <CricketField t={frame} />
          </div>
        </Pop>
      </div>

      {/* Light rays: field -> lens */}
      <svg
        width="1920"
        height="1080"
        style={{ position: "absolute", left: 0, top: 0, pointerEvents: "none" }}
      >
        <defs>
          <linearGradient id="ray" x1="0" y1="0" x2="1" y2="0">
            <stop offset="0" stopColor={theme.colors.accent} stopOpacity="0.0" />
            <stop offset="1" stopColor={theme.colors.accent} stopOpacity="0.55" />
          </linearGradient>
        </defs>
        <polygon
          points={`${sources[0][0]},${sources[0][1]} ${sources[2][0]},${sources[2][1]} ${LENS[0] - 8},${LENS[1] + 56} ${LENS[0] - 8},${LENS[1] - 56}`}
          fill="url(#ray)"
          opacity={rayP * 0.5}
        />
        {sources.map((s, i) => {
          const dx = LENS[0] - s[0];
          const dy = LENS[1] - s[1];
          return (
            <g key={i} opacity={rayP}>
              <line
                x1={s[0]}
                y1={s[1]}
                x2={s[0] + dx * rayP}
                y2={s[1] + dy * rayP}
                stroke={theme.colors.accent}
                strokeWidth="4"
                strokeDasharray="14 12"
                strokeDashoffset={-frame * 3}
                strokeLinecap="round"
              />
              {[0, 1, 2].map((k) => {
                const ph = ((frame / 38 + k / 3 + i * 0.17) % 1 + 1) % 1;
                return (
                  <circle
                    key={k}
                    cx={s[0] + dx * ph}
                    cy={s[1] + dy * ph}
                    r={7 - ph * 3}
                    fill={theme.colors.text}
                    opacity={Math.min(1, ph * 4) * (1 - ph * 0.3)}
                  />
                );
              })}
            </g>
          );
        })}
      </svg>

      {/* Camera */}
      <div
        style={{
          position: "absolute",
          left: CAM_LEFT,
          top: CAM_TOP,
          transform: `scale(${zoom})`,
          transformOrigin: "58px 266px",
        }}
      >
        <Pop delay={q(BEATS.s2.camera)} y={70} s={0.9} cfg={theme.spring.bouncy}>
          <TVCamera glow={glow} />
        </Pop>
      </div>

      <div style={{ position: "absolute", left: FIELD.left + 24, top: 160 }}>
        <Tag text="মাঠ" tone="hero" delay={q(BEATS.s2.field) + 8} size={52} />
      </div>
      <div style={{ position: "absolute", left: CAM_LEFT + 240, top: 160 }}>
        <Tag text="ক্যামেরা" tone="accent" delay={q(BEATS.s2.camera) + 8} size={52} />
      </div>
    </AbsoluteFill>
  );
};
