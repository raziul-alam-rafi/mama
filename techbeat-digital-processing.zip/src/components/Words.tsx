import React from "react";
import { interpolate } from "remotion";
import { theme } from "../theme";
import { useClock, popAt } from "./clock";

/** Word-by-word staggered reveal. Splits ONLY on spaces (never inside a Bengali word). */
export const Words: React.FC<{
  text: string;
  start: number; // local frame
  per?: number;
  size?: number;
  weight?: number;
  color?: string;
  gradientWords?: number[]; // indices rendered with the hero gradient
  gap?: number;
  exitAt?: number; // local frame at which the line leaves
  align?: "left" | "center";
  style?: React.CSSProperties;
}> = ({ text, start, per = 4, size = 120, weight = 700, color = theme.colors.text, gradientWords = [] as number[], gap = 28, exitAt, align = "center", style }) => {
  const { f, fps } = useClock();
  const exit = exitAt === undefined ? 0 : interpolate(f, [exitAt, exitAt + 10], [0, 1], { easing: theme.ease.in, extrapolateLeft: "clamp", extrapolateRight: "clamp" });
  return (
    <div
      style={{
        display: "flex",
        flexWrap: "wrap",
        justifyContent: align === "center" ? "center" : "flex-start",
        columnGap: gap,
        rowGap: 6,
        fontFamily: theme.fonts.main,
        fontWeight: weight,
        fontSize: size,
        lineHeight: 1.12,
        letterSpacing: 0,
        color,
        opacity: 1 - exit,
        transform: `translateY(${-60 * exit}px)`,
        ...style,
      }}
    >
      {text.split(" ").map((w, i) => {
        const p = popAt(f, fps, start + i * per, theme.spring.snappy);
        const g = gradientWords.includes(i);
        return (
          <span
            key={i}
            style={{
              display: "inline-block",
              opacity: Math.min(1, p * 1.4),
              transform: `translateY(${(1 - p) * 38}px) scale(${0.92 + 0.08 * p})`,
              ...(g
                ? { background: `linear-gradient(100deg, ${theme.colors.primary}, #8FB6FF)`, WebkitBackgroundClip: "text", backgroundClip: "text", color: "transparent", WebkitTextFillColor: "transparent", filter: `drop-shadow(0 0 28px ${theme.colors.primary}66)` }
                : {}),
            }}
          >
            {w}
          </span>
        );
      })}
    </div>
  );
};
