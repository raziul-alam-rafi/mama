import { cueStart, TOTAL_FRAMES } from "./srt";

/** ভিজ্যুয়াল cue-র এত ফ্রেম আগে ঢোকে */
export const LEAD = 6;
/** পরের সিনের সঙ্গে ওভারল্যাপ (এক্সিট অ্যানিমেশনের জন্য) */
export const OVERLAP = 10;

// সিনের সীমা cue-র সীমায় মিলছে (cue 2, 5, 7, 9, 11 থেকে নতুন সিন)।
const starts = [
  0,
  cueStart(2) - LEAD,
  cueStart(5) - LEAD,
  cueStart(7) - LEAD,
  cueStart(9) - LEAD,
  cueStart(11) - LEAD,
];

export const sceneTimes = starts.map((from, i) => {
  const next = i < starts.length - 1 ? starts[i + 1] + OVERLAP : TOTAL_FRAMES;
  return { from, duration: next - from };
});
