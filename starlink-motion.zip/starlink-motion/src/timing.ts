// timing.ts — every frame number is derived from the SRT cues (src/cues.ts) and FPS.
import { cues } from "./cues";

export const FPS = 30;
export const WIDTH = 1920;
export const HEIGHT = 1080;
export const LEAD = 5; // visuals arrive ~5 frames before the related words
export const OVERLAP = 10; // frames a scene stays on screen while the next one enters

export const msToFrame = (ms: number) => Math.round((ms / 1000) * FPS);
export const sec = (s: number) => Math.round(s * FPS);
export const cue = (n: number) => cues[n - 1];
export const TOTAL_FRAMES = msToFrame(cues[cues.length - 1].end);

/** ms inside cue `n` where `phrase` begins (proportional to its position in the cue text). */
export const phraseMs = (n: number, phrase: string) => {
  const c = cue(n);
  const idx = c.text.indexOf(phrase);
  if (idx < 0) return c.start;
  return c.start + (idx / c.text.length) * (c.end - c.start);
};

export type Scene = {
  id: string;
  first: number; // first SRT cue (1-based)
  last: number; // last SRT cue
  from: number; // composition frame where the scene begins
  duration: number;
};

// Scene boundaries sit on cue boundaries; one scene may span several cues.
const defs = [
  { id: "hook", first: 1, last: 1 },
  { id: "compare", first: 2, last: 2 },
  { id: "array", first: 3, last: 4 },
  { id: "orbit", first: 5, last: 6 },
  { id: "question", first: 7, last: 8 },
];

const froms = defs.map((d, i) => (i === 0 ? 0 : Math.max(0, msToFrame(cue(d.first).start) - LEAD)));

export const scenes: Scene[] = defs.map((d, i) => ({
  ...d,
  from: froms[i],
  duration: i === defs.length - 1 ? TOTAL_FRAMES - froms[i] : froms[i + 1] - froms[i] + OVERLAP,
}));

/** Scene-local frame for an SRT time, minus the lead so the visual lands before the words. */
export const localFrame = (s: Scene, ms: number, lead = LEAD) => Math.max(0, msToFrame(ms) - s.from - lead);
