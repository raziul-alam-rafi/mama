import React from 'react';
import {useThree} from '@react-three/fiber';
import {useCurrentFrame, useVideoConfig} from 'remotion';
import {cameraAzimuth, cameraDistance} from '../timeline';

const TARGET = {x: 0, y: 0, z: 1.2};

/** Deterministic: camera pose is a pure function of the current frame. */
export const CameraRig: React.FC = () => {
  const frame = useCurrentFrame();
  const {fps} = useVideoConfig();
  const {camera} = useThree();
  const t = frame / fps;
  const az = cameraAzimuth(t);
  const R = cameraDistance(t);
  camera.position.set(-Math.cos(az) * R, 1.6, TARGET.z + Math.sin(az) * R);
  camera.lookAt(TARGET.x, TARGET.y, TARGET.z);
  return null;
};
