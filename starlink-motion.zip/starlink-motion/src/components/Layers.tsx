import React from "react";
import { AbsoluteFill, useCurrentFrame } from "remotion";
import { theme } from "../theme";

/** Layer 1 — animated background mesh + faint drifting grid. Never a flat colour. */
export const BgMesh: React.FC = () => {
  const frame = useCurrentFrame();
  const d1 = Math.sin(frame / 55) * 60;
  const d2 = Math.cos(frame / 70) * 50;
  const mask = "radial-gradient(ellipse at center, black 15%, transparent 72%)";
  return (
    <AbsoluteFill style={{ background: `radial-gradient(ellipse at 50% 115%, ${theme.colors.bgAlt}, ${theme.colors.bg} 70%)` }}>
      <div
        style={{
          position: "absolute",
          width: 1300,
          height: 1300,
          borderRadius: "50%",
          top: -620,
          left: -380 + d1,
          filter: "blur(60px)",
          background: `radial-gradient(circle, ${theme.colors.primary}26, transparent 62%)`,
        }}
      />
      <div
        style={{
          position: "absolute",
          width: 1000,
          height: 1000,
          borderRadius: "50%",
          bottom: -520,
          right: -300 - d2,
          filter: "blur(70px)",
          background: `radial-gradient(circle, ${theme.colors.accent}1F, transparent 65%)`,
        }}
      />
      <AbsoluteFill
        style={{
          backgroundImage: `linear-gradient(${theme.colors.border} 1px, transparent 1px), linear-gradient(90deg, ${theme.colors.border} 1px, transparent 1px)`,
          backgroundSize: "96px 96px",
          backgroundPosition: `${-frame * 0.3}px ${-frame * 0.2}px`,
          opacity: 0.35,
          WebkitMaskImage: mask,
          maskImage: mask,
        }}
      />
    </AbsoluteFill>
  );
};

/** Layer 4 — colour grade (unifies everything under one warm tone). */
export const Grade: React.FC = () => (
  <AbsoluteFill style={{ pointerEvents: "none" }}>
    <AbsoluteFill style={{ backgroundColor: theme.colors.primary, mixBlendMode: "soft-light", opacity: 0.16 }} />
    <AbsoluteFill
      style={{
        background: `linear-gradient(180deg, ${theme.colors.bg}33, transparent 28%, transparent 72%, ${theme.colors.bg}55)`,
      }}
    />
  </AbsoluteFill>
);

/** Layer 5a — procedural film grain (no asset file). */
export const Grain: React.FC = () => {
  const frame = useCurrentFrame();
  const noise = `url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='220' height='220'%3E%3Cfilter id='n'%3E%3CfeTurbulence type='fractalNoise' baseFrequency='0.9' numOctaves='2'/%3E%3C/filter%3E%3Crect width='220' height='220' filter='url(%23n)' opacity='0.5'/%3E%3C/svg%3E")`;
  return (
    <AbsoluteFill
      style={{
        pointerEvents: "none",
        backgroundImage: noise,
        backgroundSize: "220px",
        backgroundPosition: `${(frame * 7) % 220}px ${(frame * 13) % 220}px`,
        opacity: 0.06,
        mixBlendMode: "overlay",
      }}
    />
  );
};

/** Layer 5b — vignette, topmost. */
export const Vignette: React.FC = () => (
  <AbsoluteFill
    style={{
      pointerEvents: "none",
      background: `radial-gradient(ellipse at center, transparent 54%, ${theme.colors.bg}D9 100%)`,
    }}
  />
);
