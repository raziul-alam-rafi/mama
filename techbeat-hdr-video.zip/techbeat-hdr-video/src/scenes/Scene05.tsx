// সিন ৫ (cue 8): HDR — নাম প্রকাশ (Kinetic Typography) + সীমা প্রসারিত হয়ে ফলাফল ছবি
import React from "react";
import { useCurrentFrame } from "remotion";
import { theme } from "../theme";
import { makeT } from "../timing";
import { Entrance, SceneShell, Words, tween, useBreathe, useSpringAt } from "../components/anim";
import { Label } from "../components/ui";
import { EXPO, Photo } from "../components/photo";
import { RangeBar } from "../components/rangebar";
import { SfxEvent } from "../sfx";

const T = makeT(4);
const tIntro = T(8);
const tHDR = T(8, "HDR");
const tFull = T(8, "High Dynamic");
const tResult = T(8, "এর ফলে");
const tEnds = T(8, "উজ্জ্বল আকাশ");

export const sfx05: SfxEvent[] = [
  { kind: "pop", frame: tIntro + 4, rate: 0.95 },
  { kind: "thud", frame: tHDR + 2, vol: 0.9 },
  { kind: "chime", frame: tHDR + 8, vol: 0.7 },
  { kind: "click", frame: tFull + 20 },
  { kind: "pop", frame: tResult + 6, rate: 1.05 },
  { kind: "chime", frame: tEnds + 10, vol: 0.7 },
];

const pulse = (frame: number, at: number) => { const d = frame - at; return d < 0 || d > 40 ? 0 : Math.sin((d / 40) * Math.PI); };

export const Scene05: React.FC = () => {
  const frame = useCurrentFrame();
  const bob = useBreathe(42, 4);
  const hdr = useSpringAt(tHDR, theme.spring.bouncy);
  const expand = tween(frame, tFull + 6, tFull + 36, 0, 1, theme.ease.inOut);
  const lo = 0.45 - 0.43 * expand;
  const res = tween(frame, tResult, tResult + 24, 0, 1);

  return (
    <SceneShell>
      <Entrance delay={tIntro} style={{ position: "absolute", left: 120, top: 190 }}>
        <Label size={46} color={theme.colors.textDim}>এই পদ্ধতিকে বলা হয়</Label>
      </Entrance>
      <div style={{ position: "absolute", left: 110, top: 240, transform: `scale(${0.6 + 0.4 * Math.min(1, hdr)})`, transformOrigin: "0% 50%", opacity: Math.min(1, hdr * 1.4) }}>
        <div style={{ fontFamily: theme.fonts.display, fontWeight: 700, fontSize: 330, lineHeight: 1.1, letterSpacing: 0,
          backgroundImage: `linear-gradient(100deg, ${theme.colors.hero}, ${theme.colors.text} 48%, ${theme.colors.accent})`,
          WebkitBackgroundClip: "text", backgroundClip: "text", color: "transparent", WebkitTextFillColor: "transparent" }}>HDR</div>
      </div>
      <div style={{ position: "absolute", left: 120, top: 640, width: 780 }}>
        <Words text="High Dynamic Range Processing" delay={tFull} per={5} justify="flex-start" style={{ fontSize: 72 }} hl={{ Range: theme.colors.accent }} />
      </div>

      {/* ফলাফল ছবি */}
      <div style={{ position: "absolute", left: 1040, top: 130 + bob, opacity: res, transform: `translateY(${(1 - res) * 40}px) scale(${0.94 + 0.06 * res})` }}>
        <div style={{ borderRadius: 22, overflow: "hidden", border: `3px solid ${theme.colors.ok}`, boxShadow: `0 0 50px ${theme.colors.ok}33, ${theme.shadow.card}` }}>
          <Photo uid="s5" gRoom={EXPO.over} gSky={EXPO.under} width={760} radius={0} />
        </div>
      </div>
      <Entrance delay={tIntro + 6} style={{ position: "absolute", left: 1060, top: 640 }}>
        <RangeBar w={720} lo={lo} hi={0.98} bracketLabel="Dynamic Range" bracketColor={theme.colors.accent}
          pulseSky={pulse(frame, tEnds)} pulseFace={pulse(frame, tEnds + 14)} />
      </Entrance>
    </SceneShell>
  );
};
