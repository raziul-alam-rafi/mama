import React from "react";
import { AbsoluteFill, Sequence } from "remotion";
import { scenes } from "./timing";
import { theme } from "./theme";
import { BgMesh, Grade, Grain, Vignette } from "./components/Layers";
import { SceneShell } from "./components/SceneShell";
import { Sfx } from "./components/Sfx";
import { PreviewAudio } from "./components/PreviewAudio";
import { HookScene } from "./scenes/HookScene";
import { CompareScene } from "./scenes/CompareScene";
import { ArrayScene } from "./scenes/ArrayScene";
import { OrbitScene } from "./scenes/OrbitScene";
import { QuestionScene } from "./scenes/QuestionScene";

const sceneComponents: Record<string, React.FC> = {
  hook: HookScene,
  compare: CompareScene,
  array: ArrayScene,
  orbit: OrbitScene,
  question: QuestionScene,
};

export const Main: React.FC = () => (
  <AbsoluteFill style={{ backgroundColor: theme.colors.bg }}>
    {/* layer 1: background mesh */}
    <BgMesh />
    {/* layers 2-3: assets + graphics/type, one scene at a time (scenes overlap during transitions) */}
    {scenes.map((s, i) => {
      const Comp = sceneComponents[s.id];
      return (
        <Sequence key={s.id} from={s.from} durationInFrames={s.duration} name={s.id}>
          <SceneShell duration={s.duration} first={i === 0} last={i === scenes.length - 1}>
            <Comp />
          </SceneShell>
        </Sequence>
      );
    })}
    {/* layer 4: colour grade, layer 5: grain + vignette */}
    <Grade />
    <Grain />
    <Vignette />
    <Sfx />
    <PreviewAudio />
  </AbsoluteFill>
);
