import React from "react";
import {AbsoluteFill, interpolate, spring, useCurrentFrame, useVideoConfig} from "remotion";
import {theme} from "../theme";
import {at} from "../timeline";
import {SvgDefs} from "../components/Optics";
import {Iris} from "../components/Art";
import {WordReveal} from "../components/Text";
import {Sfx} from "../components/Sfx";
import {prog} from "../components/util";

const SI = 5;
const CX = 960, CY = 640, R = 190;

/** Scene 6 — the open question: a beam of light meets an opening whose size is not yet decided. */
export const S6Question: React.FC = () => {
  const frame = useCurrentFrame();
  const {fps} = useVideoConfig();

  const tQ = at(SI, 10, "কীভাবে");
  const tAmount = at(SI, 10, "কতটুকু");

  const pIn = spring({frame: frame - 2, fps, config: theme.spring.smooth});
  const beam = prog(frame, 4, 26, theme.ease.inOut);
  // the opening slowly breathes between small and large (no answer is given yet)
  const open = 0.55 + 0.38 * Math.sin(Math.max(0, frame - 10) / 17);
  const r = R * (0.12 + 0.78 * open);

  const rays = [-150, -90, -30, 30, 90, 150];
  const dots = (frame * 9) % 220;

  return (
    <AbsoluteFill>
      <svg width={1920} height={1080} viewBox="0 0 1920 1080" style={{position: "absolute", inset: 0}}>
        <SvgDefs />
        <defs>
          <linearGradient id="beamAll" gradientUnits="userSpaceOnUse" x1="0" x2="1920" y1="0" y2="0">
            <stop offset="0" stopColor={theme.colors.hero} stopOpacity="0" />
            <stop offset="0.5" stopColor={theme.colors.hero} stopOpacity="0.30" />
            <stop offset="1" stopColor={theme.colors.hero} stopOpacity="0.16" />
          </linearGradient>
          <clipPath id="passClip"><rect x={CX} y={CY - r} width={1920 - CX} height={2 * r} /></clipPath>
        </defs>

        {/* one continuous beam: wide before the opening, only as wide as the opening after it */}
        <polygon
          points={`0,${CY - 170} ${CX * beam},${CY - 170} ${CX * beam},${CY - r} 1920,${CY - r} 1920,${CY + r} ${CX * beam},${CY + r} ${CX * beam},${CY + 170} 0,${CY + 170}`}
          fill="url(#beamAll)"
        />
        <g filter="url(#glowSm)">
          {rays.map((h, i) => (
            <g key={i}>
              <line x1={0} x2={CX * beam} y1={CY + h} y2={CY + h} stroke={theme.colors.hero} strokeWidth={3} opacity={0.9} />
              {beam >= 1 && [0, 1, 2, 3, 4, 5].map((k) => {
                const x = (dots + k * 220) % 1320;
                return x < CX ? <circle key={k} cx={x} cy={CY + h} r={5} fill="#FFFFFF" /> : null;
              })}
            </g>
          ))}
        </g>

        {/* only what fits through the opening continues */}
        <g clipPath="url(#passClip)" filter="url(#glowSm)" opacity={beam}>
          {rays.map((h, i) => (
            <line key={i} x1={CX} x2={1920} y1={CY + h} y2={CY + h} stroke={theme.colors.hero} strokeWidth={3} opacity={0.9} />
          ))}
        </g>

        <g opacity={Math.min(1, pIn)} transform={`translate(0 ${(1 - Math.min(1, pIn)) * 40})`}>
          <Iris cx={CX} cy={CY} R={R} open={open} rot={interpolate(open, [0, 1], [0.1, -0.2])} />
        </g>
      </svg>

      <div style={{position: "absolute", left: 160, right: 160, top: 120, display: "flex", justifyContent: "center"}}>
        <WordReveal
          words={["কতটুকু", {t: "আলো", color: theme.colors.accent}, "ভেতরে", "ঢুকতে", "দেওয়া", "দরকার?"]}
          delay={tAmount} per={5} size={92} justify="center" gap={22}
        />
      </div>
      <Sfx at={4} name="whoosh" vol={0.5} />
      <Sfx at={tQ} name="thud" vol={0.8} />
      <Sfx at={tAmount + 2} name="pop" />
    </AbsoluteFill>
  );
};
