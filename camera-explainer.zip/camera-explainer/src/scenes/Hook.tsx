import React from "react";
import { AbsoluteFill, useCurrentFrame } from "remotion";
import { theme, alpha } from "../theme";
import { SceneShell, WordReveal, ease } from "../components/ui";
import { Cutaway } from "../components/Cutaway";
import { at } from "../timing";
import type { Sfx } from "../sfx";

const K = 0;
const L2 = at(K, 1, 0.3); // "ক্যামেরার ভেতরে কী ঘটে?"
const R0 = at(K, 1, 0.62); // আলো ঢোকে

export const sfx: Sfx[] = [
  { f: 0, s: "thud", v: 0.24 },
  { f: L2, s: "whoosh", v: 0.2 },
  { f: 30, s: "pop", v: 0.28 },
  { f: R0 + 24, s: "chime", v: 0.26 },
];

export const Hook: React.FC = () => {
  const f = useCurrentFrame();
  const flash = f < 22 ? ease(f, [17, 22], [0, 1]) : ease(f, [22, 38], [1, 0]);
  const float = Math.sin(f / 26) * 5;
  return (
    <SceneShell>
      <AbsoluteFill style={{ alignItems: "center", paddingTop: 64 }}>
        <WordReveal text="আপনি যখন ছবি তোলেন" size={74} weight={600} color={theme.colors.textDim} delay={0} />
        <WordReveal
          text="ক্যামেরার ভেতরে কী ঘটে?"
          size={138}
          hi={[1]}
          glow
          delay={L2}
          per={5}
        />
      </AbsoluteFill>
      <div style={{ position: "absolute", left: 248, top: 335 + float }}>
        <Cutaway
          width={1500}
          p={{
            body: ease(f, [6, 44], [0, 1], theme.ease.inOut),
            lens: ease(f, [26, 70], [0, 1], theme.ease.inOut),
            aperture: ease(f, [50, 74], [0, 1]),
            sensor: ease(f, [62, 92], [0, 1]),
            chip: ease(f, [76, 104], [0, 1]),
            display: ease(f, [88, 114], [0, 1]),
          }}
          rays={ease(f, [R0, R0 + 34], [0, 1], theme.ease.inOut)}
          glow={ease(f, [R0 + 26, R0 + 44], [0, 1])}
        />
      </div>
      {/* ছবি তোলার মুহূর্ত: হালকা এক্সপোজার পালস */}
      <AbsoluteFill style={{ background: alpha(theme.colors.text, 0.14 * flash), pointerEvents: "none" }} />
    </SceneShell>
  );
};
