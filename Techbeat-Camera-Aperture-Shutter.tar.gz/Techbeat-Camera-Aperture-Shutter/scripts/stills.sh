#!/usr/bin/env bash
# Renders key frames (open, closing, closed, opening, open) for visual inspection.
set -e
mkdir -p out
for f in 15 90 150 240 300 420; do
  npx remotion still src/index.ts ApertureProto out/proto_f$f.png --frame=$f
done
echo "Stills saved in out/"
