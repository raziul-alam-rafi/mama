import React from "react";
import { interpolate, spring, useCurrentFrame, useVideoConfig } from "remotion";
import { theme } from "../theme";
import { beat } from "../cues";
import { Ray, ThinLens, backFocus, prog, Pt, traceThin } from "../draw";
import { SensorPlate } from "../art/Art";
import { Label, Sfx, WordReveal } from "../components/Common";

const c = theme.colors;
const AY = 640; // optical axis
// simplified compound lens: converging – diverging – converging – converging (paraxial thin-lens model)
const ELS = [
  { x: 800, f: 700, H: 124, kind: "convex" },
  { x: 900, f: -500, H: 112, kind: "concave" },
  { x: 1010, f: 620, H: 108, kind: "convex" },
  { x: 1115, f: 1000, H: 100, kind: "convex" },
] as const;
const LENSES: ThinLens[] = ELS.map((e) => ({ x: e.x, f: e.f, ya: AY }));
const SENSOR_X = Math.round(backFocus(LENSES, AY));
const X0 = 130; // where incoming light starts

const elementPath = (e: (typeof ELS)[number]) => {
  const { x, H } = e; const y = AY;
  if (e.kind === "convex") { const b = 15; return `M${x} ${y - H} Q${x + 2 * b} ${y} ${x} ${y + H} Q${x - 2 * b} ${y} ${x} ${y - H} Z`; }
  const t = 15, d = 11;
  return `M${x - t} ${y - H} L${x + t} ${y - H} Q${x + t - 2 * d} ${y} ${x + t} ${y + H} L${x - t} ${y + H} Q${x - t + 2 * d} ${y} ${x - t} ${y - H} Z`;
};

const bundle = (m0: number, hs: number[]): Pt[][] =>
  hs.map((h) => traceThin({ x: X0, y: AY + h - m0 * (ELS[0].x - X0) }, m0, LENSES, SENSOR_X));
const straight = (hs: number[]): Pt[][] => hs.map((h) => [{ x: X0, y: AY + h }, { x: SENSOR_X - 18, y: AY + h }]);

export const Elements: React.FC<{ from: number }> = ({ from }) => {
  const frame = useCurrentFrame();
  const { fps } = useVideoConfig();
  const tHead = beat(from, 10);
  const tPlain = beat(from, 10, "সাধারণ কাঁচ নয়");
  const tMulti = beat(from, 10, "একাধিক optical");
  const tBend = beat(from, 11, "বাঁকিয়ে");

  const pHouse = spring({ frame: frame - 4, fps, config: theme.spring.smooth });
  const pPane = spring({ frame: frame - 14, fps, config: theme.spring.smooth }) * (1 - prog(frame, tMulti + 2, 10, theme.ease.in));
  const pX = spring({ frame: frame - (tPlain + 6), fps, config: theme.spring.bouncy }) * (1 - prog(frame, tMulti, 8, theme.ease.in));
  const pEl = ELS.map((_, i) => spring({ frame: frame - (tMulti + 6 + i * 5), fps, config: theme.spring.bouncy }));
  const pSensor = spring({ frame: frame - 10, fps, config: theme.spring.smooth });
  const straightFade = 1 - prog(frame, tMulti - 4, 8, theme.ease.in);
  const bracket = prog(frame, tMulti + 26, 18);
  const dotP = spring({ frame: frame - (tBend + 36), fps, config: theme.spring.bouncy });
  const breathe = Math.sin(frame / 20);

  const hs = [-84, -42, 0, 42, 84];
  const central = bundle(0, hs);
  const upper = bundle(0.1, [-30, 0, 30]);
  const lower = bundle(-0.1, [-30, 0, 30]);
  const flat = straight(hs);

  const focusY = (b: Pt[][]) => b[1][b[1].length - 1].y;

  return (
    <>
      <svg width={1920} height={1080} style={{ position: "absolute", inset: 0 }}>
        <defs>
          <pattern id="hatch" width="12" height="12" patternUnits="userSpaceOnUse" patternTransform="rotate(45)">
            <line x1="0" y1="0" x2="0" y2="12" stroke={c.textDim} strokeWidth="2" opacity="0.45" />
          </pattern>
          <linearGradient id="el-glass" x1="0" y1="0" x2="1" y2="1">
            <stop offset="0%" stopColor="#CFE6FF" stopOpacity="0.75" /><stop offset="100%" stopColor="#4A7FD0" stopOpacity="0.45" />
          </linearGradient>
        </defs>
        {/* cutaway: lens barrel + camera body (section view, hatched cut walls) */}
        <g opacity={pHouse} transform={`translate(0 ${(1 - pHouse) * 26})`}>
          <rect x={730} y={452} width={470} height={376} rx={26} fill={c.bgAlt} stroke={c.line} strokeWidth={3} />
          <rect x={730} y={452} width={470} height={34} rx={14} fill="url(#hatch)" stroke={c.line} strokeWidth={2} />
          <rect x={730} y={794} width={470} height={34} rx={14} fill="url(#hatch)" stroke={c.line} strokeWidth={2} />
          <rect x={1196} y={420} width={SENSOR_X + 110 - 1196} height={440} rx={34} fill={c.bgAlt} stroke={c.line} strokeWidth={3} />
          <rect x={1196} y={420} width={SENSOR_X + 110 - 1196} height={34} rx={14} fill="url(#hatch)" stroke={c.line} strokeWidth={2} />
          <rect x={1196} y={826} width={SENSOR_X + 110 - 1196} height={34} rx={14} fill="url(#hatch)" stroke={c.line} strokeWidth={2} />
        </g>
        <g transform={`translate(${SENSOR_X} ${AY})`}><SensorPlate h={300} reveal={pSensor} /></g>

        {/* phase 1 — plain glass pane: light passes straight, nothing is gathered */}
        <g opacity={straightFade}>
          {flat.map((pts, i) => <Ray key={"f" + i} pts={pts} p={prog(frame, 16 + i * 3, 30)} frame={frame} opacity={0.45} phase={i * 0.1} />)}
        </g>
        <g opacity={pPane}>
          <rect x={940} y={AY - 128} width={28} height={256} rx={6} fill="url(#el-glass)" stroke={c.glass} strokeWidth={3} />
        </g>
        <g transform={`translate(954 ${AY - 170}) scale(${pX})`}>
          <circle r={34} fill={c.bgAlt} stroke={c.appleLight} strokeWidth={4} />
          <path d="M-13 -13 L13 13 M13 -13 L-13 13" stroke={c.appleLight} strokeWidth={6} strokeLinecap="round" />
        </g>

        {/* phase 2 — multiple optical elements */}
        {ELS.map((e, i) => (
          <g key={i} opacity={pEl[i]} transform={`translate(${e.x} ${AY}) scale(${interpolate(pEl[i], [0, 1], [0.5, 1])}) translate(${-e.x} ${-AY})`}>
            <path d={elementPath(e)} fill="url(#el-glass)" stroke={c.glass} strokeWidth={3.2} />
          </g>
        ))}
        <g opacity={bracket}>
          <path d={`M${ELS[0].x - 26} ${AY - 164} H${ELS[3].x + 26}`} stroke={c.primary} strokeWidth={3.5} strokeLinecap="round" strokeDasharray="1000" strokeDashoffset={(1 - bracket) * 1000} fill="none" />
          <path d={`M${ELS[0].x - 26} ${AY - 164} v14 M${ELS[3].x + 26} ${AY - 164} v14`} stroke={c.primary} strokeWidth={3.5} strokeLinecap="round" fill="none" />
        </g>

        {/* phase 3 — light is bent and gathered onto the sensor (inverted point positions) */}
        {central.map((pts, i) => <Ray key={"c" + i} pts={pts} p={prog(frame, tBend + i * 3, 36)} frame={frame} opacity={0.6} packet={i % 2 === 0} phase={i * 0.09} speed={0.01} />)}
        {upper.map((pts, i) => <Ray key={"u" + i} pts={pts} p={prog(frame, tBend + 10 + i * 3, 36)} frame={frame} opacity={0.34} width={2} packet={false} />)}
        {lower.map((pts, i) => <Ray key={"l" + i} pts={pts} p={prog(frame, tBend + 14 + i * 3, 36)} frame={frame} opacity={0.34} width={2} packet={false} />)}
        {[focusY(upper), focusY(central), focusY(lower)].map((y, i) => (
          <circle key={i} cx={SENSOR_X} cy={y} r={(i === 1 ? 11 : 8) * dotP + breathe * 1.2 * dotP} fill={c.accent} opacity={dotP} />
        ))}
      </svg>
      <div style={{ position: "absolute", left: 100, top: 70, height: 130, width: 1500 }}>
        <div style={{ position: "absolute", left: 0, top: 0 }}>
          <WordReveal text="শুধু সাধারণ কাঁচ *নয়*" delay={tHead} size={88} hi={c.appleLight} exitAt={tMulti - 6} />
        </div>
        <div style={{ position: "absolute", left: 0, top: 0 }}>
          {frame >= tMulti - 4 && <WordReveal text="একাধিক *optical* *element*" delay={tMulti - 2} size={88} hi={c.primary} exitAt={tBend - 6} />}
        </div>
        <div style={{ position: "absolute", left: 0, top: 0 }}>
          {frame >= tBend - 4 && <WordReveal text="আলোকে *বাঁকিয়ে* ভেতরে পাঠায়" delay={tBend - 2} size={88} hi={c.accent} />}
        </div>
      </div>
      {frame < tMulti && <Label text="সাধারণ কাঁচ" x={954} y={AY + 190} delay={tPlain + 4} />}
      <Label text="optical element" x={(ELS[0].x + ELS[3].x) / 2} y={AY - 214} delay={tMulti + 30} color={c.primary} />
      <Label text="sensor" x={SENSOR_X} y={AY + 250} delay={20} />
      <Sfx name="pop" at={tHead + 2} vol={0.28} />
      <Sfx name="click" at={tPlain + 8} vol={0.28} />
      <Sfx name="pop" at={tMulti + 4} vol={0.26} rate={0.96} />
      <Sfx name="pop" at={tMulti + 19} vol={0.24} rate={1.08} />
      <Sfx name="whoosh" at={tBend} vol={0.26} />
      <Sfx name="chime" at={tBend + 36} vol={0.26} />
    </>
  );
};
