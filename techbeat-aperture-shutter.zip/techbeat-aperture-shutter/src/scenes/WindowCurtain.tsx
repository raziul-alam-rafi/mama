import React from "react";
import { AbsoluteFill } from "remotion";
import { theme } from "../theme";
import { useScene } from "../SceneContext";
import { Card, Chip, ip, keys, mono, Entrance, useBreathe } from "../components/Motion";
import { WindowScene } from "../components/WindowScene";
import { Iris } from "../components/Iris";
import { Sfx } from "../components/Sfx";

// Scene 4 · Window-curtain analogy (cue 5): drawing the curtain aside = widening the aperture.
export const WindowCurtain: React.FC = () => {
  const S = useScene();
  const f = S.frame;
  const c5 = Math.max(S.cue(5), 0);
  const fOpen = S.word(5, "সরিয়ে");
  const fClose = S.word(5, "টেনে");
  const [a, b, c, d] = mono([c5 + 6, fOpen, fClose, S.cueEnd(5) - 8], 8);
  const holdOpen = keys(f, [a, b, b + 26, c - 2, c + 28, d], [0.32, 0.32, 1.0, 1.0, 0.1, 0.1]);
  const br = useBreathe(0.6);
  const lightHi = ip(f, [b + 14, b + 28], [0, 1]) * (1 - ip(f, [c, c + 10], [0, 1]));
  const lightLo = ip(f, [c + 18, c + 32], [0, 1]);

  return (
    <AbsoluteFill>
      <div style={{ position: "absolute", left: 130, top: 112 }}>
        <Chip text="জানালার পর্দা" tone="primary" size={50} delay={c5 + 2} />
      </div>
      <div style={{ position: "absolute", left: 130, top: 200, transform: `translateY(${br.float}px)` }}>
        <Entrance delay={c5 + 4} y={50} from={0.96}>
          <WindowScene width={830} open={holdOpen} uid="w5" />
        </Entrance>
      </div>

      {/* analogy link */}
      <Entrance delay={c5 + 26} y={0} from={0.6} config={theme.spring.bouncy} style={{ position: "absolute", left: 1000, top: 520 }}>
        <div style={{ width: 84, height: 84, borderRadius: 42, background: theme.colors.bgAlt, border: `3px solid ${theme.colors.accent}`, display: "flex", alignItems: "center", justifyContent: "center", fontFamily: theme.fonts.display, fontWeight: 700, fontSize: 56, color: theme.colors.accent, lineHeight: 1 }}>≈</div>
      </Entrance>

      <Card x={1120} y={220} w={680} h={700} delay={c5 + 16} border={theme.colors.accent}>
        <div style={{ position: "absolute", left: 0, right: 0, top: 130, display: "flex", justifyContent: "center" }}>
          <Iris size={370} open={holdOpen} glow={0.35 + 0.6 * holdOpen} highlight uid="w5" />
        </div>
        <div style={{ position: "absolute", left: 0, right: 0, top: 530, display: "flex", justifyContent: "center", fontFamily: theme.fonts.display, fontWeight: 700, fontSize: 80, color: theme.colors.accent }}>Aperture</div>
        <div style={{ position: "absolute", left: 0, right: 0, top: 36, display: "flex", justifyContent: "center", height: 60 }}>
          <div style={{ position: "absolute", opacity: lightHi }}><Chip text="বেশি আলো" tone="accent" size={42} delay={0} /></div>
          <div style={{ position: "absolute", opacity: lightLo }}><Chip text="কম আলো" tone="primary" size={42} delay={0} /></div>
        </div>
      </Card>

      <Sfx name="pop" at={c5 + 14} />
      <Sfx name="click" at={fOpen + 2} />
      <Sfx name="click" at={fClose + 2} rate={0.92} />
    </AbsoluteFill>
  );
};
