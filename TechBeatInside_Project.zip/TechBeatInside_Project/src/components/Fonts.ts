import {loadFont} from '@remotion/google-fonts/HindSiliguri';
import {FONT_WEIGHTS} from '../config/theme';

// Hind Siliguri: reliable Bengali conjuncts. Loaded via Google Fonts at render time
// (needs internet once). To go fully offline, download the TTFs into public/fonts and use @font-face.
export const {fontFamily: BN_FONT} = loadFont('normal', {
  weights: [...FONT_WEIGHTS],
  subsets: ['bengali', 'latin'],
});
