// Scene 5 — "টিভির ভেতরের সার্কিট ছবির তথ্য আলাদা করত আর শব্দের তথ্য পাঠাতো স্পিকারের দিকে"
// Style: Cutaway (side view of a CRT set). Cable -> circuit board -> split: picture -> tube, sound -> speaker.
import React from "react";
import { AbsoluteFill, useCurrentFrame } from "remotion";
import { theme } from "../theme";
import { BEATS } from "../timeline";
import { ip, Pop, Tag } from "../components/kit";
import { SceneProps, makeQ } from "./types";

const O = theme.objects;
const BOX = { left: 150, top: 80, w: 1500, h: 860 };

// signal paths in box coordinates
const IN_PATH = "M1490 700 L1110 700";
const PIC_PATH = "M1110 700 L1110 640 C1110 560 1255 560 1255 440";
const SND_PATH = "M1110 700 L400 704";

/** point on a polyline-ish path by sampling an SVG path in the browser is not allowed in SSR,
 *  so we use hand-written parametric versions of the three paths. */
const lerp = (a: number, b: number, t: number) => a + (b - a) * t;
const inPt = (t: number): [number, number] => [lerp(1490, 1110, t), 700];
const sndPt = (t: number): [number, number] => [lerp(1110, 400, t), lerp(700, 704, t)];
const picPt = (t: number): [number, number] => {
  if (t < 0.18) return [1110, lerp(700, 640, t / 0.18)];
  const u = (t - 0.18) / 0.82;
  const v = 1 - u;
  // cubic (1110,640) (1110,560) (1255,560) (1255,440)
  return [
    v * v * v * 1110 + 3 * v * v * u * 1110 + 3 * v * u * u * 1255 + u * u * u * 1255,
    v * v * v * 640 + 3 * v * v * u * 560 + 3 * v * u * u * 560 + u * u * u * 440,
  ];
};

const Packets: React.FC<{
  at: number;
  pt: (t: number) => [number, number];
  color: string;
  n?: number;
  speed?: number;
}> = ({ at, pt, color, n = 4, speed = 52 }) => {
  const frame = useCurrentFrame();
  if (frame < at) return null;
  return (
    <>
      {Array.from({ length: n }, (_, k) => {
        const ph = (((frame - at) / speed + k / n) % 1 + 1) % 1;
        const [x, y] = pt(ph);
        return (
          <circle
            key={k}
            cx={x}
            cy={y}
            r="11"
            fill={color}
            opacity={Math.min(1, ph * 8) * Math.min(1, (1 - ph) * 8)}
            style={{ filter: `drop-shadow(0 0 10px ${color})` }}
          />
        );
      })}
    </>
  );
};

export const Scene5: React.FC<SceneProps> = ({ cs, cd }) => {
  const frame = useCurrentFrame();
  const q = makeQ(cs, cd);
  const cutAt = q(BEATS.s5.cut);
  const splitAt = q(BEATS.s5.split);
  const picAt = q(BEATS.s5.picture);
  const sndAt = q(BEATS.s5.sound);
  const reveal = ip(frame, [cutAt + 4, cutAt + 40], [0, 1]);
  const draw = (at: number, len = 18) => ip(frame, [at, at + len], [0, 1], theme.ease.out);
  const tilt = ip(frame, [0, cs + cd + 40], [-14, -6]);
  const speakerPulse = frame > sndAt ? 1 + Math.sin((frame - sndAt) / 3.2) * 0.03 : 1;
  const waves = frame > sndAt + 20;
  return (
    <AbsoluteFill>
      <div
        style={{
          position: "absolute",
          left: BOX.left,
          top: BOX.top,
          width: BOX.w,
          height: BOX.h,
          perspective: 2600,
        }}
      >
        <div
          style={{
            width: BOX.w,
            height: BOX.h,
            transform: `rotateY(${tilt}deg) rotateX(3deg)`,
            transformStyle: "preserve-3d",
          }}
        >
          <Pop delay={2} y={50} s={0.94}>
            <svg viewBox={`0 0 ${BOX.w} ${BOX.h}`} width={BOX.w} height={BOX.h} style={{ overflow: "visible" }}>
              <defs>
                <linearGradient id="glassG" x1="0" y1="0" x2="1" y2="1">
                  <stop offset="0" stopColor="#bfe0e2" stopOpacity="0.55" />
                  <stop offset="1" stopColor="#6e9296" stopOpacity="0.28" />
                </linearGradient>
                <linearGradient id="caseG" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="0" stopColor={O.casingHi} />
                  <stop offset="1" stopColor={O.casingLo} />
                </linearGradient>
                <linearGradient id="copperG" x1="0" y1="0" x2="1" y2="0">
                  <stop offset="0" stopColor="#8a5224" />
                  <stop offset="0.5" stopColor="#e0a060" />
                  <stop offset="1" stopColor="#8a5224" />
                </linearGradient>
                <clipPath id="cutClip">
                  <rect x="0" y="0" width={BOX.w * reveal} height={BOX.h} />
                </clipPath>
              </defs>

              {/* outer casing (cut away from the left edge to the right) */}
              <path
                d="M130 110 L820 232 L1010 292 L1300 292 L1300 482 L1010 482 L820 548 L130 612 Z"
                fill="url(#caseG)"
                stroke="#0d0e10"
                strokeWidth="4"
                opacity={1 - reveal * 0.72}
              />

              <g clipPath="url(#cutClip)">
                {/* casing outline when cut */}
                <path
                  d="M130 110 L820 232 L1010 292 L1300 292 L1300 482 L1010 482 L820 548 L130 612 Z"
                  fill="rgba(20,24,38,0.55)"
                  stroke={O.casingHi}
                  strokeWidth="5"
                />
                {/* CRT glass funnel + faceplate */}
                <path
                  d="M162 134 L812 250 L1000 308 L1252 316 L1252 458 L1000 466 L812 530 L162 590 Z"
                  fill="url(#glassG)"
                  stroke="#cfe5e6"
                  strokeWidth="3"
                  strokeOpacity="0.7"
                />
                <rect x="150" y="128" width="38" height="468" rx="10" fill="#aac6c9" opacity="0.8" />
                <rect x="150" y="128" width="12" height="468" rx="6" fill="#e9f6f6" opacity="0.7" />
                {/* neck */}
                <rect x="1000" y="332" width="270" height="110" fill="#9dbcbf" opacity="0.35" />
                {/* electron gun */}
                <rect x="1090" y="352" width="140" height="70" rx="10" fill={O.metal} />
                <rect x="1104" y="360" width="112" height="54" rx="8" fill={O.metalDark} />
                {[0, 1, 2, 3, 4, 5].map((i) => (
                  <rect key={i} x={1110 + i * 17} y="368" width="8" height="38" fill="#d7dbe2" />
                ))}
                <rect x="1236" y="360" width="42" height="54" rx="6" fill="#2b2d31" />
                {/* deflection yoke (copper) */}
                <rect x="960" y="282" width="110" height="210" rx="22" fill="url(#copperG)" stroke="#6d3f18" strokeWidth="3" />
                {Array.from({ length: 9 }, (_, i) => (
                  <line key={i} x1={976 + i * 11} y1="288" x2={976 + i * 11} y2="486" stroke="#6d3f18" strokeWidth="2" opacity="0.7" />
                ))}
                {/* anode cable + cup */}
                <path d="M690 214 C 690 130 900 120 1010 210 C 1050 250 1050 300 1030 330" fill="none" stroke={O.red} strokeWidth="9" strokeLinecap="round" />
                <circle cx="690" cy="218" r="30" fill="#7a1713" stroke="#3a0b09" strokeWidth="3" />
                <circle cx="682" cy="210" r="9" fill="rgba(255,255,255,0.35)" />

                {/* circuit board */}
                <rect x="520" y="640" width="800" height="130" rx="10" fill={O.pcb} stroke={O.pcbDark} strokeWidth="4" />
                {Array.from({ length: 14 }, (_, i) => (
                  <path key={i} d={`M${540 + i * 55} 770 V ${700 - (i % 3) * 18} H ${570 + i * 55}`} fill="none" stroke="#7bb68a" strokeWidth="2" opacity="0.5" />
                ))}
                {/* capacitors */}
                {[560, 612, 664].map((x, i) => (
                  <g key={x}>
                    <rect x={x} y={656 - i * 4} width="34" height={60 + i * 6} rx="8" fill="#16171a" />
                    <rect x={x} y={656 - i * 4} width="34" height="12" rx="6" fill="#8a8f99" />
                  </g>
                ))}
                {/* flyback transformer */}
                <rect x="780" y="656" width="90" height="82" rx="8" fill="#17181b" stroke="#2c2d31" strokeWidth="3" />
                <rect x="800" y="640" width="50" height="22" fill="#2c2d31" />
                {/* heat sink */}
                {Array.from({ length: 7 }, (_, i) => (
                  <rect key={i} x={920 + i * 14} y="650" width="8" height="70" fill="#c3c8d0" />
                ))}
                <rect x="916" y="716" width="104" height="10" fill="#9ea4ad" />
                {/* ICs */}
                <rect x="1040" y="668" width="70" height="44" rx="4" fill="#111215" />
                <rect x="1130" y="668" width="70" height="44" rx="4" fill="#111215" />
                <rect x="1220" y="660" width="70" height="30" rx="4" fill="#d9c27a" />

                {/* speaker */}
                <rect x="190" y="620" width="220" height="170" rx="16" fill="#1b1c20" stroke="#3a3c42" strokeWidth="4" />
                <g style={{ transformOrigin: "300px 705px", transform: `scale(${speakerPulse})` }}>
                  <circle cx="300" cy="705" r="68" fill="#2a2c32" stroke="#6c727c" strokeWidth="5" />
                  <circle cx="300" cy="705" r="44" fill="#16171a" />
                  <circle cx="300" cy="705" r="16" fill="#8a8f99" />
                </g>
              </g>

              {/* signal paths */}
              <path d={IN_PATH} fill="none" stroke={theme.colors.text} strokeWidth="7" strokeLinecap="round" strokeDasharray="600" strokeDashoffset={600 * (1 - draw(cutAt + 20))} />
              <path d={PIC_PATH} fill="none" stroke={theme.colors.hero} strokeWidth="9" strokeLinecap="round" strokeDasharray="500" strokeDashoffset={500 * (1 - draw(picAt, 22))} style={{ filter: `drop-shadow(0 0 10px ${theme.colors.hero})` }} />
              <path d={SND_PATH} fill="none" stroke={theme.colors.accent} strokeWidth="9" strokeLinecap="round" strokeDasharray="760" strokeDashoffset={760 * (1 - draw(sndAt, 26))} style={{ filter: `drop-shadow(0 0 10px ${theme.colors.accent})` }} />
              <circle cx="1110" cy="700" r={14 * draw(splitAt, 10)} fill={theme.colors.text} />

              <Packets at={cutAt + 26} pt={inPt} color={theme.colors.text} n={3} speed={46} />
              <Packets at={picAt + 14} pt={picPt} color={theme.colors.hero} n={3} speed={50} />
              <Packets at={sndAt + 18} pt={sndPt} color={theme.colors.accent} n={4} speed={70} />

              {/* sound waves leaving the speaker */}
              {waves &&
                [0, 1, 2].map((k) => {
                  const ph = (((frame - sndAt) / 40 + k / 3) % 1 + 1) % 1;
                  return (
                    <path
                      key={k}
                      d={`M${200 - ph * 70} ${705 - 30 - ph * 60} Q ${170 - ph * 120} 705 ${200 - ph * 70} ${705 + 30 + ph * 60}`}
                      fill="none"
                      stroke={theme.colors.accent}
                      strokeWidth="6"
                      strokeLinecap="round"
                      opacity={(1 - ph) * 0.9}
                    />
                  );
                })}
            </svg>
          </Pop>

          {/* labels (inside the same tilted plane) */}
          <div style={{ position: "absolute", left: 1300, top: 520 }}>
            <Tag text="ছবির তথ্য" tone="hero" delay={picAt + 8} size={50} />
          </div>
          <div style={{ position: "absolute", left: 730, top: 800 }}>
            <Tag text="সার্কিট" tone="text" delay={splitAt - 4} size={50} />
          </div>
          <div style={{ position: "absolute", left: 360, top: 800 }}>
            <Tag text="শব্দের তথ্য" tone="accent" delay={sndAt + 6} size={50} />
          </div>
          <div style={{ position: "absolute", left: 120, top: 800 }}>
            <Tag text="স্পিকার" tone="accent" delay={sndAt + 18} size={50} />
          </div>
        </div>
      </div>
    </AbsoluteFill>
  );
};
