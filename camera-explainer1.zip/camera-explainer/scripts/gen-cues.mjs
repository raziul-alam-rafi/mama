// SRT -> src/cues.data.ts  (run: node scripts/gen-cues.mjs)
import fs from "node:fs";
const raw = fs.readFileSync("public/script.srt", "utf8").replace(/\r/g, "").trim();
const ts = (s) => { const m = s.match(/(\d+):(\d+):(\d+),(\d+)/); return (+m[1]) * 3600 + (+m[2]) * 60 + (+m[3]) + (+m[4]) / 1000; };
const cues = raw.split(/\n\s*\n/).map((b) => {
  const l = b.split("\n").filter((x) => x.trim().length);
  const [a, z] = l[1].split(" --> ");
  return { id: +l[0], start: ts(a), end: ts(z), text: l.slice(2).filter((x) => !x.endsWith(".srt")).join(" ").replace(/\s+/g, " ").trim() };
}).filter((c) => !Number.isNaN(c.id) && c.text.length > 0);
fs.writeFileSync("src/cues.data.ts", `// AUTO-GENERATED from public/script.srt — do not edit by hand\nexport const CUES = ${JSON.stringify(cues, null, 2)} as const;\n`);
console.log(cues.length, "cues; end =", cues[cues.length - 1].end);
