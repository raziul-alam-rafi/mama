import React from 'react';
import {SENSOR_Z} from './optics';
import {theme} from '../theme';

/** Glow tracks the fraction of rays that actually arrive (cause -> effect). */
export const SensorPlate: React.FC<{fraction: number}> = ({fraction}) => (
  <group position={[0, 0, SENSOR_Z]}>
    <mesh>
      <boxGeometry args={[3.6, 3.6, 0.1]} />
      <meshStandardMaterial color={theme.colors.accent} emissive={theme.colors.accent} emissiveIntensity={0.08 + 1.6 * fraction} metalness={0.2} roughness={0.5} />
    </mesh>
    <mesh position={[0, 0, 0.1]}>
      <boxGeometry args={[3.9, 3.9, 0.1]} />
      <meshStandardMaterial color={theme.colors.metal} metalness={0.7} roughness={0.4} />
    </mesh>
  </group>
);
