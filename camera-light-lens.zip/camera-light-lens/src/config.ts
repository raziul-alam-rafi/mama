// ছোট সুইচ — এখানেই চালু/বন্ধ করুন
export const VOICEOVER = {
  // public/voiceover.mp3 থাকলে Remotion Studio প্রিভিউতে বাজবে (না থাকলে নীরবে বাদ)
  studio: true,
  // MP4 রেন্ডারে ভয়েসওভার মেশাবে কি না (ডিফল্ট: বন্ধ)
  render: false,
};

// SFX সব সময় চালু; বন্ধ করতে false
export const SFX_ENABLED = true;
