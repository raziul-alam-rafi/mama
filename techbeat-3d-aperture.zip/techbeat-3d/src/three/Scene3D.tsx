import React from "react";
import { ThreeCanvas } from "@remotion/three";
import { useThree } from "@react-three/fiber";
import * as THREE from "three";
import { LensAssembly } from "./LensAssembly";
import { CamState } from "../lib/camera";
import { theme } from "../theme";

const CameraRig: React.FC<{ cam: CamState }> = ({ cam }) => {
  const camera = useThree((s) => s.camera) as THREE.PerspectiveCamera;
  camera.position.set(...cam.pos);
  camera.fov = cam.fov;
  camera.lookAt(...cam.look);
  camera.updateProjectionMatrix();
  return null;
};

export const Scene3D: React.FC<{ t: number; cam: CamState; width: number; height: number }> = ({ t, cam, width, height }) => (
  <ThreeCanvas width={width} height={height} shadows camera={{ fov: cam.fov, position: cam.pos, near: 0.1, far: 100 }}>
    <CameraRig cam={cam} />
    <ambientLight intensity={0.55} />
    <hemisphereLight args={["#bcd2ff", "#0B1020", 0.55]} />
    <directionalLight position={[6, 10, 8]} intensity={1.6} castShadow
      shadow-mapSize-width={2048} shadow-mapSize-height={2048}
      shadow-camera-left={-12} shadow-camera-right={12} shadow-camera-top={12} shadow-camera-bottom={-12} />
    <pointLight position={[-9, 3, -6]} color={theme.colors.primary} intensity={80} distance={30} />
    <pointLight position={[0, 0.2, 0.2]} color={theme.colors.accent} intensity={3} distance={4} />
    <LensAssembly t={t} />
    {/* shadow catcher only: no visible floor edge against the gradient background */}
    <mesh rotation={[-Math.PI / 2, 0, 0]} position={[1, -2.3, 0]} receiveShadow>
      <planeGeometry args={[40, 40]} />
      <shadowMaterial opacity={0.35} />
    </mesh>
  </ThreeCanvas>
);
