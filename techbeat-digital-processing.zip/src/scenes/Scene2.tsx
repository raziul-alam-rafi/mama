// Scene 2 (cues 2-3) — Readout circuit -> ADC (analog wave to digital numbers) -> Processor.
import React from "react";
import { AbsoluteFill } from "remotion";
import { theme } from "../theme";
import { T } from "../timing";
import { along, bin4, clamp, lerp, prog, progIO, smoothPath } from "../util";
import { rawLuma } from "../sceneImage";
import { Defs } from "../components/Defs";
import { CameraGlyph, ChipGlyph, PhoneGlyph } from "../components/Glyphs";
import { useClock, popAt } from "../components/clock";
import { COLS, ROWS, Well, wellLevel } from "./Scene1";

const K1 = { cx: 560, cy: 540, s: 1.5 };
const K2 = { cx: 1240, cy: 540, s: 1.5 };
const K3 = { cx: 1180, cy: 540, s: 1.2 };
const mixK = (a: typeof K1, b: typeof K1, t: number) => ({ cx: lerp(a.cx, b.cx, t), cy: lerp(a.cy, b.cy, t), s: lerp(a.s, b.s, t) });

// sensor (world coords)
const CELL = 30, GAP = 4;
const SG = { x: 141, y: 446 };
const SW = COLS * CELL + (COLS - 1) * GAP;
const BUS_X = 462;
const MID_Y = 540;
// ADC scope
const SC = { x0: 1000, x1: 1480, yTop: 408, yBot: 632 };
const SLOT = (SC.x1 - SC.x0) / COLS;
const slotX = (i: number) => SC.x0 + SLOT * (i + 0.5);
const CHIP = { x: 1740, y: 540 };

// the row whose signal is shown in the ADC (the one with the most variation)
const rowLevels = (r: number) => Array.from({ length: COLS }, (_, c) => wellLevel(c, r));
const rowSel = [0, 1, 2, 3].reduce((best, r) => {
  const rg = (a: number[]) => Math.max(...a) - Math.min(...a);
  return rg(rowLevels(r)) > rg(rowLevels(best)) ? r : best;
}, 0);
const LV_RAW = rowLevels(rowSel);
const lvMin = Math.min(...LV_RAW), lvMax = Math.max(...LV_RAW);
// stretch the row's range so the waveform is clearly readable (it is a schematic of the row's signal)
const LV = LV_RAW.map((v) => 0.1 + (0.85 * (v - lvMin)) / Math.max(0.001, lvMax - lvMin));
const lvY = (v: number) => SC.yBot - 18 - v * (SC.yBot - SC.yTop - 40);
const quant = (v: number) => Math.round(clamp(v) * 15) / 15;

export const Scene2: React.FC = () => {
  const { f, fps, at } = useClock();
  const c = theme.colors;

  const tElec = at(T("Electronic"), 6);
  const tRead = at(T("Electronic"), -2);
  const tAdc = at(T("এরপর"), 8);
  const tAnalog = at(T("Analog"), 6);
  const tSample = at(T("Digital সংখ্যায়"), 6);
  const tQuant = at(T("রূপান্তর"), 14);
  const tChip = at(T("করা"), 8);
  const tPhone = at(T("ফোন"), 6);
  const tCam = at(T("ক্যামেরার Processor"), 6);
  const tProc = at(T("ক্যামেরার Processor"), -4);
  const tOut = at(T("এখন"), 6);

  // camera
  const p1 = progIO(f, tAdc, tAdc + 30);
  const p2 = progIO(f, tChip + 6, tChip + 40);
  const cam = mixK(mixK(K1, K2, p1), K3, p2);

  // sensor read-out: rows read one after another; the row's cells drain, packets slide out
  const rowStart = (r: number) => tRead + 4 + r * 17;
  const PACKET_DUR = 40;
  const packets: React.ReactNode[] = [];
  for (let r = 0; r < ROWS; r++) {
    for (let col = 0; col < COLS; col++) {
      const t0 = rowStart(r) + (COLS - 1 - col) * 2;
      const t = (f - t0) / PACKET_DUR;
      if (t < 0 || t > 1) continue;
      const y = SG.y + r * (CELL + GAP) + CELL / 2;
      const x0 = SG.x + col * (CELL + GAP) + CELL / 2;
      const [px, py] = along([[x0, y], [BUS_X, y], [BUS_X, MID_Y], [560, MID_Y]], theme.ease.soft(t));
      const lv = wellLevel(col, r);
      const fade = 1 - prog(px, 520, 600, theme.ease.soft);
      packets.push(<rect key={r * 10 + col} x={px - 7} y={py - 4 - lv * 6} width={14} height={8 + lv * 12} rx={4} fill="url(#gAmber)" opacity={fade} filter="url(#fGlow)" />);
    }
  }

  const sensorPop = popAt(f, fps, 0, theme.spring.smooth);
  const circuitPop = popAt(f, fps, tElec, theme.spring.smooth);
  const adcPop = popAt(f, fps, tAdc - 2, theme.spring.smooth);
  const chipPop = popAt(f, fps, tChip, theme.spring.bouncy);
  const circuitGlow = clamp(1 - Math.abs(((f - tRead - 30) % 60) / 60) * 0) * prog(f, tRead + 20, tRead + 40) * (1 - prog(f, tRead + 90, tRead + 110));

  // analog wave in the scope
  const pts: [number, number][] = [[SC.x0, lvY(LV[0])], ...LV.map((v, i) => [slotX(i), lvY(v)] as [number, number]), [SC.x1, lvY(LV[COLS - 1])]];
  const wavePath = smoothPath(pts);
  const waveP = prog(f, tAnalog, tAnalog + 46, theme.ease.inOut);
  const sampleStart = (i: number) => tSample + i * 4;
  const quantP = prog(f, tQuant, tQuant + 22, theme.ease.out);
  const levelsP = prog(f, tQuant - 8, tQuant + 10);

  // digital stream to processor
  const streamStart = (i: number) => tChip + 2 + (COLS - 1 - i) * 6;
  const chipIn = Array.from({ length: COLS }).reduce<number>((acc, _, i) => acc + prog(f, streamStart(i) + 30, streamStart(i) + 38), 0) / COLS;
  const chipGlow = clamp(chipIn * 1.4) * (0.75 + 0.25 * Math.sin(f / 7));
  const tiles = prog(f, tOut, tOut + 10);

  return (
    <AbsoluteFill>
      <svg width="1920" height="1080" style={{ position: "absolute", inset: 0 }}>
        <Defs />
        <g transform={`translate(960 540) scale(${cam.s}) translate(${-cam.cx} ${-cam.cy})`}>
          {/* ---------- Sensor ---------- */}
          <g opacity={sensorPop} transform={`translate(0 ${(1 - sensorPop) * 20})`}>
            <rect x={110} y={410} width={346} height={262} rx={30} fill={c.bgAlt} stroke={c.line} strokeWidth={3} filter="url(#fShadow)" />
            {Array.from({ length: ROWS * COLS }).map((_, i) => {
              const col = i % COLS, row = Math.floor(i / COLS);
              const drain = prog(f, rowStart(row) + (COLS - 1 - col) * 2, rowStart(row) + (COLS - 1 - col) * 2 + 18, theme.ease.out);
              const ring = f >= rowStart(row) && f < rowStart(row) + 17 ? 1 : 0;
              return <Well key={i} idx={i} x={SG.x + col * (CELL + GAP)} y={SG.y + row * (CELL + GAP)} size={CELL} level={wellLevel(col, row)} fill={1 - drain} f={f} ring={ring} />;
            })}
            {/* active row highlight bar */}
            {[0, 1, 2, 3].map((r) => {
              const on = f >= rowStart(r) && f < rowStart(r) + 17;
              return on ? <rect key={r} x={SG.x - 6} y={SG.y + r * (CELL + GAP) - 3} width={SW + 12} height={CELL + 6} rx={9} fill="none" stroke={c.primary} strokeWidth={3} filter="url(#fGlow)" /> : null;
            })}
            <text x={283} y={642} textAnchor="middle" fontFamily={theme.fonts.main} fontWeight={600} fontSize={28} fill={c.textDim}>Sensor</text>
            {/* collector bus */}
            <path d={`M${SG.x + SW + 10} ${SG.y + 10} H${BUS_X} V${MID_Y} H560`} fill="none" stroke={c.line} strokeWidth={4} strokeLinejoin="round" opacity={0.0} />
            <path d={`M${BUS_X} ${SG.y - 6} V${MID_Y} H530`} fill="none" stroke={c.line} strokeWidth={5} strokeLinecap="round" strokeLinejoin="round" />
          </g>

          {/* ---------- Electronic Circuit ---------- */}
          <g opacity={circuitPop} transform={`translate(0 ${(1 - circuitPop) * 24})`}>
            <rect x={520} y={404} width={360} height={272} rx={28} fill="url(#gPanel)" stroke={circuitGlow > 0.2 ? c.accent : c.line} strokeWidth={3} filter="url(#fShadow)" />
            <rect x={520} y={404} width={360} height={272} rx={28} fill="url(#gSheen)" />
            {/* traces */}
            <g fill="none" stroke={c.line} strokeWidth={4} strokeLinecap="round" strokeLinejoin="round">
              <path d="M540 540 H640" /><path d="M760 540 H880" />
              <path d="M580 452 H650 V500" /><path d="M820 452 H760 V500" />
              <path d="M580 628 H650 V580" /><path d="M820 628 H760 V580" />
            </g>
            {[[580, 452], [820, 452], [580, 628], [820, 628]].map(([x, y], i) => <circle key={i} cx={x} cy={y} r={8} fill={c.bg} stroke={c.line} strokeWidth={3} />)}
            {/* amplifier / read-out symbol */}
            <path d="M640 490 L640 590 L760 540 Z" fill={c.bg} stroke={circuitGlow > 0.2 ? c.accent : c.primary} strokeWidth={5} strokeLinejoin="round" filter={circuitGlow > 0.2 ? "url(#fGlow)" : undefined} />
            <text x={700} y={720} textAnchor="middle" fontFamily={theme.fonts.main} fontWeight={600} fontSize={28} fill={c.textDim}>Electronic Circuit</text>
          </g>
          {/* analog signal leaving the circuit */}
          <line x1={880} x2={880 + 120 * prog(f, tRead + 36, tRead + 60)} y1={MID_Y} y2={MID_Y} stroke={c.accent} strokeWidth={6} strokeLinecap="round" filter="url(#fGlow)" opacity={prog(f, tRead + 36, tRead + 50)} />
          {packets}

          {/* ---------- ADC ---------- */}
          <g opacity={adcPop} transform={`translate(0 ${(1 - adcPop) * 30})`}>
            <rect x={960} y={292} width={560} height={496} rx={32} fill="url(#gPanel)" stroke={c.line} strokeWidth={3} filter="url(#fShadow)" />
            <rect x={960} y={292} width={560} height={496} rx={32} fill="url(#gSheen)" />
            <text x={992} y={348} fontFamily={theme.fonts.main} fontWeight={700} fontSize={40} fill={c.text}>ADC</text>
            <text x={1478} y={346} textAnchor="end" fontFamily={theme.fonts.main} fontWeight={500} fontSize={24} fill={c.textDim}>Analog → Digital</text>
            {/* scope */}
            <rect x={SC.x0 - 14} y={SC.yTop - 18} width={SC.x1 - SC.x0 + 28} height={SC.yBot - SC.yTop + 36} rx={16} fill={c.bg} opacity={0.85} />
            {/* quantisation levels */}
            {Array.from({ length: 16 }).map((_, k) => {
              const y = SC.yBot - 18 - (k / 15) * (SC.yBot - SC.yTop - 40);
              return <line key={k} x1={SC.x0} x2={SC.x1} y1={y} y2={y} stroke={c.line} strokeWidth={1.5} opacity={0.65 * levelsP} />;
            })}
            <path d={wavePath} fill="none" stroke={c.accent} strokeWidth={6} strokeLinecap="round" pathLength={1} strokeDasharray={1} strokeDashoffset={1 - waveP} filter="url(#fGlow)" />
            {/* sampling */}
            {LV.map((v, i) => {
              const p = popAt(f, fps, sampleStart(i), theme.spring.snappy);
              const yRaw = lvY(v), yQ = lvY(quant(v));
              const y = lerp(yRaw, yQ, quantP);
              return (
                <g key={i} opacity={Math.min(1, p * 1.5)}>
                  <line x1={slotX(i)} x2={slotX(i)} y1={SC.yBot + 10} y2={y} stroke={c.primary} strokeWidth={3} strokeDasharray="6 7" opacity={0.85} />
                  <circle cx={slotX(i)} cy={y} r={10 * (0.5 + 0.5 * p)} fill={c.primary} stroke="#fff" strokeWidth={2.5} />
                  {quantP > 0.4 && <rect x={slotX(i) - SLOT * 0.36} y={y - 3} width={SLOT * 0.72} height={6} rx={3} fill={c.primary} opacity={0.55 * quantP} />}
                </g>
              );
            })}
            <text x={SC.x0 + 4} y={SC.yTop + 8} fontFamily={theme.fonts.main} fontWeight={600} fontSize={24} fill={c.accent} opacity={prog(f, tAnalog, tAnalog + 12)}>Analog Signal</text>
            {/* digital numbers */}
            {LV.map((v, i) => {
              const p = popAt(f, fps, tQuant + 12 + i * 4, theme.spring.snappy);
              const stream = prog(f, streamStart(i), streamStart(i) + 8);
              return (
                <g key={i} opacity={Math.min(1, p * 1.5) * (1 - stream)} transform={`translate(${slotX(i)} ${700 + (1 - p) * 16})`}>
                  <rect x={-28} y={-20} width={56} height={36} rx={10} fill={c.bg} stroke={c.primary} strokeWidth={2.5} />
                  <text textAnchor="middle" y={6} fontFamily={theme.fonts.main} fontWeight={700} fontSize={21} fill={c.primary} style={{ fontVariantNumeric: "tabular-nums" }}>{bin4(quant(v))}</text>
                </g>
              );
            })}
            <text x={992} y={764} fontFamily={theme.fonts.main} fontWeight={600} fontSize={24} fill={c.primary} opacity={prog(f, tQuant + 10, tQuant + 24)}>Digital সংখ্যা</text>
          </g>

          {/* ---------- digital stream to the processor ---------- */}
          {LV.map((v, i) => {
            const t = (f - streamStart(i)) / 40;
            if (t < 0 || t > 1) return null;
            const [px, py] = along([[slotX(i), 700], [1580, 700], [1580, MID_Y], [CHIP.x - 100 - 6, MID_Y]], theme.ease.soft(t));
            return (
              <g key={i} transform={`translate(${px} ${py})`} opacity={1 - prog(t, 0.86, 1)}>
                <rect x={-26} y={-18} width={52} height={34} rx={10} fill={c.bg} stroke={c.primary} strokeWidth={2.5} filter="url(#fGlow)" />
                <text textAnchor="middle" y={6} fontFamily={theme.fonts.main} fontWeight={700} fontSize={20} fill={c.primary}>{bin4(quant(v))}</text>
              </g>
            );
          })}

          {/* ---------- Processor + devices ---------- */}
          <g opacity={Math.min(1, chipPop * 1.4)} transform={`translate(${CHIP.x} ${CHIP.y}) scale(${0.8 + 0.2 * chipPop})`}>
            <ChipGlyph size={200} glow={chipGlow} act={f} />
          </g>
          <text x={CHIP.x} y={CHIP.y + 168} textAnchor="middle" fontFamily={theme.fonts.main} fontWeight={700} fontSize={32} fill={c.text} opacity={prog(f, tProc, tProc + 10)}>Processor</text>
          <g opacity={popAt(f, fps, tPhone)} transform={`translate(${CHIP.x - 52} ${CHIP.y - 190}) scale(${0.7 + 0.3 * popAt(f, fps, tPhone, theme.spring.bouncy)})`}>
            <PhoneGlyph s={0.62} />
          </g>
          <g opacity={popAt(f, fps, tCam)} transform={`translate(${CHIP.x + 58} ${CHIP.y - 182}) scale(${0.7 + 0.3 * popAt(f, fps, tCam, theme.spring.bouncy)})`}>
            <CameraGlyph s={0.3} />
          </g>
          {/* processor hands pixel data on (leads into scene 3) */}
          <g opacity={tiles}>
            {Array.from({ length: 18 }).map((_, i) => {
              const col = i % 6, row = Math.floor(i / 6);
              const p = popAt(f, fps, tOut + i * 2, theme.spring.snappy);
              const l = rawLuma(((col + 0.5) / 6), ((row + 0.5) / 3), 0.12, 0.2);
              const g = Math.round(40 + clamp(l / 0.6) * 200);
              return <rect key={i} x={CHIP.x - 95 + col * 34} y={CHIP.y + 200 + row * 34} width={28} height={28} rx={7} fill={`rgb(${g},${g},${Math.min(255, g + 14)})`} opacity={p} transform={`translate(0 ${(1 - p) * -16})`} />;
            })}
          </g>
        </g>
      </svg>
    </AbsoluteFill>
  );
};
