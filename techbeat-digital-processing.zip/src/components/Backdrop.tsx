import React from "react";
import { AbsoluteFill, useCurrentFrame } from "remotion";
import { theme } from "../theme";

/** Layer 1 — animated background mesh + faint blueprint grid. */
export const BgMesh: React.FC = () => {
  const f = useCurrentFrame();
  const d1 = Math.sin(f / 80) * 60;
  const d2 = Math.cos(f / 95) * 50;
  const d3 = Math.sin(f / 110 + 2) * 40;
  const c = theme.colors;
  return (
    <AbsoluteFill style={{ background: c.bg }}>
      <div style={{ position: "absolute", width: 1400, height: 1400, borderRadius: "50%", top: -640, left: -380 + d1, filter: "blur(60px)", background: `radial-gradient(circle, ${c.primary}30, transparent 62%)` }} />
      <div style={{ position: "absolute", width: 1100, height: 1100, borderRadius: "50%", bottom: -560, right: -300 - d2, filter: "blur(70px)", background: `radial-gradient(circle, ${c.primaryDeep}2e, transparent 64%)` }} />
      <div style={{ position: "absolute", width: 700, height: 700, borderRadius: "50%", top: 380 + d3, right: 120, filter: "blur(80px)", background: `radial-gradient(circle, ${c.accent}12, transparent 66%)` }} />
      <svg width="1920" height="1080" style={{ position: "absolute", inset: 0, opacity: 0.5 }}>
        <defs>
          <pattern id="bpGrid" width="60" height="60" patternUnits="userSpaceOnUse" patternTransform={`translate(${(f * 0.25) % 60} ${(f * 0.15) % 60})`}>
            <path d="M60 0H0V60" fill="none" stroke={c.line} strokeWidth="1" opacity="0.28" />
          </pattern>
          <radialGradient id="bpFade" cx="50%" cy="50%" r="65%">
            <stop offset="35%" stopColor="#fff" stopOpacity="1" />
            <stop offset="100%" stopColor="#fff" stopOpacity="0" />
          </radialGradient>
          <mask id="bpMask"><rect width="1920" height="1080" fill="url(#bpFade)" /></mask>
        </defs>
        <rect width="1920" height="1080" fill="url(#bpGrid)" mask="url(#bpMask)" />
      </svg>
    </AbsoluteFill>
  );
};

/** Layer 4 — colour grade. */
export const Grade: React.FC = () => (
  <AbsoluteFill style={{ pointerEvents: "none" }}>
    <AbsoluteFill style={{ backgroundColor: theme.colors.primary, mixBlendMode: "soft-light", opacity: 0.12 }} />
    <AbsoluteFill style={{ background: "linear-gradient(180deg, rgba(0,0,0,0.10), transparent 26%, transparent 74%, rgba(0,0,0,0.18))" }} />
  </AbsoluteFill>
);

/** Layer 5 — procedural film grain + vignette. */
export const Grain: React.FC = () => {
  const f = useCurrentFrame();
  const noise = `url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='220' height='220'%3E%3Cfilter id='n'%3E%3CfeTurbulence type='fractalNoise' baseFrequency='0.9' numOctaves='2'/%3E%3C/filter%3E%3Crect width='220' height='220' filter='url(%23n)' opacity='0.5'/%3E%3C/svg%3E")`;
  return (
    <AbsoluteFill
      style={{ pointerEvents: "none", backgroundImage: noise, backgroundSize: "220px", backgroundPosition: `${(f * 7) % 220}px ${(f * 13) % 220}px`, opacity: 0.045, mixBlendMode: "overlay" }}
    />
  );
};

export const Vignette: React.FC = () => (
  <AbsoluteFill style={{ pointerEvents: "none", background: "radial-gradient(ellipse at center, transparent 58%, rgba(2,4,12,0.34) 100%)" }} />
);
