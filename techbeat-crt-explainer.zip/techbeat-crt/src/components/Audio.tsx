import React, { useEffect, useState } from "react";
import { Audio, Sequence, getRemotionEnvironment, staticFile } from "remotion";
import { CUES, SCENES, globalBeat, BEATS } from "../timeline";

/** Flip to true ONLY if you want the voice-over baked into a render. */
export const INCLUDE_VOICEOVER_IN_RENDER = false;
/** Master switch for the voice-over preview inside Remotion Studio. */
export const PREVIEW_VOICEOVER = true;

/** Plays public/voiceover.mp3 in Studio if the file exists; silently skipped if not. */
export const PreviewAudio: React.FC = () => {
  const { isRendering } = getRemotionEnvironment();
  const allowed = PREVIEW_VOICEOVER && (!isRendering || INCLUDE_VOICEOVER_IN_RENDER);
  const [exists, setExists] = useState(false);
  useEffect(() => {
    if (!allowed) return;
    let alive = true;
    fetch(staticFile("voiceover.mp3"), { method: "HEAD" })
      .then((r) => {
        const type = r.headers.get("content-type") || "";
        if (alive) setExists(r.ok && !type.includes("text/html"));
      })
      .catch(() => {});
    return () => {
      alive = false;
    };
  }, [allowed]);
  if (!allowed || !exists) return null;
  return <Audio src={staticFile("voiceover.mp3")} volume={1} />;
};

type Ev = { f: number; file: string; vol: number; rate?: number };

// SFX events — all frames are derived from SRT cue times (via BEATS), 3 frames early.
const EARLY = 3;
const ev = (scene: number, frac: number, file: string, vol: number, rate = 1): Ev => ({
  f: Math.max(0, globalBeat(scene, frac) - EARLY),
  file,
  vol,
  rate,
});

export const SFX_EVENTS: Ev[] = [
  // 1 — hook
  { f: 2, file: "thud", vol: 0.28 },
  ev(0, BEATS.s1.title + 0.03, "pop", 0.26),
  ev(0, BEATS.s1.reveal, "pop", 0.3, 1.08),
  // transitions (scene boundaries)
  ...SCENES.slice(1).map((s, i) => ({
    f: Math.max(0, s.from - 2),
    file: "whoosh",
    vol: 0.26,
    rate: 0.94 + i * 0.05,
  })),
  // 2 — camera
  ev(1, BEATS.s2.field + 0.02, "pop", 0.24),
  ev(1, BEATS.s2.camera, "pop", 0.3, 0.94),
  ev(1, BEATS.s2.rays, "click", 0.26),
  // 3 — scan -> signal -> broadcast
  ev(2, BEATS.s3.scan, "tick", 0.24),
  ev(2, BEATS.s3.wave, "click", 0.26, 1.06),
  ev(2, BEATS.s3.tower, "chime", 0.26),
  // 4 — receive
  ev(3, BEATS.s4.pulse, "pop", 0.24),
  ev(3, BEATS.s4.antenna, "chime", 0.28, 1.12),
  ev(3, BEATS.s4.wire, "click", 0.26),
  // 5 — split
  ev(4, BEATS.s5.cut, "pop", 0.28, 0.96),
  ev(4, BEATS.s5.split, "click", 0.3),
  ev(4, BEATS.s5.picture, "pop", 0.26, 1.06),
  ev(4, BEATS.s5.sound, "pop", 0.26, 0.92),
];

export const Sfx: React.FC = () => (
  <>
    {SFX_EVENTS.map((e, i) => (
      <Sequence key={i} from={e.f} durationInFrames={40} layout="none">
        <Audio src={staticFile(`sfx/${e.file}.wav`)} volume={e.vol} playbackRate={e.rate ?? 1} />
      </Sequence>
    ))}
  </>
);

// keep CUES referenced so the SRT is the single timing source of truth
export const SFX_CUE_COUNT = CUES.length;
