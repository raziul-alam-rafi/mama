import React from "react";
import { useCurrentFrame } from "remotion";
import { theme } from "../theme";
import { FullSvg, P, SceneShell, Sfx, Tag, Title, Win, hash, lerp } from "../fx";
import { sceneTimes } from "../timeline";
import { cueStart, wordFrame } from "../srt";

const C = theme.colors;
const T0 = sceneTimes[3].from;
const t8 = cueStart(8) - T0;
const tBright = wordFrame(8, "উজ্জ্বলতা", 6) - T0;
const tShadow = wordFrame(8, "ছায়া", 6) - T0;
const tShape = wordFrame(8, "আকৃতির", 6) - T0;

const cols = 40;
const rows = 22;
const cs = 28;
const gx0 = (theme.width - cols * cs) / 2;
const gy0 = 300;

/** আপেলের আলো-ছায়া মানচিত্র: 0..1 উজ্জ্বলতা + অঞ্চল */
const sample = (i: number, j: number) => {
  const x = (i + 0.5) / cols;
  const y = (j + 0.5) / rows;
  const cx = 0.5;
  const cy = 0.5;
  // আপেল দেহ: দুটি ওভারল্যাপিং গোলক
  const d1 = Math.hypot((x - 0.46) * 1.78, y - cy - 0.04) / 0.34;
  const d2 = Math.hypot((x - 0.54) * 1.78, y - cy - 0.04) / 0.34;
  const inApple = Math.min(d1, d2) < 1 && !(y < 0.2 && Math.abs(x - cx) < 0.02 && false);
  const stem = Math.abs(x - 0.5) < 0.012 && y > 0.15 && y < 0.3;
  const leaf = Math.hypot((x - 0.56) * 1.78, (y - 0.2) * 2.4) < 0.1;
  // উপরে আলো, নিচে ছায়া
  const lx = (x - 0.4) * 1.78;
  const ly = y - 0.4;
  const light = 1 - Math.min(1, Math.hypot(lx, ly) / 0.75);
  if (stem) return { v: 0.18, kind: "shape" as const };
  if (leaf) return { v: 0.35, kind: "shape" as const };
  if (inApple) {
    const v = 0.36 + light * 0.64;
    return { v: Math.min(1, v), kind: light > 0.6 ? ("bright" as const) : ("body" as const) };
  }
  // মাটির ছায়া (আপেলের নিচে)
  const sh = Math.hypot((x - 0.54) * 1.78 / 0.42, (y - 0.9) / 0.07) < 1;
  if (sh) return { v: 0.0, kind: "shadow" as const };
  return { v: 0.2, kind: "bg" as const };
};

export const S4Grid: React.FC = () => {
  const frame = useCurrentFrame();
  const cells: React.ReactNode[] = [];
  const toGray = P(frame, t8 + 4, 26, theme.ease.inOut); // বার → ছবি
  for (let j = 0; j < rows; j++)
    for (let i = 0; i < cols; i++) {
      const { v, kind } = sample(i, j);
      const dist = Math.hypot(i - cols / 2, (j - rows / 2) * 1.6);
      const s = P(frame, 10 + dist * 0.9, 14, theme.ease.out);
      if (s <= 0.01) continue;
      const jitter = 0.04 * Math.sin(frame / 9 + hash(i * 7 + j, 3) * 6);
      const lv = Math.min(1, Math.max(0.03, v + jitter * (1 - toGray)));
      const x = gx0 + i * cs;
      const y = gy0 + j * cs;
      const inset = lerp(3, 0.4, toGray);
      const side = cs - inset * 2;
      const gray = Math.round(10 + lv * 245);
      // একই অঞ্চলে হাইলাইট (বাংলা শব্দের সঙ্গে)
      let hl = 0;
      if (kind === "bright") hl = P(frame, tBright, 14) * (1 - P(frame, tBright + 46, 14));
      if (kind === "shadow") hl = P(frame, tShadow, 14) * (1 - P(frame, tShadow + 46, 14));
      if (kind === "shape") hl = P(frame, tShape, 14);
      // বার-মোড (charge স্তর) ও ছবি-মোড
      const barH = side * lv;
      cells.push(
        <g key={`${i}-${j}`} opacity={s} transform={`translate(${x + cs / 2} ${y + cs / 2}) scale(${lerp(0.5, 1, s)}) translate(${-cs / 2} ${-cs / 2})`}>
          <rect x={inset} y={inset} width={side} height={side} rx={lerp(5, 1, toGray)} fill={C.panel} />
          <rect x={inset} y={inset + side - barH} width={side} height={barH} rx={4} fill={C.primary} opacity={0.9 * (1 - toGray)} />
          <rect x={inset} y={inset} width={side} height={side} rx={1} fill={`rgb(${gray},${gray},${Math.min(255, gray + 14)})`} opacity={toGray} />
          {hl > 0 ? <rect x={inset} y={inset} width={side} height={side} rx={2} fill="none" stroke={C.accent} strokeWidth={3} opacity={hl} /> : null}
        </g>
      );
    }

  return (
    <SceneShell>
      <Win from={0} to={t8 + 6}>
        <Title text="প্রতিটি pixel আলাদা তথ্য রাখে" top={70} delay={4} highlight={{ 1: C.primary }} />
      </Win>
      <Win from={t8 - 2} to={t8 + 600}>
        <Title text="পার্থক্যেই লুকিয়ে ছবি" top={70} delay={8} highlight={{ 0: C.accent }} />
      </Win>
      <FullSvg>
        <g>{cells}</g>
        <g stroke={C.accent} strokeWidth={3} opacity={0.7}>
          {frame > tBright + 8 && frame < tShadow + 20 ? <line x1={1475} y1={470} x2={760} y2={560} /> : null}
          {frame > tShadow + 8 && frame < tShape + 20 ? <line x1={1475} y1={880} x2={1150} y2={900} /> : null}
          {frame > tShape + 8 ? <line x1={560} y1={560} x2={650} y2={560} stroke={C.text} /> : null}
        </g>
      </FullSvg>
      <Win from={46} to={t8 - 4}>
        <Tag x={1480} y={470} text="বেশি আলো" color={C.accent} delay={0} anchor="l" size={36} />
        <Tag x={440} y={820} text="কম আলো" color={C.textDim} delay={22} anchor="l" size={36} />
      </Win>
      <Win from={tBright} to={tShadow + 40}>
        <Tag x={1480} y={470} text="উজ্জ্বলতা" color={C.accent} delay={0} anchor="l" />
      </Win>
      <Win from={tShadow} to={tShape + 40}>
        <Tag x={1480} y={880} text="ছায়া" color={C.text} delay={0} anchor="l" />
      </Win>
      <Win from={tShape} to={t8 + 600}>
        <Tag x={440} y={560} text="আকৃতি" color={C.text} delay={0} anchor="l" />
      </Win>

      <Sfx at={8} name="whoosh" vol={0.22} />
      <Sfx at={18} name="pop" vol={0.24} />
      <Sfx at={t8 + 4} name="whoosh" vol={0.2} rate={1.12} />
      <Sfx at={tBright} name="click" vol={0.28} rate={1.0} />
      <Sfx at={tShadow} name="click" vol={0.28} rate={0.94} />
      <Sfx at={tShape} name="click" vol={0.28} rate={1.06} />
    </SceneShell>
  );
};
