// সিন ৪ (cue 7): বিভিন্ন Exposure-এর একাধিক ফ্রেম সংগ্রহ → একত্র (Timeline / Process Flow)
import React from "react";
import { useCurrentFrame } from "remotion";
import { theme } from "../theme";
import { makeT } from "../timing";
import { Entrance, SceneShell, tween, useBreathe } from "../components/anim";
import { Chip, Label } from "../components/ui";
import { EXPO, FACE, Photo, WIN } from "../components/photo";
import { SfxEvent } from "../sfx";

const T = makeT(3);
const tExp = T(7);
const tCollect = T(7, "একাধিক ছবি");
const tMerge = T(7, "একত্র");
const tName = T(7, "আর এই পদ্ধতিকে");

export const sfx04: SfxEvent[] = [
  { kind: "pop", frame: tExp + 6 }, { kind: "pop", frame: tExp + 12, rate: 1.07 }, { kind: "pop", frame: tExp + 18, rate: 0.95 },
  { kind: "click", frame: tCollect + 10 },
  { kind: "whoosh", frame: tMerge + 4, rate: 1.05, vol: 0.7 },
  { kind: "chime", frame: tMerge + 30, vol: 0.8 },
];

const FW = 520;
const S = FW / 640;
const FX = [120, 700, 1280];
const FY = 120;
const FR = [
  { g: EXPO.under, label: "কম", color: theme.colors.hero },
  { g: EXPO.mid, label: "মাঝারি", color: theme.colors.text },
  { g: EXPO.over, label: "বেশি", color: theme.colors.accent },
];
const RW = 576; // ফলাফল ছবির প্রস্থ
const RX = 960 - RW / 2, RY = 610;

export const Scene04: React.FC = () => {
  const frame = useCurrentFrame();
  const bob = useBreathe(40, 3);
  const hl = tween(frame, tCollect + 8, tCollect + 26, 0, 1);
  const flow = tween(frame, tMerge, tMerge + 26, 0, 1, theme.ease.inOut);
  const res = tween(frame, tMerge + 14, tMerge + 40, 0, 1);

  return (
    <SceneShell>
      <Entrance delay={tExp} style={{ position: "absolute", left: 120, top: 40 }}>
        <Label size={62} weight={700}>বিভিন্ন <span style={{ color: theme.colors.accent }}>Exposure</span>-এ একাধিক ফ্রেম</Label>
      </Entrance>

      {FR.map((f, i) => (
        <Entrance key={i} delay={tExp + 6 + i * 6} y={50} style={{ position: "absolute", left: FX[i], top: FY + 40 + bob * (i === 1 ? -1 : 1) }}>
          <div style={{ position: "relative", borderRadius: 18, overflow: "hidden", border: `3px solid ${f.color}55`, boxShadow: theme.shadow.card, width: FW }}>
            <Photo uid={`s4-${i}`} gRoom={f.g} gSky={f.g} width={FW} radius={0} />
            {/* কোন অঞ্চল এই ফ্রেম থেকে নেওয়া হবে */}
            {i === 0 && (
              <div style={{ position: "absolute", left: WIN.x * S, top: WIN.y * S, width: WIN.w * S, height: WIN.h * S, border: `5px dashed ${theme.colors.hero}`,
                borderRadius: 6, opacity: hl, boxShadow: `0 0 24px ${theme.colors.glowHero}` }} />
            )}
            {i === 2 && (
              <div style={{ position: "absolute", left: (FACE.cx - 70) * S, top: (FACE.cy - 78) * S, width: 140 * S, height: 156 * S, border: `5px dashed ${theme.colors.accent}`,
                borderRadius: 40, opacity: hl, boxShadow: `0 0 24px ${theme.colors.glowAccent}` }} />
            )}
          </div>
          <div style={{ marginTop: 18, display: "flex", justifyContent: "center" }}>
            <Chip text={`${f.label} Exposure`} color={f.color} size={34} />
          </div>
        </Entrance>
      ))}

      {/* তিন ফ্রেম থেকে ফলাফলের দিকে ডেটা-প্রবাহ */}
      <svg width={1920} height={1080} style={{ position: "absolute", inset: 0 }}>
        {FX.map((x, i) => {
          const sx = x + FW / 2, sy = FY + 40 + FW * 0.5625 + 82, ex = 960 + (i - 1) * 120, ey = RY - 12;
          const my = (sy + ey) / 2;
          const d = `M${sx} ${sy} C ${sx} ${my}, ${ex} ${my}, ${ex} ${ey}`;
          const col = FR[i].color;
          const t = (k: number) => { const u = (flow * 1.0 + k * 0.33) % 1; return u; };
          return (
            <g key={i} opacity={flow > 0 ? 1 : 0}>
              <path d={d} fill="none" stroke={col} strokeOpacity={0.45} strokeWidth={4} pathLength={1} strokeDasharray={1} strokeDashoffset={1 - flow} />
              {[0, 1].map((k) => {
                const u = t(k);
                const bx = (1 - u) ** 3 * sx + 3 * (1 - u) ** 2 * u * sx + 3 * (1 - u) * u * u * ex + u ** 3 * ex;
                const by = (1 - u) ** 3 * sy + 3 * (1 - u) ** 2 * u * my + 3 * (1 - u) * u * u * my + u ** 3 * ey;
                return <rect key={k} x={bx - 9} y={by - 9} width={18} height={18} rx={4} fill={col} opacity={flow > 0.05 && flow < 1 ? 1 : 0} />;
              })}
            </g>
          );
        })}
      </svg>

      {/* একত্র করা ফলাফল */}
      <div style={{ position: "absolute", left: RX, top: RY, opacity: res, transform: `scale(${0.9 + 0.1 * res})`, transformOrigin: "50% 0%" }}>
        <div style={{ borderRadius: 20, overflow: "hidden", border: `3px solid ${theme.colors.ok}`, boxShadow: `0 0 50px ${theme.colors.ok}44, ${theme.shadow.card}` }}>
          <Photo uid="s4-res" gRoom={EXPO.over} gSky={EXPO.under} width={RW} radius={0} />
        </div>
      </div>
      <Entrance delay={tMerge + 26} style={{ position: "absolute", left: 1290, top: RY + 120 }}>
        <Chip text="একত্র" color={theme.colors.ok} solid size={44} />
      </Entrance>
    </SceneShell>
  );
};
