// All prototype timing in SECONDS (converted to frames via fps at use-site).
import {interpolate} from 'remotion';
import {theme} from './theme';

export const PROTO_SECONDS = 15;
export const OPEN_R = 1.0; // aperture radius (inscribed), scene units
export const CLOSED_R = 0.45;

const clamp = {extrapolateLeft: 'clamp', extrapolateRight: 'clamp'} as const;

// open (0-3s) -> close (3-5s) -> hold small (5-8s) -> open (8-10s) -> hold open
export const apertureRadius = (t: number) =>
  interpolate(t, [0, 3, 5, 8, 10], [OPEN_R, OPEN_R, CLOSED_R, CLOSED_R, OPEN_R], {easing: theme.ease.inOut, ...clamp});

export const cameraAzimuth = (t: number) =>
  interpolate(t, [0, 10, 15], [-0.15, -0.85, -0.5], {easing: theme.ease.inOut, ...clamp});

export const cameraDistance = (t: number) =>
  interpolate(t, [0, 1.5, 15], [15, 12.5, 10], {easing: theme.ease.out, ...clamp});
