// সিন ৭ (cue 10): ধারণা বনাম বাস্তব — "সরাসরি Recording" নয়, Sensor-এর তথ্য আর … (Before/After Split)
import React from "react";
import { useCurrentFrame } from "remotion";
import { theme } from "../theme";
import { makeT } from "../timing";
import { Entrance, SceneShell, tween, useBreathe } from "../components/anim";
import { Card, Chip, Label } from "../components/ui";
import { SensorDie } from "../components/sensor";
import { EXPO, Photo } from "../components/photo";
import { SfxEvent } from "../sfx";

const T = makeT(6);
const tIdea = T(10);
const tRec = T(10, "সরাসরি Recording");
const tReal = T(10, "সেটা আসলে");
const tSensor = T(10, "Sensor এর তথ্য");

export const sfx07: SfxEvent[] = [
  { kind: "pop", frame: tIdea + 6 },
  { kind: "click", frame: tRec + 6, rate: 1.05 },
  { kind: "pop", frame: tReal + 8, rate: 0.95 },
  { kind: "pop", frame: tSensor + 6, rate: 1.06 },
];

export const Scene07: React.FC = () => {
  const frame = useCurrentFrame();
  const bob = useBreathe(42, 4);
  const dim = tween(frame, tReal, tReal + 16, 0, 1);
  const lift = tween(frame, tReal, tReal + 20, 0, 1);
  const recBlink = Math.sin(frame / 5) > 0 ? 1 : 0.25;
  const q = 0.55 + 0.45 * Math.abs(Math.sin(frame / 14));

  return (
    <SceneShell>
      {/* বাম: আপনি ভাবছেন */}
      <Entrance delay={tIdea} x={-50} y={0} style={{ position: "absolute", left: 120, top: 220 + bob, opacity: 1 }}>
        <div style={{ opacity: 1 - 0.55 * dim, transform: `scale(${1 - 0.03 * dim})`, filter: `saturate(${1 - 0.5 * dim})` }}>
          <Card w={780} h={600} border={theme.colors.line}>
            <div style={{ padding: "30px 40px", display: "flex", flexDirection: "column", gap: 22 }}>
              <Label size={44} color={theme.colors.textDim}>আপনি ভাবছেন</Label>
              <div style={{ position: "relative", borderRadius: 18, overflow: "hidden", width: 700, border: `2px solid ${theme.colors.line}`, boxSizing: "content-box" }}>
                <Photo uid="s7" gRoom={EXPO.over} gSky={EXPO.under} width={600} radius={0} />
                <div style={{ position: "absolute", left: 20, top: 18, display: "flex", alignItems: "center", gap: 12, padding: "6px 18px", borderRadius: 999, background: `${theme.colors.bg}CC` }}>
                  <div style={{ width: 20, height: 20, borderRadius: 10, background: theme.colors.warn, opacity: recBlink }} />
                  <Label size={30} weight={700}>REC</Label>
                </div>
              </div>
              <Entrance delay={tRec}><Chip text="একটা মুহূর্তের সরাসরি Recording" color={theme.colors.text} size={36} /></Entrance>
            </div>
          </Card>
          {/* কাটা দাগ */}
          <div style={{ position: "absolute", left: 40, right: 40, top: 330, height: 6, borderRadius: 3, background: theme.colors.warn, opacity: dim, transform: "rotate(-4deg)", boxShadow: `0 0 18px ${theme.colors.warn}` }} />
        </div>
      </Entrance>

      {/* ডান: আসলে */}
      <Entrance delay={tReal} x={50} y={0} style={{ position: "absolute", left: 1020, top: 220 - bob }}>
        <div style={{ transform: `scale(${1 + 0.02 * lift})` }}>
          <Card w={780} h={600} border={lift > 0.5 ? theme.colors.hero : theme.colors.line} style={{ boxShadow: `0 0 ${60 * lift}px ${theme.colors.glowHero}, ${theme.shadow.card}` }}>
            <div style={{ padding: "30px 40px", display: "flex", flexDirection: "column", gap: 22 }}>
              <Label size={44} color={theme.colors.hero} weight={700}>আসলে</Label>
              <div style={{ display: "flex", alignItems: "center", gap: 28, marginTop: 40 }}>
                <Entrance delay={tSensor}>
                  <div style={{ display: "flex", flexDirection: "column", alignItems: "center", gap: 24 }}>
                    <SensorDie size={270} />
                    <Chip text="Sensor-এর তথ্য" color={theme.colors.hero} size={34} />
                  </div>
                </Entrance>
                <Entrance delay={tSensor + 16}><Label size={110} color={theme.colors.accent} weight={700} style={{ marginTop: -70 }}>+</Label></Entrance>
                <Entrance delay={tSensor + 24}>
                  <div style={{ width: 230, height: 270, borderRadius: 26, border: `4px dashed ${theme.colors.accent}`, opacity: q, display: "flex", alignItems: "center", justifyContent: "center", marginTop: -58 }}>
                    <Label size={120} color={theme.colors.accent} weight={700}>?</Label>
                  </div>
                </Entrance>
              </div>
            </div>
          </Card>
        </div>
      </Entrance>
    </SceneShell>
  );
};
