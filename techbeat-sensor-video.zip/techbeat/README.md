# Techbeat Inside — Image Sensor → Pixel → Photodiode (Remotion)

    npm install
    npx remotion studio
    npx remotion render src/index.ts Main out/video.mp4

- Composition ID: `Main` (1920×1080, 30 fps, 1599 frames = SRT end).
- Timing comes only from `src/srt-data.ts` (the supplied SRT) via `src/timing.ts` / `src/events.ts`.
- Optional voiceover preview: put `voiceover.mp3` in `public/` (flags in `src/PreviewAudio.tsx`; off in renders by default).
- SFX: `public/sfx/*.wav`, regenerate with `npm run sfx`.
