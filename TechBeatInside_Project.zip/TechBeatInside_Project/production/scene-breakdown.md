# Scene breakdown

Total: 566 frames @ 30 fps = 18.87 s (SRT ends at 18.84 s).

| Shot | Frames | Seconds | Narration | Visual |
|---|---|---|---|---|
| A | 0–128 | 0–4.27 | ধরুন একটি টিভি চ্যানেলে ক্রিকেট ম্যাচ দেখানো হচ্ছে | Establishing — living room, CRT TV shows the cricket match |
| B | 128–243 | 4.27–8.1 | এখানে মাঠে যা ঘটছে ক্যামেরা | Stadium reveal — crane down to the studio camera aimed at the pitch |
| C | 243–292 | 8.1–9.73 | সেই দৃশ্য ধারণ করছে। এরপর ক্যামেরার ছবিকে | Macro push-in to the lens |
| D | 292–363 | 9.73–12.1 | বৈদ্যুতিক সংকেতে রূপান্তর করে | Orbit behind camera — picture scanned line by line into a voltage waveform (explanatory overlay) |
| E | 363–427 | 12.1–14.23 | সম্প্রচারের জন্য পাঠানো হত | Tracking the signal along the cable and up the transmitter tower; RF waves start radiating |
| F | 427–497 | 14.23–16.57 | আর সেই সংকেত antennaর মাধ্যমে | Following the wave front across the landscape to the rooftop Yagi antenna |
| G | 497–566 | 16.57–18.87 | আপনার বাড়ির টিভিতে পৌঁছাত | Following the coax from antenna down into the living room, push-in to the TV |
