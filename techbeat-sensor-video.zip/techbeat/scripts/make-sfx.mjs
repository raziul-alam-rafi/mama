// Synthesizes a small, clean UI/motion-graphics SFX kit (no downloads, deterministic).
// Output: public/sfx/*.wav (16-bit mono 44.1k) + src/sfx-meta.json
import fs from "node:fs";

const SR = 44100;
const out = "public/sfx";
fs.mkdirSync(out, {recursive: true});

let seed = 12345;
const rnd = () => ((seed = (seed * 1664525 + 1013904223) >>> 0) / 4294967296) * 2 - 1;

const buf = (sec) => new Float32Array(Math.round(sec * SR));
const env = (t, a, d) => Math.min(1, t / a) * Math.exp(-t / d);

// RBJ biquad
const biquad = (x, type, f0, q = 0.707) => {
  const w = (2 * Math.PI * f0) / SR, c = Math.cos(w), s = Math.sin(w), al = s / (2 * q);
  let b0, b1, b2, a0 = 1 + al, a1 = -2 * c, a2 = 1 - al;
  if (type === "lp") { b0 = (1 - c) / 2; b1 = 1 - c; b2 = (1 - c) / 2; }
  else if (type === "hp") { b0 = (1 + c) / 2; b1 = -(1 + c); b2 = (1 + c) / 2; }
  else { b0 = al; b1 = 0; b2 = -al; } // bandpass
  const y = new Float32Array(x.length);
  let x1 = 0, x2 = 0, y1 = 0, y2 = 0;
  for (let i = 0; i < x.length; i++) {
    const v = (b0 * x[i] + b1 * x1 + b2 * x2 - a1 * y1 - a2 * y2) / a0;
    x2 = x1; x1 = x[i]; y2 = y1; y1 = v; y[i] = v;
  }
  return y;
};
const tinyVerb = (x) => {
  const y = Float32Array.from(x);
  [[0.011, 0.22], [0.023, 0.14], [0.037, 0.08]].forEach(([d, g]) => {
    const o = Math.round(d * SR);
    for (let i = o; i < y.length; i++) y[i] += x[i - o] * g;
  });
  return y;
};
const fadeEnd = (x, sec = 0.02) => {
  const n = Math.round(sec * SR);
  for (let i = 0; i < n; i++) x[x.length - 1 - i] *= i / n;
  return x;
};

const pop = () => {
  const x = buf(0.28);
  let ph = 0;
  for (let i = 0; i < x.length; i++) {
    const t = i / SR;
    ph += (2 * Math.PI * (170 + 520 * Math.exp(-t / 0.035))) / SR;
    x[i] = Math.sin(ph) * env(t, 0.004, 0.07);
  }
  return tinyVerb(biquad(x, "lp", 3500));
};
const click = () => {
  const x = buf(0.14);
  for (let i = 0; i < x.length; i++) {
    const t = i / SR;
    x[i] = rnd() * env(t, 0.001, 0.012) + Math.sin(2 * Math.PI * 2100 * t) * env(t, 0.001, 0.01) * 0.35;
  }
  return tinyVerb(biquad(biquad(x, "hp", 1500), "lp", 6000));
};
const whoosh = () => {
  const n = Math.round(0.72 * SR);
  const noise = new Float32Array(n);
  for (let i = 0; i < n; i++) noise[i] = rnd();
  const y = new Float32Array(n);
  // sweep: process in blocks with moving band-pass centre
  const B = 256;
  for (let s = 0; s < n; s += B) {
    const t = s / n;
    const f = 350 * Math.pow(2600 / 350, t);
    const seg = biquad(noise.subarray(s, Math.min(n, s + B)), "bp", f, 1.1);
    for (let i = 0; i < seg.length; i++) y[s + i] = seg[i];
  }
  for (let i = 0; i < n; i++) y[i] *= Math.pow(Math.sin(Math.PI * (i / n)), 1.6);
  return tinyVerb(biquad(y, "lp", 5000));
};
const chime = () => {
  const x = buf(0.5);
  for (let i = 0; i < x.length; i++) {
    const t = i / SR;
    x[i] = (Math.sin(2 * Math.PI * 660 * t) + 0.3 * Math.sin(2 * Math.PI * 1320 * t) * Math.exp(-t / 0.12) + 0.12 * Math.sin(2 * Math.PI * 1980 * t) * Math.exp(-t / 0.08)) * env(t, 0.004, 0.14);
  }
  return tinyVerb(biquad(x, "lp", 4500));
};
const thud = () => {
  const x = buf(0.32);
  let ph = 0;
  for (let i = 0; i < x.length; i++) {
    const t = i / SR;
    ph += (2 * Math.PI * (52 + 60 * Math.exp(-t / 0.05))) / SR;
    x[i] = Math.sin(ph) * env(t, 0.006, 0.09);
  }
  return biquad(x, "lp", 400);
};

const TARGET_RMS = 0.12; // equal loudness across the kit
const kit = {pop, click, whoosh, chime, thud};
const meta = {};
for (const [name, fn] of Object.entries(kit)) {
  let x = fadeEnd(fn());
  let rms = Math.sqrt(x.reduce((a, v) => a + v * v, 0) / x.length);
  let g = TARGET_RMS / rms;
  let peak = Math.max(...x.map(Math.abs)) * g;
  if (peak > 0.85) g *= 0.85 / peak; // never clip
  x = x.map((v) => v * g);
  peak = Math.max(...x.map(Math.abs));
  rms = Math.sqrt(x.reduce((a, v) => a + v * v, 0) / x.length);
  const data = Buffer.alloc(44 + x.length * 2);
  data.write("RIFF", 0); data.writeUInt32LE(36 + x.length * 2, 4); data.write("WAVEfmt ", 8);
  data.writeUInt32LE(16, 16); data.writeUInt16LE(1, 20); data.writeUInt16LE(1, 22);
  data.writeUInt32LE(SR, 24); data.writeUInt32LE(SR * 2, 28); data.writeUInt16LE(2, 32); data.writeUInt16LE(16, 34);
  data.write("data", 36); data.writeUInt32LE(x.length * 2, 40);
  x.forEach((v, i) => data.writeInt16LE(Math.round(Math.max(-1, Math.min(1, v)) * 32767), 44 + i * 2));
  fs.writeFileSync(`${out}/${name}.wav`, data);
  meta[name] = {seconds: +(x.length / SR).toFixed(3), peak: +peak.toFixed(3), rms: +rms.toFixed(3)};
  console.log(name.padEnd(7), meta[name], peak >= 0.99 ? "CLIPPING!" : "ok");
}
fs.writeFileSync("src/sfx-meta.json", JSON.stringify(meta, null, 2) + "\n");
