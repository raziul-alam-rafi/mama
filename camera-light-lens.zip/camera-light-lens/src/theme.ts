// theme.ts — রং, ইজিং, spring, ফন্ট, টাইমিং-এর একমাত্র উৎস। কম্পোনেন্টে সরাসরি রঙের কোড নয়।
// কালার স্কিম: "Midnight Lens" (ইউজারের পছন্দ ১)
import { Easing } from "remotion";

export const FPS = 30;
export const WIDTH = 1920;
export const HEIGHT = 1080;

export const theme = {
  colors: {
    bg: "#0B1020", // ব্যাকগ্রাউন্ড
    bgAlt: "#131B34", // কার্ড/সারফেস
    bgDeep: "#070B16",
    primary: "#4F8CFF", // হিরো — প্রতি ফ্রেমে সর্বোচ্চ একটি উপাদানে
    accent: "#FFB547", // অ্যাকসেন্ট — আলো/রশ্মি
    text: "#F2F5FA",
    textDim: "#9AA6C2",
    line: "rgba(242,245,250,0.12)",
    glass: "rgba(255,255,255,0.06)",
    glassBorder: "rgba(255,255,255,0.14)",
    glow: "rgba(79,140,255,0.45)",
    accentGlow: "rgba(255,181,71,0.5)",
    // ইলাস্ট্রেশন-কালার (বিষয়বস্তু: "লাল আপেল")
    apple: "#FF6B5E",
    appleDark: "#C93D3A",
    black: "#000000",
    white: "#FFFFFF",
  },
  fonts: {
    // Hind Siliguri যোগ করলে (public/fonts) সেটাই আগে ব্যবহার হবে; না থাকলে বান্ডলড FreeSans
    display: "'Hind Siliguri', 'Free Sans Latin', 'Free Sans Bn', 'FreeSans', sans-serif",
    body: "'Hind Siliguri', 'Free Sans Latin', 'Free Sans Bn', 'FreeSans', sans-serif",
  },
  weight: { heavy: 700, regular: 400 },
  radius: { card: 32, small: 20, pill: 999 },
  shadow: {
    card: "0 40px 90px -30px rgba(0,0,0,0.65)",
    soft: "0 18px 50px -18px rgba(0,0,0,0.55)",
  },
  // কোথাও linear নয়
  ease: {
    out: Easing.bezier(0.16, 1, 0.3, 1),
    inOut: Easing.bezier(0.83, 0, 0.17, 1),
    in: Easing.bezier(0.7, 0, 0.84, 0),
  },
  spring: {
    snappy: { damping: 14, stiffness: 160, mass: 0.6 },
    smooth: { damping: 20, stiffness: 90, mass: 1 },
    bouncy: { damping: 11, stiffness: 170, mass: 0.7 },
  },
  // ফ্রেমে (30fps)
  timing: {
    lead: 5, // ভিজ্যুয়াল কথার ৪-৬ ফ্রেম আগে ঢোকে
    stagger: 4, // কার্ড/আইটেম
    word: 3, // শব্দ
    enter: 20,
    exit: 10,
    wipe: 16, // সিন ট্রানজিশন
    tail: 45, // শেষ cue-র পর ক্লোজিং হোল্ড
  },
  margin: 120,
} as const;

export type Theme = typeof theme;
