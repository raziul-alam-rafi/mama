import React from "react";
import { theme } from "../theme";

/** গ্লসি কার্ড */
export const Card: React.FC<{ w: number; h: number; style?: React.CSSProperties; border?: string; children?: React.ReactNode }> =
({ w, h, style, border, children }) => (
  <div style={{
    width: w, height: h, borderRadius: theme.radius.lg, position: "relative", overflow: "hidden",
    background: `linear-gradient(160deg, ${theme.colors.surfaceHi}, ${theme.colors.surface} 55%, ${theme.colors.bgAlt})`,
    border: `2px solid ${border ?? theme.colors.line}`, boxShadow: theme.shadow.card, ...style,
  }}>{children}</div>
);

export const Chip: React.FC<{ text: string; color?: string; size?: number; solid?: boolean; style?: React.CSSProperties }> =
({ text, color = theme.colors.text, size = 38, solid, style }) => (
  <div style={{
    display: "inline-flex", alignItems: "center", gap: 12, padding: `${size * 0.28}px ${size * 0.6}px`,
    borderRadius: 999, fontFamily: theme.fonts.body, fontWeight: 600, fontSize: size, letterSpacing: 0, lineHeight: 1.2,
    color: solid ? theme.colors.bg : color, background: solid ? color : `${theme.colors.bg}CC`,
    border: `2px solid ${color}`, boxShadow: theme.shadow.soft, whiteSpace: "nowrap", ...style,
  }}>{text}</div>
);

export const Label: React.FC<{ children: React.ReactNode; size?: number; color?: string; weight?: number; style?: React.CSSProperties }> =
({ children, size = 40, color = theme.colors.text, weight = 600, style }) => (
  <div style={{ fontFamily: theme.fonts.body, fontWeight: weight, fontSize: size, color, letterSpacing: 0, lineHeight: 1.25, ...style }}>{children}</div>
);

/** ছোট অনুভূমিক মিটার (০..১) */
export const Meter: React.FC<{ w: number; value: number; color: string }> = ({ w, value, color }) => (
  <div style={{ width: w, height: 26, borderRadius: 13, background: theme.colors.black, border: `2px solid ${theme.colors.line}`, overflow: "hidden" }}>
    <div style={{ width: `${Math.max(0, Math.min(1, value)) * 100}%`, height: "100%", borderRadius: 13,
      background: `linear-gradient(90deg, ${color}88, ${color})`, boxShadow: `0 0 18px ${color}88` }} />
  </div>
);
