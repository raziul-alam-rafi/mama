// A single procedural "photo" used through the whole video so every stage shows the SAME picture.
// Stage 0 = what the sensor+demosaicing give (dim, slightly blue, noisy, soft).
// Stages 1..6 = the Image Processor fixing one problem at a time. Stage 6 = final photo.
import { clamp, hash, luma, RGB } from "./util";

export const IMG_W = 480;
export const IMG_H = 270;

const sm = (a: number, b: number, x: number) => {
  const t = clamp((x - a) / (b - a));
  return t * t * (3 - 2 * t);
};
const mix = (a: RGB, b: RGB, t: number): RGB => [a[0] + (b[0] - a[0]) * t, a[1] + (b[1] - a[1]) * t, a[2] + (b[2] - a[2]) * t];

/** The clean scene: sky, sun, far hills, a house with red roof, near hills. u,v in [0,1]. */
export function sampleScene(u: number, v: number): RGB {
  const asp = 16 / 9;
  let c = mix([0.14, 0.34, 0.8], [0.99, 0.74, 0.46], Math.pow(sm(0, 0.64, v), 1.15));
  // sun glow + disc
  const d = Math.hypot((u - 0.7) * asp, v - 0.38);
  const glow = Math.exp(-(d * d) / 0.045);
  c = mix(c, [1, 0.86, 0.5], glow * 0.55);
  c = mix(c, [1, 0.93, 0.5], 1 - sm(0.105, 0.118, d));
  // far hills
  const far = 0.63 + 0.045 * Math.sin(u * 6.2 + 1.0) + 0.02 * Math.sin(u * 13 + 2);
  c = mix(c, [0.2, 0.42, 0.5], sm(far - 0.004, far + 0.004, v));
  // house (cream walls, red roof, dark door, blue window)
  const hx0 = 0.17, hx1 = 0.31, hy0 = 0.6, hy1 = 0.77;
  const wall = sm(hx0 - 0.002, hx0 + 0.002, u) * (1 - sm(hx1 - 0.002, hx1 + 0.002, u)) * sm(hy0 - 0.002, hy0 + 0.002, v) * (1 - sm(hy1 - 0.002, hy1 + 0.002, v));
  c = mix(c, [0.95, 0.88, 0.72], wall);
  const du = Math.abs(u - 0.24);
  const slope = 0.47 + (du / 0.095) * 0.14;
  const roof = sm(slope - 0.003, slope + 0.003, v) * (1 - sm(0.603, 0.608, v));
  c = mix(c, [0.82, 0.16, 0.15], roof);
  const door = sm(0.222, 0.225, u) * (1 - sm(0.255, 0.258, u)) * sm(0.69, 0.693, v) * (1 - sm(hy1 - 0.002, hy1 + 0.002, v));
  c = mix(c, [0.28, 0.17, 0.12], door * wall);
  const win = sm(0.268, 0.271, u) * (1 - sm(0.295, 0.298, u)) * sm(0.63, 0.633, v) * (1 - sm(0.67, 0.673, v));
  c = mix(c, [0.25, 0.55, 0.95], win * wall);
  // near hills
  const near = 0.73 + 0.05 * Math.sin(u * 3.4 + 0.4) + 0.018 * Math.sin(u * 8.5 + 1.2);
  const grass = mix([0.2, 0.62, 0.22], [0.08, 0.3, 0.12], sm(near, 1.0, v));
  c = mix(c, grass, sm(near - 0.004, near + 0.004, v));
  return c;
}

// ---------- stage building ----------
type Flags = { bright: boolean; wb: boolean; contrast: boolean; noise: boolean; detail: boolean; tone: boolean };
const FIX_ORDER: (keyof Flags)[] = ["bright", "wb", "contrast", "noise", "detail", "tone"];

function boxBlur(src: Float32Array, w: number, h: number, r: number) {
  const tmp = new Float32Array(src.length);
  const out = new Float32Array(src.length);
  for (let y = 0; y < h; y++)
    for (let x = 0; x < w; x++)
      for (let ch = 0; ch < 3; ch++) {
        let s = 0, n = 0;
        for (let k = -r; k <= r; k++) {
          const xx = Math.min(w - 1, Math.max(0, x + k));
          s += src[(y * w + xx) * 3 + ch];
          n++;
        }
        tmp[(y * w + x) * 3 + ch] = s / n;
      }
  for (let y = 0; y < h; y++)
    for (let x = 0; x < w; x++)
      for (let ch = 0; ch < 3; ch++) {
        let s = 0, n = 0;
        for (let k = -r; k <= r; k++) {
          const yy = Math.min(h - 1, Math.max(0, y + k));
          s += tmp[(yy * w + x) * 3 + ch];
          n++;
        }
        out[(y * w + x) * 3 + ch] = s / n;
      }
  return out;
}

let cleanCache: Float32Array | null = null;
const clean = () => {
  if (cleanCache) return cleanCache;
  const d = new Float32Array(IMG_W * IMG_H * 3);
  for (let y = 0; y < IMG_H; y++)
    for (let x = 0; x < IMG_W; x++) {
      const c = sampleScene((x + 0.5) / IMG_W, (y + 0.5) / IMG_H);
      d.set(c, (y * IMG_W + x) * 3);
    }
  return (cleanCache = d);
}

function build(flags: Flags): Float32Array {
  let d = clean().slice();
  if (!flags.detail) d = boxBlur(d, IMG_W, IMG_H, 2); // soft
  for (let i = 0; i < d.length; i += 3) {
    let r = d[i], g = d[i + 1], b = d[i + 2];
    if (!flags.tone) {
      // crushed shadows + clipped highlights
      r = Math.min(1, Math.max(0, (r - 0.16) / 0.84) * 1.28);
      g = Math.min(1, Math.max(0, (g - 0.16) / 0.84) * 1.28);
      b = Math.min(1, Math.max(0, (b - 0.16) / 0.84) * 1.28);
    }
    if (!flags.contrast) {
      r = (r - 0.5) * 0.62 + 0.5; g = (g - 0.5) * 0.62 + 0.5; b = (b - 0.5) * 0.62 + 0.5;
    }
    if (!flags.bright) { r *= 0.7; g *= 0.7; b *= 0.7; }
    if (!flags.wb) { r *= 0.8; g *= 0.95; b *= 1.22; }
    if (!flags.noise) {
      const n = i / 3;
      const nl = (hash(n * 3.1) - 0.5) * 0.2;
      r += nl + (hash(n * 1.7 + 11) - 0.5) * 0.08;
      g += nl + (hash(n * 2.3 + 23) - 0.5) * 0.08;
      b += nl + (hash(n * 5.9 + 37) - 0.5) * 0.08;
    }
    d[i] = clamp(r); d[i + 1] = clamp(g); d[i + 2] = clamp(b);
  }
  return d;
}

const stageDataCache: Record<number, Float32Array> = {};
/** stage 0 = raw ... stage 6 = fully processed. */
export function stageData(k: number): Float32Array {
  if (stageDataCache[k]) return stageDataCache[k];
  const flags: Flags = { bright: false, wb: false, contrast: false, noise: false, detail: false, tone: false };
  FIX_ORDER.slice(0, k).forEach((f) => (flags[f] = true));
  return (stageDataCache[k] = build(flags));
}

const canvasCache: Record<string, HTMLCanvasElement> = {};
function toCanvas(key: string, data: Float32Array, w: number, h: number): HTMLCanvasElement {
  if (canvasCache[key]) return canvasCache[key];
  const c = document.createElement("canvas");
  c.width = w; c.height = h;
  const ctx = c.getContext("2d")!;
  const img = ctx.createImageData(w, h);
  for (let i = 0; i < w * h; i++) {
    img.data[i * 4] = Math.round(data[i * 3] * 255);
    img.data[i * 4 + 1] = Math.round(data[i * 3 + 1] * 255);
    img.data[i * 4 + 2] = Math.round(data[i * 3 + 2] * 255);
    img.data[i * 4 + 3] = 255;
  }
  ctx.putImageData(img, 0, 0);
  return (canvasCache[key] = c);
}
export const stageCanvas = (k: number) => toCanvas("stage" + k, stageData(k), IMG_W, IMG_H);

/** Raw colour (stage 0) at normalised u,v — bilinear. */
export function rawAt(u: number, v: number): RGB {
  const d = stageData(0);
  const x = clamp(u) * (IMG_W - 1), y = clamp(v) * (IMG_H - 1);
  const x0 = Math.floor(x), y0 = Math.floor(y), x1 = Math.min(IMG_W - 1, x0 + 1), y1 = Math.min(IMG_H - 1, y0 + 1);
  const fx = x - x0, fy = y - y0;
  const out: RGB = [0, 0, 0];
  for (let ch = 0; ch < 3; ch++) {
    const a = d[(y0 * IMG_W + x0) * 3 + ch] * (1 - fx) + d[(y0 * IMG_W + x1) * 3 + ch] * fx;
    const b = d[(y1 * IMG_W + x0) * 3 + ch] * (1 - fx) + d[(y1 * IMG_W + x1) * 3 + ch] * fx;
    out[ch] = a * (1 - fy) + b * fy;
  }
  return out;
}
/** Block-averaged raw colour (less noisy than a point sample) for coarse grids. */
export function rawBlock(u: number, v: number, du: number, dv: number): RGB {
  const acc: RGB = [0, 0, 0];
  const n = 4;
  for (let i = 0; i < n; i++)
    for (let j = 0; j < n; j++) {
      const c = rawAt(u + (i / (n - 1) - 0.5) * du, v + (j / (n - 1) - 0.5) * dv);
      acc[0] += c[0]; acc[1] += c[1]; acc[2] += c[2];
    }
  return [acc[0] / (n * n), acc[1] / (n * n), acc[2] / (n * n)];
}
export const rawLuma = (u: number, v: number, du = 0.06, dv = 0.1) => luma(rawBlock(u, v, du, dv));

// ---------- Bayer sampling ----------
/** 0=R 1=G 2=B for RGGB */
export const bayerCh = (r: number, c: number): 0 | 1 | 2 => (r % 2 === 0 ? (c % 2 === 0 ? 0 : 1) : c % 2 === 0 ? 1 : 2);

export const GRID_W = 96;
export const GRID_H = 54;

/** Channel planes at 96x54 cell resolution. sparse = only the cells that channel actually measured. */
export function planeCanvas(ch: 0 | 1 | 2, mode: "sparse" | "full"): HTMLCanvasElement {
  const key = `plane${ch}${mode}`;
  if (canvasCache[key]) return canvasCache[key];
  const data = new Float32Array(GRID_W * GRID_H * 3);
  for (let r = 0; r < GRID_H; r++)
    for (let c = 0; c < GRID_W; c++) {
      const col = rawBlock((c + 0.5) / GRID_W, (r + 0.5) / GRID_H, 0.5 / GRID_W, 0.5 / GRID_H);
      if (mode === "full" || bayerCh(r, c) === ch) data[(r * GRID_W + c) * 3 + ch] = col[ch];
    }
  return toCanvas(key, data, GRID_W, GRID_H);
}
/** Whole Bayer mosaic (each cell shows only its own channel) = union of the three sparse planes. */
export function mosaicCanvas(): HTMLCanvasElement {
  const key = "mosaic";
  if (canvasCache[key]) return canvasCache[key];
  const data = new Float32Array(GRID_W * GRID_H * 3);
  for (let r = 0; r < GRID_H; r++)
    for (let c = 0; c < GRID_W; c++) {
      const col = rawBlock((c + 0.5) / GRID_W, (r + 0.5) / GRID_H, 0.5 / GRID_W, 0.5 / GRID_H);
      const ch = bayerCh(r, c);
      data[(r * GRID_W + c) * 3 + ch] = col[ch];
    }
  return toCanvas(key, data, GRID_W, GRID_H);
}
/** Demosaiced full-colour picture at cell resolution (96x54). */
export function demosaicedCanvas(): HTMLCanvasElement {
  const key = "demosaiced";
  if (canvasCache[key]) return canvasCache[key];
  const data = new Float32Array(GRID_W * GRID_H * 3);
  for (let r = 0; r < GRID_H; r++)
    for (let c = 0; c < GRID_W; c++) {
      const col = rawBlock((c + 0.5) / GRID_W, (r + 0.5) / GRID_H, 0.5 / GRID_W, 0.5 / GRID_H);
      data.set(col, (r * GRID_W + c) * 3);
    }
  return toCanvas(key, data, GRID_W, GRID_H);
}
