import {Config} from '@remotion/cli/config';

Config.setVideoImageFormat('jpeg');
Config.setCodec('h264');
Config.setCrf(17);
Config.setPixelFormat('yuv420p');
Config.setOverwriteOutput(true);
Config.setConcurrency(2); // WebGL in Codespaces is heavy; raise only if stable
Config.setChromiumOpenGlRenderer('angle'); // software GL via ANGLE; change if gl-check fails (see README)
