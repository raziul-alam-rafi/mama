// সিন ১০ (cue 14): সমাপ্তি — অবিশ্বাস্য মেকানিজম, Like, Tech Beat Insight (Statement Card + CTA)
import React from "react";
import { useCurrentFrame } from "remotion";
import { theme } from "../theme";
import { makeT } from "../timing";
import { Entrance, SceneShell, Words, tween, useBreathe, useSpringAt } from "../components/anim";
import { Label } from "../components/ui";
import { Gear, ThumbUp } from "../components/icons";
import { SfxEvent } from "../sfx";

const T = makeT(9);
const tTitle = T(14, "অবিশ্বাস্য");
const tLike = T(14, "Like");
const tBrand = T(14, "Tech Beat Insight");
const tStay = T(14, "সাথেই থাকুন");

export const sfx10: SfxEvent[] = [
  { kind: "pop", frame: 4 },
  { kind: "pop", frame: tTitle + 4, rate: 1.05 },
  { kind: "click", frame: tLike + 14 },
  { kind: "chime", frame: tBrand + 8 },
  { kind: "pop", frame: tStay + 4, rate: 1.08, vol: 0.8 },
];

export const Scene10: React.FC = () => {
  const frame = useCurrentFrame();
  const bob = useBreathe(40, 4);
  const press = tween(frame, tLike + 8, tLike + 14, 0, 1) - tween(frame, tLike + 14, tLike + 24, 0, 1);
  const pressed = tween(frame, tLike + 14, tLike + 20, 0, 1);
  const ripple = tween(frame, tLike + 14, tLike + 44, 0, 1);
  const btn = useSpringAt(tLike - 4, theme.spring.bouncy);
  const brand = useSpringAt(tBrand, theme.spring.smooth);
  const sweep = tween(frame, tBrand + 6, tBrand + 34, 0, 100, theme.ease.inOut);

  return (
    <SceneShell last>
      {/* পেছনে ধীরে ঘোরা গিয়ার (মেকানিজমের ইঙ্গিত) */}
      <div style={{ position: "absolute", left: -120, top: 560, opacity: 0.22 }}><Gear size={520} teeth={16} rot={frame * 0.5} color={theme.colors.hero} /></div>
      <div style={{ position: "absolute", right: -100, top: -120, opacity: 0.22 }}><Gear size={460} teeth={12} rot={-frame * 0.65} color={theme.colors.accent} /></div>

      <div style={{ position: "absolute", left: 0, right: 0, top: 130 }}>
        <Words text="অবিশ্বাস্য মেকানিজম" delay={tTitle} per={6} style={{ fontSize: 142 }} hl={{ মেকানিজম: theme.colors.accent }} />
      </div>

      {/* Like আসার আগে: মেশিং গিয়ার (লুকানো মেকানিজম) */}
      <Entrance delay={tTitle + 12} style={{ position: "absolute", left: 0, top: 0, width: 1920, height: 1080, opacity: 1 - tween(frame, tLike - 8, tLike + 4, 0, 1, theme.ease.in) }}>
        <div style={{ position: "absolute", left: 870 - 110, top: 470 - 110 + bob }}><Gear size={220} teeth={14} rot={frame * 1.4} color={theme.colors.hero} /></div>
        <div style={{ position: "absolute", left: 1046 - 82, top: 470 - 82 - bob }}><Gear size={164} teeth={10} rot={-frame * 1.4 * 1.4 + 18} color={theme.colors.accent} /></div>
      </Entrance>

      {/* Like বাটন */}
      <div style={{ position: "absolute", left: 960 - 170, top: 400 + bob, width: 340, height: 120, opacity: Math.min(1, btn * 1.3), transform: `scale(${(0.8 + 0.2 * Math.min(1, btn)) * (1 - 0.08 * press)})` }}>
        <div style={{ position: "absolute", inset: -4, borderRadius: 70, border: `4px solid ${theme.colors.hero}`, transform: `scale(${1 + ripple * 0.7})`, opacity: (1 - ripple) * pressed }} />
        <div style={{ width: 340, height: 120, borderRadius: 60, display: "flex", alignItems: "center", justifyContent: "center", gap: 22,
          background: pressed > 0.5 ? theme.colors.hero : theme.colors.surface, border: `3px solid ${theme.colors.hero}`, boxShadow: `0 0 ${40 * pressed}px ${theme.colors.glowHero}, ${theme.shadow.card}` }}>
          <ThumbUp size={64} color={pressed > 0.5 ? theme.colors.bg : theme.colors.hero} />
          <Label size={56} weight={700} color={pressed > 0.5 ? theme.colors.bg : theme.colors.text}>Like</Label>
        </div>
      </div>

      {/* ব্র্যান্ড (শুধু টেক্সট — লোগো অ্যাসেট নেই) */}
      <div style={{ position: "absolute", left: 0, right: 0, top: 620, display: "flex", justifyContent: "center", opacity: Math.min(1, brand * 1.3), transform: `translateY(${(1 - Math.min(1, brand)) * 30}px)` }}>
        <div style={{ position: "relative", fontFamily: theme.fonts.display, fontWeight: 700, fontSize: 130, lineHeight: 1.2, letterSpacing: 0,
          backgroundImage: `linear-gradient(100deg, ${theme.colors.hero}, ${theme.colors.text} 50%, ${theme.colors.accent})`,
          WebkitBackgroundClip: "text", backgroundClip: "text", color: "transparent", WebkitTextFillColor: "transparent",
          clipPath: `inset(0 ${100 - sweep}% 0 0)` }}>Tech Beat Insight</div>
      </div>
      <div style={{ position: "absolute", left: 0, right: 0, top: 820 }}>
        <Words text="সাথেই থাকুন" delay={tStay} per={6} style={{ fontSize: 80, color: theme.colors.textDim }} />
      </div>
    </SceneShell>
  );
};
