// Scene 4 (cues 6-8) — DEMOSAICING: neighbours -> estimated R,G,B -> three planes merge into a full-colour picture.
import React from "react";
import { AbsoluteFill } from "remotion";
import { theme } from "../theme";
import { T } from "../timing";
import { along, clamp, hexToRgb, lerp, mixRgb, prog, progIO, rgbCss, RGB } from "../util";
import { bayerCh, demosaicedCanvas, mosaicCanvas, planeCanvas, rawBlock, stageCanvas } from "../sceneImage";
import { Defs } from "../components/Defs";
import { Words } from "../components/Words";
import { CanvasView } from "../components/CanvasView";
import { useClock, popAt } from "../components/clock";

const chHex = [theme.colors.chR, theme.colors.chG, theme.colors.chB];
const chName = ["লাল", "সবুজ", "নীল"];
const PATCH = { n: 5, cell: 118, gap: 8, x: 140, y: 318, u0: 0.6, v0: 0.27, du: 0.2, dv: 0.2 };
const cellUV = (r: number, c: number) => ({ u: PATCH.u0 + ((c + 0.5) / PATCH.n) * PATCH.du, v: PATCH.v0 + ((r + 0.5) / PATCH.n) * PATCH.dv });
const cellRawColor = (r: number, c: number): RGB => {
  const { u, v } = cellUV(r, c);
  return rawBlock(u, v, 0.02, 0.02);
};
const lift = (c: RGB): RGB => [clamp(c[0] / 0.8), clamp(c[1] / 0.8), clamp(c[2] / 0.8)];
const mosaicCell = (r: number, c: number): RGB => {
  const ch = bayerCh(r, c);
  const v = clamp(cellRawColor(r, c)[ch] / 0.7);
  return mixRgb([0.07, 0.1, 0.2], hexToRgb(chHex[ch]), 0.25 + 0.75 * v);
};
const px = (c: number) => PATCH.x + c * (PATCH.cell + PATCH.gap) + PATCH.cell / 2;
const py = (r: number) => PATCH.y + r * (PATCH.cell + PATCH.gap) + PATCH.cell / 2;

export const Scene4: React.FC = () => {
  const { f, fps, at } = useClock();
  const c = theme.colors;

  const tKick = at(T("গুরুত্বপূর্ণ"), 4);
  const tTitle = at(T("Demosaicing"), 9);
  const tHead = at(T("ক্যামেরা আশেপাশের"), 8);
  const tLal = at(T("লাল"), 6);
  const tSob = at(T("সবুজ"), 6);
  const tNil = at(T("নীল"), 6);
  const tEst = at(T("অনুমান"), 8);
  const tAll = at(T("ফলে"), 14);
  const tC = at(T("আলাদা আলাদা"), 10);
  const tExp = at(T("রঙের নমুনা"), 4);
  const tFill = at(T("মিলিয়ে"), 8);
  const tConv = at(T("তৈরি হয়"), 6);
  const tPhoto = at(T("পূর্ণাঙ্গ রঙিন"), 8);

  const ab = 1 - prog(f, tC - 10, tC + 4, theme.ease.in); // stage A/B visibility
  const headP = popAt(f, fps, tHead - 4, theme.spring.smooth);
  const kick = popAt(f, fps, tKick, theme.spring.smooth);
  const pulse = 0.5 + 0.5 * Math.sin(f / 6);

  // centre pixel (2,2) is a red-filter pixel: green from the 4 neighbours, blue from the 4 diagonals
  const centre = cellRawColor(2, 2);
  const neighbours: [number, number][] = [[1, 2], [3, 2], [2, 1], [2, 3], [1, 1], [1, 3], [3, 1], [3, 3]];
  const neighP = prog(f, tHead + 4, tHead + 22);

  // estimation card
  const CARD = { x: 900, y: 380, w: 500, h: 400 };
  const barBase = CARD.y + CARD.h - 70;
  const barMax = 230;
  const barX = (i: number) => CARD.x + 52 + i * 104;
  const barT = [tLal, tSob, tNil];
  const estP = prog(f, tEst, tEst + 20, theme.ease.out);
  const swatchP = prog(f, tEst + 12, tEst + 30);

  // result grid fills as the window sweeps across every pixel
  const RES = { x: 1460, y: 450, cell: 60, gap: 5 };
  const resStart = at(T("অনুমান"), -14);
  const order = (i: number) => resStart + i * 2;
  const sweepIdx = Math.floor(clamp((f - resStart) / 2, 0, 24));
  const sweeping = f >= resStart && f < resStart + 52;

  // ---- stage C: exploded layers ----
  const e = progIO(f, tExp, tExp + 36);
  const g = progIO(f, tConv, tConv + 40);
  const ee = e * (1 - g);
  const cIn = popAt(f, fps, tC, theme.spring.smooth);
  const W = 880, H = 495;
  const photoP = prog(f, tPhoto, tPhoto + 18);
  const cOut = 1; // stage C stays to the end of the scene
  const planeStyle = (i: number): React.CSSProperties => ({
    position: "absolute",
    left: "50%",
    top: "50%",
    width: W,
    height: H,
    margin: `${-H / 2}px 0 0 ${-W / 2}px`,
    transform: `perspective(2800px) rotateX(${54 * ee}deg) rotateZ(${-24 * ee}deg) translateZ(${(i - 1) * 250 * ee}px) scale(${1.18 - 0.28 * ee})`,
    mixBlendMode: "screen",
    borderRadius: 16,
    overflow: "hidden",
    boxShadow: ee > 0.05 ? `0 0 0 3px ${chHex[i]}aa` : undefined,
  });

  return (
    <AbsoluteFill>
      {/* ---------- kicker + hero title ---------- */}
      <div style={{ position: "absolute", left: 0, right: 0, top: 300, display: "flex", justifyContent: "center", opacity: kick * (1 - prog(f, tHead - 4, tHead + 6)), transform: `translateY(${(1 - kick) * 20}px)` }}>
        <div style={{ fontFamily: theme.fonts.main, fontWeight: 600, fontSize: 40, color: c.accent, padding: "10px 30px", border: `2px solid ${c.accent}`, borderRadius: 999, background: c.panel }}>গুরুত্বপূর্ণ অংশ</div>
      </div>
      <div style={{ position: "absolute", left: 0, right: 0, top: 400 }}>
        <Words text="Demosaicing" start={tTitle} per={5} size={200} gradientWords={[0]} exitAt={tHead - 2} />
      </div>

      <svg width="1920" height="1080" style={{ position: "absolute", inset: 0 }}>
        <Defs />
        {/* heading chip (the title "lands" here) */}
        <g opacity={headP} transform={`translate(140 ${164 + (1 - headP) * 120}) scale(${1 + (1 - headP) * 0.5})`}>
          <rect width={310} height={64} rx={32} fill={c.panel} stroke={c.primary} strokeWidth={3} />
          <circle cx={36} cy={32} r={9} fill={c.primary} filter="url(#fGlow)" />
          <text x={60} y={44} fontFamily={theme.fonts.main} fontWeight={700} fontSize={36} fill={c.text}>Demosaicing</text>
        </g>

        <g opacity={ab}>
          {/* ---------- mosaic patch ---------- */}
          <rect x={PATCH.x - 24} y={PATCH.y - 24} width={PATCH.n * PATCH.cell + (PATCH.n - 1) * PATCH.gap + 48} height={PATCH.n * PATCH.cell + (PATCH.n - 1) * PATCH.gap + 48} rx={30} fill={c.bgAlt} stroke={c.line} strokeWidth={3} opacity={prog(f, tHead - 8, tHead + 8)} filter="url(#fShadow)" />
          {Array.from({ length: 25 }).map((_, i) => {
            const r = Math.floor(i / 5), col = i % 5;
            const pop = popAt(f, fps, tHead - 6 + (r + col) * 2, theme.spring.snappy);
            const isN = neighbours.some((n) => n[0] === r && n[1] === col);
            const glowN = isN ? neighP : 0;
            return (
              <g key={i} transform={`translate(${px(col)} ${py(r)}) scale(${0.6 + 0.4 * pop})`} opacity={Math.min(1, pop * 1.5) * (isN || (r === 2 && col === 2) || neighP < 0.05 ? 1 : 1 - 0.55 * neighP)}>
                <rect x={-PATCH.cell / 2} y={-PATCH.cell / 2} width={PATCH.cell} height={PATCH.cell} rx={14} fill={rgbCss(mosaicCell(r, col))} stroke={glowN > 0.5 ? "#fff" : "rgba(255,255,255,0.12)"} strokeWidth={glowN > 0.5 ? 3 : 1.5} />
                <rect x={-PATCH.cell / 2} y={-PATCH.cell / 2} width={PATCH.cell} height={PATCH.cell} rx={14} fill="url(#gSheen)" />
              </g>
            );
          })}
          {/* information flowing from neighbours to the centre pixel */}
          {neighbours.map(([r, col], k) => {
            const ch = bayerCh(r, col);
            const t = ((f - tHead - k * 3) % 42) / 42;
            const [dx, dy] = along([[px(col), py(r)], [px(2), py(2)]], theme.ease.soft(clamp(t)));
            return (
              <g key={k} opacity={neighP}>
                <line x1={px(col)} y1={py(r)} x2={px(2)} y2={py(2)} stroke={chHex[ch]} strokeWidth={3} strokeDasharray="5 9" opacity={0.75} />
                <circle cx={dx} cy={dy} r={9} fill={chHex[ch]} stroke="#fff" strokeWidth={2} opacity={t < 0 ? 0 : 1 - t * 0.4} filter="url(#fGlow)" />
              </g>
            );
          })}
          <rect x={px(2) - PATCH.cell / 2 - 7} y={py(2) - PATCH.cell / 2 - 7} width={PATCH.cell + 14} height={PATCH.cell + 14} rx={18} fill="none" stroke={c.primary} strokeWidth={5} filter="url(#fGlow)" opacity={neighP * (0.7 + 0.3 * pulse)} />
          {sweeping && <rect x={px(sweepIdx % 5) - PATCH.cell / 2 - 5} y={py(Math.floor(sweepIdx / 5)) - PATCH.cell / 2 - 5} width={PATCH.cell + 10} height={PATCH.cell + 10} rx={16} fill="none" stroke={c.primary} strokeWidth={5} filter="url(#fGlow)" />}

          {/* ---------- estimation card ---------- */}
          <g opacity={prog(f, tHead + 26, tHead + 44)} transform={`translate(${CARD.x} ${CARD.y + (1 - prog(f, tHead + 26, tHead + 50)) * 24})`}>
            <rect width={CARD.w} height={CARD.h} rx={30} fill="url(#gPanel)" stroke={c.line} strokeWidth={3} filter="url(#fShadow)" />
            <rect width={CARD.w} height={CARD.h} rx={30} fill="url(#gSheen)" />
            <text x={36} y={62} fontFamily={theme.fonts.main} fontWeight={700} fontSize={34} fill={c.text}>প্রতিটি Pixel</text>
          </g>
          {[0, 1, 2].map((i) => {
            const measured = i === 0;
            const p = popAt(f, fps, barT[i], theme.spring.smooth);
            const val = clamp(centre[i] / 0.7);
            const h = barMax * (0.18 + 0.82 * val) * p;
            const solid = measured ? 1 : estP;
            return (
              <g key={i} opacity={prog(f, barT[i] - 2, barT[i] + 8)}>
                <rect x={barX(i)} y={barBase - barMax} width={86} height={barMax} rx={16} fill={c.bg} opacity={0.7} />
                <rect x={barX(i)} y={barBase - h} width={86} height={h} rx={16} fill={chHex[i]} opacity={0.25 + 0.75 * solid} />
                {!measured && <rect x={barX(i)} y={barBase - h} width={86} height={h} rx={16} fill="none" stroke="#fff" strokeWidth={3} strokeDasharray="9 8" opacity={1 - estP} />}
                {!measured && <text x={barX(i) + 43} y={barBase - h - 14} textAnchor="middle" fontFamily={theme.fonts.main} fontWeight={700} fontSize={34} fill="#fff" opacity={estP * p}>≈</text>}
                <text x={barX(i) + 43} y={barBase + 42} textAnchor="middle" fontFamily={theme.fonts.main} fontWeight={600} fontSize={30} fill={c.text}>{chName[i]}</text>
              </g>
            );
          })}
          <g opacity={swatchP} transform={`translate(${CARD.x + 366} ${barBase - 150 + (1 - swatchP) * 10})`}>
            <rect width={104} height={104} rx={22} fill={rgbCss(lift(centre))} stroke="#fff" strokeOpacity={0.6} strokeWidth={3} />
          </g>

          {/* ---------- result grid ---------- */}
          <g opacity={prog(f, resStart - 10, resStart + 6)}>
            <text x={RES.x} y={RES.y - 24} fontFamily={theme.fonts.main} fontWeight={600} fontSize={28} fill={c.textDim}>রঙিন Pixel</text>
            {Array.from({ length: 25 }).map((_, i) => {
              const r = Math.floor(i / 5), col = i % 5;
              const p = popAt(f, fps, order(i), theme.spring.snappy);
              return (
                <g key={i}>
                  <rect x={RES.x + col * (RES.cell + RES.gap)} y={RES.y + r * (RES.cell + RES.gap)} width={RES.cell} height={RES.cell} rx={10} fill={c.bg} opacity={0.6} />
                  <rect x={RES.x + col * (RES.cell + RES.gap) + RES.cell * (1 - p) / 2} y={RES.y + r * (RES.cell + RES.gap) + RES.cell * (1 - p) / 2} width={RES.cell * p} height={RES.cell * p} rx={10} fill={rgbCss(lift(cellRawColor(r, col)))} />
                </g>
              );
            })}
          </g>
        </g>
      </svg>

      {/* ---------- stage C: exploded colour planes (HTML + CSS 3D) ---------- */}
      <div style={{ position: "absolute", inset: 0, opacity: cIn, pointerEvents: "none" }}>
        <div style={{ position: "absolute", left: "50%", top: 560, width: 0, height: 0 }}>
          <div style={{ position: "absolute", left: -W * 0.59, top: -H * 0.59, width: W * 1.18, height: H * 1.18, background: "#000", borderRadius: 22, opacity: (1 - clamp(ee * 8)) * cIn, boxShadow: `0 0 0 3px ${c.line}, 0 40px 80px -20px rgba(0,0,0,0.6)` }} />
          {[0, 1, 2].map((i) => {
            const fillP = prog(f, tFill + i * 9, tFill + i * 9 + 24);
            return (
              <div key={i} style={planeStyle(i)}>
                <CanvasView source={planeCanvas(i as 0 | 1 | 2, "sparse")} width={W} height={H} pixelated style={{ position: "absolute", inset: 0 }} />
                <CanvasView source={planeCanvas(i as 0 | 1 | 2, "full")} width={W} height={H} pixelated style={{ position: "absolute", inset: 0, opacity: fillP }} />
              </div>
            );
          })}
          <div style={{ position: "absolute", left: -W * 0.59, top: -H * 0.59, width: W * 1.18, height: H * 1.18, borderRadius: 22, overflow: "hidden", opacity: photoP, boxShadow: photoP > 0.5 ? `0 0 90px ${c.primary}55` : undefined }}>
            <CanvasView source={stageCanvas(0)} width={W * 1.18} height={H * 1.18} />
          </div>
        </div>
        {/* channel legend while the layers are apart */}
        {[0, 1, 2].map((i) => {
          const p = prog(f, tExp + 6 + i * 4, tExp + 24 + i * 4) * (1 - prog(f, tConv - 4, tConv + 12));
          return (
            <div key={i} style={{ position: "absolute", left: 140, top: 400 + i * 96, opacity: p, transform: `translateX(${(1 - p) * -30}px)`, display: "flex", alignItems: "center", gap: 18, fontFamily: theme.fonts.main, fontWeight: 600, fontSize: 36, color: c.text }}>
              <div style={{ width: 40, height: 40, borderRadius: 11, background: chHex[i] }} />
              {chName[i]}
            </div>
          );
        })}
        <div style={{ position: "absolute", left: 0, right: 0, top: 900, display: "flex", justifyContent: "center", opacity: prog(f, tPhoto + 6, tPhoto + 22), transform: `translateY(${(1 - prog(f, tPhoto + 6, tPhoto + 26)) * 16}px)` }}>
          <div style={{ fontFamily: theme.fonts.main, fontWeight: 700, fontSize: 44, color: c.text, padding: "10px 34px", borderRadius: 999, background: c.panel, border: `2px solid ${c.primary}` }}>পূর্ণাঙ্গ রঙিন ছবি</div>
        </div>
      </div>
    </AbsoluteFill>
  );
};
