import React from "react";
import { AbsoluteFill } from "remotion";
import { theme } from "../theme";
import { OVERLAP } from "../timing";
import { prog } from "../util";
import { SceneClockProvider, useClock } from "./clock";

const Inner: React.FC<{ exit: boolean; children: React.ReactNode }> = ({ exit, children }) => {
  const { f, dur } = useClock();
  const enter = prog(f, 5, 15, theme.ease.out);
  const out = exit ? prog(f, dur - OVERLAP, dur - OVERLAP + 7, theme.ease.in) : 0;
  const scale = (1.03 - 0.03 * enter) * (1 - 0.02 * out);
  return (
    <AbsoluteFill style={{ opacity: enter * (1 - out), transform: `scale(${scale})`, transformOrigin: "50% 50%", filter: out > 0.02 ? `blur(${out * 6}px)` : undefined }}>
      {children}
    </AbsoluteFill>
  );
};

/** Wraps a scene: provides the scene clock, a fast enter and an even faster exit. */
export const SceneShell: React.FC<{ from: number; exit?: boolean; children: React.ReactNode }> = ({ from, exit = true, children }) => (
  <SceneClockProvider value={from}>
    <Inner exit={exit}>{children}</Inner>
  </SceneClockProvider>
);
