import React from "react";
import { AbsoluteFill, useCurrentFrame } from "remotion";
import { theme, alpha } from "../theme";
import { Pop, SceneShell, WordReveal, ease } from "../components/ui";
import { Cutaway, JOURNEY } from "../components/Cutaway";
import { pointAt } from "../components/ui";
import { at } from "../timing";
import type { Sfx } from "../sfx";

const K = 4;
const T = theme.colors;
const W = 1560;
const SC = W / 1250;
const LEFT = 221;
const TOP = 262;

// যাত্রাপথের (JOURNEY) মোট দৈর্ঘ্যের অনুপাতে পাঁচটি স্টপ
const STOP_T = [0.345, 0.4246, 0.673, 0.825, 1.0];
const NAMES = ["Lens", "Aperture", "Sensor", "Processor", "Display"];
const LABEL: [number, number][] = [
  [215, 70],
  [315, 462],
  [649, 56],
  [745, 470],
  [874, 120],
];

// cue ৭-এর ভেতরে পাঁচ স্টপ সমান ব্যবধানে
const S0 = at(K, 7, 0.26);
const TS = [at(K, 7, 0.4), at(K, 7, 0.52), at(K, 7, 0.64), at(K, 7, 0.78), at(K, 7, 0.92)];

export const sfx: Sfx[] = [
  { f: 2, s: "whoosh", v: 0.22 },
  { f: 12, s: "pop", v: 0.26 },
  { f: TS[0], s: "pop", r: 1.0 },
  { f: TS[1], s: "click", r: 1.0 },
  { f: TS[2], s: "chime", v: 0.27 },
  { f: TS[3], s: "pop", r: 1.1 },
  { f: TS[4], s: "click", r: 1.1 },
];

const Pill: React.FC<{ x: number; y: number; text: string; p: number; color: string }> = ({ x, y, text, p, color }) => {
  const w = 44 + text.length * 17;
  return (
    <g opacity={Math.min(1, p * 1.5)} transform={`translate(${x} ${y + (1 - p) * 14})`}>
      <rect x={-w / 2} y={-26} width={w} height={52} rx={26} fill={alpha(T.bgAlt, 0.95)} stroke={color} strokeWidth={2.4} />
      <text x={0} y={11} textAnchor="middle" fontSize={32} fontWeight={600} fill={T.text} style={{ fontFamily: theme.fonts.main }}>
        {text}
      </text>
    </g>
  );
};

export const Journey: React.FC = () => {
  const f = useCurrentFrame();
  const zoom = ease(f, [0, 70], [0.72, 1], theme.ease.inOut);
  const t = ease(f, [S0, ...TS], [0, ...STOP_T], theme.ease.inOut);
  const [dx, dy] = pointAt(JOURNEY, t);
  const electric = t > 0.68;
  const active = TS.findIndex((ts) => f >= ts - 6 && f < ts + 26);
  const hl = active >= 0 ? NAMES[active].toLowerCase().replace("processor", "chip") : undefined;
  const open = ease(f, [TS[1] - 12, TS[1] - 2, TS[1] + 18], [70, 38, 68], theme.ease.inOut);

  return (
    <SceneShell>
      <AbsoluteFill style={{ alignItems: "center", paddingTop: 54 }}>
        <WordReveal text="ক্যামেরার ভেতরে ঢুকে" size={80} delay={0} per={5} />
        <WordReveal text="শুরু থেকে শেষ পর্যন্ত" size={56} weight={600} color={T.textDim} hi={[0, 3]} hiColor={T.hero} delay={at(K, 7, 0.12)} per={5} />
      </AbsoluteFill>

      <div
        style={{
          position: "absolute",
          left: LEFT,
          top: TOP,
          transform: `scale(${zoom})`,
          transformOrigin: "60% 55%",
          opacity: ease(f, [0, 16], [0, 1]),
        }}
      >
        <Cutaway
          width={W}
          p={{
            body: ease(f, [4, 40], [0, 1], theme.ease.inOut),
            lens: ease(f, [14, 56], [0, 1], theme.ease.inOut),
            aperture: ease(f, [30, 54], [0, 1]),
            sensor: ease(f, [38, 66], [0, 1]),
            chip: ease(f, [48, 76], [0, 1]),
            display: ease(f, [56, 82], [0, 1]),
          }}
          open={open}
          rays={ease(f, [TS[0] - 20, TS[0] + 24], [0, 1], theme.ease.inOut)}
          glow={ease(f, [TS[2], TS[2] + 14], [0, 1])}
          signal={ease(f, [TS[2] + 4, TS[4]], [0, 1], theme.ease.inOut)}
          hl={hl}
        >
          {f >= S0 - 4 && (
            <g style={{ filter: `drop-shadow(0 0 12px ${electric ? T.glowHero : T.glowAccent})` }}>
              <circle cx={dx} cy={dy} r={11} fill={electric ? T.hero : T.accent} stroke={T.text} strokeWidth={2.5} />
            </g>
          )}
          {NAMES.map((n, i) => (
            <Pill
              key={n}
              x={LABEL[i][0]}
              y={LABEL[i][1]}
              text={n}
              color={i < 2 ? T.accent : T.hero}
              p={ease(f, [TS[i] - 8, TS[i] + 8], [0, 1])}
            />
          ))}
        </Cutaway>
      </div>

      {/* শুরু → শেষ টাইমলাইন */}
      <svg width={1920} height={1080} style={{ position: "absolute", left: 0, top: 0, pointerEvents: "none" }}>
        <line x1={320} x2={1600} y1={985} y2={985} stroke={T.lineSoft} strokeWidth={6} strokeLinecap="round" />
        <line x1={320} x2={320 + 1280 * t} y1={985} y2={985} stroke={electric ? T.hero : T.accent} strokeWidth={6} strokeLinecap="round" />
        {STOP_T.map((s, i) => (
          <circle key={i} cx={320 + 1280 * s} cy={985} r={11} fill={t >= s - 0.001 ? T.text : T.bg} stroke={T.line} strokeWidth={3} />
        ))}
        <circle cx={320 + 1280 * t} cy={985} r={13} fill={electric ? T.hero : T.accent} />
      </svg>
      <div style={{ position: "absolute", left: 120, top: 944, fontSize: 44, fontWeight: 700, lineHeight: 1.45, letterSpacing: 0, color: T.textDim }}>শুরু</div>
      <div style={{ position: "absolute", left: 1640, top: 944, fontSize: 44, fontWeight: 700, lineHeight: 1.45, letterSpacing: 0, color: T.textDim }}>শেষ</div>
    </SceneShell>
  );
};
