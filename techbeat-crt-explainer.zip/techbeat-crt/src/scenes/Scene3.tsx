// Scene 3 — "ক্যামেরার ছবিকে বৈদ্যুতিক সংকেতে রূপান্তর করে সম্প্রচারের জন্য পাঠানো হতো"
// Style: Process flow. Picture is scanned line by line -> becomes an electrical waveform -> tower broadcasts.
import React from "react";
import { AbsoluteFill, useCurrentFrame } from "remotion";
import { theme } from "../theme";
import { BEATS } from "../timeline";
import { ip, Pop, Tag } from "../components/kit";
import { CricketField, Tower } from "../components/objects";
import { SceneProps, makeQ } from "./types";

const CARD = { left: 110, top: 330, w: 560, h: 380 };
const WAVE = { left: 700, top: 390, w: 640, h: 280 };
const TOWER = { left: 1400, top: 190, s: 0.95 };

export const Scene3: React.FC<SceneProps> = ({ cs, cd }) => {
  const frame = useCurrentFrame();
  const q = makeQ(cs, cd);
  const scanA = q(BEATS.s3.scan);
  const scanB = q(BEATS.s3.wave) + 20;
  const scanP = ip(frame, [scanA, scanB], [0, 1]);
  const waveAt = q(BEATS.s3.wave);
  const towerAt = q(BEATS.s3.tower);
  const phase = frame * 0.32;

  let d = "";
  for (let x = 0; x <= WAVE.w - 20; x += 5) {
    const env = 0.5 + 0.5 * Math.sin(x / 70 + 1);
    const y =
      WAVE.h / 2 +
      env * (62 * Math.sin(x / 15 + phase) + 30 * Math.sin(x / 6.4 + phase * 1.7));
    d += `${x === 0 ? "M" : "L"}${x + 10},${y.toFixed(1)} `;
  }
  const clipW = scanP * WAVE.w;
  const link = ip(frame, [waveAt, waveAt + 20], [0, 1], theme.ease.out);
  const startX = WAVE.left + WAVE.w - 10;
  const endX = TOWER.left + 150 * TOWER.s;
  const lineY = WAVE.top + WAVE.h / 2;

  return (
    <AbsoluteFill>
      {/* Picture card (what the camera captured) */}
      <div style={{ position: "absolute", left: CARD.left, top: CARD.top }}>
        <Pop delay={q(BEATS.s3.card)} y={50} s={0.92}>
          <div
            style={{
              position: "relative",
              width: CARD.w,
              height: CARD.h,
              borderRadius: 26,
              overflow: "hidden",
              boxShadow: "0 40px 80px -20px rgba(0,0,0,0.7), 0 0 0 3px rgba(255,255,255,0.1)",
            }}
          >
            <CricketField t={frame} />
            {/* digitised (scanned) region */}
            <div
              style={{
                position: "absolute",
                left: 0,
                top: 0,
                width: "100%",
                height: `${scanP * 100}%`,
                backgroundColor: "rgba(79,140,255,0.22)",
                backgroundImage:
                  "linear-gradient(rgba(79,140,255,0.55) 1px, transparent 1px), linear-gradient(90deg, rgba(79,140,255,0.55) 1px, transparent 1px)",
                backgroundSize: "14px 14px",
              }}
            />
            {/* scan line */}
            <div
              style={{
                position: "absolute",
                left: 0,
                width: "100%",
                top: `${scanP * 100}%`,
                height: 6,
                marginTop: -3,
                background: theme.colors.accent,
                opacity: scanP > 0 && scanP < 1 ? 1 : 0,
                boxShadow: `0 0 26px 6px ${theme.colors.glowAccent}`,
              }}
            />
          </div>
        </Pop>
      </div>

      {/* Waveform = electrical signal */}
      <div style={{ position: "absolute", left: WAVE.left, top: WAVE.top }}>
        <svg width={WAVE.w} height={WAVE.h} style={{ overflow: "visible" }}>
          <defs>
            <clipPath id="wclip">
              <rect x="0" y="-40" width={clipW} height={WAVE.h + 80} />
            </clipPath>
          </defs>
          <line
            x1="0"
            y1={WAVE.h / 2}
            x2={WAVE.w}
            y2={WAVE.h / 2}
            stroke="rgba(154,166,199,0.3)"
            strokeWidth="2"
            strokeDasharray="6 10"
          />
          <g clipPath="url(#wclip)">
            <path
              d={d}
              fill="none"
              stroke={theme.colors.hero}
              strokeWidth="6"
              strokeLinejoin="round"
              strokeLinecap="round"
              style={{ filter: `drop-shadow(0 0 12px ${theme.colors.hero})` }}
            />
          </g>
        </svg>
      </div>

      {/* link wave -> tower */}
      <svg width="1920" height="1080" style={{ position: "absolute", left: 0, top: 0 }}>
        <line
          x1={startX}
          y1={lineY}
          x2={startX + (endX - startX) * link}
          y2={lineY}
          stroke={theme.colors.accent}
          strokeWidth="5"
          strokeDasharray="12 12"
          strokeDashoffset={-frame * 2.5}
          strokeLinecap="round"
          opacity={link}
        />
        {[0, 1, 2].map((k) => {
          const ph = ((frame / 30 + k / 3) % 1 + 1) % 1;
          return (
            <circle
              key={k}
              cx={startX + (endX - startX) * ph}
              cy={lineY}
              r="8"
              fill={theme.colors.text}
              opacity={link * Math.min(1, ph * 5)}
            />
          );
        })}
      </svg>

      <div
        style={{
          position: "absolute",
          left: TOWER.left,
          top: TOWER.top,
          transform: `scale(${TOWER.s})`,
          transformOrigin: "0 0",
        }}
      >
        <Pop delay={q(BEATS.s3.tower) - 10} y={60} s={0.92}>
          <Tower t={frame} rings={frame >= towerAt} ringT={Math.max(0, frame - towerAt)} />
        </Pop>
      </div>

      {/* labels */}
      <div style={{ position: "absolute", left: CARD.left, top: 235 }}>
        <Tag text="ক্যামেরার ছবি" tone="accent" delay={q(BEATS.s3.card) + 8} size={48} />
      </div>
      <div style={{ position: "absolute", left: WAVE.left + 20, top: 250 }}>
        <Tag text="বৈদ্যুতিক সংকেত" tone="hero" delay={scanA + 6} size={52} />
      </div>
      <div style={{ position: "absolute", left: 1470, top: 860 }}>
        <Tag text="সম্প্রচার" tone="accent" delay={towerAt} size={52} />
      </div>
    </AbsoluteFill>
  );
};
