import * as THREE from 'three';
import {mulberry32} from '../../utils/math';

const make = (w: number, h: number, draw: (ctx: CanvasRenderingContext2D, w: number, h: number) => void) => {
  const c = document.createElement('canvas');
  c.width = w;
  c.height = h;
  const ctx = c.getContext('2d')!;
  draw(ctx, w, h);
  const t = new THREE.CanvasTexture(c);
  t.colorSpace = THREE.SRGBColorSpace;
  t.anisotropy = 8;
  t.wrapS = t.wrapT = THREE.RepeatWrapping;
  return t;
};

const cache = new Map<string, THREE.CanvasTexture>();
const memo = (k: string, fn: () => THREE.CanvasTexture) => {
  if (!cache.has(k)) cache.set(k, fn());
  return cache.get(k)!;
};

export const woodTexture = (base = '#6b4426', seed = 3) =>
  memo('wood' + base + seed, () =>
    make(512, 512, (ctx, w, h) => {
      const r = mulberry32(seed);
      ctx.fillStyle = base;
      ctx.fillRect(0, 0, w, h);
      for (let i = 0; i < 260; i++) {
        const y = r() * h;
        ctx.strokeStyle = `rgba(${r() > 0.5 ? '30,15,5' : '150,100,60'},${0.05 + r() * 0.13})`;
        ctx.lineWidth = 0.6 + r() * 2.2;
        ctx.beginPath();
        ctx.moveTo(0, y);
        for (let x = 0; x <= w; x += 32) ctx.lineTo(x, y + Math.sin(x * 0.02 + i) * 3 * r());
        ctx.stroke();
      }
    }),
  );

export const floorPlanks = () =>
  memo('floor', () => {
    const t = make(1024, 1024, (ctx, w, h) => {
      const r = mulberry32(11);
      const n = 12;
      for (let i = 0; i < n; i++) {
        const shade = 70 + r() * 30;
        ctx.fillStyle = `rgb(${shade + 40},${shade + 10},${shade - 15})`;
        ctx.fillRect(0, (i * h) / n, w, h / n - 2);
        for (let j = 0; j < 40; j++) {
          ctx.strokeStyle = `rgba(30,15,5,${0.04 + r() * 0.08})`;
          ctx.beginPath();
          const y = (i * h) / n + r() * (h / n);
          ctx.moveTo(0, y);
          ctx.lineTo(w, y + (r() - 0.5) * 6);
          ctx.stroke();
        }
        ctx.fillStyle = 'rgba(0,0,0,0.5)';
        ctx.fillRect(r() * w, (i * h) / n, 2, h / n);
      }
    });
    t.repeat.set(2, 1.5);
    return t;
  });

export const grassTexture = () =>
  memo('grass', () => {
    const t = make(1024, 1024, (ctx, w, h) => {
      const r = mulberry32(5);
      const bands = 16;
      for (let i = 0; i < bands; i++) {
        ctx.fillStyle = i % 2 ? '#2e7a34' : '#3a8a3e';
        ctx.fillRect((i * w) / bands, 0, w / bands, h);
      }
      for (let i = 0; i < 9000; i++) {
        ctx.fillStyle = `rgba(${r() > 0.5 ? '20,70,25' : '90,160,70'},0.18)`;
        ctx.fillRect(r() * w, r() * h, 2, 2);
      }
    });
    t.repeat.set(2, 2);
    return t;
  });

export const crowdTexture = () =>
  memo('crowd', () => {
    const t = make(1024, 128, (ctx, w, h) => {
      const r = mulberry32(21);
      ctx.fillStyle = '#1b1d28';
      ctx.fillRect(0, 0, w, h);
      for (let i = 0; i < 2600; i++) {
        const hue = Math.floor(r() * 360);
        ctx.fillStyle = `hsl(${hue},${35 + r() * 40}%,${35 + r() * 35}%)`;
        ctx.beginPath();
        ctx.arc(r() * w, r() * h, 1.6 + r() * 2.2, 0, Math.PI * 2);
        ctx.fill();
      }
    });
    t.repeat.set(10, 1);
    return t;
  });

export const adBoardTexture = () =>
  memo('ads', () => {
    // colour blocks only: no brand names / logos
    const t = make(1024, 64, (ctx, w, h) => {
      const cols = ['#0e6ba8', '#d6a21d', '#1a8f5a', '#b2392f', '#5a3fb0', '#e8e8e8'];
      const n = 12;
      for (let i = 0; i < n; i++) {
        ctx.fillStyle = cols[i % cols.length];
        ctx.fillRect((i * w) / n, 0, w / n - 4, h);
      }
    });
    t.repeat.set(3, 1);
    return t;
  });

export const glowSprite = () =>
  memo('glow', () => {
    const t = make(128, 128, (ctx, w, h) => {
      const g = ctx.createRadialGradient(w / 2, h / 2, 0, w / 2, h / 2, w / 2);
      g.addColorStop(0, 'rgba(255,255,255,1)');
      g.addColorStop(0.25, 'rgba(255,240,210,0.45)');
      g.addColorStop(1, 'rgba(255,240,210,0)');
      ctx.fillStyle = g;
      ctx.fillRect(0, 0, w, h);
    });
    t.wrapS = t.wrapT = THREE.ClampToEdgeWrapping;
    return t;
  });

export const blobShadow = () =>
  memo('blob', () => {
    const t = make(128, 128, (ctx, w, h) => {
      const g = ctx.createRadialGradient(w / 2, h / 2, 0, w / 2, h / 2, w / 2);
      g.addColorStop(0, 'rgba(0,0,0,0.55)');
      g.addColorStop(1, 'rgba(0,0,0,0)');
      ctx.fillStyle = g;
      ctx.fillRect(0, 0, w, h);
    });
    t.wrapS = t.wrapT = THREE.ClampToEdgeWrapping;
    return t;
  });

export const newCanvasTexture = (w: number, h: number) => {
  const c = document.createElement('canvas');
  c.width = w;
  c.height = h;
  const t = new THREE.CanvasTexture(c);
  t.colorSpace = THREE.SRGBColorSpace;
  t.anisotropy = 8;
  return {canvas: c, ctx: c.getContext('2d')!, texture: t};
};
