import React from "react";
import { useCurrentFrame } from "remotion";
import { theme, alpha, mix } from "../theme";
import { Draw, Glass, Pop, SceneShell, ease, pointAt, toD, Pt } from "../components/ui";
import { WorldSVG, gridCells, lumColor } from "../world";
import { at } from "../timing";
import type { Sfx } from "../sfx";

const K = 1;
const T = theme.colors;
const CW = 380;
const CH = 470;
const GAP = 56;
const X0 = 116;
const TOP = 250;
const cx = (i: number) => X0 + i * (CW + GAP);

// প্রতিটি কার্ডের এন্ট্রি-সময় (SRT cue থেকে)
const D = [at(K, 2, 0.12), at(K, 2, 0.52), at(K, 3, 0.0), at(K, 3, 0.38)];
const PIVOT = at(K, 3, 0.72); // "কিন্তু সবচেয়ে অবাক করা..."
const TIMER = at(K, 2, 0);

export const sfx: Sfx[] = [
  { f: TIMER + 4, s: "click", v: 0.28 },
  { f: D[0], s: "pop", r: 0.96 },
  { f: D[1], s: "pop", r: 1.02 },
  { f: D[2], s: "pop", r: 1.08 },
  { f: D[3], s: "pop", r: 1.14 },
  { f: D[3] + 30, s: "chime", v: 0.27 },
  { f: PIVOT, s: "thud", v: 0.2 },
];

/* ---- ১. লেন্স + আলো ---- */
const VisLens: React.FC<{ t: number }> = ({ t }) => {
  const offs = [-76, -38, 0, 38, 76];
  return (
    <svg width={CW} height={330} viewBox={`0 0 ${CW} 330`}>
      <Draw d="M10 165 H370" p={1} stroke={T.lineSoft} w={1.5} dash="6 9" />
      <g style={{ filter: `drop-shadow(0 0 7px ${T.glowAccent})` }}>
        {offs.map((o, i) => {
          const pts: Pt[] = [[8, 165 + o], [150, 165 + o], [338, 165]];
          const p = ease(t, [i * 3, 26 + i * 3], [0, 1], theme.ease.inOut);
          return (
            <g key={i}>
              <Draw d={toD(pts)} p={p} stroke={T.accent} w={3} />
              {p >= 1 &&
                [0, 0.5].map((k) => {
                  const u = (((t * 0.018 + i * 0.1 + k) % 1) + 1) % 1;
                  const [x, y] = pointAt(pts, u);
                  return <circle key={k} cx={x} cy={y} r={4.5} fill={T.accent} />;
                })}
            </g>
          );
        })}
      </g>
      <Draw
        d="M150 62 Q216 165 150 268 Q84 165 150 62 Z"
        p={ease(t, [0, 18], [0, 1])}
        stroke={T.text}
        w={3}
        fill={alpha(T.hero, 0.22)}
      />
      <circle cx={338} cy={165} r={7} fill={T.text} opacity={ease(t, [30, 40], [0, 1])} />
    </svg>
  );
};

/* ---- ২. সেন্সর: আলো → বিদ্যুৎ ---- */
const VisSensor: React.FC<{ t: number }> = ({ t }) => {
  const cols = 6;
  const rows = 5;
  const cells = gridCells(cols, rows);
  const sig: Pt[] = [[190, 252], [190, 296], [345, 296]];
  return (
    <svg width={CW} height={330} viewBox={`0 0 ${CW} 330`}>
      {cells.map((c) => {
        const x = 73 + c.i * 40;
        const y = 36 + c.j * 40;
        const land = 8 + c.i * 3 + c.j * 2;
        const fall = ease(t, [land - 12, land], [-70, 0], theme.ease.in);
        const lit = ease(t, [land, land + 8], [0, 1]);
        return (
          <g key={`${c.i}-${c.j}`}>
            <rect x={x} y={y} width={34} height={34} rx={5} fill={mix(T.bgAlt, T.hero, 0.12 + lit * (0.25 + c.lum * 0.6))} stroke={T.lineSoft} strokeWidth={1.2} />
            {t < land && t > land - 12 && <circle cx={x + 17} cy={y + 17 + fall} r={4.5} fill={T.accent} />}
          </g>
        );
      })}
      <Draw d={toD(sig)} p={ease(t, [34, 52], [0, 1])} stroke={T.hero} w={3} />
      {t > 52 &&
        [0, 0.5].map((k) => {
          const [x, y] = pointAt(sig, (((t * 0.02 + k) % 1) + 1) % 1);
          return <circle key={k} cx={x} cy={y} r={5.5} fill={T.text} />;
        })}
    </svg>
  );
};

/* ---- ৩. প্রসেসর: হিসাব ---- */
const VisChip: React.FC<{ t: number }> = ({ t }) => {
  const grid = 4;
  return (
    <svg width={CW} height={330} viewBox={`0 0 ${CW} 330`}>
      {[0, 1, 2].map((i) => (
        <g key={i}>
          <Draw d={`M10 ${110 + i * 55} H80`} p={ease(t, [i * 3, 16 + i * 3], [0, 1])} stroke={T.lineSoft} w={2} />
          <Draw d={`M300 ${110 + i * 55} H370`} p={ease(t, [14 + i * 3, 30 + i * 3], [0, 1])} stroke={T.lineSoft} w={2} />
          {t > 20 && (
            <>
              <circle cx={10 + ((((t * 0.04 + i * 0.3) % 1) + 1) % 1) * 70} cy={110 + i * 55} r={4} fill={T.hero} />
              <circle cx={300 + ((((t * 0.04 + i * 0.3 + 0.5) % 1) + 1) % 1) * 70} cy={110 + i * 55} r={4} fill={T.text} />
            </>
          )}
        </g>
      ))}
      <Draw
        d="M96 62 H284 Q300 62 300 78 V252 Q300 268 284 268 H96 Q80 268 80 252 V78 Q80 62 96 62 Z"
        p={ease(t, [0, 20], [0, 1])}
        stroke={T.text}
        w={3}
        fill={alpha(T.panel, 0.95)}
      />
      {Array.from({ length: grid * grid }, (_, n) => {
        const i = n % grid;
        const j = Math.floor(n / grid);
        const wave = 0.5 + 0.5 * Math.sin(t / 5 - (i + j) * 0.9);
        const on = ease(t, [12 + n, 24 + n], [0, 1]);
        return (
          <rect
            key={n}
            x={108 + i * 46}
            y={88 + j * 42}
            width={38}
            height={34}
            rx={6}
            fill={mix(T.bgAlt, T.hero, 0.15 + on * wave * 0.8)}
            stroke={T.lineSoft}
          />
        );
      })}
    </svg>
  );
};

/* ---- ৪. ছবি: ডিসপ্লে ---- */
const VisImage: React.FC<{ t: number; pivot: number }> = ({ t, pivot }) => {
  const cols = 20;
  const rows = 12;
  const cells = gridCells(cols, rows);
  const w = 316;
  const h = w / 1.6;
  const resolve = ease(t, [10, 44], [1, 0], theme.ease.inOut);
  const back = ease(pivot, [0, 16], [0, 1], theme.ease.in);
  const mosaic = Math.max(resolve, back);
  return (
    <div style={{ width: CW, height: 330, position: "relative" }}>
      <div
        style={{
          position: "absolute",
          left: 32,
          top: 40,
          width: w,
          height: h,
          borderRadius: 14,
          overflow: "hidden",
          border: `3px solid ${T.line}`,
          boxShadow: `0 0 ${Math.round(30 * (1 - mosaic))}px ${T.glowHero}`,
        }}
      >
        <WorldSVG w={w} id="disp" />
        <svg width={w} height={h} viewBox={`0 0 ${cols} ${rows}`} style={{ position: "absolute", left: 0, top: 0, opacity: mosaic }}>
          {cells.map((c) => (
            <rect key={`${c.i}-${c.j}`} x={c.i} y={c.j} width={1.02} height={1.02} fill={lumColor(c.lum)} />
          ))}
        </svg>
      </div>
      <div style={{ position: "absolute", left: 150, top: 40 + h + 14, width: 80, height: 8, borderRadius: 4, background: T.lineSoft }} />
    </div>
  );
};

const Card: React.FC<{
  i: number;
  title: string;
  children: (t: number) => React.ReactNode;
}> = ({ i, title, children }) => {
  const f = useCurrentFrame();
  const t = f - D[i];
  return (
    <div style={{ position: "absolute", left: cx(i), top: TOP }}>
      <Pop delay={D[i]} y={46} cfg={theme.spring.smooth}>
        <Glass style={{ width: CW, height: CH, overflow: "hidden" }}>
          <div style={{ marginTop: 10 }}>{children(t)}</div>
          <div
            style={{
              position: "absolute",
              bottom: 20,
              width: "100%",
              textAlign: "center",
              fontSize: 46,
              fontWeight: 700,
              lineHeight: 1.45,
              letterSpacing: 0,
              color: T.text,
            }}
          >
            {title}
          </div>
        </Glass>
      </Pop>
    </div>
  );
};

export const Pipeline: React.FC = () => {
  const f = useCurrentFrame();
  const arc = ease(f, [TIMER, TIMER + 26], [0, 1], theme.ease.inOut);
  const centers = D.map((_, i) => cx(i) + CW / 2);
  const fillX = ease(f, [D[0], D[1], D[2], D[3]], [centers[0], centers[1], centers[2], centers[3]], theme.ease.inOut);
  return (
    <SceneShell>
      {/* ১ সেকেন্ডেরও কম — টাইমার ব্যাজ */}
      <div style={{ position: "absolute", top: 54, width: "100%", display: "flex", justifyContent: "center" }}>
        <Pop delay={TIMER} y={24} cfg={theme.spring.snappy}>
          <div style={{ display: "flex", alignItems: "center", columnGap: 22 }}>
            <svg width={76} height={76} viewBox="-38 -38 76 76">
              <circle r={28} fill="none" stroke={T.lineSoft} strokeWidth={5} />
              <circle
                r={28}
                fill="none"
                stroke={T.hero}
                strokeWidth={5}
                strokeLinecap="round"
                pathLength={1}
                strokeDasharray="1 1"
                strokeDashoffset={1 - arc}
                transform="rotate(-90)"
              />
              <line x1={0} y1={0} x2={0} y2={-16} stroke={T.text} strokeWidth={4} strokeLinecap="round" transform={`rotate(${arc * 360})`} />
            </svg>
            <span style={{ fontSize: 58, fontWeight: 700, lineHeight: 1.4, letterSpacing: 0, color: T.text }}>
              ১ সেকেন্ডেরও কম
            </span>
          </div>
        </Pop>
      </div>

      <Card i={0} title="আলো ধরে">{(t) => <VisLens t={t} />}</Card>
      <Card i={1} title="বিদ্যুতে রূপান্তর">{(t) => <VisSensor t={t} />}</Card>
      <Card i={2} title="কোটি কোটি হিসাব">{(t) => <VisChip t={t} />}</Card>
      <Card i={3} title="পরিচিত ছবি">{(t) => <VisImage t={t} pivot={f - PIVOT} />}</Card>

      {/* কার্ডের মাঝের সংযোগ-তীর */}
      <svg width={1920} height={1080} style={{ position: "absolute", left: 0, top: 0, pointerEvents: "none" }}>
        {[0, 1, 2].map((i) => {
          const x1 = cx(i) + CW + 6;
          const x2 = cx(i + 1) - 6;
          const y = TOP + 175;
          const p = ease(f, [D[i + 1] - 10, D[i + 1] + 6], [0, 1]);
          return (
            <g key={i}>
              <Draw d={`M${x1} ${y} H${x2}`} p={p} stroke={T.hero} w={4} />
              <Draw d={`M${x2 - 12} ${y - 11} L${x2} ${y} L${x2 - 12} ${y + 11}`} p={p} stroke={T.hero} w={4} />
            </g>
          );
        })}
        {/* নিচের টাইমলাইন */}
        <line x1={X0 + CW / 2} x2={cx(3) + CW / 2} y1={880} y2={880} stroke={T.lineSoft} strokeWidth={5} strokeLinecap="round" />
        <line x1={centers[0]} x2={fillX} y1={880} y2={880} stroke={T.hero} strokeWidth={5} strokeLinecap="round" />
        {centers.map((x, i) => {
          const on = ease(f, [D[i] - 2, D[i] + 8], [0, 1]);
          return (
            <circle key={i} cx={x} cy={880} r={12 + on * 4} fill={mix(T.bg, T.hero, on)} stroke={on > 0.5 ? T.text : T.line} strokeWidth={3} />
          );
        })}
      </svg>
    </SceneShell>
  );
};
