import React from "react";
import { useCurrentFrame, useVideoConfig } from "remotion";
import { theme } from "../theme";
import { FullSvg, P, SceneShell, Sfx, Tag, Title, Win, lerp, sp } from "../fx";
import { Electron, Photon, PixelWell } from "../parts";
import { sceneTimes } from "../timeline";
import { cueEnd, cueStart, wordFrame } from "../srt";

const C = theme.colors;
const T0 = sceneTimes[4].from;
const t10 = cueStart(10) - T0;
const tEnd = cueEnd(10) - T0;
const tQ = wordFrame(10, "পার্থক্য", 8) - T0;

const Apple: React.FC<{ x: number; y: number; color: string; s?: number }> = ({ x, y, color, s = 1 }) => (
  <g transform={`translate(${x} ${y}) scale(${s})`}>
    <ellipse cx={0} cy={118} rx={110} ry={16} fill="#000" opacity={0.28} />
    <path
      d="M0 -62 C-30 -92 -110 -80 -112 0 C-114 82 -52 118 -22 108 C-10 104 10 104 22 108 C52 118 114 82 112 0 C110 -80 30 -92 0 -62 Z"
      fill={color}
    />
    <path d="M-66 -30 C-76 -2 -70 30 -54 52" fill="none" stroke="#fff" strokeWidth={9} strokeLinecap="round" opacity={0.28} />
    <path d="M0 -62 C2 -86 10 -104 24 -118" fill="none" stroke={C.textDim} strokeWidth={9} strokeLinecap="round" />
  </g>
);

export const S5Problem: React.FC = () => {
  const frame = useCurrentFrame();
  const { fps } = useVideoConfig();

  /* স্টেজ A: বিভিন্ন রঙের ফোটন → একই পিক্সেল → একই রকম ইলেকট্রন */
  const aO = P(frame, 4, 12) * (1 - P(frame, t10 - 4, 10, theme.ease.in));
  const levelA = P(frame, 14, t10 - 30, theme.ease.soft) * 0.75;
  const cols = [C.red, C.green, C.accent, C.text, C.primary];
  const rain = cols.map((col, i) => {
    const cyc = 40;
    const off = i * 8;
    const t = ((frame + off) % cyc) / cyc;
    const x = 840 + i * 60;
    const y = lerp(250, 470, theme.ease.in(Math.min(1, t / 0.8)));
    const o = t < 0.8 ? 1 : 1 - (t - 0.8) / 0.2;
    return <Photon key={i} x={x} y={y} rot={90} len={64} amp={8} phase={frame / 2.4 + i} o={o} color={col} scale={0.9} />;
  });

  /* স্টেজ B: লাল ও সবুজ আপেল, একই মাপের charge */
  const bO = P(frame, t10 - 2, 14);
  const pL = sp(frame, fps, t10 + 2, theme.spring.smooth);
  const pR = sp(frame, fps, t10 + 10, theme.spring.smooth);
  const gaugeFill = P(frame, t10 + 40, 60, theme.ease.soft) * 0.6;
  const qPop = sp(frame, fps, tQ, theme.spring.bouncy);
  const pulse = 1 + Math.sin(frame / 7) * 0.04;
  const rays = (cx: number, col: string, k: number) =>
    [0, 1, 2].map((i) => {
      const cyc = 46;
      const t = (((frame + i * 15 + k * 7) % cyc) / cyc);
      const y = lerp(470, 640, theme.ease.soft(t));
      const x = cx - 40 + i * 40;
      return <Photon key={`${k}-${i}`} x={x} y={y} rot={90} len={56} amp={7} color={col} phase={frame / 2.4 + i} o={Math.min(1, t * 6) * (1 - Math.max(0, (t - 0.85) / 0.15)) * bO} />;
    });

  return (
    <SceneShell>
      <Win from={0} to={t10 + 6}>
        <Title text="কিন্তু এখানেও একটা সমস্যা" top={70} delay={4} highlight={{ 3: C.accent, 4: C.accent }} />
      </Win>
      <Win from={t10 - 2} to={tEnd + 400}>
        <Title text="লাল আপেল বনাম সবুজ আপেল" top={70} delay={6} highlight={{ 0: C.red, 2: C.green }} />
      </Win>

      <FullSvg>
        {/* স্টেজ A */}
        <g opacity={aO}>
          <PixelWell x={810} y={480} w={300} h={400} level={levelA} cols={6} rows={9} />
          {rain}
        </g>
        {/* স্টেজ B */}
        <g opacity={bO}>
          <line x1={960} y1={250} x2={960} y2={960} stroke={C.panelLine} strokeWidth={3} strokeDasharray="6 14" />
          <g opacity={pL} transform={`translate(0 ${lerp(30, 0, pL)})`}>
            <Apple x={520} y={380} color={C.red} s={1.1} />
          </g>
          <g opacity={pR} transform={`translate(0 ${lerp(30, 0, pR)})`}>
            <Apple x={1400} y={380} color={C.green} s={1.1} />
          </g>
          {rays(520, C.red, 1)}
          {rays(1400, C.green, 2)}
          {[520, 1400].map((cx, k) => (
            <g key={k}>
              <rect x={cx - 220} y={700} width={440} height={56} rx={28} fill={C.panel} stroke={C.panelLine} strokeWidth={3} />
              <rect x={cx - 212} y={708} width={Math.max(0, 424 * gaugeFill)} height={40} rx={20} fill={C.primary} />
              <Electron x={cx - 212 + Math.max(20, 424 * gaugeFill) - 20} y={728} r={16} o={gaugeFill > 0.02 ? 1 : 0} glow={false} />
              <rect x={cx - 110} y={790} width={220} height={100} rx={18} fill="#8D93A3" opacity={gaugeFill > 0.02 ? 1 : 0} />
            </g>
          ))}
        </g>
      </FullSvg>

      {/* প্রশ্নচিহ্ন */}
      <Win from={tQ} to={tEnd + 400}>
        <div
          style={{
            position: "absolute",
            left: 960 - 80,
            top: 640 - 100,
            width: 160,
            height: 160,
            borderRadius: 80,
            background: C.accent,
            color: C.bg,
            fontFamily: theme.fonts.main,
            fontWeight: 700,
            fontSize: 120,
            lineHeight: "160px",
            textAlign: "center",
            transform: `scale(${qPop * pulse})`,
            boxShadow: `0 0 70px ${C.glowAccent}`,
          }}
        >
          ?
        </div>
      </Win>

      <Win from={30} to={t10 - 6}>
        <Tag x={1250} y={560} text="শুধু আলোর পরিমাণ" color={C.accent} delay={0} anchor="l" />
      </Win>
      <Win from={t10 + 50} to={tEnd + 400}>
        <Tag x={520} y={968} text="সমান charge?" color={C.text} delay={0} size={34} />
        <Tag x={1400} y={968} text="সমান charge?" color={C.text} delay={6} size={34} />
      </Win>

      <Sfx at={8} name="whoosh" vol={0.22} />
      <Sfx at={30} name="pop" vol={0.26} />
      <Sfx at={t10 + 2} name="pop" vol={0.26} rate={0.96} />
      <Sfx at={t10 + 10} name="pop" vol={0.26} rate={1.06} />
      <Sfx at={tQ} name="pop" vol={0.3} rate={0.9} />
    </SceneShell>
  );
};
