import React from "react";
import {theme} from "../theme";
import {clamp01} from "../ui";

// Shared sensor-face geometry (canvas coordinates at scale 1).
export const COLS = 24;
export const ROWS = 16;
export const CELL = 40;
export const FACE_W = COLS * CELL; // 960
export const FACE_H = ROWS * CELL; // 640
export const FACE_X = 480;
export const FACE_Y = 225;
export const cellCenter = (c: number, r: number) => ({
  x: FACE_X + (c + 0.5) * CELL,
  y: FACE_Y + (r + 0.5) * CELL,
});

export const AMBER_CELL = {c: 19, r: 7}; // "light-sensitive part" highlight
export const PATCH_CELL = {c: 12, r: 6}; // zoom focus for the light-intensity scene
export const PATCH_ZOOM = 6.72;
export const PATCH_TARGET = {x: 960, y: 640};

/** Procedural scene brightness (a sun disk over a sky): what the sensor "sees". */
export const lum = (c: number, r: number) => {
  const d = Math.hypot(c - 9.5, r - 6);
  const t = clamp01((d - 1.6) / 2.0);
  const ss = t * t * (3 - 2 * t);
  const sky = 0.12 + 0.06 * (1 - r / (ROWS - 1));
  const ground = r >= 11 ? -0.04 : 0;
  return clamp01(sky + ground + 0.8 * (1 - ss));
};

/** Pixel cell. Geometry is identical to <DenseGrid> at c=40 so swaps are invisible. */
export const Cell: React.FC<{
  c: number;
  r: number;
  fill?: number;
  scale?: number;
  opacity?: number;
  glow?: number;
}> = ({c, r, fill = 0, scale = 1, opacity = 1, glow = 0}) => {
  if (opacity <= 0.001) return null;
  const {x, y} = cellCenter(c, r);
  const l = lum(c, r);
  return (
    <g
      transform={`translate(${x} ${y}) scale(${scale}) translate(${-x} ${-y})`}
      opacity={opacity}
    >
      <rect
        x={x - 18}
        y={y - 18}
        width={36}
        height={36}
        rx={5}
        fill={theme.colors.cell}
        stroke={theme.colors.cellEdge}
        strokeWidth={1.5}
        vectorEffect="non-scaling-stroke"
      />
      {fill > 0 && (
        <rect
          x={x - 18}
          y={y - 18}
          width={36}
          height={36}
          rx={5}
          fill={`rgba(${theme.rgb.primary},${(fill * (0.1 + 0.82 * l)).toFixed(3)})`}
        />
      )}
      {glow > 0 && (
        <rect
          x={x - 18}
          y={y - 18}
          width={36}
          height={36}
          rx={5}
          fill={`rgba(${theme.rgb.text},${(glow * 0.4).toFixed(3)})`}
        />
      )}
    </g>
  );
};

export type CellFn = (c: number, r: number) => number;
export const GridCells: React.FC<{
  fill?: CellFn;
  scale?: CellFn;
  opacity?: CellFn;
  glow?: CellFn;
}> = ({fill, scale, opacity, glow}) => (
  <g>
    {Array.from({length: ROWS}).map((_, r) =>
      Array.from({length: COLS}).map((__, c) => (
        <Cell
          key={`${c}-${r}`}
          c={c}
          r={r}
          fill={fill ? fill(c, r) : 0}
          scale={scale ? scale(c, r) : 1}
          opacity={opacity ? opacity(c, r) : 1}
          glow={glow ? glow(c, r) : 0}
        />
      ))
    )}
  </g>
);

/** Same cells drawn as an SVG pattern, so cell size can shrink to "megapixel" density. */
export const DenseGrid: React.FC<{size: number}> = ({size}) => {
  const g = Math.max(0.5, size * 0.05);
  const sw = 0.6 + (0.9 * (size - 6)) / 34;
  return (
    <g>
      <defs>
        <pattern
          id="dense-cells"
          width={size}
          height={size}
          patternUnits="userSpaceOnUse"
          x={FACE_X}
          y={FACE_Y}
        >
          <rect
            x={g}
            y={g}
            width={size - 2 * g}
            height={size - 2 * g}
            rx={size * 0.125}
            fill={theme.colors.cell}
            stroke={theme.colors.cellEdge}
            strokeWidth={sw}
          />
        </pattern>
      </defs>
      <rect x={FACE_X} y={FACE_Y} width={FACE_W} height={FACE_H} fill="url(#dense-cells)" />
    </g>
  );
};

/** SVG group transform that zooms so focal point F lands on T at scale s. */
export const zoomTransform = (s: number, F: {x: number; y: number}, T: {x: number; y: number}) =>
  `translate(${T.x - s * F.x} ${T.y - s * F.y}) scale(${s})`;
