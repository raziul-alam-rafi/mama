// Tests every Remotion OpenGL backend in Remotion's own browser with a real three.js draw call.
// Saves the first working one to .glmode. Works on Windows CMD, PowerShell, macOS, Linux.
import fs from "node:fs";
import { run, mkdirOut, GLMODE_FILE } from "./lib.mjs";

mkdirOut();
let working = null;
for (const m of ["swangle", "angle-egl", "angle", "egl", "vulkan"]) {
  const log = `out/glprobe_${m}.log`;
  const r = run(`npx remotion still src/index.ts GlProbe out/glprobe_${m}.png --gl=${m} --log=verbose --overwrite`, { capture: true });
  fs.writeFileSync(log, r.out);
  const ok = r.status === 0 && /GLPROBE_RENDERER=/.test(r.out);
  if (ok) {
    console.log(`OK    --gl=${m}   ${(r.out.match(/GLPROBE_RENDERER=.*/) || [""])[0].trim()}`);
    if (!working) working = m;
  } else {
    const why = (r.out.split(/\r?\n/).find((l) => /GLPROBE_FAILED|webgl|error/i.test(l)) || "(see log)").trim().slice(0, 160);
    console.log(`FAIL  --gl=${m}   ${why}`);
  }
}
if (!working) {
  console.log("\nNo GL backend worked. Send me all out/glprobe_*.log files and the output of:\n  npx remotion versions\n  npx remotion browser ensure");
  process.exit(1);
}
fs.writeFileSync(GLMODE_FILE, working + "\n");
console.log(`\nSelected: --gl=${working} (saved to ${GLMODE_FILE})`);
