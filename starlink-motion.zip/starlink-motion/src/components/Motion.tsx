import React from "react";
import { interpolate, spring, useCurrentFrame, useVideoConfig } from "remotion";
import { theme } from "../theme";

export const CL = { extrapolateLeft: "clamp", extrapolateRight: "clamp" } as const;

type SpringCfg = { damping: number; stiffness: number; mass: number };

export const useSpringP = (delay = 0, config: SpringCfg = theme.spring.smooth) => {
  const frame = useCurrentFrame();
  const { fps } = useVideoConfig();
  return spring({ frame: frame - delay, fps, config });
};

/** Premium entrance: opacity + translate + scale together, driven by a spring. */
export const Entrance: React.FC<{
  delay?: number;
  x?: number;
  y?: number;
  scaleFrom?: number;
  config?: SpringCfg;
  style?: React.CSSProperties;
  children?: React.ReactNode;
}> = ({ delay = 0, x = 0, y = 40, scaleFrom = 0.94, config = theme.spring.smooth, style, children }) => {
  const p = useSpringP(delay, config);
  return (
    <div
      style={{
        opacity: Math.min(1, Math.max(0, p)),
        transform: `translate(${interpolate(p, [0, 1], [x, 0])}px, ${interpolate(p, [0, 1], [y, 0])}px) scale(${interpolate(
          p,
          [0, 1],
          [scaleFrom, 1]
        )})`,
        ...style,
      }}
    >
      {children}
    </div>
  );
};

/** Content that leaves at frame `to` with a quick exit (faster than the entrance). */
export const TimedBlock: React.FC<{ to: number; style?: React.CSSProperties; children?: React.ReactNode }> = ({
  to,
  style,
  children,
}) => {
  const frame = useCurrentFrame();
  const { fps } = useVideoConfig();
  const exitF = Math.round(fps * 0.3);
  if (frame >= to) return null;
  const ex = interpolate(frame, [to - exitF, to], [0, 1], { easing: theme.ease.in, ...CL });
  return (
    <div style={{ opacity: 1 - ex, transform: `translateY(${-34 * ex}px)`, ...style }}>{children}</div>
  );
};
