#!/usr/bin/env sh
# Final 1080p render. Usage: sh scripts/render.sh   (4K: sh scripts/render.sh 4k)
cd "$(dirname "$0")/.." || exit 1
if [ "$1" = "4k" ]; then
  npx remotion render src/index.ts Main output/TechBeatInside_4K.mp4 --scale=2
else
  npx remotion render src/index.ts Main output/TechBeatInside_1080p.mp4
fi
