// Scene 6 (cues 12-14) — RECAP: not just one photo, but a flood of light data refined into a picture; the smartphone goes one step further.
import React from "react";
import { AbsoluteFill } from "remotion";
import { theme } from "../theme";
import { T } from "../timing";
import { bayerCh, stageCanvas } from "../sceneImage";
import { clamp, hash, hexToRgb, lerp, prog, progIO, rgbCss } from "../util";
import { Defs } from "../components/Defs";
import { ChipGlyph, PhoneGlyph } from "../components/Glyphs";
import { CanvasView } from "../components/CanvasView";
import { useClock, popAt } from "../components/clock";

const rowX = (i: number) => 260 + 350 * i;
const stairX = (i: number) => 300 + 290 * i;
const stairY = (i: number) => 740 - 76 * i;
const NODE = 150;
const labels = ["Sensor", "ADC", "Demosaicing", "Processor", "Photo", "Smartphone"];

export const Scene6: React.FC = () => {
  const { f, fps, at } = useClock();
  const c = theme.colors;

  const tPhoto = 4;
  const tShrink = at(T("বরং"), 6);
  const tFlood = at(T("বিপুল"), 4);
  const tRecv = at(T("ব্যবহারযোগ্য"), 4);
  const tStair = at(T("আধুনিক"), 4);
  const tPhone = at(T("Smartphone"), 8);
  const tStep = at(T("আরও এক ধাপ"), 4);

  const s = progIO(f, tStair, tStair + 44);
  const tick = (n: number) => tRecv + n * 15;

  const nodeIn = (i: number) => popAt(f, fps, tShrink + 4 + i * 4, theme.spring.snappy);
  const phoneIn = popAt(f, fps, tPhone, theme.spring.bouncy);
  const rise = progIO(f, tStep, tStep + 30);
  const pos = (i: number): [number, number] => {
    if (i === 5) {
      const y = lerp(stairY(4), stairY(5), rise);
      return [stairX(5), y];
    }
    return [lerp(rowX(i), stairX(i), s), lerp(540, stairY(i), s)];
  };
  const count = f >= tPhone ? 6 : 5;
  const pulse = 0.5 + 0.5 * Math.sin(f / 7);

  // photo card: big at the start, then it becomes the last node
  const toNode = progIO(f, tShrink, tShrink + 30);
  const [p4x, p4y] = pos(4);
  const photoIn = popAt(f, fps, tPhoto, theme.spring.smooth);
  const bigX = 960, bigY = 520;
  const scaleBig = 1, scaleNode = (NODE - 16) / 640;
  const phX = lerp(bigX, p4x, toNode), phY = lerp(bigY, p4y, toNode);
  const phS = lerp(scaleBig, scaleNode, toNode);
  const photoGlow = prog(f, tick(4), tick(4) + 14);

  // data flood
  const particles: React.ReactNode[] = [];
  const N = 240;
  for (let i = 0; i < N; i++) {
    const start = tFlood + hash(i * 1.37) * 96;
    const dur = 62 + hash(i * 2.1) * 40;
    const t = (f - start) / dur;
    if (t < 0 || t > 1) continue;
    const laneY = 540 + (hash(i * 3.3) * 2 - 1) * 300;
    const e = theme.ease.inOut(t);
    const x = lerp(-40, rowX(0) - 20, e);
    const y = lerp(laneY, 540 + (hash(i * 5.1) - 0.5) * 70, Math.pow(e, 1.6));
    const sz = 8 + hash(i * 7.7) * 9;
    const fade = 1 - prog(t, 0.88, 1);
    particles.push(<rect key={i} x={x - sz / 2} y={y - sz / 2} width={sz} height={sz} rx={3} fill={hash(i * 9.1) > 0.7 ? c.primary : c.accent} opacity={0.9 * fade} transform={`rotate(${t * 180 * (hash(i) - 0.5)} ${x} ${y})`} />);
  }
  const g0 = prog(f, tFlood + 30, tFlood + 100);

  const iconFor = (i: number) => {
    if (i === 0)
      return (
        <g transform="translate(-52 -34)">
          {Array.from({ length: 12 }).map((_, k) => {
            const col = k % 4, row = Math.floor(k / 4);
            const lv = 0.3 + hash(k * 3.1) * 0.65;
            return (
              <g key={k} transform={`translate(${col * 27} ${row * 27})`}>
                <rect width={23} height={23} rx={5} fill={c.bg} stroke={c.line} strokeWidth={1.5} />
                <rect y={23 - 21 * lv * (0.4 + 0.6 * g0)} x={2} width={19} height={21 * lv * (0.4 + 0.6 * g0)} rx={3} fill="url(#gAmber)" />
              </g>
            );
          })}
        </g>
      );
    if (i === 1)
      return (
        <g>
          {["0110", "1011", "0101"].map((b, k) => <text key={k} x={0} y={-24 + k * 34} textAnchor="middle" fontFamily={theme.fonts.main} fontWeight={700} fontSize={30} fill={c.primary}>{b}</text>)}
        </g>
      );
    if (i === 2)
      return (
        <g transform="translate(-48 -48)">
          {Array.from({ length: 16 }).map((_, k) => {
            const col = k % 4, row = Math.floor(k / 4);
            return <rect key={k} x={col * 25} y={row * 25} width={22} height={22} rx={4} fill={rgbCss(hexToRgb([c.chR, c.chG, c.chB][bayerCh(row, col)]))} opacity={0.9} />;
          })}
        </g>
      );
    if (i === 3) return <g transform="scale(0.62)"><ChipGlyph size={110} glow={0.5 + 0.4 * pulse} act={f} pins={3} /></g>;
    if (i === 5) return <PhoneGlyph s={0.62} color={c.text} glow={0.6 * rise + 0.3} />;
    return null;
  };

  // connectors (elbows) between consecutive nodes
  const links: React.ReactNode[] = [];
  for (let i = 0; i < count - 1; i++) {
    const [x1, y1] = pos(i), [x2, y2] = pos(i + 1);
    const mid = (x1 + x2) / 2;
    const d = `M${x1 + NODE / 2} ${y1} H${mid} V${y2} H${x2 - NODE / 2}`;
    const lit = i < 4 ? prog(f, tick(i), tick(i + 1) - 2) : i === 4 ? phoneIn * (1 - 0.0) : 0;
    const vis = i < 4 ? nodeIn(i + 1) : phoneIn;
    links.push(
      <g key={i} opacity={vis}>
        <path d={d} fill="none" stroke={c.line} strokeWidth={6} strokeLinecap="round" strokeLinejoin="round" />
        <path d={d} fill="none" stroke={i === 4 ? c.accent : c.primary} strokeWidth={6} strokeLinecap="round" strokeLinejoin="round" pathLength={1} strokeDasharray={1} strokeDashoffset={1 - lit} filter="url(#fGlow)" />
      </g>,
    );
  }

  return (
    <AbsoluteFill>
      <svg width="1920" height="1080" style={{ position: "absolute", inset: 0 }}>
        <Defs />
        {links}
        {Array.from({ length: count }).map((_, i) => {
          if (i === 4) return null; // drawn as the HTML photo
          const [x, y] = pos(i);
          const vis = i === 5 ? phoneIn : nodeIn(i);
          const tk = i < 4 ? prog(f, tick(i), tick(i) + 10) : 0;
          const isPhone = i === 5;
          return (
            <g key={i} transform={`translate(${x} ${y}) scale(${0.7 + 0.3 * vis})`} opacity={Math.min(1, vis * 1.5)}>
              {isPhone && <rect x={-NODE / 2 - 14} y={-NODE / 2 - 14} width={NODE + 28} height={NODE + 28} rx={34} fill={c.accent} opacity={0.22 + 0.15 * pulse} filter="url(#fSoftGlow)" />}
              <rect x={-NODE / 2} y={-NODE / 2} width={NODE} height={NODE} rx={26} fill="url(#gPanel)" stroke={isPhone ? c.accent : tk > 0.5 ? c.primary : c.line} strokeWidth={isPhone ? 4 : 3} filter="url(#fShadow)" />
              <rect x={-NODE / 2} y={-NODE / 2} width={NODE} height={NODE} rx={26} fill="url(#gSheen)" />
              {iconFor(i)}
              {i < 4 && tk > 0.05 && (
                <g transform={`translate(${NODE / 2 - 6} ${-NODE / 2 + 6}) scale(${tk})`}>
                  <circle r={19} fill={c.ok} stroke={c.bg} strokeWidth={4} />
                  <path d="M-8 0 l6 6 l11 -12" fill="none" stroke={c.bg} strokeWidth={4.5} strokeLinecap="round" strokeLinejoin="round" />
                </g>
              )}
              <text y={NODE / 2 + 44} textAnchor="middle" fontFamily={theme.fonts.main} fontWeight={600} fontSize={isPhone ? 32 : 28} fill={isPhone ? c.accent : c.text}>{labels[i]}</text>
            </g>
          );
        })}
        {/* photo node label */}
        <text x={p4x} y={p4y + 84 / 2 + 44} textAnchor="middle" fontFamily={theme.fonts.main} fontWeight={600} fontSize={28} fill={c.text} opacity={toNode}>{labels[4]}</text>
        {f >= tFlood - 4 && particles}
        {/* "+1 step" tag */}
        {(() => {
          const [x, y] = pos(5);
          const p = prog(f, tStep + 8, tStep + 28);
          return (
            <g opacity={p} transform={`translate(${x - 85} ${y - NODE / 2 - 92 + (1 - p) * 14})`}>
              <rect width={170} height={54} rx={27} fill={c.bg} stroke={c.accent} strokeWidth={3} />
              <path d="M30 38 V16 M20 26 L30 15 L40 26" fill="none" stroke={c.accent} strokeWidth={4.5} strokeLinecap="round" strokeLinejoin="round" />
              <text x={56} y={37} fontFamily={theme.fonts.main} fontWeight={700} fontSize={30} fill={c.text}>+১ ধাপ</text>
            </g>
          );
        })()}
      </svg>

      {/* the finished photo: big hero, then the last pipeline node */}
      <div style={{ position: "absolute", left: 0, top: 0, width: 640, height: 360, transform: `translate(${phX - 320}px, ${phY - 180}px) scale(${phS})`, transformOrigin: "50% 50%", opacity: Math.min(1, photoIn * 1.4), borderRadius: 26 / phS * (NODE / 150), overflow: "hidden", boxShadow: `0 30px 80px -20px rgba(0,0,0,0.7), 0 0 0 ${3 / phS}px ${photoGlow > 0.3 ? c.primary : c.line}, 0 0 ${60 * photoGlow}px ${c.primary}77` }}>
        <CanvasView source={stageCanvas(6)} width={640} height={360} />
      </div>
    </AbsoluteFill>
  );
};
