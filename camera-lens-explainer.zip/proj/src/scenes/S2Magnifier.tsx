import React from "react";
import {AbsoluteFill, spring, useCurrentFrame, useVideoConfig} from "remotion";
import {theme} from "../theme";
import {at} from "../timeline";
import {Elem, LensShape, Ray, SvgDefs, traceRay} from "../components/Optics";
import {MagnifierIcon} from "../components/Art";
import {Entrance, Headlines} from "../components/Text";
import {Sfx} from "../components/Sfx";
import {breathe, prog} from "../components/util";

const SI = 1;
const AX = 640;
const LX = 820;
const F = 420;
const HEIGHTS = [-150, -100, -50, 0, 50, 100, 150];
const X_END = 1760;

/** Scene 2 — a magnifying glass: parallel light runs straight; the glass drops in and the paths bend. */
export const S2Magnifier: React.FC = () => {
  const frame = useCurrentFrame();
  const {fps} = useVideoConfig();

  const tG = at(SI, 2, "Magnifying");
  const tBend = at(SI, 3, "গতিপথ");
  const end = at(SI, 3) + 400;

  const rayIn = HEIGHTS.map((_, i) => prog(frame, 8 + i * 3, 40, theme.ease.inOut));
  const drop = spring({frame: frame - tG, fps, config: theme.spring.bouncy});
  const glassY = (1 - drop) * -420 + breathe(frame, 3, 30) * drop;
  const b = drop; // the glass is the CAUSE: bending strength follows its arrival
  const focusP = prog(frame, tG + 22, 16);

  const elems: Elem[] = [{x: LX, power: b / F, kind: "convex", h: 190, w: 36}];

  return (
    <AbsoluteFill>
      <svg width={1920} height={1080} viewBox="0 0 1920 1080" style={{position: "absolute", inset: 0}}>
        <SvgDefs />
        <line x1={0} x2={1920} y1={AX} y2={AX} stroke={theme.colors.panelEdge} strokeWidth={2} strokeDasharray="14 12" />

        {/* ghost of the straight, un-bent path (stays after the glass arrives) */}
        {drop > 0.05 && HEIGHTS.map((h, i) => (
          <line key={i} x1={LX} x2={X_END} y1={AX + h} y2={AX + h} stroke={theme.colors.textDim} strokeWidth={2}
            strokeDasharray="8 10" opacity={0.35 * Math.min(1, drop)} />
        ))}

        {/* light rays: pass LEFT of the lens straight, then bend by the lens power */}
        {HEIGHTS.map((h, i) => (
          <Ray key={i} pts={traceRay(h, 0, 0, elems, X_END, AX)} p={rayIn[i]} flow />
        ))}

        {/* magnifying glass (side view): lens, rim caps, handle */}
        <g transform={`translate(0 ${glassY})`}>
          <rect x={LX - 20} y={AX + 190} width={40} height={250} rx={18} fill={theme.colors.trunk} />
          <rect x={LX - 26} y={AX + 184} width={52} height={22} rx={8} fill={theme.colors.panelEdge} />
          <rect x={LX - 26} y={AX - 206} width={52} height={22} rx={8} fill={theme.colors.panelEdge} />
          <LensShape x={LX} cy={AX} h={190} w={36} kind="convex" />
        </g>

        {/* the bundle converges on one bright spot */}
        <g opacity={focusP}>
          <g filter="url(#glow)">
            <circle cx={LX + F} cy={AX} r={14} fill={theme.colors.accent} />
          </g>
        </g>

      </svg>

      <Headlines
        items={[
          {words: ["আলোর", "পথ"], from: 4, to: Math.max(tG - 2, 30)},
          {words: [{t: "Magnifying Glass", color: theme.colors.accent}], from: Math.max(tG - 2, 30), to: tBend - 2},
          {words: ["আলোর", {t: "গতিপথ", color: theme.colors.accent}, "পরিবর্তন"], from: tBend - 2, to: end},
        ]}
        size={92}
      />
      <Entrance delay={tG + 6} y={30} style={{position: "absolute", left: 1500, top: 190}}>
        <svg width={240} height={240} viewBox="-70 -70 240 240"><SvgDefs /><MagnifierIcon x={20} y={20} s={1.15} /></svg>
      </Entrance>
      <Sfx at={10} name="whoosh" vol={0.5} />
      <Sfx at={tG} name="pop" />
      <Sfx at={tBend} name="click" />
      <Sfx at={tG + 24} name="chime" />
    </AbsoluteFill>
  );
};
