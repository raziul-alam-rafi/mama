// SRT -> src/script.ts  (চালান: node scripts/gen-cues.mjs)
import fs from "node:fs";
const srt = fs.readFileSync(new URL("../public/voiceover.srt", import.meta.url), "utf8").replace(/\r/g, "");
const toSec = (t) => { const [h, m, r] = t.split(":"); const [s, ms] = r.split(","); return +h * 3600 + +m * 60 + +s + +ms / 1000; };
const cues = srt.trim().split(/\n\n+/).map((b) => {
  const l = b.split("\n"); const [a, z] = l[1].split(" --> ");
  return { n: +l[0], start: toSec(a.trim()), end: toSec(z.trim()), text: l.slice(2).join(" ").replace(/\s+/g, " ").trim() };
});
const out = `// AUTO-GENERATED from public/voiceover.srt by scripts/gen-cues.mjs — সময় শুধু SRT থেকে
export type Cue = { n: number; start: number; end: number; text: string };
export const CUES: Cue[] = ${JSON.stringify(cues, null, 2)};
`;
fs.writeFileSync(new URL("../src/script.ts", import.meta.url), out);
console.log("cues:", cues.length, "end:", cues.at(-1).end);
