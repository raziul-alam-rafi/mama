import React from "react";
import { useCurrentFrame } from "remotion";
import { theme } from "../theme";
import { clamp01 } from "./Motion";
import { partial, toPts, Pt } from "./optics";
import { shutterEdges } from "./ShutterFront";

const L = 150, XC = 700, XFILM = 772;
const YF = [-150, 0, 150];
const HS = [-84, 0, 84];

/** Old film camera, side cutaway (simplified schematic): lens → focal-plane shutter (two curtains) → film. */
export const FilmCamera: React.FC<{
  width: number; p1: number; p2: number; prog?: number; assemble?: number; uid?: string; latent?: boolean;
}> = ({ width, p1, p2, prog = 1, assemble = 1, uid = "fc", latent = true }) => {
  const frame = useCurrentFrame();
  const [e1, e2] = shutterEdges(p1, p2);
  const open = e2 > e1;
  const VB = { x: -250, y: -360, w: 1590, h: 720 };
  const a = clamp01(assemble);
  const inv = 1 - a;
  const flow = -(frame * 7);

  const rays = YF.flatMap((yf) =>
    HS.map((h) => {
      const m = yf / (XFILM - L);
      const yc = h + (yf - h) * ((XC - L) / (XFILM - L));
      const pass = open && yc >= e1 && yc <= e2;
      const start: Pt = [L - 190, h - 190 * m];
      const path: Pt[] = pass ? [start, [L, h], [XFILM, yf]] : [start, [L, h], [XC - 8, yc]];
      return { pass, path, yc };
    }),
  );
  // rays only exist when an object/scene is lit: always flowing, but gated by curtains
  const revealY = Math.min(190, Math.max(-190, e1)); // latent image: rows already reached by the slit
  const exposedH = latent ? Math.max(0, 190 - revealY) : 0;

  return (
    <svg width={width} height={(width * VB.h) / VB.w} viewBox={`${VB.x} ${VB.y} ${VB.w} ${VB.h}`} style={{ overflow: "visible" }}>
      <defs>
        <linearGradient id={`${uid}-metal`} x1="0" y1="0" x2="1" y2="0">
          <stop offset="0" stopColor={theme.colors.metalDark} />
          <stop offset="0.5" stopColor={theme.colors.metal} />
          <stop offset="1" stopColor={theme.colors.metalDark} />
        </linearGradient>
        <linearGradient id={`${uid}-glass`} x1="0" y1="0" x2="1" y2="1">
          <stop offset="0" stopColor={theme.colors.primarySoft} stopOpacity="0.85" />
          <stop offset="1" stopColor={theme.colors.primaryDeep} stopOpacity="0.75" />
        </linearGradient>
        <linearGradient id={`${uid}-body`} x1="0" y1="0" x2="0" y2="1">
          <stop offset="0" stopColor={theme.colors.panelHi} />
          <stop offset="1" stopColor={theme.colors.panel} />
        </linearGradient>
        <linearGradient id={`${uid}-sky`} x1="0" y1="0" x2="0" y2="1">
          <stop offset="0" stopColor={theme.colors.accentSoft} />
          <stop offset="1" stopColor={theme.colors.light} />
        </linearGradient>
        <clipPath id={`${uid}-latent`}>
          <rect x={980} y={revealY} width={250} height={exposedH} />
        </clipPath>
        <pattern id={`${uid}-hatch`} width="9" height="9" patternUnits="userSpaceOnUse" patternTransform="rotate(45)">
          <line x1="0" y1="0" x2="0" y2="9" stroke={theme.colors.metalDark} strokeWidth="2.5" />
        </pattern>
      </defs>

      {/* subject (distant scene lit by the sun) */}
      <g opacity={a} transform="translate(-170,30)">
        <rect x={-8} y={20} width={16} height={72} rx={4} fill={theme.colors.metalDark} />
        <circle cx={0} cy={-14} r={44} fill={theme.colors.signal} opacity={0.88} />
        <circle cx={-28} cy={14} r={29} fill={theme.colors.signal} opacity={0.72} />
        <circle cx={30} cy={12} r={31} fill={theme.colors.signal} opacity={0.78} />
      </g>

      {/* body */}
      <g transform={`translate(0,${-40 * inv})`} opacity={a}>
        <rect x={320} y={-318} width={560} height={636} rx={44} fill={`url(#${uid}-body)`} stroke={theme.colors.line} strokeWidth={4} />
        <rect x={334} y={-304} width={532} height={608} rx={34} fill={theme.colors.bg} opacity={0.92} />
        <rect x={320} y={-318} width={16} height={636} fill={`url(#${uid}-hatch)`} opacity={0.35} />
      </g>

      {/* lens */}
      <g transform={`translate(${-220 * inv},0)`} opacity={a}>
        <rect x={20} y={-176} width={320} height={352} rx={22} fill={theme.colors.bgAlt} stroke={theme.colors.metalDark} strokeWidth={4} />
        <path d="M128 -150 Q82 0 128 150 L152 150 Q198 0 152 -150 Z" fill={`url(#${uid}-glass)`} stroke={theme.colors.primarySoft} strokeWidth={3} />
        <path d="M232 -128 Q212 0 232 128 L248 128 Q270 0 248 -128 Z" fill={`url(#${uid}-glass)`} stroke={theme.colors.primarySoft} strokeWidth={2.5} opacity={0.9} />
      </g>

      {/* film: spools + strip */}
      <g transform={`translate(${220 * inv},0)`} opacity={a}>
        <rect x={XFILM - 11} y={-262} width={22} height={524} fill={theme.colors.metalDark} opacity={0.9} />
        {Array.from({ length: 25 }).map((_, i) => (
          <g key={i}>
            <rect x={XFILM - 8} y={-250 + i * 21} width={5} height={9} rx={2} fill={theme.colors.bg} />
            <rect x={XFILM + 3} y={-250 + i * 21} width={5} height={9} rx={2} fill={theme.colors.bg} />
          </g>
        ))}
        <rect x={XFILM - 16} y={-190} width={32} height={380} rx={4} fill="none" stroke={theme.colors.accent} strokeWidth={3.5} />
        {[-262, 262].map((y) => (
          <g key={y}>
            <circle cx={XFILM} cy={y} r={42} fill={theme.colors.panelHi} stroke={theme.colors.metal} strokeWidth={4} />
            <circle cx={XFILM} cy={y} r={11} fill={theme.colors.metal} />
          </g>
        ))}
      </g>

      {/* curtains */}
      <g opacity={a}>
        <rect x={XC - 7} y={-190} width={14} height={Math.max(0, Math.min(380, e1 + 190))} fill={`url(#${uid}-metal)`} stroke={theme.colors.bgAlt} strokeWidth={1.5} />
        <rect x={XC - 7} y={Math.max(-190, e2)} width={14} height={Math.max(0, 190 - Math.max(-190, e2))} fill={`url(#${uid}-metal)`} stroke={theme.colors.bgAlt} strokeWidth={1.5} />
        <rect x={XC - 7} y={-200} width={14} height={10} fill={theme.colors.metalDark} />
        <rect x={XC - 7} y={190} width={14} height={10} fill={theme.colors.metalDark} />
      </g>

      {/* rays */}
      {a > 0.95 &&
        rays.map((r, i) => {
          const p = partial(r.path, prog);
          return (
            <g key={i}>
              <polyline points={toPts(p)} fill="none" stroke={theme.colors.light} strokeWidth={3} strokeOpacity={r.pass ? 0.4 : 0.22} strokeLinecap="round" strokeLinejoin="round" />
              <polyline points={toPts(p)} fill="none" stroke={theme.colors.light} strokeWidth={4.5} strokeOpacity={r.pass ? 1 : 0.5} strokeDasharray="14 30" strokeDashoffset={flow - i * 5} strokeLinecap="round" strokeLinejoin="round" />
              {!r.pass && <circle cx={r.path[2][0]} cy={r.path[2][1]} r={4.5} fill={theme.colors.accent} opacity={0.85} />}
            </g>
          );
        })}

      {/* exposed film frame inset (front view of the film frame) */}
      <g opacity={a}>
        <line x1={XFILM + 20} y1={0} x2={966} y2={0} stroke={theme.colors.metalDark} strokeWidth={3} strokeDasharray="6 10" />
        <rect x={970} y={-200} width={270} height={400} rx={14} fill={theme.colors.bgAlt} stroke={theme.colors.line} strokeWidth={4} />
        <rect x={980} y={-190} width={250} height={380} rx={8} fill={theme.colors.panel} />
        <g clipPath={`url(#${uid}-latent)`}>
          <rect x={980} y={-190} width={250} height={380} fill={`url(#${uid}-sky)`} opacity={0.95} />
          {/* image is upside-down on film: tree inverted */}
          <g transform="translate(1105,10) scale(1,-1)">
            <rect x={-8} y={8} width={16} height={70} rx={4} fill={theme.colors.metalDark} />
            <circle cx={0} cy={-18} r={44} fill={theme.colors.signal} opacity={0.9} />
            <circle cx={-28} cy={10} r={28} fill={theme.colors.signal} opacity={0.75} />
            <circle cx={30} cy={8} r={30} fill={theme.colors.signal} opacity={0.8} />
          </g>
        </g>
        <rect x={980} y={-190} width={250} height={380} rx={8} fill="none" stroke={theme.colors.accent} strokeWidth={3} opacity={0.9} />
        {open && <line x1={980} x2={1230} y1={revealY} y2={revealY} stroke={theme.colors.accentSoft} strokeWidth={4} />}
      </g>
    </svg>
  );
};
