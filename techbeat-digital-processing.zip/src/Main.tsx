import React from "react";
import { AbsoluteFill, Sequence } from "remotion";
import { SCENES, SceneId } from "./timing";
import { BgMesh, Grade, Grain, Vignette } from "./components/Backdrop";
import { SceneShell } from "./components/SceneShell";
import { StageRail } from "./components/StageRail";
import { PreviewAudio } from "./components/PreviewAudio";
import { SfxLayer } from "./components/Sfx";
import { Scene1 } from "./scenes/Scene1";
import { Scene2 } from "./scenes/Scene2";
import { Scene3 } from "./scenes/Scene3";
import { Scene4 } from "./scenes/Scene4";
import { Scene5 } from "./scenes/Scene5";
import { Scene6 } from "./scenes/Scene6";

const COMPONENTS: Record<SceneId, React.FC> = { s1: Scene1, s2: Scene2, s3: Scene3, s4: Scene4, s5: Scene5, s6: Scene6 };

export const Main: React.FC = () => (
  <AbsoluteFill>
    {/* layer 1: background mesh */}
    <BgMesh />
    {/* layers 2-3: assets + graphics, one Sequence per scene */}
    {SCENES.map((s) => {
      const C = COMPONENTS[s.id];
      return (
        <Sequence key={s.id} from={s.from} durationInFrames={s.duration} name={s.id}>
          <SceneShell from={s.from} exit={!s.last}>
            <C />
          </SceneShell>
        </Sequence>
      );
    })}
    <StageRail />
    {/* layers 4-5: grade, grain, vignette */}
    <Grade />
    <Grain />
    <Vignette />
    {/* audio */}
    <PreviewAudio />
    <SfxLayer />
  </AbsoluteFill>
);
