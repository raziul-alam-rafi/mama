import React from "react";
import { Composition } from "remotion";
import { ApertureScene } from "./scenes/ApertureScene";
import { VIDEO } from "./config";

export const RemotionRoot: React.FC = () => (
  <Composition
    id={VIDEO.id}
    component={ApertureScene}
    durationInFrames={VIDEO.durationInFrames}
    fps={VIDEO.fps}
    width={VIDEO.width}
    height={VIDEO.height}
  />
);
