import React, {useLayoutEffect, useMemo} from 'react';
import * as THREE from 'three';
import {LIGHT} from '../../config/theme';
import {drawCricket} from '../materials/broadcastPicture';
import {newCanvasTexture, woodTexture} from '../materials/textures';
import {RBox} from './parts';

type V3 = [number, number, number];

/**
 * Consumer CRT television (wood-cabinet, 4:3 tube, rear taper where the tube neck lives).
 * Local origin: bottom-centre of the cabinet, screen facing +Z.
 * Named meshes follow the component list in research/component-reference.md.
 */
export const CrtTv: React.FC<{position: V3; frame: number; on?: boolean}> = ({position, frame, on = true}) => {
  const screen = useMemo(() => newCanvasTexture(512, 384), []);
  const screenGeo = useMemo(() => {
    const g = new THREE.PlaneGeometry(0.5, 0.38, 28, 22);
    const p = g.attributes.position;
    for (let i = 0; i < p.count; i++) {
      const x = p.getX(i) / 0.25;
      const y = p.getY(i) / 0.19;
      p.setZ(i, 0.028 * (1 - x * x * 0.8) * (1 - y * y * 0.8)); // convex CRT faceplate
    }
    g.computeVertexNormals();
    return g;
  }, []);

  useLayoutEffect(() => {
    if (on) drawCricket(screen.ctx, 512, 384, frame, true);
    else {
      screen.ctx.fillStyle = '#0b0f0c';
      screen.ctx.fillRect(0, 0, 512, 384);
    }
    screen.texture.needsUpdate = true;
  });

  const tex = woodTexture('#6b4426', 3);
  const flick = 1 + 0.12 * Math.sin(frame * 0.9) + 0.05 * Math.sin(frame * 2.3);
  const SX = -0.09;

  return (
    <group position={position} name="Television_Cabinet">
      {/* front cabinet */}
      <RBox size={[0.8, 0.64, 0.3]} radius={0.03} position={[0, 0.34, 0.15]} name="Cabinet_Front">
        <meshStandardMaterial map={tex} color="#9a7048" roughness={0.55} metalness={0} />
      </RBox>
      {/* tapered rear housing (tube bell) */}
      <RBox size={[0.66, 0.5, 0.36]} radius={0.04} position={[0, 0.31, -0.18]} name="Cabinet_Rear">
        <meshStandardMaterial color="#1a1a1c" roughness={0.7} />
      </RBox>
      {/* neck housing + yoke bump at the very back */}
      <mesh position={[SX * 0.4, 0.34, -0.4]} rotation={[Math.PI / 2, 0, 0]} name="Deflection_Yoke_Housing">
        <cylinderGeometry args={[0.07, 0.09, 0.1, 24]} />
        <meshStandardMaterial color="#111" roughness={0.6} />
      </mesh>
      {/* bezel */}
      <RBox size={[0.57, 0.45, 0.02]} radius={0.015} position={[SX, 0.34, 0.305]} name="Front_Bezel">
        <meshStandardMaterial color="#0d0d0e" roughness={0.35} metalness={0.1} />
      </RBox>
      {/* phosphor screen (emissive picture) */}
      <mesh geometry={screenGeo} position={[SX, 0.34, 0.31]} name="Phosphor_Screen">
        <meshBasicMaterial map={screen.texture} toneMapped={false} />
      </mesh>
      {/* front glass reflection layer */}
      <mesh geometry={screenGeo} position={[SX, 0.34, 0.3125]} name="CRT_Glass_Envelope">
        <meshPhysicalMaterial
          color="#ffffff"
          transparent
          opacity={0.1}
          roughness={0.04}
          metalness={0}
          clearcoat={1}
          clearcoatRoughness={0.05}
          depthWrite={false}
        />
      </mesh>
      {/* control panel */}
      <RBox size={[0.15, 0.5, 0.012]} radius={0.006} position={[0.29, 0.34, 0.304]}>
        <meshStandardMaterial color="#2a2118" roughness={0.5} metalness={0.2} />
      </RBox>
      {[0.5, 0.4].map((y, i) => (
        <group key={i} position={[0.29, y, 0.31]} rotation={[Math.PI / 2, 0, 0]}>
          <mesh>
            <cylinderGeometry args={[0.032, 0.036, 0.03, 28]} />
            <meshStandardMaterial color="#cfc8b8" roughness={0.3} metalness={0.9} />
          </mesh>
          <mesh position={[0, 0.0155, 0.018]}>
            <boxGeometry args={[0.004, 0.002, 0.02]} />
            <meshBasicMaterial color="#222" />
          </mesh>
        </group>
      ))}
      {/* speaker grille */}
      {Array.from({length: 9}).map((_, i) => (
        <mesh key={i} position={[0.29, 0.08 + i * 0.024, 0.31]}>
          <boxGeometry args={[0.11, 0.008, 0.006]} />
          <meshStandardMaterial color="#0e0e0e" roughness={0.8} />
        </mesh>
      ))}
      {/* feet */}
      {[-0.32, 0.32].flatMap((x) => [-0.12, 0.2].map((z) => ({x, z}))).map(({x, z}, i) => (
        <mesh key={i} position={[x, 0.012, z]}>
          <cylinderGeometry args={[0.03, 0.026, 0.024, 16]} />
          <meshStandardMaterial color="#111" roughness={0.6} />
        </mesh>
      ))}
      {/* antenna terminal at the back */}
      <mesh position={[0.2, 0.22, -0.37]} rotation={[Math.PI / 2, 0, 0]}>
        <cylinderGeometry args={[0.012, 0.012, 0.05, 12]} />
        <meshStandardMaterial color="#c8b27a" metalness={1} roughness={0.3} />
      </mesh>
      {on && (
        <pointLight
          position={[SX, 0.36, 0.95]}
          color="#9fc7ff"
          intensity={LIGHT.tvGlow * flick}
          distance={5}
          decay={0}
        />
      )}
    </group>
  );
};
