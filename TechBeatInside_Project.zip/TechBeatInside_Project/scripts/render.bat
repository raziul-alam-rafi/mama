@echo off
cd /d "%~dp0\.."
if "%1"=="4k" (
  call npx remotion render src/index.ts Main output/TechBeatInside_4K.mp4 --scale=2
) else (
  call npx remotion render src/index.ts Main output/TechBeatInside_1080p.mp4
)
pause
