import React from 'react';
import {Audio, Sequence, interpolate, staticFile, useVideoConfig} from 'remotion';
import timeline from '../audioTimeline.json';

/** Scene-based audio system: every entry = asset, start, duration, volume, fades. */
export const SfxTrack: React.FC = () => {
  const {fps} = useVideoConfig();
  return (
    <>
      {timeline.map((a, i) => {
        const dur = Math.round(a.durationSec * fps);
        const fi = Math.max(1, Math.round(a.fadeInSec * fps));
        const fo = Math.max(1, Math.round(a.fadeOutSec * fps));
        return (
          <Sequence key={i} from={Math.round(a.fromSec * fps)} durationInFrames={dur}>
            <Audio
              src={staticFile(a.file)}
              volume={(f) => interpolate(f, [0, fi, Math.max(fi + 1, dur - fo), dur], [0, 1, 1, 0], {extrapolateLeft: 'clamp', extrapolateRight: 'clamp'}) * a.volume}
            />
          </Sequence>
        );
      })}
    </>
  );
};
