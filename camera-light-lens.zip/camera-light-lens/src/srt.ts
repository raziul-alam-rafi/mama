export type Cue = { index: number; start: number; end: number; text: string };

const toSec = (t: string) => {
  const m = t.trim().match(/(\d+):(\d+):(\d+)[,.](\d+)/);
  if (!m) throw new Error("Bad SRT time: " + t);
  return Number(m[1]) * 3600 + Number(m[2]) * 60 + Number(m[3]) + Number(m[4].padEnd(3, "0")) / 1000;
};

export function parseSrt(raw: string): Cue[] {
  return raw
    .replace(/\r/g, "")
    .trim()
    .split(/\n{2,}/)
    .map((block) => {
      const lines = block.split("\n");
      const timeIdx = lines.findIndex((l) => l.includes("-->"));
      if (timeIdx < 0) throw new Error("SRT block without time: " + block);
      const [a, b] = lines[timeIdx].split("-->");
      return {
        index: Number(lines[0]) || 0,
        start: toSec(a),
        end: toSec(b),
        text: lines.slice(timeIdx + 1).join(" ").replace(/\s+/g, " ").trim(),
      };
    });
}
