// Installs an exact-pinned, compatible Remotion + three.js + React Three Fiber stack.
// All @remotion/* packages MUST share one identical version, so it is resolved once.
import { run } from "./lib.mjs";

let V = process.env.REMOTION_VERSION;
if (!V) {
  const r = run("npm view remotion version", { capture: true });
  if (r.status !== 0) { console.error("Could not reach the npm registry:\n" + r.out); process.exit(1); }
  V = r.out.trim().split(/\s+/).pop();
}
console.log("Using Remotion version:", V);
const a = run(`npm install --save-exact remotion@${V} @remotion/cli@${V} @remotion/three@${V} @remotion/google-fonts@${V} react@18.3.1 react-dom@18.3.1 three@0.169.0 @react-three/fiber@8.17.10`);
if (a.status !== 0) process.exit(a.status);
const b = run("npm install --save-dev --save-exact typescript@5.6.3 @types/react@18.3.12 @types/three@0.169.0");
if (b.status !== 0) process.exit(b.status);
console.log(`Done. Remotion ${V} (react 18, three 0.169, R3F 8.17).`);
