// Scene 2 — Before / After split (cue 2): whole torch must turn  vs  dish doesn't.
import React from "react";
import { AbsoluteFill, interpolate, spring, useCurrentFrame, useVideoConfig } from "remotion";
import { theme } from "../theme";
import { compare as b } from "../beats";
import { WordReveal } from "../components/Words";
import { Entrance } from "../components/Motion";
import { TorchShape, DishShape } from "../components/Icons";

const CARD_W = 760;
const CARD_H = 700;

const Card: React.FC<{ hero?: boolean; label: string; style?: React.CSSProperties; children?: React.ReactNode }> = ({
  hero,
  label,
  style,
  children,
}) => (
  <div
    style={{
      position: "absolute",
      top: 190,
      width: CARD_W,
      height: CARD_H,
      borderRadius: theme.radius.card,
      overflow: "hidden",
      background: `linear-gradient(180deg, ${theme.colors.surfaceHi}, ${theme.colors.surface})`,
      boxShadow: hero ? theme.shadow.cardHero : theme.shadow.card,
      border: `1px solid ${theme.colors.border}`,
      ...style,
    }}
  >
    <div
      style={{
        position: "absolute",
        left: 40,
        top: 30,
        zIndex: 2,
        padding: "6px 24px",
        borderRadius: theme.radius.pill,
        background: theme.colors.bg,
        border: `1px solid ${theme.colors.border}`,
        fontFamily: theme.fonts.display,
        fontSize: 40,
        fontWeight: 600,
        lineHeight: 1.4,
        color: hero ? theme.colors.text : theme.colors.textDim,
      }}
    >
      {label}
    </div>
    {children}
  </div>
);

export const CompareScene: React.FC = () => {
  const frame = useCurrentFrame();
  const { fps } = useVideoConfig();

  // left: the whole torch swings around to aim somewhere else
  const swing = 38 * Math.sin(frame / 12);
  // right: dish stays still, the beam hops between directions electronically
  const wedge = (k: number) => Math.pow(Math.max(0, Math.sin(frame / 14 - k * 2.1)), 2);
  const angles = [-38, 0, 38];
  const pPill = spring({ frame: frame - b.tK, fps, config: theme.spring.bouncy });
  const breathe = 1 + Math.sin(frame / 22) * 0.015;
  const ringT = ((frame % 40) / 40);

  return (
    <AbsoluteFill>
      <Entrance delay={b.t0} x={-90} y={30} style={{ position: "absolute", inset: 0 }}>
        <Card label="torch" style={{ left: 140 }}>
          <svg width={CARD_W} height={CARD_H} viewBox={`0 0 ${CARD_W} ${CARD_H}`} style={{ position: "absolute", left: 0, top: 0 }}>
            <defs>
              <linearGradient id="cmpBeamDim" gradientUnits="userSpaceOnUse" x1={0} y1={0} x2={0} y2={-520}>
                <stop offset="0" stopColor={theme.colors.text} stopOpacity={0.45} />
                <stop offset="1" stopColor={theme.colors.text} stopOpacity={0} />
              </linearGradient>
            </defs>
            <g transform={`translate(380 550) rotate(${swing}) scale(1.2)`}>
              <polygon points="-40,-250 40,-250 150,-520 -150,-520" fill="url(#cmpBeamDim)" />
              <TorchShape on={0.5} />
            </g>
            {/* motion arc hint */}
            <path d="M 150 300 A 230 230 0 0 1 610 300" fill="none" stroke={theme.colors.textDim} strokeWidth={3} strokeDasharray="4 14" strokeLinecap="round" opacity={0.5} />
          </svg>
          <div style={{ position: "absolute", left: 40, right: 40, bottom: 34 }}>
            <WordReveal text="পুরো torch-টাই ঘুরাতে হবে" delay={b.capL} per={3} size={46} weight={600} lineHeight={1.4} />
          </div>
        </Card>
      </Entrance>

      <Entrance delay={b.tK} x={90} y={30} style={{ position: "absolute", inset: 0 }}>
        <Card hero label="Starlink-এর dish" style={{ left: 1020 }}>
          <svg width={CARD_W} height={CARD_H} viewBox={`0 0 ${CARD_W} ${CARD_H}`} style={{ position: "absolute", left: 0, top: 0 }}>
            <defs>
              <linearGradient id="cmpBeamHero" gradientUnits="userSpaceOnUse" x1={0} y1={0} x2={0} y2={-250}>
                <stop offset="0" stopColor={theme.colors.primary} stopOpacity={0.85} />
                <stop offset="1" stopColor={theme.colors.primary} stopOpacity={0} />
              </linearGradient>
            </defs>
            <g transform={`translate(380 550) scale(${1.2 * breathe})`}>
              {angles.map((a, k) => (
                <g key={k} transform={`translate(0 -150) rotate(${a})`} opacity={wedge(k)}>
                  <polygon points="-26,0 26,0 100,-250 -100,-250" fill="url(#cmpBeamHero)" />
                </g>
              ))}
              <DishShape ring={ringT} dot={(i, j) => 0.25 + 0.75 * wedge((i + j) % 3)} />
            </g>
          </svg>
          <div style={{ position: "absolute", left: 40, right: 40, bottom: 34 }}>
            <WordReveal text="প্রতিবার পুরো dish ঘুরানোর প্রয়োজন পড়ে না" delay={b.capR} per={3} size={46} weight={600} lineHeight={1.4} />
          </div>
        </Card>
      </Entrance>

      {/* pivot word between the two cards */}
      <div
        style={{
          position: "absolute",
          left: 960,
          top: 540,
          transform: `translate(-50%, -50%) scale(${interpolate(pPill, [0, 1], [0.4, 1])})`,
          opacity: Math.min(1, pPill * 1.5),
          padding: "8px 34px",
          borderRadius: theme.radius.pill,
          background: theme.colors.accent,
          color: theme.colors.bg,
          fontFamily: theme.fonts.display,
          fontSize: 54,
          fontWeight: 700,
          lineHeight: 1.35,
          boxShadow: theme.shadow.card,
        }}
      >
        কিন্তু
      </div>
    </AbsoluteFill>
  );
};
