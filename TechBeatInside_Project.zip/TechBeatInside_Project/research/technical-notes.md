# Technical notes

## What the narration says (and what is shown)
1. A cricket match is shown on a TV channel -> living-room CRT TV displaying a cricket picture.
2. A camera at the ground captures the action -> studio camera on a tripod aimed at the pitch.
3. The camera's picture is converted to an electrical signal -> explanatory overlay: the picture is scanned
   line by line and each line becomes a voltage waveform (sync pulse, blanking, active video whose voltage follows brightness).
4. The signal is sent for broadcast -> cable to a transmitter tower; waves radiate from the tower.
5. Via the antenna it reaches the home TV -> Yagi-Uda rooftop antenna, coax cable down into the room, TV.

## Physical vs explanatory (rule: never mislead)
| Element | Status |
|---|---|
| TV, camera, tower, house, Yagi antenna, cable | physical objects (generic designs) |
| Glowing cable pulse, signal trace panel, scanned-picture panel | explanatory overlay — electrical signals are not visible |
| Expanding cyan shells from the tower | explanatory overlay — radio waves are invisible; real towers radiate mostly horizontally, a sphere is a simplification |
| Scan speed in shot D | exaggerated (real TV: 25/30 frames per second, hundreds of lines per frame) |
| Distances | NOT to scale (stadium -> tower -> house is compressed) |
The on-screen tag "ব্যাখ্যামূলক চিত্র" appears during shots D, E, F.

## Known simplifications / accuracy notes
- The narration is in the past tense ("পাঠানো হত"): analog era. The studio camera is a generic broadcast
  shoulder/studio-style camera; we do not claim a specific era or sensor type (tube vs CCD).
- The CRT TV shows its cabinet, convex faceplate, bezel, controls and rear bell; the electron gun, yoke and shadow mask
  are NOT shown because the narration never opens the TV. If you extend the script to the TV's inside, add them
  (see component-reference.md for the part list to research first).
- Yagi proportions follow the sources in sources.md (reflector ~5% longer, directors shorter, spacings in wavelengths).
  Exact lengths are scene units, not a tuned design for a real channel.
- A real TV antenna on the roof would be oriented with the directors toward the transmitter; here directors point toward the tower (-X).
- Intra-cue timing is estimated by character position (see visual-plan.md).

## Unresolved / to verify with real references
- Real appearance of the specific camera/TV model the channel wants to depict.
- Polarization and element orientation used locally (horizontal elements assumed).
