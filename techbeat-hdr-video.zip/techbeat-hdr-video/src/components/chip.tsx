import React from "react";
import { theme } from "../theme";

/** Processor চিপ (উপর থেকে): বডি, ডাই, চারদিকে পিন */
export const ProcChip: React.FC<{ size: number; active?: number; color?: string }> = ({ size, active = 0, color = theme.colors.hero }) => {
  const pins: React.ReactNode[] = [];
  for (let i = 0; i < 8; i++) {
    const p = 40 + i * 31.4;
    pins.push(<rect key={`l${i}`} x={8} y={p} width={30} height={10} rx={3} fill={color} opacity={0.7} />);
    pins.push(<rect key={`r${i}`} x={262} y={p} width={30} height={10} rx={3} fill={color} opacity={0.7} />);
    pins.push(<rect key={`t${i}`} x={p} y={8} width={10} height={30} rx={3} fill={color} opacity={0.7} />);
    pins.push(<rect key={`b${i}`} x={p} y={262} width={10} height={30} rx={3} fill={color} opacity={0.7} />);
  }
  return (
    <svg width={size} height={size} viewBox="0 0 300 300" style={{ filter: active > 0 ? `drop-shadow(0 0 ${30 * active}px ${theme.colors.glowHero})` : undefined }}>
      {pins}
      <rect x={36} y={36} width={228} height={228} rx={22} fill={theme.colors.surface} stroke={color} strokeWidth={5} />
      <rect x={82} y={82} width={136} height={136} rx={12} fill={theme.colors.bg} stroke={color} strokeWidth={3} strokeOpacity={0.6 + 0.4 * active} />
      {[0, 1, 2].map((i) => (
        <g key={i} stroke={color} strokeOpacity={0.5} strokeWidth={3}>
          <line x1={104} y1={112 + i * 38} x2={196} y2={112 + i * 38} />
        </g>
      ))}
      <circle cx={150} cy={150} r={14 + 4 * active} fill={theme.colors.accent} opacity={0.35 + 0.65 * active} />
    </svg>
  );
};
