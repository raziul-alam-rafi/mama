import React from "react";
import { AbsoluteFill, useCurrentFrame } from "remotion";
import { theme } from "../theme";

/** layer 1 — background mesh (never flat) */
export const BgMesh: React.FC = () => {
  const frame = useCurrentFrame();
  const d1 = Math.sin(frame / 55) * 50;
  const d2 = Math.cos(frame / 70) * 40;
  return (
    <AbsoluteFill style={{ background: `linear-gradient(180deg, ${theme.colors.bg}, ${theme.colors.bgAlt})` }}>
      <div
        style={{
          position: "absolute", width: 1300, height: 1300, borderRadius: "50%",
          top: -560, left: -380 + d1, filter: "blur(60px)",
          background: `radial-gradient(circle, ${theme.colors.primary}2E, transparent 62%)`,
        }}
      />
      <div
        style={{
          position: "absolute", width: 1000, height: 1000, borderRadius: "50%",
          bottom: -520, right: -300 - d2, filter: "blur(80px)",
          background: `radial-gradient(circle, ${theme.colors.accent}1C, transparent 65%)`,
        }}
      />
      <svg width="1920" height="1080" style={{ position: "absolute", opacity: 0.5 }}>
        <defs>
          <pattern id="dots" width="48" height="48" patternUnits="userSpaceOnUse">
            <circle cx="2" cy="2" r="1.6" fill={theme.colors.line} opacity="0.55" />
          </pattern>
        </defs>
        <rect width="1920" height="1080" fill="url(#dots)" />
      </svg>
    </AbsoluteFill>
  );
};

/** layer 4 — color grade (above content) */
export const Grade: React.FC = () => (
  <AbsoluteFill style={{ pointerEvents: "none" }}>
    <AbsoluteFill style={{ backgroundColor: theme.colors.primary, mixBlendMode: "soft-light", opacity: 0.1 }} />
    <AbsoluteFill
      style={{ background: "linear-gradient(180deg, rgba(0,0,0,0.08), transparent 26%, transparent 76%, rgba(0,0,0,0.16))" }}
    />
  </AbsoluteFill>
);

/** layer 5 — grain + vignette (topmost) */
export const GrainVignette: React.FC = () => {
  const frame = useCurrentFrame();
  const noise = `url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='220' height='220'%3E%3Cfilter id='n'%3E%3CfeTurbulence type='fractalNoise' baseFrequency='0.9' numOctaves='2'/%3E%3C/filter%3E%3Crect width='220' height='220' filter='url(%23n)' opacity='0.5'/%3E%3C/svg%3E")`;
  return (
    <>
      <AbsoluteFill
        style={{
          pointerEvents: "none", backgroundImage: noise, backgroundSize: "220px",
          backgroundPosition: `${(frame * 7) % 220}px ${(frame * 13) % 220}px`,
          opacity: 0.045, mixBlendMode: "overlay",
        }}
      />
      <AbsoluteFill
        style={{ pointerEvents: "none", background: "radial-gradient(ellipse at center, transparent 58%, rgba(0,0,0,0.24) 100%)" }}
      />
    </>
  );
};
