import React from "react";
import { interpolate, spring, useCurrentFrame, useVideoConfig } from "remotion";
import { theme } from "../theme";

const c = theme.colors;

/** ☀️ সূর্য — রশ্মি স্ট্যাগার্ড, ধীরে ঘোরে */
export const SunIcon: React.FC<{ size: number; delay?: number }> = ({ size, delay = 0 }) => {
  const frame = useCurrentFrame();
  const { fps } = useVideoConfig();
  const rays = 12;
  const core = spring({ frame: frame - delay, fps, config: theme.spring.bouncy });
  return (
    <svg width={size} height={size} viewBox="0 0 200 200" style={{ overflow: "visible", filter: `drop-shadow(0 0 ${size * 0.16}px ${c.accentGlow})` }}>
      <defs>
        <radialGradient id="sun-core" cx="40%" cy="35%" r="75%">
          <stop offset="0%" stopColor={c.white} stopOpacity="0.95" />
          <stop offset="35%" stopColor={c.accent} />
          <stop offset="100%" stopColor={c.accent} stopOpacity="0.85" />
        </radialGradient>
      </defs>
      <g transform={`rotate(${frame * 0.35} 100 100)`}>
        {Array.from({ length: rays }).map((_, i) => {
          const p = spring({ frame: frame - delay - 6 - i * 1.5, fps, config: theme.spring.snappy });
          return (
            <rect key={i} x={95} y={100 - 92} width={10} height={Math.max(0.01, 30 * p)} rx={5} fill={c.accent}
              opacity={0.9} transform={`rotate(${(360 / rays) * i} 100 100)`} />
          );
        })}
      </g>
      <circle cx="100" cy="100" r={44 * core} fill="url(#sun-core)" />
    </svg>
  );
};

/** 🍎 আপেল */
export const AppleIcon: React.FC<{ size: number; uid?: string }> = ({ size, uid = "ap" }) => (
  <svg width={size} height={size} viewBox="0 0 100 100" style={{ overflow: "visible" }}>
    <defs>
      <radialGradient id={`${uid}-body`} cx="35%" cy="32%" r="80%">
        <stop offset="0%" stopColor={c.apple} />
        <stop offset="100%" stopColor={c.appleDark} />
      </radialGradient>
    </defs>
    <path d="M50 30 C 38 22, 14 26, 14 54 C 14 78, 32 94, 44 92 C 48 91, 52 91, 56 92 C 68 94, 86 78, 86 54 C 86 26, 62 22, 50 30 Z" fill={`url(#${uid}-body)`} />
    <path d="M50 30 C 50 22, 52 14, 58 8" stroke={c.text} strokeOpacity="0.55" strokeWidth="4" strokeLinecap="round" fill="none" />
    <path d="M54 19 C 62 9, 76 9, 80 15 C 72 25, 60 25, 54 19 Z" fill={c.text} fillOpacity="0.55" />
    <ellipse cx="32" cy="46" rx="7" ry="13" fill={c.white} opacity="0.35" transform="rotate(18 32 46)" />
  </svg>
);

/** 👁 চোখ */
export const EyeIcon: React.FC<{ size: number; look?: number }> = ({ size, look = 0 }) => (
  <svg width={size} height={size} viewBox="0 0 100 100" style={{ overflow: "visible" }}>
    <defs>
      <radialGradient id="eye-iris" cx="40%" cy="35%" r="80%">
        <stop offset="0%" stopColor={c.white} stopOpacity="0.9" />
        <stop offset="40%" stopColor={c.primary} />
        <stop offset="100%" stopColor={c.bgAlt} />
      </radialGradient>
    </defs>
    <path d="M6 50 C 26 16, 74 16, 94 50 C 74 84, 26 84, 6 50 Z" fill={c.text} fillOpacity="0.95" />
    <circle cx={50 + look} cy="50" r="21" fill="url(#eye-iris)" />
    <circle cx={50 + look} cy="50" r="9" fill={c.bgDeep} />
    <circle cx={43 + look} cy="42" r="4.5" fill={c.white} opacity="0.9" />
  </svg>
);

/** 📷 ক্যামেরা (বডি + lens) */
export const CameraIcon: React.FC<{ size: number }> = ({ size }) => (
  <svg width={size} height={size} viewBox="0 0 100 100" style={{ overflow: "visible" }}>
    <defs>
      <linearGradient id="cam-body" x1="0" y1="0" x2="0" y2="1">
        <stop offset="0%" stopColor="#2A355C" />
        <stop offset="100%" stopColor="#141C38" />
      </linearGradient>
      <radialGradient id="cam-glass" cx="38%" cy="32%" r="80%">
        <stop offset="0%" stopColor={c.white} stopOpacity="0.9" />
        <stop offset="35%" stopColor={c.primary} />
        <stop offset="100%" stopColor={c.bgDeep} />
      </radialGradient>
    </defs>
    <path d="M34 24 L40 14 L60 14 L66 24" fill="#222C50" />
    <rect x="8" y="24" width="84" height="58" rx="12" fill="url(#cam-body)" stroke={c.glassBorder} strokeWidth="1.5" />
    <rect x="14" y="30" width="14" height="6" rx="3" fill={c.text} opacity="0.5" />
    <circle cx="50" cy="53" r="22" fill={c.bgDeep} stroke={c.text} strokeOpacity="0.35" strokeWidth="2" />
    <circle cx="50" cy="53" r="16" fill="url(#cam-glass)" />
    <ellipse cx="44" cy="46" rx="5" ry="3" fill={c.white} opacity="0.6" transform="rotate(-30 44 46)" />
  </svg>
);

/** সেন্সর — পিক্সেল গ্রিড; litRows দিয়ে কোথায় আলো পড়ছে বোঝানো যায় */
export const SensorIcon: React.FC<{ w: number; h: number; cols?: number; rows?: number; glow?: number; uid?: string }> = ({
  w, h, cols = 4, rows = 12, glow = 0, uid = "sn",
}) => (
  <svg width={w} height={h} viewBox={`0 0 ${w} ${h}`} style={{ overflow: "visible", filter: glow > 0 ? `drop-shadow(0 0 ${30 * glow}px ${c.glow})` : undefined }}>
    <defs>
      <linearGradient id={`${uid}-g`} x1="0" y1="0" x2="1" y2="1">
        <stop offset="0%" stopColor="#26335F" />
        <stop offset="100%" stopColor="#101834" />
      </linearGradient>
    </defs>
    <rect x="1" y="1" width={w - 2} height={h - 2} rx={20} fill={`url(#${uid}-g)`} stroke={c.glassBorder} strokeWidth="2" />
    {Array.from({ length: cols - 1 }).map((_, i) => (
      <line key={"v" + i} x1={(w / cols) * (i + 1)} x2={(w / cols) * (i + 1)} y1={14} y2={h - 14} stroke={c.text} strokeOpacity="0.1" />
    ))}
    {Array.from({ length: rows - 1 }).map((_, i) => (
      <line key={"h" + i} y1={(h / rows) * (i + 1)} y2={(h / rows) * (i + 1)} x1={14} x2={w - 14} stroke={c.text} strokeOpacity="0.1" />
    ))}
  </svg>
);

/** lens সামনের দৃশ্য — গ্লাস রিং, প্রতিফলন, ধীরে ঘোরা হাইলাইট */
export const LensFront: React.FC<{ size: number; uid?: string }> = ({ size, uid = "lf" }) => {
  const frame = useCurrentFrame();
  const sweep = interpolate(Math.sin(frame / 40), [-1, 1], [-14, 14]);
  return (
    <svg width={size} height={size} viewBox="0 0 400 400" style={{ overflow: "visible", filter: `drop-shadow(0 30px 50px rgba(0,0,0,0.55))` }}>
      <defs>
        <linearGradient id={`${uid}-barrel`} x1="0" y1="0" x2="1" y2="1">
          <stop offset="0%" stopColor="#2B3763" />
          <stop offset="100%" stopColor="#0E1430" />
        </linearGradient>
        <radialGradient id={`${uid}-glass`} cx="36%" cy="30%" r="85%">
          <stop offset="0%" stopColor={c.white} stopOpacity="0.8" />
          <stop offset="30%" stopColor={c.primary} stopOpacity="0.9" />
          <stop offset="100%" stopColor={c.bgDeep} />
        </radialGradient>
        <radialGradient id={`${uid}-core`} cx="50%" cy="50%" r="50%">
          <stop offset="0%" stopColor={c.bgDeep} />
          <stop offset="100%" stopColor="#16204A" />
        </radialGradient>
      </defs>
      <circle cx="200" cy="200" r="190" fill={`url(#${uid}-barrel)`} stroke={c.text} strokeOpacity="0.2" strokeWidth="3" />
      <circle cx="200" cy="200" r="172" fill="none" stroke={c.text} strokeOpacity="0.14" strokeWidth="16" strokeDasharray="3 9" />
      <circle cx="200" cy="200" r="148" fill="#0A1028" stroke={c.text} strokeOpacity="0.25" strokeWidth="3" />
      <circle cx="200" cy="200" r="126" fill={`url(#${uid}-glass)`} />
      <circle cx="200" cy="200" r="92" fill="none" stroke={c.white} strokeOpacity="0.28" strokeWidth="3" />
      <circle cx="200" cy="200" r="64" fill={`url(#${uid}-core)`} stroke={c.white} strokeOpacity="0.3" strokeWidth="3" />
      <circle cx="200" cy="200" r="30" fill="none" stroke={c.primary} strokeOpacity="0.8" strokeWidth="3" />
      <g transform={`rotate(${sweep} 200 200)`}>
        <path d="M112 128 A 110 110 0 0 1 188 92" stroke={c.white} strokeOpacity="0.55" strokeWidth="9" strokeLinecap="round" fill="none" />
        <circle cx="236" cy="296" r="7" fill={c.white} opacity="0.5" />
        <ellipse cx="150" cy="156" rx="34" ry="14" fill={c.white} opacity="0.35" transform="rotate(-38 150 156)" />
      </g>
    </svg>
  );
};

/** আইসোমেট্রিক কিউব — "বস্তু" */
export const CubeIcon: React.FC<{ size: number }> = ({ size }) => (
  <svg width={size} height={size} viewBox="0 0 100 100" style={{ overflow: "visible" }}>
    <polygon points="50,10 88,30 50,50 12,30" fill={c.textDim} fillOpacity="0.55" stroke={c.text} strokeOpacity="0.4" strokeWidth="2" strokeLinejoin="round" />
    <polygon points="12,30 50,50 50,92 12,70" fill={c.textDim} fillOpacity="0.28" stroke={c.text} strokeOpacity="0.4" strokeWidth="2" strokeLinejoin="round" />
    <polygon points="88,30 50,50 50,92 88,70" fill={c.textDim} fillOpacity="0.16" stroke={c.text} strokeOpacity="0.4" strokeWidth="2" strokeLinejoin="round" />
  </svg>
);

/** ✓ চেকমার্ক — আঁকা হয় */
export const CheckIcon: React.FC<{ size: number; p?: number; color?: string }> = ({ size, p = 1, color = c.primary }) => (
  <svg width={size} height={size} viewBox="0 0 48 48" style={{ overflow: "visible" }}>
    <circle cx="24" cy="24" r="21" fill={color} fillOpacity="0.18" stroke={color} strokeWidth="3" />
    <path d="M14 25 L21 32 L34 17" fill="none" stroke={color} strokeWidth="5" strokeLinecap="round" strokeLinejoin="round" pathLength={1} strokeDasharray={`${p} 2`} />
  </svg>
);

/** ✕ ক্রস */
export const CrossIcon: React.FC<{ size: number; p?: number; color?: string }> = ({ size, p = 1, color = c.accent }) => (
  <svg width={size} height={size} viewBox="0 0 48 48" style={{ overflow: "visible" }}>
    <circle cx="24" cy="24" r="21" fill={color} fillOpacity="0.16" stroke={color} strokeWidth="3" />
    <path d="M16 16 L32 32 M32 16 L16 32" fill="none" stroke={color} strokeWidth="5" strokeLinecap="round" pathLength={1} strokeDasharray={`${p} 2`} />
  </svg>
);

/** → তীর */
export const ArrowIcon: React.FC<{ size: number; color?: string; p?: number }> = ({ size, color = c.textDim, p = 1 }) => (
  <svg width={size} height={size * 0.5} viewBox="0 0 80 40" style={{ overflow: "visible" }}>
    <path d="M4 20 H68 M52 6 L68 20 L52 34" fill="none" stroke={color} strokeWidth="5" strokeLinecap="round" strokeLinejoin="round" pathLength={1} strokeDasharray={`${p} 2`} />
  </svg>
);
