import React from "react";
import { Composition } from "remotion";
import { ApertureScene } from "./scenes/ApertureScene";
import { GlProbe } from "./GlProbe";
import { VIDEO } from "./config";

export const RemotionRoot: React.FC = () => (
  <>
    <Composition
      id={VIDEO.id}
      component={ApertureScene}
      durationInFrames={VIDEO.durationInFrames}
      fps={VIDEO.fps}
      width={VIDEO.width}
      height={VIDEO.height}
    />
    {/* 1-frame diagnostic: proves WebGL works in the render browser. Used by `npm run gl-check`. */}
    <Composition id="GlProbe" component={GlProbe} durationInFrames={1} fps={30} width={640} height={360} />
  </>
);
