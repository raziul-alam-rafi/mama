import { SRT_TEXT } from "./script";

export const FPS = 30;
export const WIDTH = 1920;
export const HEIGHT = 1080;
/** Visuals enter this many frames before the matching narration (spec: 4–6). */
export const LEAD = 5;

export type Cue = { index: number; startF: number; endF: number; text: string };

const toSec = (t: string) => {
  const m = t.match(/(\d+):(\d+):(\d+)[,.](\d+)/);
  if (!m) throw new Error("Bad SRT time: " + t);
  return +m[1] * 3600 + +m[2] * 60 + +m[3] + +m[4] / 1000;
};

export const parseSrt = (src: string): Cue[] =>
  src
    .trim()
    .split(/\r?\n\s*\r?\n/)
    .map((block) => {
      const lines = block.split(/\r?\n/);
      const [a, b] = lines[1].split("-->");
      return {
        index: parseInt(lines[0], 10),
        startF: Math.round(toSec(a.trim()) * FPS),
        endF: Math.round(toSec(b.trim()) * FPS),
        text: lines.slice(2).join(" "),
      };
    });

export const CUES = parseSrt(SRT_TEXT);
export const TOTAL_FRAMES = Math.ceil(CUES[CUES.length - 1].endF + 1);

export type SceneTiming = {
  from: number; // composition frame where the Sequence starts
  dur: number; // Sequence length
  cs: number; // cue start, in the scene's local frames
  cd: number; // cue duration in frames
};

export const SCENES: SceneTiming[] = CUES.map((c, i) => {
  const from = i === 0 ? 0 : Math.max(0, c.startF - LEAD);
  const to = i === CUES.length - 1 ? TOTAL_FRAMES : c.endF;
  return { from, dur: to - from, cs: c.startF - from, cd: c.endF - c.startF };
});

/** Named beats as fractions of each cue (shared by visuals and SFX so they stay in sync). */
export const BEATS = {
  s1: { title: 0.04, reveal: 0.6 },
  s2: { field: 0.02, camera: 0.22, rays: 0.42, zoom: 0.8 },
  s3: { card: 0.02, scan: 0.14, wave: 0.5, tower: 0.7 },
  s4: { tower: 0.0, pulse: 0.1, antenna: 0.5, wire: 0.7 },
  s5: { cut: 0.0, split: 0.32, picture: 0.42, sound: 0.58 },
} as const;

export const localBeat = (scene: number, frac: number) =>
  Math.round(SCENES[scene].cs + frac * SCENES[scene].cd);
export const globalBeat = (scene: number, frac: number) =>
  SCENES[scene].from + localBeat(scene, frac);
