import React from 'react';
import {theme} from '../theme';

/** Transparent housing so the internals stay visible (cutaway-style). */
export const LensBarrel: React.FC = () => (
  <group>
    <mesh rotation={[Math.PI / 2, 0, 0]}>
      <cylinderGeometry args={[2.2, 2.2, 3, 96, 1, true]} />
      <meshPhysicalMaterial color={theme.colors.glass} transparent opacity={0.1} roughness={0.1} side={2} depthWrite={false} />
    </mesh>
    {[-1.5, 1.5].map((z) => (
      <mesh key={z} position={[0, 0, z]}>
        <torusGeometry args={[2.2, 0.08, 16, 96]} />
        <meshStandardMaterial color={theme.colors.metalEdge} metalness={0.85} roughness={0.3} />
      </mesh>
    ))}
  </group>
);
