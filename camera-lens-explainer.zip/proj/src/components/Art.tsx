import React from "react";
import {theme} from "../theme";

/** Apple drawn around its centre (0,0) at scale 1. Top of the body is ≈ 50 units above centre. */
export const APPLE_TOP = 50;
export const Apple: React.FC<{x: number; y: number; s?: number; dim?: number}> = ({x, y, s = 1, dim = 1}) => (
  <g transform={`translate(${x} ${y}) scale(${s})`} opacity={dim}>
    <ellipse cx="0" cy="66" rx="64" ry="9" fill="#000" opacity="0.25" />
    <path d="M0,-34 C30,-62 70,-40 66,6 C62,50 30,72 0,62 C-30,72 -62,50 -66,6 C-70,-40 -30,-62 0,-34 Z"
      fill={theme.colors.apple} stroke={theme.colors.appleDark} strokeWidth="4" />
    <path d="M-40,-14 C-46,6 -40,28 -26,40" fill="none" stroke="#FFFFFF" strokeWidth="7" strokeLinecap="round" opacity="0.35" />
    <path d="M0,-34 C2,-52 8,-62 16,-68" fill="none" stroke={theme.colors.trunk} strokeWidth="7" strokeLinecap="round" />
    <path d="M10,-52 C28,-76 52,-70 60,-58 C42,-42 22,-44 10,-52 Z" fill={theme.colors.leaf} stroke={theme.colors.leafDark} strokeWidth="3" />
  </g>
);

/** Tree drawn from its base-centre (0,0) upward at scale 1; canopy top ≈ 288 units above the base. */
export const TREE_TOP = 288;
export const Tree: React.FC<{x: number; y: number; s?: number; dim?: number}> = ({x, y, s = 1, dim = 1}) => (
  <g transform={`translate(${x} ${y}) scale(${s})`} opacity={dim}>
    <ellipse cx="0" cy="4" rx="120" ry="12" fill="#000" opacity="0.22" />
    <rect x="-17" y="-140" width="34" height="140" rx="8" fill={theme.colors.trunk} />
    <circle cx="-64" cy="-160" r="62" fill={theme.colors.leafDark} />
    <circle cx="64" cy="-160" r="62" fill={theme.colors.leafDark} />
    <circle cx="0" cy="-215" r="76" fill={theme.colors.leaf} />
    <circle cx="0" cy="-150" r="72" fill={theme.colors.leaf} />
    <circle cx="-26" cy="-232" r="26" fill="#FFFFFF" opacity="0.10" />
  </g>
);

/** The little "real scene" picture (tree behind, apple in front) in local coords, centred on (0,0), ≈ 400×340. */
export const PictureArt: React.FC<{s?: number}> = ({s = 1}) => (
  <g transform={`scale(${s})`}>
    <rect x="-200" y="-170" width="400" height="340" fill="#17304F" />
    <rect x="-200" y="60" width="400" height="110" fill="#14283F" />
    <Tree x={-70} y={95} s={0.78} />
    <Apple x={80} y={95} s={0.9} />
  </g>
);

/** Image sensor seen from the side (thin block with a pixel-row texture). */
export const SensorBar: React.FC<{x: number; cy: number; h: number; glow?: boolean}> = ({x, cy, h, glow = false}) => (
  <g filter={glow ? "url(#glow)" : undefined}>
    <rect x={x - 12} y={cy - h} width={24} height={2 * h} rx={4} fill={theme.colors.accent} />
    {Array.from({length: Math.floor(h / 10)}).map((_, i) => (
      <line key={i} x1={x - 12} x2={x + 12} y1={cy - h + 8 + i * 20} y2={cy - h + 8 + i * 20}
        stroke={theme.colors.bg} strokeWidth={2} opacity={0.45} />
    ))}
  </g>
);

/** Front-view magnifying-glass icon (rim + glass + handle). */
export const MagnifierIcon: React.FC<{x: number; y: number; s?: number}> = ({x, y, s = 1}) => (
  <g transform={`translate(${x} ${y}) scale(${s})`}>
    <line x1="38" y1="38" x2="92" y2="92" stroke={theme.colors.trunk} strokeWidth="18" strokeLinecap="round" />
    <circle cx="0" cy="0" r="52" fill="url(#glass)" stroke={theme.colors.glassEdge} strokeWidth="9" />
    <path d="M-30,-8 A32,32 0 0 1 -6,-32" fill="none" stroke="#FFFFFF" strokeWidth="6" strokeLinecap="round" opacity="0.6" />
  </g>
);

/** Mechanical iris: `open` 0..1 is the size of the central opening. The light disc behind shows through it. */
export const Iris: React.FC<{cx: number; cy: number; R: number; open: number; blades?: number; rot?: number}> = ({
  cx, cy, R, open, blades = 7, rot = 0,
}) => {
  const r = R * (0.12 + 0.78 * open);
  const tw = 0.55 * (1 - open) + 0.25;
  const polar = (rad: number, a: number) => `${(cx + rad * Math.cos(a)).toFixed(1)},${(cy + rad * Math.sin(a)).toFixed(1)}`;
  const step = (2 * Math.PI) / blades;
  return (
    <g>
      <circle cx={cx} cy={cy} r={R} fill={theme.colors.hero} opacity={0.22} />
      <circle cx={cx} cy={cy} r={R} fill="#FFFFFF" opacity={0.10} />
      {Array.from({length: blades}).map((_, k) => {
        const a = rot + k * step;
        const pts = [polar(r, a), polar(r, a + step), polar(R * 1.02, a + step + tw), polar(R * 1.02, a + tw)].join(" ");
        return <polygon key={k} points={pts} fill="url(#metal)" stroke={theme.colors.panelEdge} strokeWidth={2.5} strokeLinejoin="round" />;
      })}
      <circle cx={cx} cy={cy} r={R * 1.08} fill="none" stroke={theme.colors.panelEdge} strokeWidth={18} />
      <circle cx={cx} cy={cy} r={R * 1.08 + 10} fill="none" stroke={theme.colors.textDim} strokeWidth={2} opacity={0.5} />
    </g>
  );
};
