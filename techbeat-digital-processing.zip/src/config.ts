// Project-wide switches. Everything time-related derives from FPS.
export const FPS = 30; // set to 60 for a 60fps render
export const WIDTH = 1920;
export const HEIGHT = 1080;

// public/voiceover.mp3 (optional). Plays in Studio preview if the file exists.
export const VOICEOVER_PREVIEW = true;
// Keep false: the voice-over is NOT baked into renders unless you flip this.
export const VOICEOVER_IN_RENDER = false;

// Sound effects (public/sfx/*.wav) — audible in Studio preview and in renders.
export const SFX_ENABLED = true;
