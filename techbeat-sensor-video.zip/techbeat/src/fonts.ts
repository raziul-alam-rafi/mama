import {loadFont} from "@remotion/google-fonts/HindSiliguri";

// Hind Siliguri: correct Bengali conjuncts (যুক্তাক্ষর). 700 = heaviest weight.
export const {fontFamily} = loadFont("normal", {
  weights: ["400", "600", "700"],
  subsets: ["bengali", "latin", "latin-ext"],
});
