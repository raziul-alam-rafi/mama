#!/usr/bin/env bash
# Installs a compatible, exact-pinned Remotion + Three.js + R3F stack.
# All @remotion/* packages MUST have the identical version, so we resolve it once.
set -euo pipefail
V="${REMOTION_VERSION:-$(npm view remotion version)}"
echo "Using Remotion version: $V"
npm install --save-exact \
  remotion@"$V" @remotion/cli@"$V" @remotion/three@"$V" @remotion/google-fonts@"$V" \
  react@18.3.1 react-dom@18.3.1 \
  three@0.169.0 @react-three/fiber@8.17.10
npm install --save-dev --save-exact typescript@5.6.3 @types/react@18.3.12 @types/three@0.169.0
echo "Done. Installed Remotion $V (react 18, three 0.169, R3F 8.17)."
