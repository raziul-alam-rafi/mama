import React from "react";
import { theme, mix } from "./theme";

// দৃশ্যপট: মানুষ, গাছ, আকাশ। একক = (x: 0..1.6, y: 0..1)
export const WW = 1.6;
export type Region = "sky" | "sun" | "hill" | "ground" | "trunk" | "canopy" | "body" | "face" | "hair";

const inC = (x: number, y: number, cx: number, cy: number, r: number) =>
  (x - cx) ** 2 + (y - cy) ** 2 <= r * r;
export const hillY = (x: number) => 0.64 + 0.035 * Math.sin(x * 4.2 + 0.6);

export function sample(x: number, y: number): { lum: number; region: Region } {
  let region: Region = "sky";
  let lum = 0.42 + 0.38 * Math.min(1, y / 0.64);
  if (inC(x, y, 1.28, 0.2, 0.08)) {
    region = "sun";
    lum = 1;
  }
  const hy = hillY(x);
  if (y > hy) {
    if (y < hy + 0.09) {
      region = "hill";
      lum = 0.34;
    } else {
      region = "ground";
      lum = 0.2;
    }
  }
  if (x >= 0.27 && x <= 0.32 && y >= 0.5 && y <= 0.84) {
    region = "trunk";
    lum = 0.14;
  }
  if (inC(x, y, 0.295, 0.4, 0.15) || inC(x, y, 0.22, 0.47, 0.1) || inC(x, y, 0.37, 0.46, 0.1)) {
    region = "canopy";
    lum = 0.3;
  }
  if (x >= 0.84 && x <= 1.04 && y >= 0.5 + 0.12 * ((x - 0.94) / 0.1) ** 2 && y <= 0.84) {
    region = "body";
    lum = 0.3;
  }
  if (inC(x, y, 0.94, 0.41, 0.075)) {
    region = "face";
    lum = 0.8;
  }
  if (inC(x, y, 0.94, 0.395, 0.08) && y < 0.4) {
    region = "hair";
    lum = 0.1;
  }
  return { lum, region };
}

// বক্স: মুখ ও গাছ (ডিটেকশনের জন্য)
export const BOX = {
  face: { x0: 0.84, y0: 0.31, x1: 1.04, y1: 0.49 },
  tree: { x0: 0.06, y0: 0.22, x1: 0.46, y1: 0.85 },
};

export type Cell = { i: number; j: number; lum: number; region: Region };
const memo = new Map<string, Cell[]>();
export const gridCells = (cols: number, rows: number): Cell[] => {
  const key = `${cols}x${rows}`;
  const hit = memo.get(key);
  if (hit) return hit;
  const out: Cell[] = [];
  for (let j = 0; j < rows; j++)
    for (let i = 0; i < cols; i++) {
      const s = sample(((i + 0.5) / cols) * WW, (j + 0.5) / rows);
      out.push({ i, j, lum: s.lum, region: s.region });
    }
  memo.set(key, out);
  return out;
};

/** পরিষ্কার ভেক্টর দৃশ্য */
export const WorldSVG: React.FC<{ w: number; id?: string }> = ({ w, id = "w" }) => {
  const c = theme.world;
  const hill = Array.from({ length: 33 }, (_, k) => {
    const x = (k / 32) * WW;
    return `${k ? "L" : "M"}${x} ${hillY(x)}`;
  }).join(" ");
  return (
    <svg width={w} height={w / WW} viewBox={`0 0 ${WW} 1`} style={{ display: "block" }}>
      <defs>
        <linearGradient id={`${id}-sky`} x1="0" y1="0" x2="0" y2="1">
          <stop offset="0" stopColor={c.skyTop} />
          <stop offset="0.64" stopColor={c.skyBottom} />
        </linearGradient>
      </defs>
      <rect width={WW} height={1} fill={`url(#${id}-sky)`} />
      <circle cx={1.28} cy={0.2} r={0.08} fill={c.sun} />
      <path d={`${hill} L${WW} 1 L0 1 Z`} fill={c.hill} />
      <path
        d={`${Array.from({ length: 33 }, (_, k) => {
          const x = (k / 32) * WW;
          return `${k ? "L" : "M"}${x} ${hillY(x) + 0.09}`;
        }).join(" ")} L${WW} 1 L0 1 Z`}
        fill={c.ground}
      />
      <rect x={0.27} y={0.5} width={0.05} height={0.34} fill={c.trunk} />
      <circle cx={0.295} cy={0.4} r={0.15} fill={c.canopy} />
      <circle cx={0.22} cy={0.47} r={0.1} fill={c.canopy} />
      <circle cx={0.37} cy={0.46} r={0.1} fill={c.canopy} />
      <path d="M0.84 0.84 L0.84 0.62 Q0.84 0.5 0.94 0.5 Q1.04 0.5 1.04 0.62 L1.04 0.84 Z" fill={c.body} />
      <circle cx={0.94} cy={0.41} r={0.075} fill={c.face} />
      <path d="M0.862 0.4 A0.08 0.08 0 0 1 1.018 0.4 Z" fill={c.hair} />
    </svg>
  );
};

/** লুমিন্যান্স-মোজাইক (ক্যামেরার "দেখা" শুধু উজ্জ্বলতার ঘর) */
export const lumColor = (lum: number) => mix(theme.colors.bgAlt, theme.colors.text, lum);
