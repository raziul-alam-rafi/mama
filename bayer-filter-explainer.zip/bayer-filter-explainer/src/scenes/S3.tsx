import React from "react";
import {AbsoluteFill} from "remotion";
import {Chip, Pop, Ray, Sfx, Words, clamp01, useAnim} from "../anim";
import {Channel, chColor, theme} from "../theme";

const LANES = [330, 550, 770];
const CH: Channel[] = ["R", "G", "B"];
const OFF: Record<Channel, number> = {R: -18, G: 0, B: 18};
const SRC_X = 150;
const BEAM_X = 340;
const FX = 800;
const FW = 46;
const PX = 1090;
const MX = 1460;

// Scene 3 - horizontal lanes: the same mixed light, but each photosite measures a different colour.
export const S3: React.FC = () => {
  const a = useAnim();
  const disc = a.sp(0.15, theme.spring.bouncy);
  const fan = a.prog(0.3, 0.9, theme.ease.out);

  return (
    <AbsoluteFill>
      <Sfx name="whoosh_swipe" at={0.05} vol={0.22} />
      <Sfx name="pop" at={0.55} vol={0.24} rate={0.97} />
      <Sfx name="click" at={2.5} vol={0.22} rate={1.03} />

      <div style={{position: "absolute", left: 140, top: 64}}>
        <Words text="photosite সব রঙ একইভাবে মাপে না" at={0.1} highlight={["একইভাবে"]} />
      </div>

      <svg width={1920} height={1080} style={{position: "absolute", inset: 0}}>
        <defs>
          <radialGradient id="s3disc">
            <stop offset="0" stopColor={theme.colors.text} />
            <stop offset="0.55" stopColor={theme.colors.text} stopOpacity={0.9} />
            <stop offset="1" stopColor={theme.colors.hero} stopOpacity={0} />
          </radialGradient>
        </defs>

        {/* light source */}
        <g transform={`translate(${SRC_X} 550) scale(${disc})`} opacity={clamp01(disc * 1.4)}>
          <circle r={74} fill="url(#s3disc)" opacity={0.55 + 0.1 * Math.sin(a.t * 3)} />
          <circle r={34} fill={theme.colors.text} />
        </g>
        {LANES.map((y, li) => (
          <Ray key={`fan${li}`} x1={SRC_X + 36} y1={550} x2={BEAM_X} y2={y} color={theme.colors.text} p={fan} w={4} opacity={0.55} />
        ))}

        {LANES.map((y, li) => {
          const c = CH[li];
          const col = chColor[c];
          const fp = a.sp(0.45 + li * 0.14, theme.spring.snappy);
          const s0 = 1.0 + li * 0.28;
          const arrive = s0 + 0.75;
          const pp = a.sp(0.6 + li * 0.14, theme.spring.smooth);
          const glow = a.prog(arrive + 0.35, arrive + 0.9) * (0.8 + 0.2 * Math.sin(a.t * 3 + li));
          return (
            <g key={li}>
              {/* filter slab */}
              <g style={{transformOrigin: `${FX + FW / 2}px ${y}px`, transform: `scale(1, ${fp})`}} opacity={clamp01(fp * 1.5)}>
                <rect x={FX} y={y - 84} width={FW} height={168} rx={12} fill={col} opacity={0.85} stroke="rgba(255,255,255,0.5)" strokeWidth={2} style={{filter: `drop-shadow(0 0 16px ${col})`}} />
              </g>
              {/* mixed beams -> only own colour continues */}
              {CH.map((cc) => {
                const own = cc === c;
                const p1 = a.prog(s0, s0 + 0.75, theme.ease.out);
                const by = y + OFF[cc];
                const spark = !own ? a.ease(arrive, arrive + 0.15, 0, 1) * (1 - a.ease(arrive + 0.15, arrive + 0.6, 0, 1)) : 0;
                return (
                  <g key={cc}>
                    <Ray x1={BEAM_X} y1={by} x2={FX} y2={by} color={chColor[cc]} p={p1} w={7} />
                    {!own && <circle cx={FX} cy={by} r={8 + 22 * a.prog(arrive, arrive + 0.6, theme.ease.out)} fill="none" stroke={chColor[cc]} strokeWidth={4} opacity={spark} />}
                    {own && <Ray x1={FX + FW} y1={by} x2={PX} y2={by} color={chColor[cc]} p={a.prog(arrive, arrive + 0.4, theme.ease.out)} w={7} />}
                  </g>
                );
              })}
              {/* photosite */}
              <g opacity={clamp01(pp * 1.5)} transform={`translate(${(1 - pp) * 40} 0)`}>
                <rect x={PX} y={y - 74} width={230} height={148} rx={22} fill={theme.colors.well} stroke={theme.colors.line} strokeWidth={3} />
                <rect x={PX + 6} y={y - 68} width={218} height={136} rx={18} fill={col} opacity={0.5 * glow} />
                <rect x={PX + 70} y={y - 22} width={90} height={44} rx={10} fill={col} opacity={0.15 + 0.65 * glow} />
              </g>
              {/* meters: R G B of what this photosite measured */}
              {CH.map((cc, k) => {
                const own = cc === c;
                const g = a.sp(arrive + 0.5 + k * 0.08, theme.spring.snappy);
                const h = (own ? 132 : 9) * g;
                const bx = MX + k * 86;
                return (
                  <g key={cc}>
                    <rect x={bx} y={y + 66 - 132} width={56} height={132} rx={14} fill={theme.colors.well} opacity={0.9} stroke={theme.colors.line} strokeWidth={2} />
                    <rect x={bx} y={y + 66 - h} width={56} height={Math.max(h, 0.01)} rx={14} fill={chColor[cc]} style={{filter: own ? `drop-shadow(0 0 12px ${chColor[cc]})` : undefined}} />
                    <circle cx={bx + 28} cy={y + 96} r={9} fill={chColor[cc]} />
                  </g>
                );
              })}
            </g>
          );
        })}
      </svg>

      <Pop at={1.8} y={20} style={{position: "absolute", left: MX - 40, top: 168}}>
        <Chip size={theme.size.small}>মাপা আলো</Chip>
      </Pop>
    </AbsoluteFill>
  );
};
