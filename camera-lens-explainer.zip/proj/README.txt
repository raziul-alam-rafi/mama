npm install
npx remotion studio            (entry: src/index.ts, composition: Main)
npx remotion render src/index.ts Main out/video.mp4
Optional: put voiceover at public/voiceover.mp3 (plays in Studio preview only; off in render by default - see src/config.ts)
Timing: public/voiceover.srt -> node scripts/srt-to-cues.mjs -> src/cues.ts
