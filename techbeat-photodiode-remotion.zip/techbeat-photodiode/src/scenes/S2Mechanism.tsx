import React from "react";
import { useCurrentFrame, useVideoConfig } from "remotion";
import { theme } from "../theme";
import { FullSvg, P, SceneShell, Sfx, Tag, Title, Win, lerp, sp } from "../fx";
import { Electron, Hole, Lattice, Photon, PixelWell } from "../parts";
import { sceneTimes } from "../timeline";
import { cueEnd, cueStart, wordFrame } from "../srt";

const C = theme.colors;
const T0 = sceneTimes[1].from;

// সিনের লোকাল ফ্রেমে মুখ্য মুহূর্ত (সব SRT থেকে)
const tB = cueStart(3) - T0; // electron মুক্ত হওয়ার অংশ
const tC = cueStart(4) - T0; // charge জমা
const tEnd = cueEnd(4) - T0;
const tRel = wordFrame(3, "electron", 4) - T0;
const tPhotonWord = wordFrame(2, "photon", 8) - T0;

const slab = { x: 360, y: 430, w: 1200, h: 500 };
const PA = { x: 960, y: 660 }; // শোষণ বিন্দু (স্টেজ A)
const PB = { x: 960, y: 500 }; // শোষণ বিন্দু (স্টেজ B)

const Flash: React.FC<{ x: number; y: number; frame: number; at: number; max?: number }> = ({ x, y, frame, at, max = 110 }) => {
  if (frame < at || frame > at + 22) return null;
  const p = P(frame, at, 20, theme.ease.out);
  return (
    <g>
      <circle cx={x} cy={y} r={lerp(8, max, p)} fill="none" stroke={C.accent} strokeWidth={lerp(10, 2, p)} opacity={1 - p} />
      <circle cx={x} cy={y} r={lerp(6, max * 0.55, p)} fill={C.accent} opacity={0.5 * (1 - p)} />
    </g>
  );
};

/* ---------------- স্টেজ A: স্ল্যাব ওভারভিউ ---------------- */
const StageA: React.FC<{ frame: number }> = ({ frame }) => {
  const { fps } = useVideoConfig();
  const pop = sp(frame, fps, 2, theme.spring.smooth);
  const start = 16;
  const arrive = tB - 18;
  const q = P(frame, start, arrive - start, theme.ease.soft);
  const S = { x: 1300, y: 250 };
  const px = lerp(S.x, PA.x, q);
  const py = lerp(S.y, PA.y, q);
  const rot = (Math.atan2(PA.y - S.y, PA.x - S.x) * 180) / Math.PI;
  const zoom = lerp(1, 2.6, P(frame, tB - 14, 24, theme.ease.inOut));
  const fade = 1 - P(frame, tB + 2, 10, theme.ease.in);
  return (
    <g opacity={fade} transform={`translate(${PA.x} ${PA.y}) scale(${zoom}) translate(${-PA.x} ${-PA.y})`}>
      <g transform={`translate(960 ${slab.y + slab.h / 2}) scale(${lerp(0.92, 1, pop)}) translate(-960 ${-(slab.y + slab.h / 2)})`} opacity={pop}>
        <rect x={slab.x} y={slab.y} width={slab.w} height={slab.h} rx={34} fill={C.silicon} stroke={C.panelLine} strokeWidth={3} />
        <rect x={slab.x + 4} y={slab.y + 4} width={slab.w - 8} height={14} rx={7} fill={C.siliconHi} />
        <Lattice x0={410} y0={485} cols={12} rows={5} gap={100} r={15} />
      </g>
      {frame >= start ? <line x1={S.x} y1={S.y} x2={px} y2={py} stroke={C.accent} strokeWidth={3} opacity={0.18} strokeDasharray="4 12" /> : null}
      {frame >= start && q < 0.995 ? <Photon x={px} y={py} rot={rot} len={170} amp={20} phase={frame / 2.4} /> : null}
      <Flash x={PA.x} y={PA.y} frame={frame} at={arrive} />
      {frame >= arrive ? <circle cx={PA.x} cy={PA.y} r={20} fill={C.accent} opacity={0.5 * (1 - P(frame, arrive, 24))} /> : null}
    </g>
  );
};

/* ---------------- স্টেজ B: ল্যাটিস জুম, electron মুক্ত ---------------- */
const B = { x0: 260, y0: 300, gap: 200, r: 40 };
const StageB: React.FC<{ frame: number }> = ({ frame }) => {
  const f = frame - tB;
  const zin = lerp(0.45, 1, P(frame, tB - 6, 26, theme.ease.out));
  const zout = lerp(1, 0.62, P(frame, tC - 6, 14, theme.ease.in));
  const o = P(frame, tB - 2, 12) * (1 - P(frame, tC - 2, 12, theme.ease.in));
  // বন্ডের মাঝের বাঁধা ইলেকট্রন
  const bound: React.ReactNode[] = [];
  for (let j = 0; j < 4; j++)
    for (let i = 0; i < 7; i++) {
      const bx = B.x0 + i * B.gap + B.gap / 2;
      const by = B.y0 + j * B.gap;
      const isTarget = i === 3 && j === 1;
      if (isTarget && frame >= tRel) continue;
      bound.push(<Electron key={`${i}-${j}`} x={bx} y={by} r={13} o={0.75} glow={false} />);
    }
  // ফোটন
  const pStart = tB + 10;
  const pEnd = Math.max(pStart + 26, tRel - 3);
  const qq = P(frame, pStart, pEnd - pStart, theme.ease.soft);
  const SB = { x: 1560, y: 150 };
  const px = lerp(SB.x, PB.x, qq);
  const py = lerp(SB.y, PB.y, qq);
  const rot = (Math.atan2(PB.y - SB.y, PB.x - SB.x) * 180) / Math.PI;
  // মুক্ত ইলেকট্রনের পথ
  const q = P(frame, tRel, 46, theme.ease.out);
  const ex = lerp(PB.x, 1400, q);
  const ey = lerp(PB.y, 400, q) - Math.sin(Math.PI * q) * 90 + (q >= 1 ? Math.sin(frame / 14) * 6 : 0);
  const trail = [1, 2, 3, 4, 5].map((k) => {
    const qk = Math.max(0, q - k * 0.05);
    return { x: lerp(PB.x, 1400, qk), y: lerp(PB.y, 400, qk) - Math.sin(Math.PI * qk) * 90, o: (1 - k / 6) * 0.35 * (q < 1 ? 1 : 0) };
  });
  const holeP = sp(frame, 30, tRel + 4, theme.spring.bouncy);
  return (
    <g opacity={o} transform={`translate(960 600) scale(${zin * zout}) translate(-960 -600)`}>
      <rect x={200} y={230} width={1520} height={760} rx={40} fill={C.silicon} stroke={C.panelLine} strokeWidth={3} opacity={0.9} />
      <Lattice x0={B.x0} y0={B.y0} cols={8} rows={4} gap={B.gap} r={B.r} />
      {bound}
      {frame >= pStart && qq < 0.995 ? <Photon x={px} y={py} rot={rot} phase={frame / 2.4} scale={2} /> : null}
      <Flash x={PB.x} y={PB.y} frame={frame} at={tRel - 1} max={140} />
      {frame >= tRel
        ? trail.map((t, i) => <Electron key={i} x={t.x} y={t.y} r={12} o={t.o} glow={false} />)
        : null}
      {frame >= tRel ? <Electron x={ex} y={ey} r={20} /> : null}
      {frame >= tRel + 4 ? <g transform={`translate(${PB.x} ${PB.y}) scale(${holeP}) translate(${-PB.x} ${-PB.y})`}><Hole x={PB.x} y={PB.y} r={20} /></g> : null}
      {/* লিডার লাইন: ইলেকট্রন ← ট্যাগ */}
      {f > 70 ? <line x1={1400} y1={ey - 30} x2={1400} y2={215} stroke={C.primary} strokeWidth={3} opacity={0.5} /> : null}
    </g>
  );
};

/* ---------------- স্টেজ C: পিক্সেলে charge জমা ---------------- */
const body = { x: 500, y: 260, w: 720, h: 640 };
const well = { x: 700, y: 590, w: 320, h: 270 };
const events = [
  { x: 760, y: 390 },
  { x: 900, y: 440 },
  { x: 1040, y: 380 },
  { x: 830, y: 460 },
  { x: 960, y: 400 },
  { x: 1100, y: 450 },
];
const StageC: React.FC<{ frame: number }> = ({ frame }) => {
  const o = P(frame, tC - 2, 12);
  const sc = lerp(1.12, 1, P(frame, tC - 4, 22, theme.ease.out));
  const gap = Math.floor((tEnd - tC - 40) / events.length);
  const at = (k: number) => tC + 14 + k * gap;
  let level = 0;
  events.forEach((_, k) => {
    level += P(frame, at(k) + 54, 20, theme.ease.soft) * 0.135;
  });
  const marks: React.ReactNode[] = [];
  events.forEach((e, k) => {
    const a = at(k);
    const pq = P(frame, a - 20, 20, theme.ease.soft);
    if (frame >= a - 20 && frame < a) marks.push(<Photon key={`p${k}`} x={e.x} y={lerp(120, e.y, pq)} rot={90} phase={frame / 2.4 + k} />);
    marks.push(<Flash key={`f${k}`} x={e.x} y={e.y} frame={frame} at={a} max={70} />);
    const tq = P(frame, a + 4, 50, theme.ease.inOut);
    const dest = { x: well.x + 70 + (k % 3) * 90, y: well.y + 40 };
    const ex = lerp(e.x, dest.x, tq);
    const ey = lerp(e.y, dest.y, tq);
    if (frame >= a + 4 && tq < 0.98) marks.push(<Electron key={`e${k}`} x={ex} y={ey} r={14} o={1 - P(frame, a + 52, 6)} />);
  });
  return (
    <g opacity={o} transform={`translate(960 600) scale(${sc}) translate(-960 -600)`}>
      <rect x={body.x} y={body.y} width={body.w} height={body.h} rx={34} fill={C.silicon} stroke={C.panelLine} strokeWidth={3} />
      <rect x={body.x + 4} y={body.y + 4} width={body.w - 8} height={14} rx={7} fill={C.siliconHi} />
      <Lattice x0={body.x + 60} y0={body.y + 70} cols={8} rows={3} gap={86} r={11} o={0.55} />
      <PixelWell x={well.x} y={well.y} w={well.w} h={well.h} level={Math.min(1, level)} cols={7} rows={6} />
      {marks}
    </g>
  );
};

export const S2Mechanism: React.FC = () => {
  const frame = useCurrentFrame();
  const tAtomTag = wordFrame(2, "semiconductor", 6) - T0;
  return (
    <SceneShell>
      <Win from={0} to={tB + 8}>
        <Title text="photon শোষিত হয় semiconductor-এ" top={70} delay={4} highlight={{ 0: C.accent }} />
      </Win>
      <Win from={tB - 4} to={tC + 8}>
        <Title text="শক্তি পেয়ে electron মুক্ত হয়" top={70} delay={4} highlight={{ 2: C.primary }} />
      </Win>
      <Win from={tC - 4} to={tEnd + 200}>
        <Title text="pixel-এ বৈদ্যুতিক charge জমা হয়" top={70} delay={4} highlight={{ 2: C.primary }} />
      </Win>

      <FullSvg>
        <StageA frame={frame} />
        <StageB frame={frame} />
        <StageC frame={frame} />
      </FullSvg>

      {/* লেবেল */}
      <Win from={Math.max(8, tPhotonWord)} to={tB - 20}>
        <Tag x={1400} y={250} text="Photon" sub="আলোর ক্ষুদ্র কণা" color={C.accent} delay={0} anchor="l" />
      </Win>
      <Win from={Math.max(12, tAtomTag)} to={tB - 6}>
        <Tag x={360} y={385} text="Semiconductor" color={C.text} delay={0} anchor="l" />
      </Win>
      <Win from={tRel + 40} to={tC + 6}>
        <Tag x={1400} y={190} text="মুক্ত charge বাহক" color={C.primary} delay={0} />
        <Tag x={960} y={598} text="hole" color={C.text} delay={14} size={34} />
      </Win>
      <Win from={tC + 6} to={tEnd + 200}>
        <Tag x={1270} y={330} text="Pixel" color={C.text} delay={4} anchor="l" />
        <Tag x={1080} y={760} text="জমা হওয়া charge" color={C.primary} delay={30} anchor="l" />
      </Win>

      {/* সাউন্ড */}
      <Sfx at={8} name="whoosh" vol={0.22} rate={1} />
      <Sfx at={Math.max(8, tPhotonWord)} name="pop" vol={0.26} />
      <Sfx at={tB - 18} name="click" vol={0.3} rate={0.96} />
      <Sfx at={tRel} name="click" vol={0.3} rate={1.05} />
      <Sfx at={tRel + 40} name="pop" vol={0.26} rate={1.06} />
      <Sfx at={tC + 6} name="pop" vol={0.26} rate={0.94} />
      <Sfx at={tC + 34} name="pop" vol={0.24} rate={1.1} />
    </SceneShell>
  );
};
