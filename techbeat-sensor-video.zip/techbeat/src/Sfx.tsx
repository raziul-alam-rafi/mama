import React from "react";
import {Audio, Sequence, staticFile} from "remotion";
import {E} from "./events";
import {FPS, SceneId, sceneRange} from "./timing";
import meta from "./sfx-meta.json";

type Kind = "pop" | "click" | "whoosh" | "chime" | "thud";
const VOL: Record<Kind, number> = {pop: 0.3, click: 0.34, whoosh: 0.22, chime: 0.28, thud: 0.28};
const PRE = 3; // SFX lands 3 frames before the visual

// [scene, local frame, sound]. Only major entries, reveals and transitions.
const EVENTS: [SceneId, number, Kind][] = [
  ["sensor", 4, "thud"],
  ["sensor", E.sensor.lens, "pop"],
  ["sensor", E.sensor.sensor, "chime"],
  ["sensor", E.sensor.pivot, "whoosh"],
  ["sensor", E.sensor.pill, "pop"],
  ["pixel", E.pixel.zoomIn, "whoosh"],
  ["pixel", E.pixel.ring, "click"],
  ["pixel", E.pixel.label, "pop"],
  ["pixel", E.pixel.zoomOut, "whoosh"],
  ["pixel", E.pixel.chip, "pop"],
  ["pixel", E.pixel.sweep, "pop"],
  ["pixel", E.pixel.zoomPatch, "whoosh"],
  ["light", E.light.detect, "click"],
  ["light", E.light.more, "pop"],
  ["light", E.light.less, "pop"],
  ["light", E.light.compare, "click"],
  ["electric", 0, "whoosh"],
  ["electric", E.electric.notEq, "pop"],
  ["electric", E.electric.box, "pop"],
  ["electric", E.electric.zoomIn, "whoosh"],
  ["electric", E.electric.photodiode, "chime"],
];

const RATES = [1, 1.06, 0.94];

export const Sfx: React.FC = () => {
  const count: Record<string, number> = {};
  return (
    <>
      {EVENTS.map(([scene, local, kind], i) => {
        const n = (count[kind] = (count[kind] ?? -1) + 1);
        const rate = RATES[n % RATES.length];
        const from = Math.max(0, sceneRange(scene).from + local - PRE);
        const len = Math.ceil((meta[kind].seconds / rate) * FPS) + 2;
        return (
          <Sequence key={i} from={from} durationInFrames={len}>
            <Audio
              src={staticFile(`sfx/${kind}.wav`)}
              volume={VOL[kind] * (n % 2 ? 0.92 : 1)}
              playbackRate={rate}
            />
          </Sequence>
        );
      })}
    </>
  );
};
