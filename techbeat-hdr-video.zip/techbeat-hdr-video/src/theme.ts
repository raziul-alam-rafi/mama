// theme.ts — সব রং, ইজিং, spring, ফন্ট এখানে। কম্পোনেন্টে সরাসরি রঙের কোড নয়।
import { Easing } from "remotion";
import { loadFont } from "@remotion/google-fonts/HindSiliguri";

const { fontFamily } = loadFont("normal", {
  weights: ["500", "600", "700"],
  subsets: ["bengali", "latin"],
});

export const theme = {
  colors: {
    bg: "#0B1020",
    bgAlt: "#111833",
    surface: "#172043",
    surfaceHi: "#1F2A55",
    line: "#2E3C72",
    hero: "#4F8CFF", // আলোর পথ / মূল সিস্টেম
    accent: "#FFB84D", // বৈদ্যুতিক সংকেত / গুরুত্বপূর্ণ অংশ
    text: "#F4F7FF",
    textDim: "#9FAAD0",
    ok: "#4FD6A8",
    warn: "#FF7B7B",
    black: "#05070F",
    glowHero: "rgba(79,140,255,0.45)",
    glowAccent: "rgba(255,184,77,0.40)",
  },
  // ছবির দৃশ্যের "আসল" radiance (0–255 ছাড়িয়ে যেতে পারে); exposure gain দিয়ে গুণ হয়
  photo: {
    wall: [82, 90, 118], floor: [60, 52, 58], frame: [58, 56, 64], sill: [92, 86, 82],
    skin: [205, 146, 120], neck: [188, 130, 106], hair: [48, 36, 34], shirt: [96, 104, 150],
    eye: [28, 22, 24],
    skyTop: [380, 640, 1000], skyBottom: [560, 860, 1000], cloud: [1000, 1050, 1100],
    sun: [2400, 2200, 1500], hills: [180, 300, 190], hills2: [140, 250, 160],
  },
  fonts: { display: `${fontFamily}, sans-serif`, body: `${fontFamily}, sans-serif` },
  radius: { sm: 14, md: 24, lg: 36 },
  shadow: {
    card: "0 30px 70px -20px rgba(0,0,0,0.65), inset 0 1px 0 rgba(255,255,255,0.09)",
    soft: "0 14px 34px -12px rgba(0,0,0,0.55)",
  },
  ease: {
    out: Easing.bezier(0.16, 1, 0.3, 1),
    inOut: Easing.bezier(0.83, 0, 0.17, 1),
    in: Easing.bezier(0.7, 0, 0.84, 0),
  },
  spring: {
    snappy: { damping: 14, stiffness: 160, mass: 0.6 },
    smooth: { damping: 20, stiffness: 90, mass: 1 },
    bouncy: { damping: 11, stiffness: 170, mass: 0.7 },
  },
} as const;

export type RGB = readonly [number, number, number] | readonly number[];
