# Component reference (what each named object represents)

| Scene object (mesh name) | Real-world part | Notes |
|---|---|---|
| Studio_Camera / Camera_Body / Lens_Barrel_1,2 / Lens_Front_Element | Broadcast studio camera, zoom lens, hood, viewfinder, tally light, tripod | generic design |
| Signal_Cable_Connector | Cable connector at the camera rear | signal leaves the camera here |
| BROADCAST_CURVE cable | Camera cable / feeder to the transmitter | stylised route |
| Transmitter_Tower | Triangular lattice mast, red/white aviation bands, panel array, beacon | generic |
| Yagi_Antenna: Reflector, Driven_Element_Folded_Dipole, Director_1..6, Boom, mast | Yagi-Uda TV antenna | proportions from sources.md |
| House_Cutaway | Cut-away house, front open | for camera access |
| Television_Cabinet, Cabinet_Front/Rear, Front_Bezel, CRT_Glass_Envelope, Phosphor_Screen, Deflection_Yoke_Housing | Consumer CRT TV exterior | internal gun/mask not modelled (not in script) |
| Explainer_Image_To_Signal | Overlay: scanned picture -> line waveform | not a physical object |

## If the script is extended to the CRT interior, research and model first
Glass envelope, electron gun (cathode, control grid, focusing/accelerating anodes), deflection yoke,
phosphor screen, shadow mask or aperture grille (do not mix types), high-voltage anode connection, circuit boards.
