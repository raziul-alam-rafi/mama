import React from "react";
import { useCurrentFrame } from "remotion";
import { theme, alpha, mix } from "../theme";
import { Draw, Pt, pointAt, toD, ease } from "./ui";

// ক্যামেরার পাশ-কাটা (cross-section) দৃশ্য, সরল পরিকল্পিত চিত্র (schematic)।
// অপটিক্যাল অক্ষ y=270। বাঁ থেকে ডানে: লেন্স → অ্যাপারচার → সেন্সর → প্রসেসর → ডিসপ্লে।
export const VB = { x: -250, w: 1250, h: 520 };
const AX = 270;

export type Parts = {
  body?: number;
  lens?: number;
  aperture?: number;
  sensor?: number;
  chip?: number;
  display?: number;
};

const T = theme.colors;

const biconvex = (xc: number, h: number, b: number) =>
  `M${xc} ${AX - h / 2} Q${xc + b * 2} ${AX} ${xc} ${AX + h / 2} Q${xc - b * 2} ${AX} ${xc} ${AX - h / 2} Z`;

export const RAY_OFFS = [-62, -31, 0, 31, 62];
export const rayPts = (o: number): Pt[] => [
  [-240, AX + o],
  [215, AX + o],
  [648, AX],
];

// আলো → বিদ্যুৎ পথ (সেন্সর থেকে প্রসেসর, প্রসেসর থেকে ডিসপ্লে)
export const SIGNAL_PATH: Pt[] = [
  [656, 300],
  [745, 300],
  [745, 345],
  [745, 380],
  [790, 380],
  [830, 380],
  [830, 270],
  [866, 270],
];
// পুরো যাত্রাপথ (আলো + সিগন্যাল)
export const JOURNEY: Pt[] = [[-240, AX], [215, AX], [320, AX], [648, AX], ...SIGNAL_PATH];

export const Cutaway: React.FC<{
  width: number;
  p: Parts;
  open?: number; // অ্যাপারচারের অর্ধ-খোলা (px)
  rays?: number; // রশ্মির অগ্রগতি 0..1
  glow?: number; // সেন্সর গ্লো 0..1
  signal?: number; // সিগন্যাল তার বরাবর 0..1
  hl?: string;
  children?: React.ReactNode;
}> = ({ width, p, open = 70, rays = 0, glow = 0, signal = 0, hl, children }) => {
  const frame = useCurrentFrame();
  const g = (k: string) => (hl === k ? 1 : 0);
  const stroke = (k: string) => (hl === k ? T.text : T.line);
  const breathe = 1 + Math.sin(frame / 20) * 0.12;
  const b = p.body ?? 0;
  const lens = p.lens ?? 0;
  const ap = p.aperture ?? 0;
  const sn = p.sensor ?? 0;
  const ch = p.chip ?? 0;
  const dp = p.display ?? 0;
  const sigPts = SIGNAL_PATH;

  return (
    <svg
      width={width}
      height={(width * VB.h) / VB.w}
      viewBox={`${VB.x} 0 ${VB.w} ${VB.h}`}
      style={{ overflow: "visible", display: "block" }}
    >
      {/* অপটিক্যাল অক্ষ */}
      <Draw d={`M-240 ${AX} H700`} p={lens} stroke={T.lineSoft} w={1.5} dash="7 9" />

      {/* বডি: পেছনের প্লেট + গভীরতার রেখা + সামনের বডি */}
      <Draw d="M356 88 H900 Q926 88 926 114 V382 Q926 408 900 408 H356" p={b} stroke={T.lineSoft} w={1.5} />
      <Draw d="M330 110 L356 88 M900 110 L926 88 M900 430 L926 408" p={b} stroke={T.lineSoft} w={1.5} />
      <Draw
        d="M356 110 H874 Q900 110 900 136 V404 Q900 430 874 430 H356 Q330 430 330 404 V136 Q330 110 356 110 Z"
        p={b}
        stroke={T.line}
        w={2.4}
        fill={alpha(T.panel, 0.5)}
      />
      <Draw d="M372 122 H860" p={b} stroke={alpha(T.text, 0.22)} w={1.5} />

      {/* লেন্স ব্যারেল ও উপাদান */}
      <g opacity={Math.min(1, lens * 2)}>
        <Draw
          d="M96 188 Q96 172 112 172 H316 Q332 172 332 188 V352 Q332 368 316 368 H112 Q96 368 96 352 Z"
          p={lens}
          stroke={stroke("lens")}
          w={2.4}
          fill={alpha(T.bgAlt, 0.7)}
        />
        <Draw d="M78 160 V380" p={lens} stroke={T.line} w={5} />
        {[
          { x: 150, h: 150, b: 26 },
          { x: 215, h: 136, b: 22 },
          { x: 276, h: 112, b: 17 },
        ].map((e, i) => (
          <Draw
            key={i}
            d={biconvex(e.x, e.h, e.b)}
            p={ease(lens, [0.15 + i * 0.12, 0.6 + i * 0.12], [0, 1])}
            stroke={hl === "lens" ? T.text : alpha(T.text, 0.75)}
            w={2.2}
            fill={alpha(T.hero, hl === "lens" ? 0.34 : 0.17)}
          />
        ))}
      </g>

      {/* অ্যাপারচার ব্লেড */}
      <g opacity={Math.min(1, ap * 2)}>
        <path
          d={`M306 172 H324 V${AX - open - 6} L316 ${AX - open} H306 Z`}
          fill={hl === "aperture" ? T.text : T.textDim}
          opacity={ap}
        />
        <path
          d={`M306 368 H324 V${AX + open + 6} L316 ${AX + open} H306 Z`}
          fill={hl === "aperture" ? T.text : T.textDim}
          opacity={ap}
        />
      </g>

      {/* রশ্মি: প্রতিটি রশ্মি লেন্সের তলে বেঁকে সেন্সরের এক বিন্দুতে মেলে */}
      <g style={{ filter: `drop-shadow(0 0 7px ${T.glowAccent})` }}>
        {RAY_OFFS.map((o, i) => {
          const pts = rayPts(o);
          const rp = ease(rays, [i * 0.04, 0.7 + i * 0.04], [0, 1], theme.ease.inOut);
          return <Draw key={i} d={toD(pts)} p={rp} stroke={T.accent} w={2.4} />;
        })}
        {rays >= 0.98 &&
          RAY_OFFS.flatMap((o, i) =>
            [0, 0.5].map((k) => {
              const t = ((frame * 0.016 + i * 0.11 + k) % 1 + 1) % 1;
              const [x, y] = pointAt(rayPts(o), t);
              return <circle key={`${i}-${k}`} cx={x} cy={y} r={4.2} fill={T.accent} />;
            }),
          )}
      </g>

      {/* সেন্সর */}
      <g
        opacity={Math.min(1, sn * 2)}
        style={{ filter: `drop-shadow(0 0 ${(glow * 20 * breathe).toFixed(1)}px ${T.glowHero})` }}
      >
        <Draw d="M656 195 H684 V345 H656" p={sn} stroke={T.lineSoft} w={1.5} fill={alpha(T.bgAlt, 0.9)} />
        <Draw
          d="M642 205 H656 V335 H642 Z"
          p={sn}
          stroke={hl === "sensor" ? T.text : T.hero}
          w={2.4}
          fill={mix(T.panel, T.hero, 0.3 + glow * 0.4)}
        />
        {Array.from({ length: 12 }, (_, i) => (
          <line key={i} x1={644} x2={654} y1={214 + i * 10} y2={214 + i * 10} stroke={alpha(T.text, 0.35)} strokeWidth={1} opacity={sn} />
        ))}
      </g>

      {/* প্রসেসর চিপ ও তার */}
      <g opacity={Math.min(1, ch * 2)}>
        <Draw d={`M${sigPts[0][0] + 4} 335 V380 H700`} p={ch} stroke={alpha(T.hero, 0.55)} w={2} />
        <Draw
          d="M708 345 H782 Q790 345 790 353 V407 Q790 415 782 415 H708 Q700 415 700 407 V353 Q700 345 708 345 Z"
          p={ch}
          stroke={hl === "chip" ? T.text : T.line}
          w={2.4}
          fill={alpha(T.panel, 0.95)}
        />
        <Draw d="M722 362 H768 V398 H722 Z" p={ch} stroke={T.hero} w={1.8} fill={alpha(T.hero, 0.22)} />
        {Array.from({ length: 5 }, (_, i) => (
          <g key={i} opacity={ch}>
            <line x1={708 + i * 17} x2={708 + i * 17} y1={338} y2={345} stroke={T.line} strokeWidth={2} />
            <line x1={708 + i * 17} x2={708 + i * 17} y1={415} y2={422} stroke={T.line} strokeWidth={2} />
          </g>
        ))}
      </g>

      {/* ডিসপ্লে (পেছনের পর্দা) ও তার */}
      <g opacity={Math.min(1, dp * 2)}>
        <Draw d="M790 380 H830 V270 H866" p={dp} stroke={alpha(T.hero, 0.55)} w={2} />
        <Draw
          d="M866 164 H882 V376 H866 Z"
          p={dp}
          stroke={hl === "display" ? T.text : T.line}
          w={2.4}
          fill={mix(T.bg, T.hero, 0.25)}
        />
      </g>

      {/* সিগন্যাল পালস: সেন্সর → প্রসেসর → ডিসপ্লে */}
      {signal > 0 && (
        <g style={{ filter: `drop-shadow(0 0 8px ${T.glowHero})` }}>
          <Draw d={toD(sigPts)} p={ease(signal, [0, 1], [0, 1], theme.ease.inOut)} stroke={T.hero} w={3} />
          {[0, 0.33, 0.66].map((k, i) => {
            const t = (((frame * 0.014 + k) % 1) + 1) % 1;
            const [x, y] = pointAt(sigPts, t * signal);
            return <circle key={i} cx={x} cy={y} r={5} fill={T.text} opacity={signal} />;
          })}
        </g>
      )}
      {children}
    </svg>
  );
};

/** অ্যাপারচার-আইরিস (ছয় ব্লেড) — খোলা/বন্ধ হয় */
export const Iris: React.FC<{ size: number; open: number; rot?: number; color?: string }> = ({
  size,
  open,
  rot = 0,
  color = theme.colors.hero,
}) => {
  const R = 100;
  const cid = `iris${React.useId().replace(/[^a-zA-Z0-9]/g, "")}`;
  const r = 14 + open * 56;
  const vs = Array.from({ length: 6 }, (_, k) => {
    const a = ((k * 60 + 30 + rot) * Math.PI) / 180;
    const rr = r / Math.cos(Math.PI / 6);
    return [Math.cos(a) * rr, Math.sin(a) * rr] as Pt;
  });
  return (
    <svg width={size} height={size} viewBox="-110 -110 220 220" style={{ overflow: "visible" }}>
      <circle r={R} fill={alpha(theme.colors.bgAlt, 0.9)} stroke={theme.colors.line} strokeWidth={3} />
      <circle r={R - 12} fill="none" stroke={theme.colors.lineSoft} strokeWidth={2} />
      <clipPath id={cid}>
        <circle r={R - 6} />
      </clipPath>
      <g clipPath={`url(#${cid})`}>
      {vs.map((v, k) => {
        const n = vs[(k + 1) % 6];
        const dx = n[0] - v[0];
        const dy = n[1] - v[1];
        const L = Math.hypot(dx, dy);
        const ex = n[0] + (dx / L) * 90;
        const ey = n[1] + (dy / L) * 90;
        return (
          <line
            key={k}
            x1={v[0]}
            y1={v[1]}
            x2={ex}
            y2={ey}
            stroke={alpha(theme.colors.text, 0.45)}
            strokeWidth={3}
            strokeLinecap="round"
          />
        );
      })}
      </g>
      <path
        d={`M${vs.map((v) => `${v[0].toFixed(2)} ${v[1].toFixed(2)}`).join(" L")} Z`}
        fill={alpha(color, 0.9)}
        stroke={theme.colors.text}
        strokeWidth={2.5}
      />
    </svg>
  );
};
