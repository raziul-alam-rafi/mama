# Techbeat Inside — Camera: Aperture & Shutter (Prototype v0.1)

> স্ট্যাটাস: এই প্রোজেক্টের সোর্স কোড লেখা হয়েছে, কিন্তু **Remotion/Three.js রেন্ডার এখনো কোথাও চালিয়ে যাচাই করা হয়নি**
> (যেখানে এটি বানানো হয়েছে সেখানে ইন্টারনেট ছিল না)। প্রথমে নিচের ধাপ ১–৪ চালিয়ে দেখুন।

## যা যাচাই হয়েছে / হয়নি
| বিষয় | অবস্থা |
|---|---|
| SRT পার্সার, ১৭ cue, ৩০০৪ ফ্রেম (১:৪০.১২০) | যাচাই হয়েছে |
| SFX জেনারেটর (৪৮ kHz WAV, ৫টি ফাইল) ও asset checker | যাচাই হয়েছে |
| Ray-blocking গণিত (aperture ছোট → কম রশ্মি) | যাচাই হয়েছে |
| `npm install`, TypeScript compile | **যাচাই হয়নি** |
| WebGL (headless Chromium), Remotion Studio, still/MP4 রেন্ডার | **যাচাই হয়নি** |
| MP4-তে অডিও সিঙ্ক, লাউডনেস (-14 LUFS) | **যাচাই হয়নি** |
| lockfile (`package-lock.json`) | নেই — প্রথম `npm install` এর পর তৈরি হবে |

## Prerequisites
GitHub account, Codespaces (Linux). Node 18+ (Codespaces default Node চলবে)।

## Codespaces — ক্রমানুযায়ী কমান্ড (প্রোজেক্ট ফোল্ডারের ভেতরে চালান)
```bash
# ১) ফোল্ডারে ঢুকুন (আপলোড ও extract করার পর)
tar -xzf Techbeat-Camera-Aperture-Shutter.tar.gz
cd Techbeat-Camera-Aperture-Shutter

# ২) ইনস্টল + সাউন্ড তৈরি
npm run setup

# ৩) Remotion প্যাকেজ ভার্সন মিলছে কি না দেখুন (সব remotion প্যাকেজ একই ভার্সন হতে হবে)
npm run versions

# ৪) চেক: SRT + অডিও ফাইল
npm run check
npm run typecheck

# ৫) WebGL ডায়াগনস্টিক (এটি পাস না করলে নিচের ধাপ চালাবেন না)
npm run gl-check          # সফল হলে out/gl-check.png এ একটি নীল ঘূর্ণায়মান কিউব থাকবে

# ৬) Remotion Studio
npm run studio            # তারপর Codespaces এর "Ports" ট্যাবে 3000 পোর্টের "Open in Browser" চাপুন
                          # বাম পাশে Composition: ApertureProto বেছে নিন

# ৭) টেস্ট স্টিল ফ্রেম (দেখুন aperture খোলা/বন্ধ ঠিক আছে কি না)
npm run stills            # out/proto_f*.png

# ৮) ১৫ সেকেন্ডের টেস্ট ভিডিও
npm run render:test       # out/proto.mp4
```
ডাউনলোড: VS Code এক্সপ্লোরারে `out/proto.mp4` এ রাইট ক্লিক → **Download**।

**ফাইনাল ফুল ভিডিওর স্ক্রিপ্ট (`master`) এখনো নেই** — প্রোটোটাইপ পাস করার পর যোগ করা হবে।

## প্রোটোটাইপে কী আছে
- Composition `ApertureProto` — 1920×1080, 30 FPS, ১৫ সেকেন্ড (450 ফ্রেম)।
- ৮-ব্লেডের aperture, স্বচ্ছ লেন্স ব্যারেল, সমান্তরাল আলোর রশ্মি, সেন্সর প্লেট।
- Aperture ছোট হলে ব্লেডে আটকে যাওয়া রশ্মি থামে এবং সেন্সরের উজ্জ্বলতা কমে (একই গণিত `src/three/optics.ts` থেকে আসে)।
- ক্যামেরা অরবিট (ফ্রেম-নির্ভর, deterministic)। SFX টাইমলাইন: `src/audioTimeline.json`।
- **সরলীকরণ:** রশ্মি সোজা দেখানো হয়েছে, লেন্সের refraction/focus দেখানো হয়নি। `sensor_glow` শব্দটি ব্যাখ্যামূলক, আলোর আসল শব্দ নয়।

## Troubleshooting
- **`npm run versions` এ ভার্সন অমিল:** `npm install --save-exact remotion@4 @remotion/cli@4 @remotion/three@4` চালান।
- **gl-check ব্যর্থ / কালো ছবি / "WebGL" ত্রুটি:** `remotion.config.ts` এ `angle` বদলে `swangle` বা `swiftshader` দিয়ে আবার চেষ্টা করুন; অথবা `npx remotion still src/index.ts GlCheck out/gl-check.png --gl=swangle`। এরপরও না হলে ত্রুটির পুরো লেখা আমাকে পাঠান।
- **Chromium ডাউনলোড/ডিপেন্ডেন্সি ত্রুটি:** `npx remotion browser ensure` চালান; লাইব্রেরি না থাকলে `sudo apt-get update && sudo apt-get install -y libnss3 libatk1.0-0 libatk-bridge2.0-0 libcups2 libgbm1 libasound2`।
- **"MISSING sfx/..." :** `npm run sfx` চালান।
- **রেন্ডার ধীর/মেমরি শেষ:** `remotion.config.ts` এ `setConcurrency(1)` দিন।
- **অনুপস্থিত script:** `npm run` লিখে সব বৈধ স্ক্রিপ্টের তালিকা দেখুন।
