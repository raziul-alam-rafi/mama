// Single source of truth. Palette from the techbeat inside brand.
import { Easing } from "remotion";

export const theme = {
  colors: {
    bg: "#0B1020",
    bgAlt: "#121A33",
    primary: "#4F8CFF", // main blue (housing, structure)
    accent: "#FFB84D", // amber — the ONE hero highlight per frame (the aperture/iris)
    text: "#F4F7FF",
    textDim: "#A9B4D0",
    ray: "#FFF1D1", // light rays: warm white so they read against the blue housing
    sensorBody: "#18213D",
  },
  fonts: { family: "Noto Sans Bengali" },
  ease: {
    out: Easing.bezier(0.16, 1, 0.3, 1),
    inOut: Easing.bezier(0.83, 0, 0.17, 1),
    soft: Easing.bezier(0.45, 0, 0.25, 1), // gentler than inOut: camera moves
    in: Easing.bezier(0.7, 0, 0.84, 0),
  },
  spring: {
    snappy: { damping: 14, stiffness: 160, mass: 0.6 },
    smooth: { damping: 20, stiffness: 90, mass: 1 },
  },
} as const;
