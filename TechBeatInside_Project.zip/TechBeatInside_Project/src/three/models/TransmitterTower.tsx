import React, {useMemo} from 'react';
import * as THREE from 'three';
import {TOWER_H} from '../animations/paths';
import {beamGeometry, ContactShadow} from './parts';

type V3 = [number, number, number];

/** Triangular lattice broadcast mast with red/white aviation banding and a top antenna array. */
export const TransmitterTower: React.FC<{position: V3; frame: number}> = ({position, frame}) => {
  const {red, white} = useMemo(() => {
    const levels = 14;
    const baseR = 4.2;
    const topR = 0.9;
    const angles = [90, 210, 330].map((d) => (d * Math.PI) / 180);
    const rAt = (y: number) => THREE.MathUtils.lerp(baseR, topR, y / TOWER_H);
    const pt = (i: number, y: number): V3 => [Math.cos(angles[i]) * rAt(y), y, Math.sin(angles[i]) * rAt(y)];
    const redList: {a: V3; b: V3; r: number}[] = [];
    const whiteList: {a: V3; b: V3; r: number}[] = [];
    for (let l = 0; l < levels; l++) {
      const y0 = (l / levels) * TOWER_H;
      const y1 = ((l + 1) / levels) * TOWER_H;
      const target = l % 2 === 0 ? redList : whiteList;
      for (let i = 0; i < 3; i++) {
        const j = (i + 1) % 3;
        target.push({a: pt(i, y0), b: pt(i, y1), r: 0.16 - 0.08 * (y0 / TOWER_H)}); // legs
        target.push({a: pt(i, y1), b: pt(j, y1), r: 0.06}); // horizontals
        target.push({a: pt(i, y0), b: pt(j, y1), r: 0.05}); // diagonals
      }
    }
    return {red: beamGeometry(redList), white: beamGeometry(whiteList)};
  }, []);
  const blink = Math.sin(frame * 0.35) > 0 ? 1 : 0.15;
  return (
    <group position={position} name="Transmitter_Tower">
      <ContactShadow position={[0, 0.03, 0]} size={[16, 16]} opacity={0.8} />
      <mesh geometry={red}>
        <meshStandardMaterial color="#c9332b" roughness={0.55} metalness={0.4} />
      </mesh>
      <mesh geometry={white}>
        <meshStandardMaterial color="#e8e6e0" roughness={0.55} metalness={0.4} />
      </mesh>
      {/* concrete base + equipment hut */}
      <mesh position={[0, 0.3, 0]}>
        <cylinderGeometry args={[5, 5.4, 0.6, 24]} />
        <meshStandardMaterial color="#6d6f72" roughness={0.9} />
      </mesh>
      <mesh position={[9, 1.4, 2]}>
        <boxGeometry args={[6, 2.8, 4]} />
        <meshStandardMaterial color="#8a8d92" roughness={0.8} />
      </mesh>
      {/* top mast + panel array */}
      <mesh position={[0, TOWER_H + 4, 0]}>
        <cylinderGeometry args={[0.1, 0.16, 8, 12]} />
        <meshStandardMaterial color="#d9d9d9" roughness={0.4} metalness={0.8} />
      </mesh>
      {[0, 120, 240].map((d) => (
        <mesh
          key={d}
          position={[Math.cos((d * Math.PI) / 180) * 1.0, TOWER_H + 2.2, Math.sin((d * Math.PI) / 180) * 1.0]}
          rotation={[0, (-d * Math.PI) / 180 + Math.PI / 2, 0]}
        >
          <boxGeometry args={[0.15, 3.2, 0.9]} />
          <meshStandardMaterial color="#e6e6e6" roughness={0.5} metalness={0.4} />
        </mesh>
      ))}
      {/* aviation beacon */}
      <mesh position={[0, TOWER_H + 8.3, 0]}>
        <sphereGeometry args={[0.3, 12, 10]} />
        <meshBasicMaterial color="#ff2a1c" transparent opacity={blink} toneMapped={false} />
      </mesh>
    </group>
  );
};
