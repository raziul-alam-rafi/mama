import React from "react";
import { theme } from "../theme";
import { Label } from "./ui";

export const DARK_POS = 0.17; // "মুখ" (ছায়া) বারের কোথায়
export const BRIGHT_POS = 0.85; // "আকাশ"

/** উজ্জ্বলতার সীমা; ব্র্যাকেট = এক ছবিতে যতটা ধরা যায় (lo..hi) */
export const RangeBar: React.FC<{ w: number; lo: number; hi: number; bracketLabel?: string; bracketColor?: string; showMarkers?: boolean; pulseFace?: number; pulseSky?: number }> =
({ w, lo, hi, bracketLabel, bracketColor = theme.colors.hero, showMarkers = true, pulseFace = 0, pulseSky = 0 }) => {
  const H = 38;
  const marker = (pos: number, text: string, pulse: number) => {
    const inside = pos >= lo && pos <= hi;
    const col = inside ? theme.colors.ok : theme.colors.warn;
    return (
      <div style={{ position: "absolute", left: pos * w, top: -96, transform: "translateX(-50%)", display: "flex", flexDirection: "column", alignItems: "center", gap: 6,
        opacity: inside ? 1 : 0.8, scale: `${1 + pulse * 0.12}` }}>
        <Label size={36} color={col} style={{ whiteSpace: "nowrap", textShadow: pulse > 0 ? `0 0 24px ${col}` : undefined }}>{text}</Label>
        <div style={{ width: 4, height: 30, background: col, borderRadius: 2 }} />
      </div>
    );
  };
  return (
    <div style={{ position: "relative", width: w, height: H, marginTop: 100 }}>
      <div style={{ position: "absolute", inset: 0, borderRadius: H / 2, border: `2px solid ${theme.colors.line}`,
        background: `linear-gradient(90deg, ${theme.colors.black}, #5A6280 55%, ${theme.colors.text})`, boxShadow: theme.shadow.soft }} />
      {/* সীমার বাইরের অংশ ক্লিপড */}
      <div style={{ position: "absolute", left: 0, top: 0, width: lo * w, height: H, borderRadius: `${H / 2}px 0 0 ${H / 2}px`, background: `${theme.colors.bg}CC` }} />
      <div style={{ position: "absolute", left: hi * w, top: 0, width: (1 - hi) * w, height: H, borderRadius: `0 ${H / 2}px ${H / 2}px 0`, background: `${theme.colors.bg}CC` }} />
      <div style={{ position: "absolute", left: lo * w, top: -9, width: (hi - lo) * w, height: H + 18, borderRadius: (H + 18) / 2,
        border: `4px solid ${bracketColor}`, boxShadow: `0 0 26px ${bracketColor}88, inset 0 0 18px ${bracketColor}33` }} />
      {showMarkers && marker(DARK_POS, "মুখ", pulseFace)}
      {showMarkers && marker(BRIGHT_POS, "আকাশ", pulseSky)}
      <div style={{ position: "absolute", top: H + 24, left: 0, right: 0, display: "flex", justifyContent: "space-between" }}>
        <Label size={32} color={theme.colors.textDim}>অন্ধকার</Label>
        {bracketLabel && <Label size={34} color={bracketColor} weight={700}>{bracketLabel}</Label>}
        <Label size={32} color={theme.colors.textDim}>উজ্জ্বল</Label>
      </div>
    </div>
  );
};
