# Camera plan

| Shot | Move | Why |
|---|---|---|
| A | slow dolly-in from room view to TV screen, fov 40 -> 30 | establish "TV shows a cricket match" |
| B | high crane behind the camera, descends and arcs to a low side view of the camera aimed at the pitch | show WHERE the camera is and WHAT it captures |
| C | macro push-in to the lens front element | focus on the device that "captures" |
| D | arc behind the camera to the overlay panels | image -> signal explanation |
| E | continue from D, lock on the signal head, follow along the cable, crane up the tower | follow the signal to the transmitter |
| F | long tracking move following the wave front across the landscape, settling on the Yagi | signal travels to the antenna |
| G | descend along the cable down the house wall, enter the room view, push-in to the TV screen | arrive at the home TV |

All paths are Catmull-Rom splines with ease-in-out; no random shake; pure functions of the frame number.
