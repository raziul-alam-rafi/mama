import React, { useEffect, useState } from "react";
import { AbsoluteFill, cancelRender, continueRender, delayRender } from "remotion";
import * as THREE from "three";

/**
 * Minimal WebGL probe (no R3F, no scene). Creates a real THREE.WebGLRenderer in Remotion's browser.
 * - success: logs GLPROBE_RENDERER=<gpu string> and renders it as text
 * - failure: cancelRender() -> `remotion still` exits non-zero, so scripts can detect it.
 */
export const GlProbe: React.FC = () => {
  const [info, setInfo] = useState("probing...");
  const [handle] = useState(() => delayRender("GlProbe"));
  useEffect(() => {
    try {
      const canvas = document.createElement("canvas");
      const renderer = new THREE.WebGLRenderer({ canvas, antialias: true });
      const gl = renderer.getContext();
      const ext = gl.getExtension("WEBGL_debug_renderer_info");
      const name = ext ? String(gl.getParameter(ext.UNMASKED_RENDERER_WEBGL)) : "unknown (no debug ext)";
      const ver = gl.getParameter(gl.VERSION);
      // draw one lit mesh to prove shaders compile and draw calls work, not just context creation
      const scene = new THREE.Scene();
      const cam = new THREE.PerspectiveCamera(50, 1, 0.1, 10);
      cam.position.z = 3;
      scene.add(new THREE.Mesh(new THREE.TorusKnotGeometry(0.6, 0.2, 64, 16), new THREE.MeshStandardMaterial({ color: "#4F8CFF" })));
      scene.add(new THREE.DirectionalLight("#ffffff", 2).translateX(2).translateY(2).translateZ(3));
      renderer.setSize(64, 64);
      renderer.render(scene, cam);
      const err = gl.getError();
      if (err !== 0) throw new Error("GL error after draw: " + err);
      console.log("GLPROBE_RENDERER=" + name + " | " + ver);
      renderer.dispose();
      setInfo(name);
      continueRender(handle);
    } catch (e) {
      console.log("GLPROBE_FAILED=" + (e as Error).message);
      cancelRender(e as Error);
    }
  }, [handle]);
  return (
    <AbsoluteFill style={{ background: "#0B1020", color: "#F4F7FF", fontSize: 40, padding: 60, fontFamily: "sans-serif" }}>
      WebGL OK: {info}
    </AbsoluteFill>
  );
};
