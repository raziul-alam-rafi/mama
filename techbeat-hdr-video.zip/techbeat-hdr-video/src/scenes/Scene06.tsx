// সিন ৬ (cue 9): ফলাফল — আকাশ ও মুখ দুটোই বিস্তারিত (Glossy UI + Checklist)
import React from "react";
import { useCurrentFrame } from "remotion";
import { theme } from "../theme";
import { makeT } from "../timing";
import { Entrance, SceneShell, tween, useBreathe } from "../components/anim";
import { Card, Chip, Label } from "../components/ui";
import { Check } from "../components/icons";
import { EXPO, FACE, Photo, SUN } from "../components/photo";
import { SfxEvent } from "../sfx";

const T = makeT(5);
const tPhoto = 4;
const tBoth = T(9);
const tFace = T(9, "মুখ দুটোই");
const tSky = tFace + 14;
const tFun = T(9, "সবচেয়ে মজার বিষয়");

export const sfx06: SfxEvent[] = [
  { kind: "pop", frame: tPhoto + 4 },
  { kind: "click", frame: tBoth + 14 },
  { kind: "click", frame: tFace + 16, rate: 1.08 },
  { kind: "pop", frame: tFun + 6, rate: 0.92 },
];

const OX = 480, OY = 195, SC = 1.5; // ছবি ৯৬০ প্রস্থ
const px = (x: number) => OX + x * SC;
const py = (y: number) => OY + y * SC;

export const Scene06: React.FC = () => {
  const frame = useCurrentFrame();
  const bob = useBreathe(44, 4);
  const cSky = tween(frame, tBoth + 14, tBoth + 34, 0, 1);
  const cFace = tween(frame, tFace + 16, tFace + 36, 0, 1);
  const line = (p: number) => tween(frame, p, p + 18, 0, 1);
  const lSky = line(tBoth + 6), lFace = line(tFace + 8);
  const photoExit = tween(frame, tFun + 4, tFun + 22, 0, 1, theme.ease.inOut);

  return (
    <SceneShell>
      <Entrance delay={tPhoto} style={{ position: "absolute", left: OX, top: OY + bob }}>
        <div style={{ borderRadius: 24, overflow: "hidden", border: `3px solid ${theme.colors.ok}`, boxShadow: `0 0 60px ${theme.colors.ok}33, ${theme.shadow.card}`,
          transform: `scale(${1 - 0.04 * photoExit})`, filter: `saturate(${1 - 0.2 * photoExit})` }}>
          <Photo uid="s6" gRoom={EXPO.over} gSky={EXPO.under} width={960} radius={0} />
        </div>
      </Entrance>

      {/* সংযোগ রেখা */}
      <svg width={1920} height={1080} style={{ position: "absolute", inset: 0, transform: `translateY(${bob}px)` }}>
        <path d={`M ${px(SUN.cx) - 80} ${py(SUN.cy)} L 400 ${py(SUN.cy)}`} stroke={theme.colors.hero} strokeWidth={4} fill="none" strokeDasharray={1} pathLength={1} strokeDashoffset={1 - lSky} style={{ filter: `drop-shadow(0 0 8px ${theme.colors.hero})` }} />
        <circle cx={px(SUN.cx) - 80} cy={py(SUN.cy)} r={9} fill={theme.colors.hero} opacity={lSky} />
        <path d={`M ${px(FACE.cx) + 70} ${py(FACE.cy) + 20} L 1520 ${py(FACE.cy) + 20}`} stroke={theme.colors.accent} strokeWidth={4} fill="none" strokeDasharray={1} pathLength={1} strokeDashoffset={1 - lFace} style={{ filter: `drop-shadow(0 0 8px ${theme.colors.accent})` }} />
        <circle cx={px(FACE.cx) + 70} cy={py(FACE.cy) + 20} r={9} fill={theme.colors.accent} opacity={lFace} />
      </svg>

      {/* বাম: আকাশ ✓ */}
      <Entrance delay={tBoth + 8} x={-50} y={0} style={{ position: "absolute", left: 70, top: py(SUN.cy) - 100 + bob }}>
        <Card w={330} h={200} border={theme.colors.hero}>
          <div style={{ padding: "26px 30px", display: "flex", flexDirection: "column", gap: 14 }}>
            <div style={{ display: "flex", alignItems: "center", gap: 16 }}>
              <Check size={58} progress={cSky} />
              <Label size={50} weight={700} color={theme.colors.hero}>আকাশ</Label>
            </div>
            <Label size={34} color={theme.colors.textDim}>বিস্তারিত তথ্য</Label>
          </div>
        </Card>
      </Entrance>
      {/* ডান: মুখ ✓ */}
      <Entrance delay={tFace + 10} x={50} y={0} style={{ position: "absolute", left: 1520, top: py(FACE.cy) - 80 + bob }}>
        <Card w={330} h={200} border={theme.colors.accent}>
          <div style={{ padding: "26px 30px", display: "flex", flexDirection: "column", gap: 14 }}>
            <div style={{ display: "flex", alignItems: "center", gap: 16 }}>
              <Check size={58} progress={cFace} />
              <Label size={50} weight={700} color={theme.colors.accent}>মুখ</Label>
            </div>
            <Label size={34} color={theme.colors.textDim}>বিস্তারিত তথ্য</Label>
          </div>
        </Card>
      </Entrance>

      <div style={{ position: "absolute", left: 0, right: 0, top: 840, display: "flex", justifyContent: "center", opacity: 1 - tween(frame, tFun - 6, tFun, 0, 1) }}>
        <Entrance delay={tFace + 24}><Chip text="দুটোই বিস্তারিত" color={theme.colors.ok} size={44} /></Entrance>
      </div>
      <div style={{ position: "absolute", left: 0, right: 0, top: 840, display: "flex", justifyContent: "center" }}>
        <Entrance delay={tFun}><Chip text="সবচেয়ে মজার বিষয়…" color={theme.colors.accent} solid size={48} /></Entrance>
      </div>
    </SceneShell>
  );
};
