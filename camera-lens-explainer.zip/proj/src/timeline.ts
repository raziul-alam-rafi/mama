// timeline.ts — every time value is derived from the SRT cues (src/cues.ts).
import {CUES} from "./cues";

export const FPS = 30;
export const WIDTH = 1920;
export const HEIGHT = 1080;
/** Visuals land this many frames BEFORE the matching spoken words. */
export const LEAD = 5;

export const msToF = (ms: number) => Math.round((ms / 1000) * FPS);
export const cueOf = (n: number) => CUES[n - 1];
export const cueStartF = (n: number) => msToF(cueOf(n).startMs);
export const cueEndF = (n: number) => msToF(cueOf(n).endMs);
export const TOTAL_FRAMES = Math.ceil((CUES[CUES.length - 1].endMs / 1000) * FPS);

/** Scenes follow meaning; boundaries always sit on cue boundaries. */
export const SCENES = [
  {id: "lens", from: 1, to: 1}, //       লেন্সের Optical Element
  {id: "magnifier", from: 2, to: 3}, //  Magnifying Glass
  {id: "compare", from: 4, to: 4}, //    একই মূলনীতি, বেশি নিয়ন্ত্রিত
  {id: "image", from: 5, to: 7}, //      Sensor-এ Focus → Optical Image
  {id: "exposure", from: 8, to: 9}, //   বেশি / কম আলো
  {id: "question", from: 10, to: 10}, // কতটুকু আলো?
] as const;
export type SceneIdx = 0 | 1 | 2 | 3 | 4 | 5;

export const sceneStart = (i: number) => (i === 0 ? 0 : cueStartF(SCENES[i].from) - LEAD);
export const sceneEnd = (i: number) =>
  i === SCENES.length - 1 ? TOTAL_FRAMES : cueStartF(SCENES[i + 1].from) - LEAD;
export const sceneDur = (i: number) => sceneEnd(i) - sceneStart(i);

/** Absolute frame at which `word` (first match) begins inside cue n, estimated by character position. */
export const wordF = (n: number, word?: string) => {
  const c = cueOf(n);
  const s = cueStartF(n);
  if (!word) return s;
  const pos = c.text.indexOf(word);
  if (pos < 0) throw new Error(`"${word}" not found in cue ${n}`);
  return s + Math.round((pos / c.text.length) * (cueEndF(n) - s));
};

/** Local (scene-relative) frame where a visual should enter for cue n / word (already LEAD frames early). */
export const at = (sceneIdx: number, n: number, word?: string) =>
  Math.max(0, wordF(n, word) - LEAD - sceneStart(sceneIdx));
/** Local frame where cue n ends. */
export const atEnd = (sceneIdx: number, n: number) => cueEndF(n) - sceneStart(sceneIdx);
