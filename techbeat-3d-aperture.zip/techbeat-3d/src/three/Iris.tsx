import React, { useMemo, useEffect } from "react";
import * as THREE from "three";
import { theme } from "../theme";

export const IRIS_OUTER_R = 1.55;
const BLADES = 7;
const DEPTH = 0.07;

/**
 * Stylised aperture diaphragm: a ring whose central hole is a 7-sided polygon
 * (like a real 7-blade iris). `r` = circumradius of the opening. Blade seams rotate
 * slightly as the iris closes, as the overlapping blades do in a real lens.
 * Lies in the YZ plane (optical axis = +X), centred at the origin.
 */
export const Iris: React.FC<{ r: number; glow: number }> = ({ r, glow }) => {
  const twist = (1 - r) * 0.55;
  const geom = useMemo(() => {
    const shape = new THREE.Shape();
    shape.absarc(0, 0, IRIS_OUTER_R, 0, Math.PI * 2, false);
    const hole = new THREE.Path();
    for (let k = 0; k < BLADES; k++) {
      const a = twist + (2 * Math.PI * k) / BLADES;
      const x = r * Math.cos(a), y = r * Math.sin(a);
      if (k === 0) hole.moveTo(x, y); else hole.lineTo(x, y);
    }
    hole.closePath();
    shape.holes.push(hole);
    return new THREE.ExtrudeGeometry(shape, { depth: DEPTH, bevelEnabled: false, curveSegments: 48 });
  }, [r, twist]);
  useEffect(() => () => geom.dispose(), [geom]);

  const seams = [];
  for (let k = 0; k < BLADES; k++) {
    const a = twist + (2 * Math.PI * k) / BLADES;
    const p1 = [r * Math.cos(a), r * Math.sin(a)], b = a + 0.6;
    const p2 = [IRIS_OUTER_R * 0.96 * Math.cos(b), IRIS_OUTER_R * 0.96 * Math.sin(b)];
    const dx = p2[0] - p1[0], dy = p2[1] - p1[1];
    seams.push(
      <mesh key={k} position={[(p1[0] + p2[0]) / 2, (p1[1] + p2[1]) / 2, DEPTH / 2]} rotation={[0, 0, Math.atan2(dy, dx)]}>
        <boxGeometry args={[Math.hypot(dx, dy), 0.012, DEPTH + 0.008]} />
        <meshStandardMaterial color="#05070f" roughness={0.9} />
      </mesh>,
    );
  }

  return (
    <group rotation={[0, Math.PI / 2, 0]}>
      <group position={[0, 0, -DEPTH / 2]}>
        <mesh geometry={geom} castShadow>
          <meshStandardMaterial color="#2a3558" metalness={0.75} roughness={0.35} side={THREE.DoubleSide} />
        </mesh>
        {seams}
        {/* amber hero highlight: edge of the opening */}
        <mesh position={[0, 0, DEPTH / 2]}>
          <torusGeometry args={[r * 0.97, 0.02 + 0.012 * glow, 12, 7 * 6]} />
          <meshStandardMaterial
            color={theme.colors.accent} emissive={theme.colors.accent}
            emissiveIntensity={0.25 + 2.2 * glow} toneMapped={false}
          />
        </mesh>
      </group>
    </group>
  );
};
