import React from "react";
import { theme } from "../theme";

const mix = (a: string, b: string, t: number) => {
  const pa = [1, 3, 5].map((i) => parseInt(a.slice(i, i + 2), 16));
  const pb = [1, 3, 5].map((i) => parseInt(b.slice(i, i + 2), 16));
  const c = pa.map((v, i) => Math.round(v + (pb[i] - v) * Math.max(0, Math.min(1, t))));
  return `rgb(${c[0]},${c[1]},${c[2]})`;
};

/** Pixel grid. level(c,r) 0..1 = accumulated light. bayer adds R/G/B colour-filter tint. */
export const SensorGrid: React.FC<{
  cols: number; rows: number; cell: number; gap?: number;
  level: (c: number, r: number) => number;
  bayer?: boolean; tint?: string; band?: (r: number) => string | null;
}> = ({ cols, rows, cell, gap = 4, level, bayer = false, tint = theme.colors.light, band }) => {
  const W = cols * cell, H = rows * cell;
  const filt = (c: number, r: number) =>
    (r % 2 === 0 ? (c % 2 === 0 ? "#FF5C5C" : "#5CE08A") : c % 2 === 0 ? "#5CE08A" : "#5C9DFF");
  return (
    <svg width={W} height={H} viewBox={`0 0 ${W} ${H}`}>
      {Array.from({ length: rows }).flatMap((_, r) =>
        Array.from({ length: cols }).map((__, c) => {
          const l = level(c, r);
          const base = mix(theme.colors.panelHi, tint, l);
          return (
            <g key={`${c}-${r}`}>
              <rect x={c * cell + gap / 2} y={r * cell + gap / 2} width={cell - gap} height={cell - gap} rx={cell * 0.14} fill={base} stroke={theme.colors.line} strokeWidth={1.5} />
              {bayer && <rect x={c * cell + gap / 2} y={r * cell + gap / 2} width={cell - gap} height={cell - gap} rx={cell * 0.14} fill={filt(c, r)} opacity={0.35} />}
              {band && band(r) && <rect x={c * cell + gap / 2} y={r * cell + gap / 2} width={cell - gap} height={cell - gap} rx={cell * 0.14} fill="none" stroke={band(r)!} strokeWidth={3} />}
            </g>
          );
        }),
      )}
    </svg>
  );
};
