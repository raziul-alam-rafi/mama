# Assets & licences
| File | Source | Licence |
|---|---|---|
| public/sfx/*.wav | Synthesized by `scripts/make-sfx.mjs` (original, deterministic) | Own work, free to use |
| public/audio/narration.srt | Channel owner's script | Owner |
| 3D models | Procedural Three.js geometry (no external models) | n/a |
| Fonts | System fallback stack only (display font not yet bundled) | n/a |
No voiceover audio and no background music file were supplied. `pad.wav` is a synthesized placeholder bed.
