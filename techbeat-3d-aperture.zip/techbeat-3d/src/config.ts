import cues from "./data/cues.json";

export const VIDEO = {
  id: "ApertureExplainer",
  fps: cues.fps,
  width: 1920,
  height: 1080,
  durationInFrames: cues.durationInFrames,
};

// If you have the recorded Bengali voiceover, put it in public/voiceover.mp3 (or .wav)
// and set this to "voiceover.mp3". The SRT is timing data only, NOT audio.
export const VOICEOVER_FILE: string | null = null;

export const MUSIC_FILE = "music/ambient_pad.wav";
export const MUSIC_BASE_VOLUME = 0.22; // under narration; raised slightly in pauses
export const MUSIC_DUCKED_VOLUME = 0.1; // while a cue is being spoken
export { cues };
