import React from "react";
import {
  AbsoluteFill,
  interpolate,
  spring,
  useCurrentFrame,
  useVideoConfig,
} from "remotion";
import { theme } from "../theme";

export const clampOpts = {
  extrapolateLeft: "clamp",
  extrapolateRight: "clamp",
} as const;

type SpringCfg = { damping: number; stiffness: number; mass: number };

/** spring progress 0→1 starting at `delay` (local frames). */
export const useSpr = (delay = 0, cfg: SpringCfg = theme.spring.smooth) => {
  const frame = useCurrentFrame();
  const { fps } = useVideoConfig();
  return spring({ frame: frame - delay, fps, config: cfg });
};

/** eased, clamped interpolation (never linear). */
export const ip = (
  frame: number,
  inR: number[],
  outR: number[],
  easing: (n: number) => number = theme.ease.inOut
) => interpolate(frame, inR, outR, { easing, ...clampOpts });

/** Premium entrance: opacity + rise + scale (3 properties together). */
export const Pop: React.FC<{
  delay?: number;
  y?: number;
  s?: number;
  cfg?: SpringCfg;
  style?: React.CSSProperties;
  children?: React.ReactNode;
}> = ({ delay = 0, y = 40, s = 0.94, cfg = theme.spring.smooth, style, children }) => {
  const p = useSpr(delay, cfg);
  return (
    <div
      style={{
        opacity: Math.min(1, p * 1.4),
        transform: `translateY(${(1 - p) * y}px) scale(${s + (1 - s) * p})`,
        ...style,
      }}
    >
      {children}
    </div>
  );
};

/** Word-by-word reveal. Splits ONLY on spaces (Bengali conjuncts never broken). */
export const WordReveal: React.FC<{
  text: string;
  delay?: number;
  per?: number;
  size?: number;
  highlight?: number[];
  style?: React.CSSProperties;
}> = ({ text, delay = 0, per = 4, size = 110, highlight = [], style }) => {
  const frame = useCurrentFrame();
  const { fps } = useVideoConfig();
  return (
    <div
      style={{
        display: "flex",
        flexWrap: "wrap",
        columnGap: Math.round(size * 0.26),
        rowGap: Math.round(size * 0.04),
        fontFamily: theme.fonts.display,
        fontWeight: 700,
        fontSize: size,
        lineHeight: 1.3,
        letterSpacing: 0,
        color: theme.colors.text,
        ...style,
      }}
    >
      {text.split(" ").map((word, i) => {
        const p = spring({
          frame: frame - delay - i * per,
          fps,
          config: theme.spring.snappy,
        });
        const hi = (highlight as number[]).includes(i);
        return (
          <span
            key={i}
            style={{
              display: "inline-block",
              opacity: Math.min(1, p * 1.5),
              transform: `translateY(${(1 - p) * 34}px) scale(${0.94 + 0.06 * p})`,
              ...(hi
                ? { color: theme.colors.accent }
                : {}),
            }}
          >
            {word}
          </span>
        );
      })}
    </div>
  );
};

/** Small component label (pill). Minimal text only. */
export const Tag: React.FC<{
  text: string;
  delay?: number;
  tone?: "hero" | "accent" | "text";
  size?: number;
  style?: React.CSSProperties;
}> = ({ text, delay = 0, tone = "text", size = 44, style }) => {
  const c =
    tone === "hero"
      ? theme.colors.hero
      : tone === "accent"
      ? theme.colors.accent
      : theme.colors.textDim;
  return (
    <Pop delay={delay} y={22} s={0.9} cfg={theme.spring.snappy} style={style}>
      <div
        style={{
          display: "inline-flex",
          alignItems: "center",
          gap: 14,
          padding: "8px 28px 12px",
          borderRadius: 999,
          background: "rgba(11,16,32,0.82)",
          border: `2px solid ${c}`,
          boxShadow: `0 10px 30px rgba(0,0,0,0.45)`,
          color: theme.colors.text,
          fontFamily: theme.fonts.display,
          fontWeight: 500,
          fontSize: size,
          lineHeight: 1.3,
          letterSpacing: 0,
          whiteSpace: "nowrap",
        }}
      >
        <span
          style={{
            width: 14,
            height: 14,
            borderRadius: 999,
            background: c,
            display: "inline-block",
          }}
        />
        {text}
      </div>
    </Pop>
  );
};

/* ---------- five-layer stack helpers ---------- */

export const BgMesh: React.FC = () => {
  const frame = useCurrentFrame();
  const d1 = Math.sin(frame / 55) * 50;
  const d2 = Math.cos(frame / 70) * 40;
  const dots =
    "radial-gradient(circle, rgba(154,166,199,0.16) 1.4px, transparent 1.6px)";
  return (
    <AbsoluteFill style={{ background: theme.colors.bg }}>
      <div
        style={{
          position: "absolute",
          width: 1300,
          height: 1300,
          borderRadius: "50%",
          top: -520,
          left: -340 + d1,
          filter: "blur(60px)",
          background: `radial-gradient(circle, ${theme.colors.hero}38, transparent 62%)`,
        }}
      />
      <div
        style={{
          position: "absolute",
          width: 1000,
          height: 1000,
          borderRadius: "50%",
          bottom: -460,
          right: -280 - d2,
          filter: "blur(80px)",
          background: `radial-gradient(circle, ${theme.colors.accent}22, transparent 65%)`,
        }}
      />
      <AbsoluteFill
        style={{
          backgroundImage: dots,
          backgroundSize: "56px 56px",
          backgroundPosition: `${(frame * 0.3) % 56}px 0px`,
          opacity: 0.5,
        }}
      />
    </AbsoluteFill>
  );
};

export const Grade: React.FC = () => (
  <AbsoluteFill style={{ pointerEvents: "none" }}>
    <AbsoluteFill
      style={{
        backgroundColor: theme.colors.hero,
        mixBlendMode: "soft-light",
        opacity: 0.16,
      }}
    />
    <AbsoluteFill
      style={{
        background:
          "linear-gradient(180deg, rgba(0,0,0,0.10), transparent 28%, transparent 72%, rgba(0,0,0,0.2))",
      }}
    />
  </AbsoluteFill>
);

export const Grain: React.FC = () => {
  const frame = useCurrentFrame();
  const noise = `url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='220' height='220'%3E%3Cfilter id='n'%3E%3CfeTurbulence type='fractalNoise' baseFrequency='0.9' numOctaves='2'/%3E%3C/filter%3E%3Crect width='220' height='220' filter='url(%23n)' opacity='0.5'/%3E%3C/svg%3E")`;
  return (
    <AbsoluteFill
      style={{
        pointerEvents: "none",
        backgroundImage: noise,
        backgroundSize: "220px",
        backgroundPosition: `${(frame * 7) % 220}px ${(frame * 13) % 220}px`,
        opacity: 0.05,
        mixBlendMode: "overlay",
      }}
    />
  );
};

export const Vignette: React.FC = () => (
  <AbsoluteFill
    style={{
      pointerEvents: "none",
      background:
        "radial-gradient(ellipse at center, transparent 56%, rgba(0,0,0,0.28) 100%)",
    }}
  />
);

/** Scene wrapper: quick eased entrance, FASTER exit (overlaps the next scene). */
export const SceneShell: React.FC<{
  dur: number;
  first?: boolean;
  last?: boolean;
  children: React.ReactNode;
}> = ({ dur, first, last, children }) => {
  const frame = useCurrentFrame();
  const inP = first ? 1 : ip(frame, [0, 12], [0, 1], theme.ease.out);
  const outP = last ? 1 : ip(frame, [dur - 6, dur - 1], [1, 0], theme.ease.in);
  const o = Math.min(inP, outP);
  const sc = first ? 1 : 1.035 - 0.035 * inP;
  return (
    <AbsoluteFill style={{ opacity: o, transform: `scale(${sc})` }}>
      {children}
    </AbsoluteFill>
  );
};

/** Deterministic pseudo-random for stable crowds, noise, etc. */
export const rng = (seed: number) => {
  let s = seed >>> 0;
  return () => {
    s = (s * 1664525 + 1013904223) >>> 0;
    return s / 4294967296;
  };
};
