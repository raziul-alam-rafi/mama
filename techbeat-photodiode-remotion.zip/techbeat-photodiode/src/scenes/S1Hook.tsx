import React from "react";
import { useCurrentFrame, useVideoConfig } from "remotion";
import { theme } from "../theme";
import { FullSvg, P, SceneShell, Sfx, Tag, Title, lerp, sp } from "../fx";
import { Electron, Photon } from "../parts";
import { sceneTimes } from "../timeline";
import { wordFrame } from "../srt";

const C = theme.colors;
const T0 = sceneTimes[0].from;

// চিপ ও সার্কিটের জ্যামিতি
const chip = { x: 620, y: 700, w: 360, h: 180 };
const wireY = 790;
const gauge = { x: 1380, y: 640, w: 100, h: 260 };
const CYCLE = 70;
const TRAVEL = 44;

export const S1Hook: React.FC = () => {
  const frame = useCurrentFrame();
  const { fps } = useVideoConfig();

  const tAbsorb = wordFrame(1, "শোষণ") - T0;
  const tCharge = wordFrame(1, "বৈদ্যুতিক") - T0;
  const flowStart = 62;

  const chipPop = sp(frame, fps, 6, theme.spring.smooth);
  const breathe = 1 + Math.sin(frame / 22) * 0.012;
  const fill = P(frame, flowStart + 10, 100, theme.ease.soft) * 0.82;

  // শিরোনামে হাইলাইট সুইপ
  const sweep = P(frame, 26, 22, theme.ease.inOut);

  const photons = [0, 1, 2].map((i) => {
    const start = 14 + i * 6;
    const t = frame - start;
    const phase = ((t % CYCLE) + CYCLE) % CYCLE;
    const prog = t < 0 ? -1 : P(phase, 0, TRAVEL, theme.ease.soft);
    const tx = 700 + i * 100;
    const ty = chip.y;
    const dx = Math.cos((60 * Math.PI) / 180);
    const dy = Math.sin((60 * Math.PI) / 180);
    const dist = 290;
    const px = tx - dx * dist * (1 - prog);
    const py = ty - dy * dist * (1 - prog);
    const visible = t >= 0 && phase < TRAVEL + 1;
    return { px, py, visible, hit: t >= 0 && phase >= TRAVEL - 2 && phase < TRAVEL + 14, hx: tx, hy: ty, prog };
  });
  const flash = photons.some((p) => p.hit) ? 1 : 0;

  return (
    <SceneShell>
      {/* গ্রাফিক্স লেয়ার */}
      <div style={{ position: "absolute", left: 120, top: 70, fontFamily: theme.fonts.main }}>
        <div
          style={{
            position: "relative",
            display: "inline-block",
            fontSize: 150,
            fontWeight: 700,
            lineHeight: 1.2,
            letterSpacing: 0,
            color: C.text,
            opacity: sp(frame, fps, 0, theme.spring.snappy),
            transform: `translateY(${lerp(50, 0, sp(frame, fps, 0, theme.spring.snappy))}px) scale(${lerp(0.92, 1, sp(frame, fps, 0, theme.spring.snappy))})`,
          }}
        >
          <span style={{ color: C.text }}>Photo</span>
          <span style={{ color: C.primary }}>diode</span>
          <div
            style={{
              position: "absolute",
              left: 0,
              bottom: 8,
              height: 8,
              width: `${sweep * 100}%`,
              borderRadius: 8,
              background: C.accent,
            }}
          />
        </div>
      </div>
      <Title
        text="আলো শোষণ করে বৈদ্যুতিক charge"
        top={262}
        size={52}
        weight={600}
        delay={tAbsorb - 10}
        per={5}
        highlight={{ 0: C.accent, 1: C.accent, 4: C.primary, 5: C.primary }}
      />
      <FullSvg>
        {/* আলোর উৎসের নরম আভা */}
        
        {/* তার */}
        <line x1={chip.x + chip.w} y1={wireY} x2={gauge.x} y2={wireY} stroke={C.panelLine} strokeWidth={8} strokeLinecap="round" />
        <line x1={chip.x} y1={wireY} x2={chip.x - 80} y2={wireY} stroke={C.panelLine} strokeWidth={8} strokeLinecap="round" />
        {/* চিপ */}
        <g transform={`translate(${chip.x + chip.w / 2} ${chip.y + chip.h / 2}) scale(${chipPop * breathe}) translate(${-(chip.x + chip.w / 2)} ${-(chip.y + chip.h / 2)})`} opacity={chipPop}>
          <rect x={chip.x} y={chip.y} width={chip.w} height={chip.h} rx={22} fill={C.silicon} stroke={C.panelLine} strokeWidth={3} />
          <rect x={chip.x + 4} y={chip.y + 4} width={chip.w - 8} height={48} rx={18} fill={C.siliconHi} />
          <rect x={chip.x + 4} y={chip.y + 54} width={chip.w - 8} height={66} fill={C.primary} opacity={0.18} />
          <rect x={chip.x} y={chip.y + 122} width={chip.w} height={2} fill={C.panelLine} />
          <rect x={chip.x + chip.w - 6} y={wireY - 26} width={20} height={52} rx={6} fill={C.textDim} />
          <rect x={chip.x - 14} y={wireY - 26} width={20} height={52} rx={6} fill={C.textDim} />
          {flash ? <rect x={chip.x} y={chip.y} width={chip.w} height={chip.h} rx={22} fill={C.accent} opacity={0.2} /> : null}
        </g>
        {/* গেজ: জমা charge */}
        <g opacity={P(frame, 40, 14)}>
          <rect x={gauge.x} y={gauge.y} width={gauge.w} height={gauge.h} rx={26} fill={C.panel} stroke={C.panelLine} strokeWidth={4} />
          <rect
            x={gauge.x + 10}
            y={gauge.y + gauge.h - 10 - (gauge.h - 20) * fill}
            width={gauge.w - 20}
            height={(gauge.h - 20) * fill}
            rx={16}
            fill={C.primary}
          />
        </g>
        {photons.map((p, i) => p.visible ? <line key={`b${i}`} x1={p.hx - 290 * 0.5} y1={p.hy - 290 * 0.866} x2={p.hx} y2={p.hy} stroke={C.accent} strokeWidth={3} strokeDasharray="4 12" opacity={0.25} /> : null)}
        {/* ফোটন */}
        {photons.map((p, i) =>
          p.visible ? <Photon key={i} x={p.px} y={p.py} rot={60} len={150} amp={17} phase={frame / 3 + i} o={Math.min(1, p.prog + 1) * (p.prog > 0.96 ? 0.4 : 1)} /> : null
        )}
        {/* তারে ইলেকট্রন প্রবাহ */}
        {frame > flowStart
          ? [0, 1, 2, 3, 4].map((k) => {
              const span = gauge.x - (chip.x + chip.w);
              const pos = (((frame - flowStart) * 4 + k * (span / 5)) % span);
              const a = Math.min(1, P(frame, flowStart, 12));
              return <Electron key={k} x={chip.x + chip.w + pos} y={wireY} r={12} o={a * Math.min(1, pos / 30) * Math.min(1, (span - pos) / 30)} />;
            })
          : null}
      </FullSvg>
      <Tag x={chip.x + chip.w / 2} y={chip.y + chip.h + 66} text="Photodiode" color={C.text} delay={30} size={36} />
      <Tag x={gauge.x + gauge.w / 2} y={gauge.y - 50} text="charge" color={C.primary} delay={tCharge} size={38} />

      <Sfx at={2} name="thud" vol={0.22} />
      <Sfx at={10} name="pop" vol={0.24} rate={1} />
      <Sfx at={tCharge} name="pop" vol={0.26} rate={1.08} />
    </SceneShell>
  );
};
