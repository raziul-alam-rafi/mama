import React from 'react';
import {interpolate, spring, useCurrentFrame, useVideoConfig} from 'remotion';
import {theme} from '../theme';

/** Label with 3-property entrance (fade+rise+scale) and a faster exit. Use inside <Sequence>. */
export const Caption: React.FC<{title: string; sub: string}> = ({title, sub}) => {
  const frame = useCurrentFrame();
  const {fps, durationInFrames} = useVideoConfig();
  const p = spring({frame, fps, config: theme.spring.smooth});
  const out = interpolate(frame, [durationInFrames - 8, durationInFrames - 1], [1, 0], {easing: theme.ease.in, extrapolateLeft: 'clamp', extrapolateRight: 'clamp'});
  const breathe = Math.sin(frame / 30) * 3;
  return (
    <div style={{position: 'absolute', left: 120, bottom: 110, opacity: p * out, transform: `translateY(${interpolate(p, [0, 1], [40, 0]) + breathe}px) scale(${interpolate(p, [0, 1], [0.94, 1])})`, fontFamily: theme.fonts.display}}>
      <div style={{fontSize: 72, fontWeight: 700, letterSpacing: '-0.03em', color: theme.colors.text, lineHeight: 1.05}}>{title}</div>
      <div style={{fontSize: 36, fontWeight: 500, color: theme.colors.textDim, marginTop: 14}}>{sub}</div>
    </div>
  );
};
