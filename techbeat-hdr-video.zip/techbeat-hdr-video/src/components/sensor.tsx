import React from "react";
import { useCurrentFrame } from "remotion";
import { theme } from "../theme";

/** Sensor ডাই (সামনের দিক): পিক্সেল গ্রিডে আলোর তীব্রতা বদলায় */
export const SensorDie: React.FC<{ size: number; color?: string; glow?: boolean }> = ({ size, color = theme.colors.hero, glow = true }) => {
  const frame = useCurrentFrame();
  const n = 8, pad = 20, cell = (300 - pad * 2) / n;
  const cells: React.ReactNode[] = [];
  for (let r = 0; r < n; r++) for (let c = 0; c < n; c++) {
    const v = 0.4 + 0.3 * Math.sin(frame / 14 + r * 0.6 + c * 0.9) + 0.2 * Math.sin(r * 1.3 + c * 0.7);
    cells.push(<rect key={`${r}-${c}`} x={pad + c * cell} y={pad + r * cell} width={cell - 4} height={cell - 4} rx={4} fill={color} opacity={Math.max(0.12, Math.min(1, v))} />);
  }
  return (
    <svg width={size} height={size} viewBox="0 0 300 300" style={{ filter: glow ? `drop-shadow(0 0 26px ${theme.colors.glowHero})` : undefined }}>
      <rect x={4} y={4} width={292} height={292} rx={26} fill={theme.colors.surface} stroke={color} strokeWidth={4} />
      {cells}
    </svg>
  );
};
