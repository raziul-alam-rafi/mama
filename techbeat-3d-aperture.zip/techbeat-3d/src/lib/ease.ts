import { interpolate } from "remotion";
import { theme } from "../theme";

type EaseFn = (t: number) => number;

/** Eased 0..1 progress of time t between a and b (always clamped). */
export const seg = (t: number, a: number, b: number, ease: EaseFn = theme.ease.inOut) =>
  interpolate(t, [a, b], [0, 1], { easing: ease, extrapolateLeft: "clamp", extrapolateRight: "clamp" });

export interface Key { t: number; v: number }

/** Piecewise value with eased transitions between keys; holds before first / after last. */
export const kf = (t: number, keys: Key[], ease: EaseFn = theme.ease.inOut): number => {
  if (t <= keys[0].t) return keys[0].v;
  for (let i = 0; i < keys.length - 1; i++) {
    const a = keys[i], b = keys[i + 1];
    if (t <= b.t) return a.v + (b.v - a.v) * seg(t, a.t, b.t, ease);
  }
  return keys[keys.length - 1].v;
};

export type Vec3 = [number, number, number];
export const lerp3 = (a: Vec3, b: Vec3, p: number): Vec3 => [
  a[0] + (b[0] - a[0]) * p, a[1] + (b[1] - a[1]) * p, a[2] + (b[2] - a[2]) * p,
];
