import React from "react";
import { useCurrentFrame, useVideoConfig } from "remotion";
import { theme } from "../theme";

const c = theme.colors;
export type Pt = readonly [number, number];

/** আলোর রশ্মি: পলিলাইন, p (0→1) পর্যন্ত আঁকা, ওপরে বয়ে চলা ড্যাশ (flow) */
export const Beam: React.FC<{
  pts: readonly Pt[]; p: number; id: string; color?: string; width?: number; opacity?: number; flow?: boolean; fadeTail?: boolean;
}> = ({ pts, p, id, color = c.accent, width = 6, opacity = 1, flow = true, fadeTail = true }) => {
  const frame = useCurrentFrame();
  const { fps } = useVideoConfig();
  if (p <= 0.001) return null;
  const d = pts.map((q, i) => `${i === 0 ? "M" : "L"}${q[0]} ${q[1]}`).join(" ");
  const first = pts[0], last = pts[pts.length - 1];
  const shown = Math.min(1, p);
  return (
    <g opacity={opacity}>
      <defs>
        <linearGradient id={id} gradientUnits="userSpaceOnUse" x1={first[0]} y1={first[1]} x2={last[0]} y2={last[1]}>
          <stop offset="0%" stopColor={color} stopOpacity={fadeTail ? 0.35 : 1} />
          <stop offset="100%" stopColor={color} stopOpacity="1" />
        </linearGradient>
      </defs>
      <path d={d} pathLength={1} fill="none" stroke={`url(#${id})`} strokeWidth={width} strokeLinecap="round" strokeLinejoin="round" strokeDasharray={`${shown} 2`} />
      {flow && (
        <path d={d} pathLength={100} fill="none" stroke={c.white} strokeOpacity={0.75} strokeWidth={width * 0.35} strokeLinecap="round"
          strokeDasharray="3 13" strokeDashoffset={-((frame / fps) * 38)} style={{ clipPath: undefined }} opacity={shown > 0.98 ? 1 : 0} />
      )}
    </g>
  );
};

/** পয়েন্ট a→b-এর মাঝে t */
export const lerpPt = (a: Pt, b: Pt, t: number): Pt => [a[0] + (b[0] - a[0]) * t, a[1] + (b[1] - a[1]) * t];

/** হালকা glow সহ SVG ওভারলে (পুরো ফ্রেম) */
export const RayLayer: React.FC<{ children: React.ReactNode; glow?: boolean }> = ({ children, glow = true }) => (
  <svg width={1920} height={1080} viewBox="0 0 1920 1080" style={{ position: "absolute", left: 0, top: 0, overflow: "visible", filter: glow ? `drop-shadow(0 0 12px ${c.accentGlow})` : undefined }}>
    {children}
  </svg>
);
