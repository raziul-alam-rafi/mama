// Offline fonts: woff2 files bundled in public/fonts (Hind Siliguri — conjuncts render correctly).
import { continueRender, delayRender, staticFile } from "remotion";

const FAMILY = "Hind Siliguri";
const RANGES = {
  bengali: "U+0980-09FF, U+200C-200D, U+25CC",
  latin: "U+0000-00FF, U+0131, U+0152-0153, U+02BB-02BC, U+02C6, U+02DA, U+02DC, U+2000-206F, U+2074, U+20AC, U+2122, U+2191, U+2193, U+2212, U+2215, U+FEFF, U+FFFD",
} as const;
const WEIGHTS = [500, 600, 700] as const;

let started = false;
export const loadFonts = () => {
  if (started || typeof document === "undefined") return;
  started = true;
  const handle = delayRender("fonts");
  const jobs: Promise<unknown>[] = [];
  for (const w of WEIGHTS) {
    for (const [subset, range] of Object.entries(RANGES)) {
      const face = new FontFace(
        FAMILY,
        `url(${staticFile(`fonts/hind-siliguri-${subset}-${w}-normal.woff2`)}) format("woff2")`,
        { weight: String(w), unicodeRange: range },
      );
      jobs.push(face.load().then((f) => document.fonts.add(f)));
    }
  }
  Promise.all(jobs)
    .then(() => continueRender(handle))
    .catch(() => continueRender(handle));
};
