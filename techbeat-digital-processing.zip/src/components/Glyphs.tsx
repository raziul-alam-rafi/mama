import React from "react";
import { theme } from "../theme";

const c = theme.colors;

/** Smartphone, drawn in vector. Centered on (0,0), height ≈ 150*s. */
export const PhoneGlyph: React.FC<{ s?: number; color?: string; lens?: boolean; glow?: number }> = ({ s = 1, color = c.text, lens = true, glow = 0 }) => (
  <g transform={`scale(${s})`} style={{ filter: glow > 0 ? `drop-shadow(0 0 ${20 * glow}px ${c.accent})` : undefined }}>
    <rect x={-42} y={-78} width={84} height={156} rx={16} fill={c.panel} stroke={color} strokeWidth={4} />
    <rect x={-34} y={-68} width={68} height={136} rx={9} fill={c.bg} />
    <rect x={-12} y={-64} width={24} height={5} rx={2.5} fill={color} opacity={0.6} />
    {lens && (
      <g>
        <circle cx={0} cy={-18} r={22} fill="none" stroke={c.primary} strokeWidth={3} opacity={0.9} />
        <circle cx={0} cy={-18} r={11} fill={c.primary} opacity={0.5} />
        <circle cx={0} cy={-18} r={4} fill="#fff" opacity={0.6} />
      </g>
    )}
    <rect x={-20} y={22} width={40} height={7} rx={3.5} fill={color} opacity={0.35} />
    <rect x={-14} y={36} width={28} height={7} rx={3.5} fill={color} opacity={0.2} />
  </g>
);

/** Front view of a camera. press 0..1 moves the shutter button down. Centered (0,0), ≈ 300 wide *s. */
export const CameraGlyph: React.FC<{ s?: number; press?: number; glow?: number }> = ({ s = 1, press = 0, glow = 0 }) => (
  <g transform={`scale(${s})`}>
    <rect x={-150} y={-70} width={300} height={190} rx={34} fill="url(#gPanel)" stroke={c.line} strokeWidth={3} />
    <path d="M-54 -70 L-38 -104 H38 L54 -70 Z" fill={c.panel2} stroke={c.line} strokeWidth={3} strokeLinejoin="round" />
    {/* shutter button */}
    <rect x={92} y={-86 + press * 12} width={44} height={16 - press * 6} rx={6} fill={c.accent} style={{ filter: glow > 0 ? `drop-shadow(0 0 ${16 * glow}px ${c.accent})` : undefined }} />
    <rect x={86} y={-72} width={56} height={6} rx={3} fill={c.line} />
    {/* lens */}
    <circle cx={0} cy={26} r={80} fill={c.bg} stroke={c.line} strokeWidth={4} />
    <circle cx={0} cy={26} r={62} fill={c.panel} stroke={c.primary} strokeWidth={4} opacity={0.95} />
    <circle cx={0} cy={26} r={40} fill="url(#gBlue)" opacity={0.9} />
    <circle cx={0} cy={26} r={16} fill={c.bg} opacity={0.9} />
    <path d="M-28 6 A40 40 0 0 1 8 -12" fill="none" stroke="#fff" strokeWidth={5} strokeLinecap="round" opacity={0.55} />
    <circle cx={-110} cy={-36} r={9} fill={c.bg} stroke={c.line} strokeWidth={2} />
  </g>
);

/** A processor chip. Centered (0,0), body = size. glow 0..1; act = animated activity phase. */
export const ChipGlyph: React.FC<{ size?: number; glow?: number; act?: number; color?: string; pins?: number }> = ({ size = 200, glow = 0, act = 0, color = c.primary, pins = 6 }) => {
  const h = size / 2;
  const pinLines: React.ReactNode[] = [];
  for (let i = 0; i < pins; i++) {
    const t = -h + (size / (pins + 1)) * (i + 1);
    pinLines.push(
      <rect key={"l" + i} x={-h - 26} y={t - 4} width={26} height={8} rx={3} fill={c.line} />,
      <rect key={"r" + i} x={h} y={t - 4} width={26} height={8} rx={3} fill={c.line} />,
      <rect key={"t" + i} x={t - 4} y={-h - 26} width={8} height={26} rx={3} fill={c.line} />,
      <rect key={"b" + i} x={t - 4} y={h} width={8} height={26} rx={3} fill={c.line} />,
    );
  }
  const cells = 5;
  const cs = (size * 0.5) / cells;
  return (
    <g>
      {glow > 0 && <rect x={-h - 10} y={-h - 10} width={size + 20} height={size + 20} rx={30} fill={color} opacity={0.35 * glow} filter="url(#fSoftGlow)" />}
      {pinLines}
      <rect x={-h} y={-h} width={size} height={size} rx={26} fill="url(#gPanel)" stroke={glow > 0.2 ? color : c.line} strokeWidth={4} />
      <rect x={-h} y={-h} width={size} height={size} rx={26} fill="url(#gSheen)" />
      <rect x={-size * 0.3} y={-size * 0.3} width={size * 0.6} height={size * 0.6} rx={12} fill={c.bg} stroke={c.line} strokeWidth={2} />
      {Array.from({ length: cells * cells }).map((_, i) => {
        const cx = (i % cells) - (cells - 1) / 2;
        const cy = Math.floor(i / cells) - (cells - 1) / 2;
        const on = Math.sin(act * 0.35 + i * 1.7) > 0.15;
        return <rect key={i} x={cx * cs - cs * 0.34} y={cy * cs - cs * 0.34} width={cs * 0.68} height={cs * 0.68} rx={3} fill={color} opacity={on ? 0.35 + 0.65 * glow : 0.12} />;
      })}
    </g>
  );
};
