import React, {useMemo} from 'react';
import * as THREE from 'three';
import {COLORS} from '../../config/theme';
import {clamp, easeInOutSine} from '../../utils/math';

const RADIAL = 6;

/**
 * Real cable (dark rubber) + an explanatory "signal pulse" travelling along it.
 * The glowing trail is the part of the tube already traversed (draw-range), the head is a
 * small bright packet train. Overlay only: electrical signal is not literally visible.
 */
export const SignalCable: React.FC<{
  curve: THREE.Curve<THREE.Vector3>;
  frame: number;
  start: number;
  end: number;
  radius?: number;
  glowRadius?: number;
  segments?: number;
  headSize?: number;
}> = ({curve, frame, start, end, radius = 0.045, glowRadius = 0.075, segments = 360, headSize = 0.35}) => {
  const tube = useMemo(() => new THREE.TubeGeometry(curve, segments, radius, RADIAL, false), [curve, segments, radius]);
  const glow = useMemo(() => new THREE.TubeGeometry(curve, segments, glowRadius, RADIAL, false), [curve, segments, glowRadius]);
  const raw = clamp((frame - start) / Math.max(1, end - start));
  const u = easeInOutSine(raw);
  const active = frame >= start;
  const idxPerSeg = RADIAL * 6;
  glow.setDrawRange(0, active ? Math.floor(u * segments) * idxPerSeg : 0);
  const head = curve.getPointAt(clamp(u));
  const trail = [0, 1, 2, 3, 4, 5].map((k) => curve.getPointAt(clamp(u - k * (headSize * 0.9) / curve.getLength())));
  return (
    <group>
      <mesh geometry={tube}>
        <meshStandardMaterial color="#0c0d0f" roughness={0.6} metalness={0.1} />
      </mesh>
      <mesh geometry={glow}>
        <meshBasicMaterial color={COLORS.signal} transparent opacity={0.9} toneMapped={false} />
      </mesh>
      {active && raw < 1 &&
        trail.map((p, k) => (
          <mesh key={k} position={p}>
            <sphereGeometry args={[headSize * (1 - k * 0.14), 12, 10]} />
            <meshBasicMaterial color={k === 0 ? COLORS.signalHot : COLORS.signal} transparent opacity={1 - k * 0.14} toneMapped={false} />
          </mesh>
        ))}
      {active && raw < 1 && <pointLight position={head} color={COLORS.signal} intensity={4} distance={12} decay={0} />}
    </group>
  );
};
