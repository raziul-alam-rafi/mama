// Hind Siliguri: clean Bengali conjuncts, bundled via @remotion/google-fonts.
import {loadFont} from "@remotion/google-fonts/HindSiliguri";

export const {fontFamily} = loadFont("normal", {
  weights: ["500", "700"],
  subsets: ["bengali", "latin"],
});
