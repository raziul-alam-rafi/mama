import React from "react";
import {AbsoluteFill, interpolate} from "remotion";
import {Chip, Pop, Ray, Sfx, Words, clamp01, useAnim} from "../anim";
import {chColor, theme} from "../theme";

const PHOTONS = Array.from({length: 18}).map((_, i) => {
  const row = i < 7 ? 0 : i < 14 ? 1 : 2;
  const col = i < 7 ? i : i < 14 ? i - 7 : i - 14 + 1.5;
  return {x: -108 + col * 36, y: 198 - row * 38};
});
const SPARKS = [-1, -0.5, 0.2, 0.7, 1].map((dx, i) => ({dx, dy: -0.6 - (i % 3) * 0.25}));

// Scene 4 - one photosite, enlarged: only the red part of the light gets through and is collected.
export const S4: React.FC = () => {
  const a = useAnim();
  const slab = a.sp(0.1);
  const filt = a.sp(0.4, theme.spring.drop);
  const tag = a.sp(3.4, theme.spring.snappy);
  const wellGlow = a.prog(2.0, 3.6) * (0.85 + 0.15 * Math.sin(a.t * 3));
  const rays: {x: number; c: "R" | "G" | "B"; s: number}[] = [
    {x: -90, c: "G", s: 1.0},
    {x: 0, c: "R", s: 1.1},
    {x: 90, c: "B", s: 1.2},
  ];

  return (
    <AbsoluteFill>
      <Sfx name="whoosh_swipe" at={0.05} vol={0.22} />
      <Sfx name="click" at={1.8} vol={0.22} rate={0.97} />
      <Sfx name="pop" at={3.4} vol={0.24} rate={1.05} />
      <Sfx name="chime" at={a.at(0.8)} vol={0.26} />

      <div style={{position: "absolute", left: 140, top: 64, width: 1500}}>
        <Words text="যে রঙ যেতে দেয়, সেই রঙের তথ্য" at={0.1} highlight={["তথ্য"]} />
      </div>

      <svg width={1920} height={1080} style={{position: "absolute", inset: 0}}>
        <defs>
          <linearGradient id="s4slab" x1="0" y1="0" x2="0" y2="1">
            <stop offset="0" stopColor={theme.colors.surfaceHi} />
            <stop offset="1" stopColor={theme.colors.surface} />
          </linearGradient>
          <linearGradient id="s4f" x1="0" y1="0" x2="0" y2="1">
            <stop offset="0" stopColor={theme.colors.red} stopOpacity={0.95} />
            <stop offset="1" stopColor={theme.colors.red} stopOpacity={0.7} />
          </linearGradient>
          <radialGradient id="s4g" cx="0.5" cy="0.9" r="0.9">
            <stop offset="0" stopColor={theme.colors.red} stopOpacity={0.85} />
            <stop offset="1" stopColor={theme.colors.red} stopOpacity={0} />
          </radialGradient>
        </defs>
        <g transform="translate(960 640) scale(1.35)">
          <g opacity={clamp01(slab * 1.5)} transform={`translate(0 ${(1 - slab) * 50})`}>
            <rect x={-210} y={44} width={420} height={214} rx={24} fill="url(#s4slab)" stroke={theme.colors.line} strokeWidth={2} />
            <rect x={-150} y={44} width={300} height={176} rx={16} fill={theme.colors.well} />
            <rect x={-150} y={44} width={300} height={176} rx={16} fill="url(#s4g)" opacity={wellGlow} />
          </g>
          <g opacity={clamp01(filt * 1.6)} transform={`translate(0 ${-90 * (1 - filt)})`}>
            <rect x={-150} y={-14} width={300} height={54} rx={12} fill="url(#s4f)" stroke="rgba(255,255,255,0.5)" strokeWidth={2} style={{filter: `drop-shadow(0 0 16px ${theme.colors.red})`}} />
            <rect x={-132} y={-6} width={150} height={7} rx={3.5} fill="#FFFFFF" opacity={0.35} />
          </g>

          {rays.map((r) => {
            const col = chColor[r.c];
            const pIn = a.prog(r.s, r.s + 0.7, theme.ease.out);
            const arrive = r.s + 0.7;
            if (r.c === "R") {
              return (
                <g key={r.c}>
                  <Ray x1={r.x} y1={-300} x2={r.x} y2={-14} color={col} p={pIn} w={8} />
                  <Ray x1={r.x} y1={40} x2={r.x} y2={110} color={col} p={a.prog(arrive, arrive + 0.3, theme.ease.out)} w={8} opacity={1 - a.ease(2.4, 3.0, 0, 1)} />
                </g>
              );
            }
            const k = a.prog(arrive, arrive + 0.6, theme.ease.out);
            const fade = 1 - a.ease(arrive + 0.1, arrive + 0.6, 0, 1);
            return (
              <g key={r.c}>
                <Ray x1={r.x} y1={-300} x2={r.x} y2={-16} color={col} p={pIn} w={8} />
                <circle cx={r.x} cy={-16} r={8 + 30 * k} fill="none" stroke={col} strokeWidth={4} opacity={fade * a.ease(arrive, arrive + 0.05, 0, 1)} />
                {SPARKS.map((s, i) => (
                  <circle key={i} cx={r.x + s.dx * 70 * k} cy={-16 + s.dy * 90 * k} r={5 * (1 - k * 0.6)} fill={col} opacity={fade * a.ease(arrive, arrive + 0.05, 0, 1)} />
                ))}
              </g>
            );
          })}

          {PHOTONS.map((ph, i) => {
            const s = 2.0 + i * 0.09;
            const p = a.ease(s, s + 0.34, 0, 1, theme.ease.out);
            const y = interpolate(p, [0, 1], [48, ph.y]);
            return (
              <g key={i} opacity={a.ease(s, s + 0.05, 0, 1)}>
                <circle cx={ph.x} cy={y} r={14} fill={theme.colors.red} style={{filter: `drop-shadow(0 0 8px ${theme.colors.red})`}} />
                <circle cx={ph.x - 3} cy={y - 3} r={4.5} fill="#FFFFFF" opacity={0.7} />
              </g>
            );
          })}
        </g>
      </svg>

      <Pop at={0.7} x={-30} y={0} style={{position: "absolute", left: 200, top: 650}}>
        <Chip dot={theme.colors.red}>লাল filter</Chip>
      </Pop>
      <div style={{position: "absolute", left: 1290, top: 800, opacity: clamp01(tag * 1.5), transform: `translateX(${(1 - tag) * 40}px) scale(${interpolate(tag, [0, 1], [0.92, 1])})`}}>
        <Chip dot={theme.colors.red} border={theme.colors.red}>লাল রঙের তথ্য</Chip>
      </div>
      <Pop at={a.at(0.8)} x={30} y={0} cfg={theme.spring.bouncy} style={{position: "absolute", left: 1290, top: 250}}>
        <Chip dot={theme.colors.amber} border={theme.colors.amber} style={{boxShadow: `0 0 40px ${theme.colors.amberGlow}`}}>মজার ব্যাপার</Chip>
      </Pop>
    </AbsoluteFill>
  );
};
