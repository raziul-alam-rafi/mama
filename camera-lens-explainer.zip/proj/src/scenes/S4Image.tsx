import React from "react";
import {AbsoluteFill, spring, useCurrentFrame, useVideoConfig} from "remotion";
import {theme} from "../theme";
import {at} from "../timeline";
import {Elem, LensShape, Ray, SvgDefs, traceRay} from "../components/Optics";
import {Apple, APPLE_TOP, SensorBar, Tree, TREE_TOP} from "../components/Art";
import {Headlines, Tag} from "../components/Text";
import {Sfx} from "../components/Sfx";
import {breathe, prog} from "../components/util";

const SI = 3;
const AX = 640;
const LX = 880;
const F = 130;
const BASE_Y = 760; // ground line
const TREE = {x: 220, s: 1};
const APPLE = {x: 470, y: BASE_Y - 66, s: 0.95};
const treeTopY = BASE_Y - TREE_TOP * TREE.s;
const appleTopY = APPLE.y - APPLE_TOP * APPLE.s;
const DO_APPLE = LX - APPLE.x;
const DI_APPLE = 1 / (1 / F - 1 / DO_APPLE); // thin-lens equation
const SX = LX + DI_APPLE; // sensor plane
const DO_TREE = LX - TREE.x;
const LENS_H = [-70, -5, 60];
const INSET = {x: 1290, y: 350, w: 540, h: 450};

const oneLens: Elem[] = [{x: LX, power: 1 / F, kind: "convex", h: 160, w: 26}];

// image point on the sensor plane for an object point (simplified thin-lens schematic)
const imageY = (objY: number, objDist: number) => AX - (objY - AX) * ((SX - LX) / objDist);
const appleImgY = imageY(appleTopY, DO_APPLE);
const treeImgY = imageY(treeTopY, DO_TREE);

const rayTo = (x0: number, y0: number, h: number, imgY: number): {x: number; y: number}[] => {
  const yl = AX + h;
  return [{x: x0, y: y0}, {x: LX, y: yl}, {x: SX, y: imgY}];
};

/** Scene 4 — light from the apple and the tree focuses on the sensor; the inverted Optical Image appears. */
export const S4Image: React.FC = () => {
  const frame = useCurrentFrame();
  const {fps} = useVideoConfig();

  const tObj = at(SI, 5, "বস্তু");
  const tFocus = at(SI, 5, "Sensor");
  const tAppleLight = at(SI, 5, "আপেলের");
  const tTree = at(SI, 6, "পিছনের");
  const tApplePart = at(SI, 6, "আপেলের ছবির");
  const tTreePart = at(SI, 6, "গাছের ছবির");
  const tImage = at(SI, 7, "Optical");
  const end = at(SI, 7) + 260;

  const pop = (t: number) => spring({frame: frame - t, fps, config: theme.spring.bouncy});
  const sceneIn = prog(frame, 0, 16);
  const lensIn = spring({frame: frame - 6, fps, config: theme.spring.smooth});
  const aIn = pop(tObj), tIn = pop(tTree - 12);
  const apRays = LENS_H.map((_, i) => prog(frame, tFocus + i * 4, 40, theme.ease.inOut));
  const trRays = LENS_H.map((_, i) => prog(frame, tTree + i * 4, 40, theme.ease.inOut));
  const tLock = tFocus + 2 * 4 + 38;
  const lock = prog(frame, tLock, 12);
  const insetIn = spring({frame: frame - (tApplePart - 14), fps, config: theme.spring.smooth});
  const apPart = prog(frame, tApplePart, 26, theme.ease.inOut);
  const trPart = prog(frame, tTreePart, 26, theme.ease.inOut);
  const done = prog(frame, tImage, 16);
  const sensorGlow = lock > 0.5;

  // picture scale and position inside the inset (rotated 180° = inverted optical image)
  const cx = INSET.x + INSET.w / 2, cy = INSET.y + INSET.h / 2 + 10;
  const ps = 1.25;

  return (
    <AbsoluteFill>
      <svg width={1920} height={1080} viewBox="0 0 1920 1080" style={{position: "absolute", inset: 0}}>
        <SvgDefs />
        <clipPath id="inClip"><rect x={INSET.x + 6} y={INSET.y + 6} width={INSET.w - 12} height={INSET.h - 12} rx={22} /></clipPath>

        <g opacity={sceneIn}>
          <line x1={80} x2={SX + 60} y1={BASE_Y} y2={BASE_Y} stroke={theme.colors.panelEdge} strokeWidth={3} />
          <line x1={80} x2={SX + 60} y1={AX} y2={AX} stroke={theme.colors.panelEdge} strokeWidth={2} strokeDasharray="14 12" />
        </g>

        {/* objects: tree (behind), apple (front) */}
        <g opacity={Math.min(1, tIn)} transform={`translate(0 ${(1 - Math.min(1, tIn)) * 30})`}>
          <Tree x={TREE.x} y={BASE_Y} s={TREE.s} />
        </g>
        <g opacity={Math.min(1, aIn)} transform={`translate(0 ${(1 - Math.min(1, aIn)) * 30})`}>
          <Apple x={APPLE.x} y={APPLE.y + breathe(frame, 2, 26)} s={APPLE.s} />
        </g>

        {/* rays: apple → lens → sensor point; tree → lens → sensor point */}
        {LENS_H.map((h, i) => <Ray key={`a${i}`} pts={rayTo(APPLE.x, appleTopY, h, appleImgY)} p={apRays[i]} />)}
        {LENS_H.map((h, i) => (
          <Ray key={`t${i}`} pts={rayTo(TREE.x, treeTopY, h, treeImgY)} p={trRays[i]} color={theme.colors.leaf} />
        ))}

        {/* lens + sensor */}
        <g opacity={Math.min(1, lensIn)} transform={`translate(0 ${(1 - Math.min(1, lensIn)) * -30})`}>
          <LensShape x={LX} cy={AX} h={160} w={26} kind="convex" />
          <SensorBar x={SX} cy={AX} h={150} glow={sensorGlow} />
        </g>
        {/* focus points on the sensor */}
        <g filter="url(#glow)" opacity={lock}>
          <circle cx={SX} cy={appleImgY} r={10} fill={theme.colors.accent} />
          <circle cx={SX} cy={treeImgY} r={10} fill={theme.colors.accent} opacity={trRays[2]} />
        </g>

        {/* zoom connector → inset */}
        <g opacity={Math.min(1, insetIn)} stroke={theme.colors.panelEdge} strokeWidth={2} strokeDasharray="8 8">
          <line x1={SX + 12} y1={AX - 150} x2={INSET.x} y2={INSET.y} />
          <line x1={SX + 12} y1={AX + 150} x2={INSET.x} y2={INSET.y + INSET.h} />
        </g>
        <g opacity={Math.min(1, insetIn)} transform={`translate(${(1 - Math.min(1, insetIn)) * 50} 0)`}>
          <rect {...INSET} rx={28} fill={theme.colors.bgAlt} stroke={done > 0 ? theme.colors.accent : theme.colors.panelEdge} strokeWidth={done > 0 ? 5 : 3} />
        </g>
        <g transform={`translate(${(1 - Math.min(1, insetIn)) * 50} 0)`}>
          <InsetImage cx={cx} cy={cy} ps={ps} ap={apPart} tr={trPart} done={done} opacity={Math.min(1, insetIn)} />
        </g>
      </svg>

      <Headlines
        items={[
          {words: [{t: "Sensor-এ", color: theme.colors.accent}, "Focus"], from: 4, to: Math.max(tApplePart - 6, 60)},
          {words: ["আলোর", "অংশ", "→", {t: "ছবির", color: theme.colors.accent}, "অংশ"], from: Math.max(tApplePart - 6, 60), to: Math.max(tImage - 4, 120)},
          {words: [{t: "Optical Image", color: theme.colors.accent}], from: Math.max(tImage - 4, 120), to: end},
        ]}
        size={88}
      />
      <Tag x={APPLE.x} y={BASE_Y + 54} text="আপেল" delay={tObj + 6} size={30} />
      <Tag x={TREE.x} y={BASE_Y + 54} text="গাছ" delay={tTree} size={30} />
      <Tag x={LX} y={AX + 215} text="লেন্স" delay={10} size={30} />
      <Tag x={SX} y={AX + 215} text="Sensor" delay={tFocus + 6} accent size={30} />
      <Tag x={INSET.x + INSET.w / 2} y={INSET.y - 40} text="Optical Image" delay={tImage} accent size={34} />
      <Sfx at={6} name="pop" vol={0.8} />
      <Sfx at={tObj} name="pop" rate={1.1} />
      <Sfx at={tFocus} name="whoosh" vol={0.5} />
      <Sfx at={tLock} name="chime" />
      <Sfx at={tTree} name="pop" rate={0.9} vol={0.8} />
      <Sfx at={tApplePart} name="click" />
      <Sfx at={tImage} name="chime" rate={1.25} />
    </AbsoluteFill>
  );
};

/** The inverted optical image painted piece by piece on the sensor view. */
const InsetImage: React.FC<{cx: number; cy: number; ps: number; ap: number; tr: number; done: number; opacity: number}> = ({
  cx, cy, ps, ap, tr, done, opacity,
}) => (
  <g opacity={opacity} clipPath="url(#inClip)">
    <g transform={`translate(${cx} ${cy}) rotate(180) scale(${ps})`}>
      <rect x={-200} y={-170} width={400} height={340} fill="#17304F" />
      <rect x={-200} y={60} width={400} height={110} fill="#14283F" />
      <g opacity={tr}><Tree x={-70} y={95} s={0.78} /></g>
      <g opacity={ap}><Apple x={80} y={95} s={0.9} /></g>
      <rect x={-200} y={-170} width={400} height={340} fill={theme.colors.accent} opacity={0.18 * (1 - done) * Math.min(1, tr)} />
    </g>
  </g>
);
