# techbeat inside — 3D Aperture test (Remotion + Three.js + R3F)

## ⚠️ Status (honest)
Tested here: SRT parsing, SFX/music generation (ffprobe-verified), ray-blocking maths, TypeScript syntax.
**NOT yet tested:** npm install, Remotion compile, WebGL render, final MP4. The sandbox had no network.
Please run the steps below in GitHub Codespaces and send me any error text or the `out/check_*.png` frames.

## Codespaces steps
```bash
unzip techbeat-3d-aperture.zip && cd techbeat-3d
npm run setup          # installs exact-pinned Remotion + three + R3F (needs internet)
npm run prepare:srt    # SRT -> src/data/cues.json (already done once)
npm run sfx            # regenerates SFX/music (already included)
npm run stills         # renders 11 key frames to out/check_*.png  <- LOOK at these first
npm run render:test    # -> out/aperture_raw.mp4 (1920x1080, 30fps, H.264 + AAC 48kHz)
npm run master         # -> out/aperture_final.mp4 (-14 LUFS, -1 dBTP)
```
Preview in browser: `npm run studio`.

## Voiceover
The SRT is timing only. Put your recording at `public/voiceover.mp3`, then in `src/config.ts` set
`VOICEOVER_FILE = "voiceover.mp3"`. Music ducks automatically under each SRT cue.

## Timing
The SRT has 3 long cues; visual beats inside them are ESTIMATED. Tune only `src/scenes/aperture/timeline.ts`
(camera keys, iris keys, label times) — audio follows automatically from the same file.

## Structure
- `scripts/` prepare (SRT), make-sfx, validate, stills, master
- `src/lib/` easing + deterministic camera + 3D→screen projection
- `src/three/` Iris, Rays, LensAssembly, Scene3D (Three.js / R3F)
- `src/audio/` SFX timeline + AudioTrack (ducking, fades)
- `src/scenes/` ApertureScene + labels + per-video timeline
