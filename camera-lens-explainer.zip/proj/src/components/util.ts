import {interpolate} from "remotion";
import {theme} from "../theme";

/** Eased 0→1 progress of `frame` over [start, start+dur]. Always clamped. */
export const prog = (frame: number, start: number, dur: number, easing: (t: number) => number = theme.ease.out) =>
  interpolate(frame, [start, start + dur], [0, 1], {easing, extrapolateLeft: "clamp", extrapolateRight: "clamp"});

/** Gentle idle motion for anything staying on screen >2 s. */
export const breathe = (frame: number, amp = 1, speed = 22) => Math.sin(frame / speed) * amp;
