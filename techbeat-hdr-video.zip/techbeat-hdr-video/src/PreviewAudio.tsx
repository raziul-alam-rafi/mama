import React, { useEffect, useState } from "react";
import { Audio, continueRender, delayRender, getRemotionEnvironment, staticFile } from "remotion";

/** চালু/বন্ধ ফ্ল্যাগ: Studio প্রিভিউতে ভয়েসওভার শোনার জন্য */
export const ENABLE_PREVIEW_AUDIO = true;
/** রেন্ডারেও ভয়েসওভার মেশাতে চাইলে true (ডিফল্ট: বন্ধ — ভিডিওতে শুধু SFX) */
export const VOICEOVER_IN_RENDER = false;

/** public/voiceover.mp3 থাকলে বাজবে, না থাকলে নীরবে বাদ */
export const PreviewAudio: React.FC = () => {
  const isRendering = getRemotionEnvironment().isRendering;
  const skip = !ENABLE_PREVIEW_AUDIO || (isRendering && !VOICEOVER_IN_RENDER);
  const [exists, setExists] = useState(false);
  const [handle] = useState(() => (skip ? null : delayRender("voiceover.mp3 আছে কিনা দেখা হচ্ছে")));

  useEffect(() => {
    if (skip || handle === null) return;
    fetch(staticFile("voiceover.mp3"), { method: "HEAD" })
      .then((r) => setExists(r.ok && (r.headers.get("content-type") ?? "").includes("audio")))
      .catch(() => setExists(false))
      .finally(() => continueRender(handle));
  }, [skip, handle]);

  if (skip || !exists) return null;
  return <Audio src={staticFile("voiceover.mp3")} />;
};
