// সিন ৩ (cue 5–6): সমস্যা — এক শটে হয় আকাশ সাদা, নয় মুখ অন্ধকার (Before/After Split + উজ্জ্বলতার সীমা)
import React from "react";
import { useCurrentFrame } from "remotion";
import { theme } from "../theme";
import { makeT } from "../timing";
import { Entrance, SceneShell, tween, useBreathe } from "../components/anim";
import { Chip } from "../components/ui";
import { EXPO, Photo } from "../components/photo";
import { RangeBar } from "../components/rangebar";
import { SfxEvent } from "../sfx";

const T = makeT(2);
const tLeft = T(5);
const tLeftChip = T(5, "ছবিতে আপনার মুখ");
const tWhite = T(5, "আকাশটা সাদা");
const tRight = T(5, "আবার আকাশ");
const tRightChip = T(6, "আপনার মুখ অন্ধকার");
const tProblem = T(6, "এই সমস্যার");
const tSolve = T(6, "সমাধানে");

export const sfx03: SfxEvent[] = [
  { kind: "pop", frame: tLeft + 4 },
  { kind: "click", frame: tLeftChip + 4 },
  { kind: "pop", frame: tRight + 4, rate: 1.06 },
  { kind: "click", frame: tRightChip + 2, rate: 0.95 },
  { kind: "pop", frame: tProblem + 2, rate: 0.9 },
  { kind: "chime", frame: tSolve + 6, vol: 0.7 },
];

const PW = 760;
const pulse = (frame: number, at: number) => { const d = frame - at; return d < 0 || d > 40 ? 0 : Math.sin((d / 40) * Math.PI); };

export const Scene03: React.FC = () => {
  const frame = useCurrentFrame();
  const bob = useBreathe(46, 4);
  const slide = tween(frame, tRight + 2, tRight + 28, 0, 1, theme.ease.inOut);
  const lo = 0.02 + 0.43 * slide;
  const hi = 0.55 + 0.43 * slide;
  const probP = tween(frame, tProblem, tProblem + 14, 0, 1);

  return (
    <SceneShell>
      <Entrance delay={4} style={{ position: "absolute", left: 120, top: 70 }}>
        <Chip text="সমস্যা" color={theme.colors.warn} solid size={40} style={{ transform: `scale(${1 + pulse(frame, tProblem) * 0.12})` }} />
      </Entrance>
      <Entrance delay={tSolve} style={{ position: "absolute", right: 120, top: 62 }}>
        <Chip text="সমাধান" color={theme.colors.ok} solid size={40} />
      </Entrance>

      {/* বাম: মুখ ঠিক, আকাশ সাদা (দীর্ঘ exposure) */}
      <Entrance delay={tLeft} x={-60} y={0} style={{ position: "absolute", left: 120, top: 185 + bob }}>
        <div style={{ borderRadius: 22, border: `3px solid ${probP > 0.5 ? theme.colors.warn : theme.colors.line}`, boxShadow: theme.shadow.card, overflow: "hidden" }}>
          <Photo uid="s3a" gRoom={EXPO.over} gSky={EXPO.over} width={PW} radius={0} />
        </div>
      </Entrance>
      <Entrance delay={tLeftChip} style={{ position: "absolute", left: 120, top: 660 }}>
        <Chip text="মুখ স্পষ্ট, আকাশ সাদা" color={theme.colors.accent} size={40} />
      </Entrance>

      {/* ডান: আকাশ ঠিক, মুখ অন্ধকার (কম exposure) */}
      <Entrance delay={tRight} x={60} y={0} style={{ position: "absolute", left: 1040, top: 185 + bob }}>
        <div style={{ borderRadius: 22, border: `3px solid ${probP > 0.5 ? theme.colors.warn : theme.colors.line}`, boxShadow: theme.shadow.card, overflow: "hidden" }}>
          <Photo uid="s3b" gRoom={EXPO.under} gSky={EXPO.under} width={PW} radius={0} />
        </div>
      </Entrance>
      <Entrance delay={tRightChip} style={{ position: "absolute", left: 1040, top: 660 }}>
        <Chip text="আকাশ ঠিক, মুখ অন্ধকার" color={theme.colors.hero} size={40} />
      </Entrance>

      {/* উজ্জ্বলতার সীমা */}
      <Entrance delay={tLeft + 10} style={{ position: "absolute", left: 120, top: 765 }}>
        <RangeBar w={1680} lo={lo} hi={hi} bracketLabel="একটি ছবির সীমা" pulseSky={pulse(frame, tWhite)} pulseFace={pulse(frame, tRightChip)} />
      </Entrance>
    </SceneShell>
  );
};
