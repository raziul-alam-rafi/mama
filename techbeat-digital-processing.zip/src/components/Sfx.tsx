import React from "react";
import { Audio, Sequence, staticFile, useVideoConfig } from "remotion";
import { SFX_ENABLED } from "../config";
import { SFX_LEN, SFX_PLAN } from "../sfxPlan";

/** Short UI/motion sounds, placed ~3 frames BEFORE the visual lands. */
export const SfxLayer: React.FC = () => {
  const { fps } = useVideoConfig();
  if (!SFX_ENABLED) return null;
  return (
    <>
      {SFX_PLAN.map((e, i) => (
        <Sequence key={i} from={Math.max(0, Math.round(e.sec * fps) - 3)} durationInFrames={Math.ceil(SFX_LEN[e.name] * fps) + 2}>
          <Audio src={staticFile(`sfx/${e.name}.wav`)} volume={e.vol} playbackRate={e.rate ?? 1} />
        </Sequence>
      ))}
    </>
  );
};
