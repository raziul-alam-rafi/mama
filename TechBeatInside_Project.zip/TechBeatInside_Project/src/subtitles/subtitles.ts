import {FPS} from '../config/theme';

export type Cue = {index: number; start: number; end: number; text: string};

// Mirrors public/srt/narration.srt (the master timeline). Times in seconds.
export const CUES: Cue[] = [
  {
    index: 1,
    start: 0.22,
    end: 6.6,
    text: 'ধরুন একটি টিভি চ্যানেলে ক্রিকেট ম্যাচ\nদেখানো হচ্ছে। এখানে মাঠে যা ঘটছে ক্যামেরা',
  },
  {
    index: 2,
    start: 6.6,
    end: 13.14,
    text: 'সেই দৃশ্য ধারণ করছে। এরপর ক্যামেরার ছবিকে\nবৈদ্যুতিক সংকেতে রূপান্তর করে সম্প্রচারের',
  },
  {
    index: 3,
    start: 13.14,
    end: 18.84,
    text: 'জন্য পাঠানো হত। আর সেই সংকেত antennaর\nমাধ্যমে আপনার বাড়ির টিভিতে পৌঁছাত।',
  },
];

export const TOTAL_FRAMES = Math.ceil(CUES[CUES.length - 1].end * FPS);

const flat = (t: string) => [...t.replace(/\n/g, ' ')];

/**
 * Time (seconds) at which `phrase` starts/ends INSIDE a cue.
 * The SRT only gives cue-level timing, so the position inside the cue is estimated
 * from the character position of the phrase (speech is roughly uniform).
 */
export function at(cueIndex: number, phrase: string, edge: 'start' | 'end' = 'start'): number {
  const cue = CUES.find((c) => c.index === cueIndex);
  if (!cue) throw new Error(`No cue ${cueIndex}`);
  const chars = flat(cue.text);
  const text = chars.join('');
  const i = text.indexOf(phrase);
  if (i < 0) throw new Error(`Phrase "${phrase}" not found in cue ${cueIndex}`);
  const startCp = [...text.slice(0, i)].length;
  const endCp = startCp + [...phrase].length;
  const frac = (edge === 'start' ? startCp : endCp) / chars.length;
  return cue.start + (cue.end - cue.start) * frac;
}

export const activeCue = (frame: number): Cue | undefined => {
  const t = frame / FPS;
  return CUES.find((c) => t >= c.start && t < c.end);
};
