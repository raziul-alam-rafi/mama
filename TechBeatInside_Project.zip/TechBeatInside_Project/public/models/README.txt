Place models assets here. See research/sources.md for licensing rules.
