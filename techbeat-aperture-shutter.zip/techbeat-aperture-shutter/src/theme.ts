// theme.ts — single source of truth: colors, easings, springs, fonts, sizes.
import { Easing } from "remotion";

export const theme = {
  colors: {
    bg: "#0B1020",
    bgAlt: "#111833",
    panel: "#161F3F",
    panelHi: "#1F2B55",
    line: "#2D3B6B",
    primary: "#4F8CFF", // hero blue — optics / main system
    primaryDeep: "#2B5FD0",
    primarySoft: "#8DB4FF",
    accent: "#FFB84D", // amber — highlighted action
    accentSoft: "#FFD9A0",
    light: "#FFD27A", // light rays
    signal: "#4FE3C1", // electronic signal / data
    text: "#F4F7FF",
    textDim: "#9AA7C7",
    metal: "#C9D3EC",
    metalDark: "#6B7AA6",
    shadow: "rgba(2,5,16,0.6)",
  },
  fonts: {
    display: '"Hind Siliguri", system-ui, sans-serif',
  },
  ease: {
    out: Easing.bezier(0.16, 1, 0.3, 1),
    inOut: Easing.bezier(0.83, 0, 0.17, 1),
    soft: Easing.bezier(0.45, 0, 0.2, 1),
    in: Easing.bezier(0.7, 0, 0.84, 0),
  },
  spring: {
    snappy: { damping: 14, stiffness: 160, mass: 0.6 },
    smooth: { damping: 20, stiffness: 90, mass: 1 },
    bouncy: { damping: 11, stiffness: 170, mass: 0.7 },
  },
  radius: { card: 28, chip: 999 },
  type: { hero: 150, title: 100, label: 48, small: 36 },
  motion: {
    lead: 5, // frames: visuals enter just before the spoken words
    exit: 10, // frames: exits are faster than entrances
    overlap: 8, // frames: incoming scene overlaps outgoing one
  },
} as const;

export type Theme = typeof theme;
