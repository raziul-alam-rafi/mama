import React from 'react';
import * as THREE from 'three';
import {LIGHT} from '../../config/theme';
import {hash1} from '../../utils/math';
import {adBoardTexture, crowdTexture, glowSprite, grassTexture} from '../materials/textures';

type V3 = [number, number, number];

const Player: React.FC<{x: number; z: number; shirt: string; frame: number; i: number}> = ({x, z, shirt, frame, i}) => {
  const bob = Math.sin(frame * 0.12 + i) * 0.03;
  return (
    <group position={[x, bob, z]}>
      <mesh position={[0, 0.85, 0]}>
        <capsuleGeometry args={[0.2, 0.55, 4, 10]} />
        <meshStandardMaterial color={shirt} roughness={0.8} />
      </mesh>
      <mesh position={[0, 1.5, 0]}>
        <sphereGeometry args={[0.13, 12, 10]} />
        <meshStandardMaterial color="#c99872" roughness={0.8} />
      </mesh>
      <mesh position={[0, 0.3, 0]}>
        <capsuleGeometry args={[0.16, 0.4, 4, 8]} />
        <meshStandardMaterial color="#f2f2ee" roughness={0.9} />
      </mesh>
    </group>
  );
};

const Stumps: React.FC<{z: number}> = ({z}) => (
  <group position={[0, 0, z]}>
    {[-0.1, 0, 0.1].map((x) => (
      <mesh key={x} position={[x, 0.36, 0]}>
        <cylinderGeometry args={[0.018, 0.018, 0.72, 8]} />
        <meshStandardMaterial color="#e9dcb4" roughness={0.6} />
      </mesh>
    ))}
    {[-0.05, 0.05].map((x) => (
      <mesh key={x} position={[x, 0.735, 0]} rotation={[0, 0, Math.PI / 2]}>
        <cylinderGeometry args={[0.01, 0.01, 0.1, 6]} />
        <meshStandardMaterial color="#e9dcb4" />
      </mesh>
    ))}
  </group>
);

const Floodlight: React.FC<{angle: number}> = ({angle}) => {
  const R = 68;
  const x = Math.cos(angle) * R;
  const z = Math.sin(angle) * R;
  const yaw = Math.atan2(-x, -z); // face the pitch
  return (
    <group position={[x, 0, z]} rotation={[0, yaw, 0]}>
      <mesh position={[0, 20, 0]}>
        <cylinderGeometry args={[0.5, 1.0, 40, 12]} />
        <meshStandardMaterial color="#9a9ea4" roughness={0.6} metalness={0.7} />
      </mesh>
      <group position={[0, 40.5, 0.4]} rotation={[0.35, 0, 0]}>
        <mesh>
          <boxGeometry args={[9, 5.5, 0.8]} />
          <meshStandardMaterial color="#222428" roughness={0.6} metalness={0.5} />
        </mesh>
        <mesh position={[0, 0, 0.42]}>
          <planeGeometry args={[8.4, 5]} />
          <meshBasicMaterial color="#fff6df" toneMapped={false} />
        </mesh>
        <sprite position={[0, 0, 3]} scale={[34, 34, 1]}>
          <spriteMaterial map={glowSprite()} blending={THREE.AdditiveBlending} depthWrite={false} transparent opacity={0.85} />
        </sprite>
      </group>
    </group>
  );
};

/** Floodlit cricket ground: striped outfield, pitch, stumps, players, tiered stands, floodlights. */
export const Stadium: React.FC<{frame: number}> = ({frame}) => {
  const crowd = crowdTexture();
  const tiers: {r0: number; r1: number; y0: number; y1: number}[] = [
    {r0: 39, r1: 46, y0: 0.8, y1: 5},
    {r0: 46, r1: 54, y0: 5, y1: 11},
    {r0: 54, r1: 63, y0: 11, y1: 19},
  ];
  const fielders = Array.from({length: 9}).map((_, i) => {
    const a = (i / 9) * Math.PI * 2 + 0.3;
    const r = 14 + hash1(i * 5.3) * 16;
    return {x: Math.cos(a) * r, z: Math.sin(a) * r};
  });
  return (
    <group name="Stadium">
      {/* outfield */}
      <mesh rotation={[-Math.PI / 2, 0, 0]} position={[0, 0.01, 0]}>
        <circleGeometry args={[37, 96]} />
        <meshStandardMaterial map={grassTexture()} roughness={0.95} />
      </mesh>
      {/* concourse */}
      <mesh rotation={[-Math.PI / 2, 0, 0]} position={[0, 0.0, 0]}>
        <ringGeometry args={[36.9, 66, 96]} />
        <meshStandardMaterial color="#3b3d42" roughness={1} />
      </mesh>
      {/* boundary rope */}
      <mesh rotation={[-Math.PI / 2, 0, 0]} position={[0, 0.06, 0]}>
        <torusGeometry args={[36.2, 0.08, 6, 160]} />
        <meshStandardMaterial color="#f4f4f0" roughness={0.7} />
      </mesh>
      {/* advertising boards: colour blocks only, no logos */}
      <mesh position={[0, 0.5, 0]}>
        <cylinderGeometry args={[37.6, 37.6, 1.0, 120, 1, true]} />
        <meshStandardMaterial
          map={adBoardTexture()}
          emissiveMap={adBoardTexture()}
          emissive="#ffffff"
          emissiveIntensity={0.35}
          roughness={0.6}
          side={THREE.DoubleSide}
        />
      </mesh>
      {/* pitch (along Z) */}
      <mesh position={[0, 0.025, 0]}>
        <boxGeometry args={[3.05, 0.03, 20.12]} />
        <meshStandardMaterial color="#c7ab7b" roughness={1} />
      </mesh>
      {[-8.8, -10.06, 8.8, 10.06].map((z) => (
        <mesh key={z} position={[0, 0.045, z]}>
          <boxGeometry args={[2.6 + (Math.abs(z) > 9.5 ? 0.5 : 0), 0.01, 0.05]} />
          <meshStandardMaterial color="#f5f5ee" />
        </mesh>
      ))}
      <Stumps z={-10.06} />
      <Stumps z={10.06} />
      {/* players */}
      <Player x={0.3} z={-9.2} shirt="#f2f2ee" frame={frame} i={0} />
      <Player x={0.0} z={3.0 + Math.sin(frame * 0.05) * 0.6} shirt="#2058c2" frame={frame} i={1} />
      {fielders.map((f, i) => (
        <Player key={i} x={f.x} z={f.z} shirt="#e9edf5" frame={frame} i={i + 2} />
      ))}
      {/* stands */}
      {tiers.map((t, i) => {
        const h = t.y1 - t.y0;
        return (
          <mesh key={i} position={[0, t.y0 + h / 2, 0]}>
            <cylinderGeometry args={[t.r1, t.r0, h, 120, 1, true]} />
            <meshStandardMaterial
              map={crowd}
              emissiveMap={crowd}
              emissive="#ffffff"
              emissiveIntensity={0.55}
              roughness={0.95}
              side={THREE.DoubleSide}
            />
          </mesh>
        );
      })}
      {/* stand roof rim */}
      <mesh position={[0, 19.2, 0]} rotation={[-Math.PI / 2, 0, 0]}>
        <ringGeometry args={[62, 66, 120]} />
        <meshStandardMaterial color="#2a2c31" roughness={0.8} side={THREE.DoubleSide} />
      </mesh>
      {[0.8, 2.4, 3.9, 5.5].map((a) => (
        <Floodlight key={a} angle={a + 0.2} />
      ))}
      {/* local stadium lighting (kept inside the stadium by distance cutoff) */}
      {([[-22, 34, -16], [24, 34, -14], [0, 38, 22]] as V3[]).map((p, i) => (
        <pointLight key={i} position={p} color="#fff1d6" intensity={LIGHT.stadiumPoint} distance={95} decay={0} />
      ))}
    </group>
  );
};
