import React from "react";
import { interpolate, spring, useCurrentFrame, useVideoConfig } from "remotion";
import { theme } from "../theme";
import { CL } from "./Motion";

export type Mark = { color: string; underline?: boolean; glow?: boolean; pop?: boolean };

/**
 * Word-by-word staggered reveal. Splits ONLY on spaces — Bengali is never animated per character
 * (conjuncts, kar-signs and ref would break). letterSpacing stays 0.
 */
export const WordReveal: React.FC<{
  text: string;
  delay?: number;
  per?: number;
  size: number;
  weight?: number;
  color?: string;
  align?: "left" | "center";
  marks?: Record<string, Mark>;
  maxWidth?: number;
  lineHeight?: number;
  gap?: number;
  style?: React.CSSProperties;
}> = ({ text, delay = 0, per = 4, size, weight = 700, color = theme.colors.text, align = "left", marks = {}, maxWidth, lineHeight = 1.32, gap, style }) => {
  const frame = useCurrentFrame();
  const { fps } = useVideoConfig();
  const words = text.split(" ").filter(Boolean);
  return (
    <div
      style={{
        display: "flex",
        flexWrap: "wrap",
        columnGap: gap ?? Math.round(size * 0.28),
        justifyContent: align === "center" ? "center" : "flex-start",
        textAlign: align,
        maxWidth,
        fontFamily: theme.fonts.display,
        fontSize: size,
        fontWeight: weight,
        lineHeight,
        letterSpacing: 0,
        color,
        ...style,
      }}
    >
      {words.map((w, i) => {
        const m = marks[w];
        const start = frame - delay - i * per;
        const p = spring({ frame: start, fps, config: m?.pop ? theme.spring.bouncy : theme.spring.snappy });
        const u = interpolate(spring({ frame: start - 8, fps, config: theme.spring.smooth }), [0, 1], [0, 1], CL);
        return (
          <span
            key={`${w}-${i}`}
            style={{
              position: "relative",
              display: "inline-block",
              whiteSpace: "nowrap",
              opacity: Math.min(1, Math.max(0, p * 1.4)),
              transform: `translateY(${interpolate(p, [0, 1], [34, 0])}px) scale(${interpolate(p, [0, 1], [m?.pop ? 0.6 : 0.92, 1])})`,
              color: m?.color ?? undefined,
              textShadow: m?.glow ? `0 0 44px ${theme.colors.glow}` : undefined,
            }}
          >
            {w}
            {m?.underline ? (
              <span
                style={{
                  position: "absolute",
                  left: 0,
                  bottom: Math.round(size * 0.02),
                  height: Math.max(6, Math.round(size * 0.05)),
                  width: `${u * 100}%`,
                  borderRadius: theme.radius.pill,
                  background: m.color,
                  opacity: 0.9,
                }}
              />
            ) : null}
          </span>
        );
      })}
    </div>
  );
};
