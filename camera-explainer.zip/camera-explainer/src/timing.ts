import { CUES, FPS, TOTAL } from "./srt";

// ভিজ্যুয়াল সংশ্লিষ্ট কথার ৫ ফ্রেম আগে ঢোকে (নির্দেশ: ৪-৬)
export const LEAD = 5;

// অর্থ অনুযায়ী সিন (cue নম্বর, ১-ভিত্তিক, সীমা সহ)
const SCENE_CUES: [number, number][] = [
  [1, 1], // হুক
  [2, 3], // আলো → বিদ্যুৎ → হিসাব → ছবি
  [4, 5], // ভেতরে ছবি নেই, আছে শুধু আলো ও সিগন্যাল
  [6, 6], // কীভাবে বোঝে: মুখ, আকাশ, গাছ
  [7, 7], // ভেতরে ঢোকার যাত্রা
  [8, 9], // সমাপ্তি
];

const cs = (n: number) => Math.round(CUES[n - 1].start * FPS);
const ce = (n: number) => Math.round(CUES[n - 1].end * FPS);

export const SCENES = SCENE_CUES.map(([a, b], k) => ({
  a,
  b,
  from: k === 0 ? 0 : cs(a) - LEAD,
  to: k === SCENE_CUES.length - 1 ? TOTAL : cs(SCENE_CUES[k + 1][0]) - LEAD,
}));

export const sceneDur = (k: number) => SCENES[k].to - SCENES[k].from;

/** সিন k-এর লোকাল ফ্রেম, যেখানে cue-এর frac অংশে পৌঁছালে কথাটা বলা হয় (LEAD ফ্রেম আগে)। */
export const at = (k: number, cue: number, frac = 0) =>
  Math.max(0, Math.round(cs(cue) + frac * (ce(cue) - cs(cue)) - LEAD - SCENES[k].from));

export { FPS, TOTAL };
