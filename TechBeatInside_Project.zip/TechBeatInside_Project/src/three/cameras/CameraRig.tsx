import React, {useLayoutEffect} from 'react';
import {useThree} from '@react-three/fiber';
import * as THREE from 'three';
import {useCurrentFrame} from 'remotion';
import {shotAt, shotProgress} from './shots';

/** Sets the camera from the shot list every frame (pure function of the frame => deterministic). */
export const CameraRig: React.FC = () => {
  const frame = useCurrentFrame();
  const {camera, invalidate} = useThree();
  const shot = shotAt(frame);
  const p = shot.ease(shotProgress(shot, frame));
  const st = shot.cam(p, frame);
  useLayoutEffect(() => {
    camera.position.copy(st.pos);
    camera.lookAt(st.target);
    if (camera instanceof THREE.PerspectiveCamera) {
      camera.fov = st.fov;
      camera.updateProjectionMatrix();
    }
    camera.updateMatrixWorld();
    invalidate();
  });
  return null;
};
