// Single switch for the voice-over preview track (public/voiceover.mp3).
//  "studio" -> plays in Remotion Studio / Player only, never baked into a render (default)
//  "always" -> also plays in renders (only if you really want the VO inside the MP4)
//  "off"    -> never plays
export const PREVIEW_AUDIO: "studio" | "always" | "off" = "studio";
export const VOICEOVER_FILE = "voiceover.mp3";
export const FPS = 30;
export const WIDTH = 1920;
export const HEIGHT = 1080;
