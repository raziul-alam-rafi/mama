// সিন ৪ — প্রথম কাজ: আলো নিয়ন্ত্রণ (Statement Card + রশ্মির ফোকাস) · cue 7–8
import React from "react";
import { AbsoluteFill, interpolate } from "remotion";
import { Beam, RayLayer } from "../components/Rays";
import { CheckIcon } from "../components/Icons";
import { Breathe, Chip, Enter, Glass, Words, usePop, useProgress } from "../components/Primitives";
import { Sfx } from "../components/audio";
import { at } from "../timeline";
import { theme } from "../theme";

const c = theme.colors;
const SI = 3;
const F = { x: 1530, y: 540 }; // ফোকাস বিন্দু
const RING = 400;
const N = 14;

// প্রতিটি রশ্মির এলোমেলো (কিন্তু নির্দিষ্ট) লক্ষ্য-অফসেট
const rays = Array.from({ length: N }).map((_, i) => {
  const a = (i / N) * Math.PI * 2 + 0.2;
  const ro = 70 + ((i * 97) % 190);
  const ao = i * 2.399963; // golden angle
  return { a, off: [Math.cos(ao) * ro, Math.sin(ao) * ro] as const };
});

export const S4Control: React.FC = () => {
  const tFirst = at(SI, 7, "ক্যামেরার");
  const tAround = at(SI, 7, "চারপাশ");
  const tCtl = at(SI, 8, "নিয়ন্ত্রণ");
  const tClear = at(SI, 8, "পরিষ্কার");

  const ring = useProgress(tAround, 26, theme.ease.inOut);
  const rayP = rays.map((_, i) => useProgress(tAround + 6 + i * 2, 24));
  const focus = useProgress(tCtl + 4, 30, theme.ease.inOut);
  const dot = usePop(tCtl + 24, theme.spring.bouncy);
  const blurBall = interpolate(focus, [0, 1], [1, 0]);
  const ctl = usePop(tCtl, theme.spring.bouncy);
  const check = useProgress(tClear + 10, 16);
  const pill = usePop(tClear, theme.spring.smooth);

  return (
    <AbsoluteFill>
      {/* ডান: রশ্মির ফোকাস */}
      <svg width={1920} height={1080} viewBox="0 0 1920 1080" style={{ position: "absolute", left: 0, top: 0, overflow: "visible" }}>
        <circle cx={F.x} cy={F.y} r={RING} fill="none" stroke={c.text} strokeOpacity={0.16} strokeWidth={3} strokeDasharray="6 18"
          pathLength={1} style={{ strokeDasharray: `${ring} 2`, transformOrigin: `${F.x}px ${F.y}px`, transform: "rotate(-90deg)" }} />
      </svg>
      <RayLayer>
        {rays.map((r, i) => {
          const sx = F.x + Math.cos(r.a) * RING, sy = F.y + Math.sin(r.a) * RING;
          const tx = F.x + r.off[0] * (1 - focus), ty = F.y + r.off[1] * (1 - focus);
          return <Beam key={i} id={`s4-r-${i}`} pts={[[sx, sy], [tx, ty]]} p={rayP[i]} width={5} flow={focus > 0.9} />;
        })}
      </RayLayer>
      {/* ফোকাস বিন্দু: ঝাপসা বল → ধারালো বিন্দু */}
      <div
        style={{
          position: "absolute", left: F.x - 130, top: F.y - 130, width: 260, height: 260, borderRadius: "50%",
          background: `radial-gradient(circle, ${c.accent}, transparent 68%)`, filter: "blur(26px)",
          opacity: 0.55 * blurBall * ring, transform: `scale(${0.6 + blurBall * 0.6})`,
        }}
      />
      <div
        style={{
          position: "absolute", left: F.x - 26, top: F.y - 26, width: 52, height: 52, borderRadius: "50%", background: c.white,
          boxShadow: `0 0 0 8px ${c.accent}, 0 0 70px 20px ${c.accentGlow}`, opacity: Math.min(1, dot), transform: `scale(${dot})`,
        }}
      />

      {/* বাঁ: বার্তা */}
      <div style={{ position: "absolute", left: theme.margin, top: 0, bottom: 0, width: 1020, display: "flex", flexDirection: "column", justifyContent: "center", gap: 26 }}>
        <Enter delay={tFirst} y={26}>
          <Chip text="ক্যামেরার প্রথম কাজ" size={46} tone="dim" />
        </Enter>
        <Words text="চারপাশ থেকে আসা আলো" delay={tAround} size={86} color={c.textDim} />
        <div style={{ opacity: Math.min(1, ctl), transform: `scale(${interpolate(ctl, [0, 1], [1.28, 1])}) translateY(${interpolate(ctl, [0, 1], [-20, 0])}px)`, transformOrigin: "left center" }}>
          <div style={{ filter: `drop-shadow(0 0 ${46 * ctl}px ${c.glow})`, display: "inline-block" }}>
            <Breathe amp={0.5}>
              <div
                style={{
                  fontFamily: theme.fonts.display, fontWeight: theme.weight.heavy, fontSize: 236, lineHeight: 1.2, letterSpacing: 0,
                  backgroundImage: `linear-gradient(100deg, ${c.white}, ${c.primary} 75%)`, WebkitBackgroundClip: "text", backgroundClip: "text", color: "transparent",
                }}
              >
                নিয়ন্ত্রণ
              </div>
            </Breathe>
          </div>
        </div>
        <div style={{ opacity: Math.min(1, pill), transform: `translateY(${interpolate(pill, [0, 1], [30, 0])}px) scale(${interpolate(pill, [0, 1], [0.94, 1])})`, alignSelf: "flex-start" }}>
          <Glass style={{ display: "flex", alignItems: "center", gap: 24, padding: "20px 44px 20px 28px", borderRadius: theme.radius.pill }}>
            <CheckIcon size={76} p={check} />
            <div style={{ fontFamily: theme.fonts.display, fontWeight: theme.weight.heavy, fontSize: 70, lineHeight: 1.25, letterSpacing: 0, color: c.text }}>পরিষ্কার ছবি</div>
          </Glass>
        </div>
      </div>

      <Sfx name="pop" at={tFirst - 2} />
      <Sfx name="whoosh-soft" at={tAround - 3} />
      <Sfx name="thud" at={tCtl - 1} n={1} />
      <Sfx name="chime" at={tCtl + 20} n={1} />
      <Sfx name="pop" at={tClear - 2} n={1} />
      <Sfx name="click" at={tClear + 12} />
    </AbsoluteFill>
  );
};
