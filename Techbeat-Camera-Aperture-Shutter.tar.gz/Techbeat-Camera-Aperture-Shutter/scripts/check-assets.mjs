import fs from 'node:fs';
const root = new URL('../public/', import.meta.url);
const tl = JSON.parse(fs.readFileSync(new URL('../src/audioTimeline.json', import.meta.url), 'utf8'));
let bad = 0;
for (const a of tl) {
  const p = new URL(a.file, root);
  if (!fs.existsSync(p)) { console.log('MISSING', a.file, '-> run: npm run sfx'); bad++; continue; }
  const b = fs.readFileSync(p); const sr = b.readUInt32LE(24), bytes = b.readUInt32LE(40);
  const dur = bytes / 2 / sr;
  const ok = dur + 0.01 >= a.durationSec;
  console.log(ok ? 'ok     ' : 'SHORT  ', a.file, `file=${dur.toFixed(2)}s needed=${a.durationSec}s sr=${sr}`);
  if (!ok) bad++;
}
if (!fs.existsSync(new URL('audio/narration.srt', root))) { console.log('MISSING narration.srt'); bad++; }
console.log(bad ? `${bad} problem(s)` : 'all assets OK');
process.exit(bad ? 1 : 0);
