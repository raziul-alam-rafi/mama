import React from 'react';
import {BLADES} from './optics';
import {theme} from '../theme';

const OUTER = 1.95;
const WIDTH = 1.9;

/** Stylized iris: 8 flat plates whose inner edges form the aperture opening. */
export const IrisBlades: React.FC<{radius: number}> = ({radius}) => (
  <group>
    {Array.from({length: BLADES}).map((_, i) => {
      const th = (i * 2 * Math.PI) / BLADES;
      const len = OUTER - radius;
      return (
        <group key={i} rotation={[0, 0, th]} position={[0, 0, i * 0.012]}>
          <mesh position={[radius + len / 2, 0, 0]}>
            <boxGeometry args={[len, WIDTH, 0.03]} />
            <meshStandardMaterial color={theme.colors.metal} metalness={0.75} roughness={0.35} />
          </mesh>
        </group>
      );
    })}
    <mesh>
      <torusGeometry args={[2.2, 0.12, 24, 96]} />
      <meshStandardMaterial color={theme.colors.metalEdge} metalness={0.85} roughness={0.3} />
    </mesh>
  </group>
);
