import React from 'react';
import {BEAM_START_Z, BLADE_Z, RAYS, SENSOR_Z, passes} from './optics';
import {theme} from '../theme';

const SPEED = 0.45; // beam cycles per second

/**
 * Parallel rays + travelling light packets. Rays blocked by the blades stop at the blade plane.
 * NOTE: stylized — rays are shown straight (lens refraction is not modelled in this prototype).
 */
export const LightBeam: React.FC<{radius: number; t: number}> = ({radius, t}) => (
  <group>
    {RAYS.map((q, i) => {
      const ok = passes(q.x, q.y, radius);
      const endZ = ok ? SENSOR_Z : BLADE_Z;
      const len = endZ - BEAM_START_Z;
      const prog = (t * SPEED + q.phase) % 1;
      return (
        <group key={i}>
          <mesh position={[q.x, q.y, BEAM_START_Z + len / 2]} rotation={[Math.PI / 2, 0, 0]}>
            <cylinderGeometry args={[0.008, 0.008, len, 6]} />
            <meshBasicMaterial color={theme.colors.primary} transparent opacity={ok ? 0.55 : 0.3} />
          </mesh>
          <mesh position={[q.x, q.y, BEAM_START_Z + prog * len]}>
            <sphereGeometry args={[0.04, 10, 10]} />
            <meshBasicMaterial color={theme.colors.text} />
          </mesh>
        </group>
      );
    })}
  </group>
);
