// Synthesises the 6 sound effects into public/sfx/*.wav (44.1 kHz, mono, 16-bit) and prints a QC report.
// No beeps/squares: pitch-dropped sines, filtered noise, soft overtones, low-pass + a tiny reverb.
import fs from "node:fs";
import path from "node:path";
import { fileURLToPath } from "node:url";

const SR = 44100;
const dir = path.join(path.dirname(fileURLToPath(import.meta.url)), "..", "public", "sfx");
fs.mkdirSync(dir, { recursive: true });

let seed = 12345;
const rnd = () => ((seed = (seed * 1664525 + 1013904223) >>> 0) / 4294967296) * 2 - 1;

const biquad = (type, f0, q = 0.707) => {
  const w = (2 * Math.PI * f0) / SR, al = Math.sin(w) / (2 * q), cw = Math.cos(w);
  let b0, b1, b2, a0 = 1 + al, a1 = -2 * cw, a2 = 1 - al;
  if (type === "lp") { b0 = (1 - cw) / 2; b1 = 1 - cw; b2 = b0; }
  else if (type === "hp") { b0 = (1 + cw) / 2; b1 = -(1 + cw); b2 = b0; }
  else { b0 = al; b1 = 0; b2 = -al; } // band-pass (constant peak gain)
  let x1 = 0, x2 = 0, y1 = 0, y2 = 0;
  return (x) => { const y = (b0 * x + b1 * x1 + b2 * x2 - a1 * y1 - a2 * y2) / a0; x2 = x1; x1 = x; y2 = y1; y1 = y; return y; };
};
const run = (buf, f) => buf.map((x) => f(x));
const mk = (sec) => new Float32Array(Math.round(sec * SR));
const env = (t, a, d) => (t < a ? t / a : Math.exp(-(t - a) / d)); // soft attack, exponential decay
const reverb = (buf, mix = 0.1) => {
  const out = Float32Array.from(buf);
  [[0.019, 0.5], [0.031, 0.35], [0.047, 0.25]].forEach(([d, g]) => {
    const n = Math.round(d * SR);
    for (let i = n; i < out.length; i++) out[i] += out[i - n] * g * mix * 4;
  });
  return out;
};
const fadeEnd = (buf, sec = 0.02) => { const n = Math.round(sec * SR); for (let i = 0; i < n; i++) buf[buf.length - 1 - i] *= i / n; return buf; };

const sounds = {
  pop: () => { // sine with fast downward pitch sweep
    const b = mk(0.22); let ph = 0;
    for (let i = 0; i < b.length; i++) { const t = i / SR; const f = 150 + 420 * Math.exp(-t / 0.035); ph += (2 * Math.PI * f) / SR; b[i] = Math.sin(ph) * env(t, 0.003, 0.05); }
    return reverb(run(b, biquad("lp", 3200)), 0.08);
  },
  click: () => { // high-passed short noise burst
    const b = mk(0.1); const hp = biquad("hp", 2400), lp = biquad("lp", 9000);
    for (let i = 0; i < b.length; i++) { const t = i / SR; b[i] = lp(hp(rnd())) * env(t, 0.0008, 0.011); }
    return reverb(b, 0.05);
  },
  whoosh: () => { // band-pass noise sweep (two moving one-pole filters), fade in/out
    const b = mk(0.6);
    let lp = 0, lp2 = 0;
    for (let i = 0; i < b.length; i++) {
      const u = i / b.length, fc = 350 + 2600 * Math.sin((u * Math.PI) / 2) ** 2;
      const a = 1 - Math.exp((-2 * Math.PI * fc) / SR);
      const x = rnd(); lp += a * (x - lp); lp2 += a * (lp - lp2);
      b[i] = (lp - lp2) * Math.sin(Math.PI * u) ** 2;
    }
    return reverb(run(b, biquad("lp", 6000)), 0.08);
  },
  chime: () => { // soft pluck/chime: fundamental + gentle overtones
    const b = mk(0.52);
    for (let i = 0; i < b.length; i++) {
      const t = i / SR;
      const s = Math.sin(2 * Math.PI * 784 * t) + 0.35 * Math.sin(2 * Math.PI * 784 * 2.01 * t) * Math.exp(-t / 0.08) + 0.12 * Math.sin(2 * Math.PI * 784 * 3.02 * t) * Math.exp(-t / 0.05);
      b[i] = s * env(t, 0.004, 0.11);
    }
    return reverb(run(b, biquad("lp", 5200)), 0.12);
  },
  thud: () => { // very soft low thump
    const b = mk(0.3); let ph = 0;
    for (let i = 0; i < b.length; i++) { const t = i / SR; const f = 48 + 60 * Math.exp(-t / 0.05); ph += (2 * Math.PI * f) / SR; b[i] = Math.sin(ph) * env(t, 0.006, 0.07); }
    return run(b, biquad("lp", 400));
  },
  tick: () => { // tiny soft tick
    const b = mk(0.07); let ph = 0;
    for (let i = 0; i < b.length; i++) { const t = i / SR; ph += (2 * Math.PI * (1500 - 400 * Math.min(1, t / 0.02))) / SR; b[i] = Math.sin(ph) * env(t, 0.001, 0.012); }
    return run(b, biquad("lp", 4000));
  },
};

const TARGET_PEAK = 0.8;
const rows = [];
for (const [name, gen] of Object.entries(sounds)) {
  let b = fadeEnd(gen());
  let pk = 0; b.forEach((x) => (pk = Math.max(pk, Math.abs(x))));
  const g = TARGET_PEAK / pk;
  b = b.map((x) => x * g);
  let rms = 0, clip = 0; b.forEach((x) => { rms += x * x; if (Math.abs(x) >= 0.999) clip++; });
  rms = Math.sqrt(rms / b.length);
  const buf = Buffer.alloc(44 + b.length * 2);
  buf.write("RIFF", 0); buf.writeUInt32LE(36 + b.length * 2, 4); buf.write("WAVEfmt ", 8); buf.writeUInt32LE(16, 16); buf.writeUInt16LE(1, 20); buf.writeUInt16LE(1, 22);
  buf.writeUInt32LE(SR, 24); buf.writeUInt32LE(SR * 2, 28); buf.writeUInt16LE(2, 32); buf.writeUInt16LE(16, 34); buf.write("data", 36); buf.writeUInt32LE(b.length * 2, 40);
  b.forEach((x, i) => buf.writeInt16LE(Math.round(Math.max(-1, Math.min(1, x)) * 32767), 44 + i * 2));
  fs.writeFileSync(path.join(dir, name + ".wav"), buf);
  rows.push({ name, dur: +(b.length / SR).toFixed(3), peak: +TARGET_PEAK.toFixed(2), rmsDb: +(20 * Math.log10(rms)).toFixed(1), clipped: clip });
}
console.table(rows);
