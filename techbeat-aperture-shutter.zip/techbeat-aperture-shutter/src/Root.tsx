import React from "react";
import { AbsoluteFill, Composition, Sequence, interpolate } from "remotion";
import { FPS, HEIGHT, WIDTH } from "./config";
import { loadFonts } from "./fonts";
import { TOTAL_FRAMES, cueStartF } from "./srt";
import { theme } from "./theme";
import { SceneProvider } from "./SceneContext";
import { BgMesh, Grade, GrainVignette } from "./components/Layers";
import { PreviewAudio } from "./components/PreviewAudio";
import { Sfx } from "./components/Sfx";
import { Hook } from "./scenes/Hook";
import { ApertureDef } from "./scenes/ApertureDef";
import { BigSmall } from "./scenes/BigSmall";
import { WindowCurtain } from "./scenes/WindowCurtain";
import { TimeSensor } from "./scenes/TimeSensor";
import { FilmShutter } from "./scenes/FilmShutter";
import { DigitalSplit } from "./scenes/DigitalSplit";
import { ElectronicTimeline } from "./scenes/ElectronicTimeline";
import { ChildRecap } from "./scenes/ChildRecap";
import { Finale } from "./scenes/Finale";
import { useCurrentFrame, useVideoConfig } from "remotion";

loadFonts();

// Scene boundaries = SRT cue boundaries (first cue of each scene). Everything else derives from the SRT.
const SCENES: { id: string; firstCue: number; C: React.FC }[] = [
  { id: "hook", firstCue: 1, C: Hook },
  { id: "aperture", firstCue: 2, C: ApertureDef },
  { id: "big-small", firstCue: 4, C: BigSmall },
  { id: "window", firstCue: 5, C: WindowCurtain },
  { id: "amount-time", firstCue: 6, C: TimeSensor },
  { id: "film-shutter", firstCue: 7, C: FilmShutter },
  { id: "digital", firstCue: 9, C: DigitalSplit },
  { id: "electronic", firstCue: 11, C: ElectronicTimeline },
  { id: "child-recap", firstCue: 12, C: ChildRecap },
  { id: "finale", firstCue: 16, C: Finale },
];

const starts = SCENES.map((s, i) => (i === 0 ? 0 : Math.max(0, cueStartF(s.firstCue) - theme.motion.lead)));

/** exit is faster than entrance; last scene holds */
const SceneShell: React.FC<{ last: boolean; children: React.ReactNode }> = ({ last, children }) => {
  const frame = useCurrentFrame();
  const { durationInFrames } = useVideoConfig();
  const t0 = durationInFrames - theme.motion.exit - 2;
  const e = last ? 0 : interpolate(frame, [t0, durationInFrames - 2], [0, 1], { easing: theme.ease.in, extrapolateLeft: "clamp", extrapolateRight: "clamp" });
  return (
    <AbsoluteFill style={{ opacity: 1 - e, transform: `translateY(${-30 * e}px) scale(${1 - 0.03 * e})`, filter: e > 0 ? `blur(${e * 6}px)` : undefined }}>
      {children}
    </AbsoluteFill>
  );
};

export const Main: React.FC = () => (
  <AbsoluteFill style={{ backgroundColor: theme.colors.bg, fontFamily: theme.fonts.display }}>
    <BgMesh />
    {SCENES.map((s, i) => {
      const from = starts[i];
      const end = i === SCENES.length - 1 ? TOTAL_FRAMES : starts[i + 1] + theme.motion.overlap;
      const C = s.C;
      return (
        <Sequence key={s.id} name={s.id} from={from} durationInFrames={end - from}>
          <SceneProvider from={from}>
            <SceneShell last={i === SCENES.length - 1}>
              <C />
              {i > 0 && <Sfx name="whoosh" at={0} vol={0.9} />}
            </SceneShell>
          </SceneProvider>
        </Sequence>
      );
    })}
    <Grade />
    <GrainVignette />
    <PreviewAudio />
  </AbsoluteFill>
);

export const RemotionRoot: React.FC = () => (
  <Composition id="Main" component={Main} durationInFrames={TOTAL_FRAMES} fps={FPS} width={WIDTH} height={HEIGHT} />
);
