import { Config } from "@remotion/cli/config";

Config.setVideoImageFormat("jpeg");
Config.setOverwriteOutput(true);
// Recommended by Remotion docs for WebGL/Three.js in headless Chrome (Codespaces/Linux).
Config.setChromiumOpenGlRenderer("angle");
Config.setConcurrency(2); // WebGL is heavy; raise only if Codespaces has RAM to spare.
