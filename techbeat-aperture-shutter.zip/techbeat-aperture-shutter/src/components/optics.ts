export type Pt = [number, number];

export const polyLen = (p: Pt[]) => {
  let L = 0;
  for (let i = 1; i < p.length; i++) L += Math.hypot(p[i][0] - p[i - 1][0], p[i][1] - p[i - 1][1]);
  return L;
};

/** first `prog` (0..1) of the polyline's length */
export const partial = (p: Pt[], prog: number): Pt[] => {
  const total = polyLen(p);
  let rem = total * Math.max(0, Math.min(1, prog));
  const out: Pt[] = [p[0]];
  for (let i = 1; i < p.length; i++) {
    const seg = Math.hypot(p[i][0] - p[i - 1][0], p[i][1] - p[i - 1][1]);
    if (rem >= seg) { out.push(p[i]); rem -= seg; }
    else {
      const t = seg === 0 ? 0 : rem / seg;
      out.push([p[i - 1][0] + (p[i][0] - p[i - 1][0]) * t, p[i - 1][1] + (p[i][1] - p[i - 1][1]) * t]);
      break;
    }
  }
  return out;
};

export const toPts = (p: Pt[]) => p.map((q) => q.join(",")).join(" ");

// ---- Lens cutaway geometry (local units) ----
export const G = { XF: 140, XI: 430, XR: 620, XSH: 872, XS: 925 };
export const RAY_YS = [-150, -112, -75, -38, 0, 38, 75, 112, 150];
export const irisHalf = (open: number) => 12 + 88 * open;
export const yAtIris = (y: number) => (y * (G.XS - G.XI)) / (G.XS - G.XF);
export const passFraction = (open: number) =>
  RAY_YS.filter((y) => Math.abs(yAtIris(y)) <= irisHalf(open) + 0.01).length / RAY_YS.length;
