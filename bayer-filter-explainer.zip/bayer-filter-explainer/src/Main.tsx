import React from "react";
import {AbsoluteFill, Sequence, interpolate, useCurrentFrame, useVideoConfig} from "remotion";
import {BgMesh, Grade, Grain, Vignette} from "./Backdrop";
import {PreviewAudio} from "./PreviewAudio";
import {SceneCtx} from "./anim";
import {PLAN, cue} from "./script";
import {theme} from "./theme";
import {S1} from "./scenes/S1";
import {S2} from "./scenes/S2";
import {S3} from "./scenes/S3";
import {S4} from "./scenes/S4";
import {S5} from "./scenes/S5";
import {S6} from "./scenes/S6";
import {S7} from "./scenes/S7";
import {S8} from "./scenes/S8";

const SCENES: Record<string, React.FC> = {
  "s1-stack": S1,
  "s2-cutaway": S2,
  "s3-lanes": S3,
  "s4-photosite": S4,
  "s5-mosaic": S5,
  "s6-eye": S6,
  "s7-split": S7,
  "s8-question": S8,
};

// Quick exit (faster than entrances), overlapping the next scene's entrance.
const SceneFrame: React.FC<{exitFrames: number; isLast: boolean; children: React.ReactNode}> = ({exitFrames, isLast, children}) => {
  const frame = useCurrentFrame();
  const {durationInFrames} = useVideoConfig();
  const start = durationInFrames - exitFrames;
  const k = isLast ? 0 : interpolate(frame, [start, durationInFrames], [0, 1], {easing: theme.ease.in, extrapolateLeft: "clamp", extrapolateRight: "clamp"});
  return (
    <AbsoluteFill style={{opacity: 1 - k, transform: `translateY(${-30 * k}px) scale(${1 + 0.03 * k})`}}>{children}</AbsoluteFill>
  );
};

export const Main: React.FC = () => {
  const {fps, durationInFrames} = useVideoConfig();
  const leadF = Math.round(fps * 0.17); // visuals land ~5 frames before the words
  const exitF = Math.round(fps * 0.3); // ~9 frames
  return (
    <AbsoluteFill style={{backgroundColor: theme.colors.bg}}>
      <BgMesh />
      {PLAN.map((sc, k) => {
        const startF = Math.round(cue(sc.from).start * fps);
        const endF = Math.round(cue(sc.to).end * fps);
        const from = k === 0 ? 0 : Math.max(0, startF - leadF);
        const isLast = k === PLAN.length - 1;
        const end = isLast ? durationInFrames : Math.min(durationInFrames, endF + exitF);
        const Scene = SCENES[sc.id];
        return (
          <Sequence key={sc.id} from={from} durationInFrames={end - from} name={sc.id}>
            <SceneCtx.Provider value={{lead: (startF - from) / fps, span: (endF - startF) / fps}}>
              <SceneFrame exitFrames={exitF} isLast={isLast}>
                <Scene />
              </SceneFrame>
            </SceneCtx.Provider>
          </Sequence>
        );
      })}
      <Grade />
      <Grain />
      <Vignette />
      <PreviewAudio />
    </AbsoluteFill>
  );
};
