import React, {useState} from "react";
import {Audio, getRemotionEnvironment, staticFile} from "remotion";

// Flags
export const VOICEOVER_ENABLED = true; // false -> never play the voiceover
export const VOICEOVER_IN_RENDER = false; // default: voiceover is NOT mixed into renders

/** Plays public/voiceover.mp3 if it exists; silently skipped if it does not. */
export const PreviewAudio: React.FC = () => {
  const [missing, setMissing] = useState(false);
  const {isRendering} = getRemotionEnvironment();
  if (!VOICEOVER_ENABLED || missing || (isRendering && !VOICEOVER_IN_RENDER)) return null;
  return <Audio src={staticFile("voiceover.mp3")} onError={() => setMissing(true)} />;
};
