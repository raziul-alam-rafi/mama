#!/usr/bin/env bash
# Loudness-normalise to ~-14 LUFS integrated, true peak -1 dBTP (two-pass), copy video untouched.
set -euo pipefail
IN="${1:-out/aperture_raw.mp4}"; OUT="${2:-out/aperture_final.mp4}"
J=$(ffmpeg -hide_banner -i "$IN" -af loudnorm=I=-14:TP=-1:LRA=11:print_format=json -f null - 2>&1 | sed -n '/^{/,/^}/p')
g() { echo "$J" | grep "\"$1\"" | sed 's/[^0-9.-]*\([-0-9.]*\).*/\1/'; }
ffmpeg -y -hide_banner -i "$IN" -c:v copy \
  -af "loudnorm=I=-14:TP=-1:LRA=11:measured_I=$(g input_i):measured_TP=$(g input_tp):measured_LRA=$(g input_lra):measured_thresh=$(g input_thresh):offset=$(g target_offset):linear=true" \
  -ar 48000 -c:a aac -b:a 256k "$OUT"
ffmpeg -hide_banner -i "$OUT" -af ebur128=peak=true -f null - 2>&1 | grep -E "I:|Peak:" | tail -2
