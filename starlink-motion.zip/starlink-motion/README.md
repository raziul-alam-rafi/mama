# Starlink motion graphics (Remotion)

1. `npm install`
2. `npx remotion studio`   (composition: Main)
3. `npx remotion render src/index.ts Main out/video.mp4`

Optional: put the narration at `public/voiceover.mp3` to hear it in Studio (flags in `src/config.ts`).
Timing comes from `public/voiceover.srt` → `npm run cues` regenerates `src/cues.ts`. `npm run sfx` rebuilds the SFX.
