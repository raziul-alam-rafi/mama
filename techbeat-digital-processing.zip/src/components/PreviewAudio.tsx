import React, { useEffect, useState } from "react";
import { Audio, continueRender, delayRender, getRemotionEnvironment, staticFile } from "remotion";
import { VOICEOVER_IN_RENDER, VOICEOVER_PREVIEW } from "../config";

/**
 * Plays public/voiceover.mp3 if (and only if) the file exists.
 * - Studio preview: on when VOICEOVER_PREVIEW is true.
 * - Rendering: off unless VOICEOVER_IN_RENDER is true.
 */
export const PreviewAudio: React.FC = () => {
  const rendering = getRemotionEnvironment().isRendering;
  const enabled = VOICEOVER_PREVIEW && (!rendering || VOICEOVER_IN_RENDER);
  const [handle] = useState(() => (enabled ? delayRender("voiceover probe") : null));
  const [state, setState] = useState<"pending" | "yes" | "no">(enabled ? "pending" : "no");

  useEffect(() => {
    if (!enabled) return;
    let dead = false;
    fetch(staticFile("voiceover.mp3"), { method: "HEAD" })
      .then((r) => {
        const type = r.headers.get("content-type") || "";
        // a missing file may be answered with the dev server's index.html — treat that as "absent"
        if (!dead) setState(r.ok && !/text\/html/i.test(type) ? "yes" : "no");
      })
      .catch(() => !dead && setState("no"));
    return () => {
      dead = true;
    };
  }, [enabled]);

  useEffect(() => {
    if (state !== "pending" && handle !== null) continueRender(handle);
  }, [state, handle]);

  return state === "yes" ? <Audio src={staticFile("voiceover.mp3")} /> : null;
};
