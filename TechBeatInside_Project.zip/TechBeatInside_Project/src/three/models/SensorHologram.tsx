import React, {useLayoutEffect, useMemo} from 'react';
import * as THREE from 'three';
import {COLORS} from '../../config/theme';
import {drawSensorImage, drawSignalTrace} from '../materials/broadcastPicture';
import {newCanvasTexture} from '../materials/textures';
import {clamp} from '../../utils/math';

type V3 = [number, number, number];

/**
 * Explanatory overlay (NOT a physical object): left panel = the picture being scanned line by line,
 * right panel = the voltage waveform of the line currently being scanned.
 */
export const SensorHologram: React.FC<{
  position: V3;
  frame: number;
  scan: number; // 0..1 vertical scan position
  opacity: number;
}> = ({position, frame, scan, opacity}) => {
  const img = useMemo(() => newCanvasTexture(512, 384), []);
  const trc = useMemo(() => newCanvasTexture(512, 384), []);
  useLayoutEffect(() => {
    drawSensorImage(img.ctx, 512, 384, frame, scan);
    img.texture.needsUpdate = true;
    drawSignalTrace(trc.ctx, 512, 384, scan, frame);
    trc.texture.needsUpdate = true;
  });
  const o = clamp(opacity);
  if (o <= 0.001) return null;
  return (
    <group position={position} rotation={[0, Math.PI / 2, 0]} name="Explainer_Image_To_Signal">
      <mesh position={[-0.62, 0, 0]}>
        <planeGeometry args={[1.1, 0.825]} />
        <meshBasicMaterial map={img.texture} transparent opacity={o * 0.96} side={THREE.DoubleSide} toneMapped={false} depthWrite={false} />
      </mesh>
      <mesh position={[0.62, 0, 0]}>
        <planeGeometry args={[1.1, 0.825]} />
        <meshBasicMaterial map={trc.texture} transparent opacity={o * 0.96} side={THREE.DoubleSide} toneMapped={false} depthWrite={false} />
      </mesh>
      {/* arrow between the panels */}
      <mesh position={[0, 0, 0]} rotation={[0, 0, -Math.PI / 2]}>
        <coneGeometry args={[0.05, 0.12, 16]} />
        <meshBasicMaterial color={COLORS.signal} transparent opacity={o} toneMapped={false} />
      </mesh>
    </group>
  );
};
