import React from "react";
import {AbsoluteFill, interpolate} from "remotion";
import {Chip, Pop, Sfx, Words, clamp01, useAnim} from "../anim";
import {bayerAt, chColor, theme} from "../theme";

const COLS = 8;
const ROWS = 5;
const CELL = 100;
const SITE = 80;
const TILE = 86;

// Scene 1 - exploded stack: colour-filter tiles drop onto the photosite array.
export const S1: React.FC = () => {
  const a = useAnim();
  const planeW = COLS * CELL;
  const planeH = ROWS * CELL;
  const rise = a.sp(0.0, theme.spring.smooth);
  const rotX = interpolate(rise, [0, 1], [24, 58]);
  const rotZ = interpolate(a.frame, [0, a.durationInFrames], [-40, -31], {easing: theme.ease.inOut});
  const float = a.wave(3.4, 7);

  return (
    <AbsoluteFill>
      <Sfx name="whoosh_soft" at={0.12} vol={0.22} />
      <Sfx name="thud" at={a.at(0.0)} vol={0.26} />
      <Sfx name="pop" at={2.1} vol={0.24} rate={1.04} />

      <div style={{position: "absolute", left: 140, top: 64}}>
        <Words text="প্রতিটি pixel-এর উপর" at={0.1} />
        <Words text="ক্ষুদ্র রঙিন filter" at={0.5} highlight={["filter"]} />
      </div>

      <div style={{position: "absolute", left: "50%", top: "61%", width: 0, height: 0, perspective: 2300}}>
        <div
          style={{
            position: "absolute",
            left: -planeW / 2,
            top: -planeH / 2,
            width: planeW,
            height: planeH,
            transformStyle: "preserve-3d",
            opacity: clamp01(rise * 1.6),
            transform: `translateY(${float}px) rotateX(${rotX}deg) rotateZ(${rotZ}deg) scale(${interpolate(rise, [0, 1], [0.95, 1.1])})`,
          }}
        >
          {/* slab thickness */}
          <div style={{position: "absolute", inset: 0, borderRadius: 22, background: theme.colors.well, transform: "translateZ(-36px)", boxShadow: `0 60px 120px ${theme.colors.shadow}`}} />
          <div style={{position: "absolute", inset: 0, borderRadius: 22, background: theme.colors.surface, transform: "translateZ(-18px)"}} />
          {/* silicon plane with photosites */}
          <div style={{position: "absolute", inset: 0, borderRadius: 22, background: `linear-gradient(135deg, ${theme.colors.surfaceHi}, ${theme.colors.surface})`, border: `2px solid ${theme.colors.line}`}} />
          {Array.from({length: ROWS * COLS}).map((_, i) => {
            const r = Math.floor(i / COLS);
            const c = i % COLS;
            return (
              <div
                key={`s${i}`}
                style={{
                  position: "absolute",
                  left: c * CELL + (CELL - SITE) / 2,
                  top: r * CELL + (CELL - SITE) / 2,
                  width: SITE,
                  height: SITE,
                  borderRadius: 12,
                  background: `linear-gradient(145deg, ${theme.colors.well}, ${theme.colors.bgAlt})`,
                  border: `2px solid ${theme.colors.line}`,
                  transform: "translateZ(2px)",
                }}
              >
                <div style={{position: "absolute", inset: 24, borderRadius: 6, background: theme.colors.hero, opacity: 0.35}} />
              </div>
            );
          })}
          {/* colour-filter tiles */}
          {Array.from({length: ROWS * COLS}).map((_, i) => {
            const r = Math.floor(i / COLS);
            const c = i % COLS;
            const col = chColor[bayerAt(r, c)];
            const delay = 0.8 + (r + c) * 0.1;
            const p = a.sp(delay, theme.spring.drop);
            const z = interpolate(p, [0, 1], [340, 14]);
            const land = a.ease(delay + 0.2, delay + 0.4, 0, 1) * (1 - a.ease(delay + 0.4, delay + 0.9, 0, 1));
            return (
              <div
                key={`f${i}`}
                style={{
                  position: "absolute",
                  left: c * CELL + (CELL - TILE) / 2,
                  top: r * CELL + (CELL - TILE) / 2,
                  width: TILE,
                  height: TILE,
                  borderRadius: theme.radius.tile,
                  opacity: clamp01(p * 2.2) * 0.92,
                  background: `linear-gradient(145deg, ${col}, ${col}B0)`,
                  border: "2px solid rgba(255,255,255,0.45)",
                  boxShadow: `0 0 ${10 + 36 * land}px ${col}`,
                  transform: `translateZ(${z}px)`,
                }}
              />
            );
          })}
        </div>
      </div>

      <svg width={1920} height={1080} style={{position: "absolute", inset: 0, pointerEvents: "none"}}>
        <line x1={560} y1={835} x2={a.ease(3.0, 3.5, 560, 650)} y2={a.ease(3.0, 3.5, 835, 775)} stroke={theme.colors.hero} strokeWidth={4} strokeLinecap="round" opacity={a.ease(3.0, 3.3, 0, 1)} />
        <line x1={1332} y1={535} x2={a.ease(3.6, 4.1, 1340, 1170)} y2={a.ease(3.6, 4.1, 535, 590)} stroke={theme.colors.amber} strokeWidth={4} strokeLinecap="round" opacity={a.ease(3.6, 3.9, 0, 1)} />
      </svg>
      <Pop at={3.0} x={-30} y={0} style={{position: "absolute", left: 130, top: 800}}>
        <Chip dot={theme.colors.hero}>pixel (photosite)</Chip>
      </Pop>
      <Pop at={3.6} x={30} y={0} style={{position: "absolute", left: 1330, top: 470}}>
        <Chip dot={theme.colors.amber}>রঙিন filter</Chip>
      </Pop>
    </AbsoluteFill>
  );
};
