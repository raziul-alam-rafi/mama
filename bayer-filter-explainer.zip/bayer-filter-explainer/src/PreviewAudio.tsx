import React, {useEffect, useState} from "react";
import {Audio, continueRender, delayRender, getRemotionEnvironment, staticFile} from "remotion";
import {PREVIEW_AUDIO, VOICEOVER_FILE} from "./config";

// Plays public/voiceover.mp3 only if the file exists. Missing file => silently skipped.
const Probe: React.FC = () => {
  const [ok, setOk] = useState(false);
  const [handle] = useState(() => delayRender("voiceover probe"));
  useEffect(() => {
    let alive = true;
    fetch(staticFile(VOICEOVER_FILE), {method: "HEAD"})
      .then((r) => {
        const ct = r.headers.get("content-type") ?? "";
        if (alive) setOk(r.ok && !ct.includes("text/html"));
      })
      .catch(() => alive && setOk(false))
      .finally(() => continueRender(handle));
    return () => {
      alive = false;
    };
  }, [handle]);
  return ok ? <Audio src={staticFile(VOICEOVER_FILE)} volume={1} /> : null;
};

export const PreviewAudio: React.FC = () => {
  const env = getRemotionEnvironment();
  const active = PREVIEW_AUDIO === "always" || (PREVIEW_AUDIO === "studio" && !env.isRendering);
  return active ? <Probe /> : null;
};
