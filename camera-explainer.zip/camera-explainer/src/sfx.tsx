import React from "react";
import { Audio, Sequence, staticFile } from "remotion";
import { FPS, SCENES } from "./timing";

export type SfxName = "pop" | "click" | "whoosh" | "chime" | "thud";
export type Sfx = { f: number; s: SfxName; v?: number; r?: number };

// সংযত ভলিউম (০.২–০.৩৫), ভয়েসওভার ঢাকবে না
const VOL: Record<SfxName, number> = { pop: 0.3, click: 0.28, whoosh: 0.24, chime: 0.27, thud: 0.24 };

export const SfxTrack: React.FC<{ events: Sfx[][] }> = ({ events }) => (
  <>
    {events.map((list, k) =>
      list.map((e, i) => (
        <Sequence
          key={`${k}-${i}`}
          from={Math.max(0, SCENES[k].from + e.f - 2)} // দৃশ্য নামার ২ ফ্রেম আগে
          durationInFrames={FPS}
        >
          <Audio src={staticFile(`sfx/${e.s}.wav`)} volume={e.v ?? VOL[e.s]} playbackRate={e.r ?? 1} />
        </Sequence>
      )),
    )}
    {/* সিন ট্রানজিশন whoosh */}
    {SCENES.slice(1).map((s, i) => (
      <Sequence key={`cut-${i}`} from={Math.max(0, s.from - 8)} durationInFrames={FPS}>
        <Audio src={staticFile("sfx/whoosh.wav")} volume={0.22} playbackRate={i % 2 ? 1.06 : 0.96} />
      </Sequence>
    ))}
  </>
);
