// theme.ts — single source of truth: colors, easings, springs, fonts, timing constants.
import { Easing } from "remotion";

export const VIDEO = { width: 1920, height: 1080, fps: 30 } as const;

export const theme = {
  colors: {
    // Scheme 1 — Deep Navy Optics
    bg: "#0A1224",
    bgAlt: "#101B33",
    surface: "#16254A",
    surfaceHi: "#23386A",
    line: "#2C4278",
    primary: "#4DA3FF", // hero
    accent: "#FFB84D", // light rays
    text: "#EAF1FF",
    textDim: "#8EA3CC",
    glow: "rgba(77, 163, 255, 0.35)",
    rayGlow: "rgba(255, 184, 77, 0.55)",
    // content colors (the objects the script talks about)
    apple: "#E0352B",
    appleDark: "#8F1D1A",
    appleLight: "#FF7A66",
    leaf: "#3FAE6A",
    glass: "#9CCBFF",
    ink: "#050A16",
  },
  fonts: {
    display: `"Hind Siliguri", "BanglaFallback", "Noto Sans Bengali", sans-serif`,
    body: `"Hind Siliguri", "BanglaFallback", "Noto Sans Bengali", sans-serif`,
  },
  ease: {
    out: Easing.bezier(0.16, 1, 0.3, 1),
    inOut: Easing.bezier(0.83, 0, 0.17, 1),
    in: Easing.bezier(0.7, 0, 0.84, 0),
    soft: Easing.bezier(0.45, 0, 0.2, 1),
  },
  spring: {
    snappy: { damping: 14, stiffness: 160, mass: 0.6 },
    smooth: { damping: 20, stiffness: 90, mass: 1 },
    bouncy: { damping: 11, stiffness: 170, mass: 0.7 },
  },
  // all motion constants in frames @30fps-independent seconds
  timing: {
    leadSec: 5 / 30, // visuals land ~5 frames before the spoken words
    staggerWord: 3,
    exitFrames: 10,
    wipeFrames: 16,
    tailSec: 0.5,
  },
  // Studio/preview + render flags
  flags: {
    previewVoiceover: true, // play public/voiceover.mp3 in Studio when it exists
    renderVoiceover: false, // include voiceover in rendered MP4 (default off)
    sfx: true,
  },
} as const;
