import React from "react";
import * as THREE from "three";
import { Vec3 } from "../lib/ease";

const UP = new THREE.Vector3(0, 1, 0);

/** Thin cylinder between two points. Geometry is constant (unit height); length via scale. */
export const Segment: React.FC<{ a: Vec3; b: Vec3; radius?: number; color: string; opacity?: number }> = ({
  a, b, radius = 0.012, color, opacity = 1,
}) => {
  const va = new THREE.Vector3(...a), vb = new THREE.Vector3(...b);
  const dir = vb.clone().sub(va);
  const len = dir.length();
  if (len < 1e-4) return null;
  const mid = va.clone().add(vb).multiplyScalar(0.5);
  const q = new THREE.Quaternion().setFromUnitVectors(UP, dir.normalize());
  return (
    <mesh position={mid} quaternion={q} scale={[1, len, 1]}>
      <cylinderGeometry args={[radius, radius, 1, 6]} />
      <meshBasicMaterial color={color} transparent opacity={opacity} toneMapped={false} depthWrite={false} />
    </mesh>
  );
};
