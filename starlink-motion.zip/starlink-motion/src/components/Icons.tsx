// Hand-drawn SVG shapes in theme colours (no emoji, no external logos). Each returns a <g>
// so scenes can place/rotate/scale them inside their own <svg>.
import React from "react";
import { theme } from "../theme";

const c = theme.colors;

/** Torch, origin at the bottom of the handle, lens pointing up (-y). Lens centre ≈ (0,-250). */
export const TorchShape: React.FC<{ on?: number }> = ({ on = 0 }) => (
  <g>
    <rect x={-18} y={-130} width={36} height={130} rx={12} fill={c.surfaceHi} stroke={c.border} strokeWidth={2} />
    <rect x={-18} y={-96} width={36} height={8} fill={c.accent} opacity={0.85} />
    <rect x={-7} y={-62} width={14} height={26} rx={7} fill={c.bg} stroke={c.border} strokeWidth={2} />
    <path d="M-24 -130 L-54 -250 L54 -250 L24 -130 Z" fill={c.surfaceHi} stroke={c.border} strokeWidth={2} strokeLinejoin="round" />
    <ellipse cx={0} cy={-250} rx={54} ry={13} fill={c.surface} stroke={c.border} strokeWidth={2} />
    <ellipse cx={0} cy={-250} rx={40} ry={9} fill={c.primary} opacity={0.18 + on * 0.82} />
    {on > 0.05 ? <ellipse cx={0} cy={-250} rx={64} ry={20} fill={c.primary} opacity={on * 0.25} /> : null}
  </g>
);

/**
 * Starlink-style flat dish, origin at the foot of the stand. Panel centre ≈ (0,-150).
 * `dot(i,j)` returns 0..1 brightness of the antenna element at column i (0-5), row j (0-3).
 */
export const DishShape: React.FC<{ dot?: (i: number, j: number) => number; ring?: number }> = ({ dot, ring = 0 }) => (
  <g>
    <ellipse cx={0} cy={0} rx={58} ry={11} fill={c.surface} stroke={c.border} strokeWidth={2} />
    <rect x={-9} y={-90} width={18} height={90} rx={7} fill={c.surfaceHi} stroke={c.border} strokeWidth={2} />
    <g transform="translate(0 -150) rotate(-6)">
      <rect x={-98} y={-72} width={196} height={144} rx={22} fill={c.surfaceHi} stroke={c.border} strokeWidth={2.5} />
      <rect x={-86} y={-60} width={172} height={120} rx={14} fill={c.bg} opacity={0.6} />
      {Array.from({ length: 4 }).map((_, j) =>
        Array.from({ length: 6 }).map((__, i) => {
          const v = dot ? dot(i, j) : 0.35;
          return (
            <g key={`${i}-${j}`}>
              <circle cx={-62.5 + i * 25} cy={-37.5 + j * 25} r={5.5} fill={c.textDim} opacity={0.35} />
              {v > 0.02 ? <circle cx={-62.5 + i * 25} cy={-37.5 + j * 25} r={5.5 + v * 2} fill={c.accent} opacity={v} /> : null}
            </g>
          );
        })
      )}
    </g>
    {ring > 0.01 ? (
      <ellipse cx={0} cy={-150} rx={120 + ring * 40} ry={96 + ring * 30} fill="none" stroke={c.primary} strokeWidth={3} opacity={(1 - ring) * 0.7} />
    ) : null}
  </g>
);

/** Satellite centred on the origin, ~260 wide. */
export const SatelliteShape: React.FC = () => (
  <g>
    <rect x={-130} y={-24} width={90} height={48} rx={6} fill={c.surfaceHi} stroke={c.border} strokeWidth={2} />
    <rect x={40} y={-24} width={90} height={48} rx={6} fill={c.surfaceHi} stroke={c.border} strokeWidth={2} />
    {[-100, -70, 70, 100].map((x) => (
      <line key={x} x1={x} y1={-24} x2={x} y2={24} stroke={c.textDim} strokeWidth={1.5} opacity={0.5} />
    ))}
    <line x1={-130} y1={0} x2={-40} y2={0} stroke={c.textDim} strokeWidth={1.5} opacity={0.5} />
    <line x1={40} y1={0} x2={130} y2={0} stroke={c.textDim} strokeWidth={1.5} opacity={0.5} />
    <rect x={-40} y={-3} width={80} height={6} fill={c.border} />
    <rect x={-30} y={-30} width={60} height={60} rx={12} fill={c.surface} stroke={c.border} strokeWidth={2.5} />
    <rect x={-30} y={-30} width={60} height={14} rx={7} fill={c.accent} opacity={0.9} />
    <line x1={0} y1={30} x2={0} y2={46} stroke={c.textDim} strokeWidth={3} />
    <ellipse cx={0} cy={50} rx={16} ry={6} fill={c.surfaceHi} stroke={c.border} strokeWidth={2} />
  </g>
);

/** Laptop centred on the origin, ~280 wide. `bars` 0..3 lit signal bars. */
export const LaptopShape: React.FC<{ bars?: number }> = ({ bars = 0 }) => (
  <g>
    <rect x={-110} y={-84} width={220} height={140} rx={12} fill={c.surfaceHi} stroke={c.border} strokeWidth={2.5} />
    <rect x={-98} y={-72} width={196} height={116} rx={6} fill={c.bg} />
    <path d="M-140 60 L140 60 L122 80 L-122 80 Z" fill={c.surface} stroke={c.border} strokeWidth={2} strokeLinejoin="round" />
    {[0, 1, 2].map((k) => (
      <rect
        key={k}
        x={-26 + k * 22}
        y={-6 - k * 14}
        width={14}
        height={20 + k * 14}
        rx={4}
        fill={k < bars ? c.primary : c.textDim}
        opacity={k < bars ? 1 : 0.3}
      />
    ))}
  </g>
);
