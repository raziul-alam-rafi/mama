import React from "react";
import { useCurrentFrame } from "remotion";
import { theme } from "../theme";
import { FullSvg, P, SceneShell, Sfx, Tag, Title, hash, lerp } from "../fx";
import { sceneTimes } from "../timeline";
import { wordFrame } from "../srt";

const C = theme.colors;
const T0 = sceneTimes[5].from;
const tFilter = wordFrame(11, "ব্যবস্থা", 6) - T0; // ফিল্টার-টাইল নামা শুরু
const tTitle = wordFrame(11, "color filter", 10) - T0; // শিরোনাম

const cols = 10;
const rows = 5;
const cell = 108;
const gap = 12;
const gx0 = (theme.width - (cols * cell + (cols - 1) * gap)) / 2;
const gy0 = 250;

// Bayer: R G / G B
const tile = (i: number, j: number) => {
  const a = i % 2;
  const b = j % 2;
  if (a === 0 && b === 0) return C.red;
  if (a === 1 && b === 1) return C.primary;
  return C.green;
};

export const S6Filter: React.FC = () => {
  const frame = useCurrentFrame();
  const slide = P(frame, tTitle, 22, theme.ease.out);
  const els: React.ReactNode[] = [];
  for (let j = 0; j < rows; j++)
    for (let i = 0; i < cols; i++) {
      const x = gx0 + i * (cell + gap);
      const y = gy0 + j * (cell + gap);
      const s = P(frame, 6 + (i + j) * 1.6, 14, theme.ease.out);
      const lv = 0.35 + hash(i + j * 13, 9) * 0.5;
      const d = tFilter + (i + j) * 1.8;
      const t = P(frame, d, 16, theme.ease.out);
      els.push(
        <g key={`${i}-${j}`} opacity={s} transform={`translate(${x + cell / 2} ${y + cell / 2}) scale(${lerp(0.6, 1, s)}) translate(${-cell / 2} ${-cell / 2})`}>
          <rect width={cell} height={cell} rx={18} fill={C.panel} stroke={C.panelLine} strokeWidth={3} />
          <rect x={10} y={10} width={cell - 20} height={cell - 20} rx={12} fill={`rgb(${Math.round(60 + lv * 170)},${Math.round(64 + lv * 170)},${Math.round(80 + lv * 170)})`} />
          {/* ফিল্টার টাইল উপর থেকে নামে */}
          <g transform={`translate(0 ${lerp(-90, 0, t)})`} opacity={t}>
            <rect x={6} y={6} width={cell - 12} height={cell - 12} rx={14} fill={tile(i, j)} opacity={0.82} />
            <rect x={6} y={6} width={cell - 12} height={cell - 12} rx={14} fill="none" stroke={C.text} strokeWidth={2} opacity={0.5} />
          </g>
        </g>
      );
    }
  const breathe = 1 + Math.sin(frame / 20) * 0.006;
  return (
    <SceneShell last>
      <Title text="আরেকটি গুরুত্বপূর্ণ ব্যবস্থা" top={70} delay={4} highlight={{ 1: C.accent }} />
      <FullSvg>
        <g transform={`translate(960 600) scale(${breathe}) translate(-960 -600)`}>{els}</g>
      </FullSvg>
      <div
        style={{
          position: "absolute",
          left: 0,
          width: theme.width,
          top: 905,
          textAlign: "center",
          fontFamily: theme.fonts.main,
          fontSize: 84,
          fontWeight: 700,
          letterSpacing: 0,
          lineHeight: 1.2,
          opacity: slide,
          transform: `translateY(${lerp(40, 0, slide)}px) scale(${lerp(0.94, 1, slide)})`,
          color: C.text,
        }}
      >
        <span style={{ color: C.accent }}>Color</span> filter
      </div>
      <Sfx at={8} name="whoosh" vol={0.22} />
      <Sfx at={tFilter} name="chime" vol={0.28} />
      <Sfx at={tTitle} name="pop" vol={0.22} rate={1.1} />
    </SceneShell>
  );
};
