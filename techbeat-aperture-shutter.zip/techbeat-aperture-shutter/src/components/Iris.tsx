import React from "react";
import { theme } from "../theme";
import { lerp } from "./Motion";

const N = 7;

/** Aperture iris, front view. open: 0 (tiny) → 1 (wide). Blades pivot as the opening changes. */
export const Iris: React.FC<{ size: number; open: number; glow?: number; highlight?: boolean; uid?: string }> = ({
  size, open, glow = 0.8, highlight = false, uid = "iris",
}) => {
  const R = 94;
  const r = lerp(13, 66, open);
  const rot = open * 0.55;
  const ang = (i: number) => (i * 2 * Math.PI) / N + rot - Math.PI / 2;
  const P = (i: number, rad: number, twist = 0): [number, number] => [
    Math.cos(ang(i) + twist) * rad,
    Math.sin(ang(i) + twist) * rad,
  ];
  const tw = 0.86;
  const hole = Array.from({ length: N }, (_, i) => P(i, r)).map((p) => p.join(",")).join(" ");
  const holePath = "M" + Array.from({ length: N }, (_, i) => P(i, r).join(",")).join(" L") + " Z";
  const discPath = `M ${-R} 0 a ${R} ${R} 0 1 0 ${2 * R} 0 a ${R} ${R} 0 1 0 ${-2 * R} 0 Z`;
  return (
    <svg width={size} height={size} viewBox="-110 -110 220 220">
      <defs>
        <linearGradient id={`${uid}-blade`} x1="0" y1="0" x2="1" y2="1">
          <stop offset="0" stopColor={theme.colors.metal} stopOpacity="0.9" />
          <stop offset="1" stopColor={theme.colors.metalDark} stopOpacity="0.95" />
        </linearGradient>
        <radialGradient id={`${uid}-light`}>
          <stop offset="0" stopColor={theme.colors.accentSoft} stopOpacity={glow} />
          <stop offset="0.7" stopColor={theme.colors.light} stopOpacity={glow * 0.9} />
          <stop offset="1" stopColor={theme.colors.light} stopOpacity={glow * 0.5} />
        </radialGradient>
        <radialGradient id={`${uid}-ring`}>
          <stop offset="0.86" stopColor={theme.colors.panelHi} />
          <stop offset="1" stopColor={theme.colors.bgAlt} />
        </radialGradient>
      </defs>
      <circle r={106} fill={`url(#${uid}-ring)`} stroke={theme.colors.metalDark} strokeWidth={3} />
      <circle r={R} fill={theme.colors.bg} />
      <polygon points={hole} fill={`url(#${uid}-light)`} />
      {Array.from({ length: N }, (_, i) => {
        const a = P(i, r), b = P((i + 1) % N, r), c = P((i + 1) % N, R, tw), d = P(i, R, tw);
        return (
          <path
            key={i}
            d={`M${a.join(",")} L${b.join(",")} L${c.join(",")} L${d.join(",")} Z`}
            fill={`url(#${uid}-blade)`}
            stroke={theme.colors.bgAlt}
            strokeWidth={1.6}
            opacity={0.96}
          />
        );
      })}
      <path d={holePath} fill="none" stroke={highlight ? theme.colors.accent : theme.colors.primarySoft} strokeWidth={highlight ? 4 : 2.4} strokeLinejoin="round" />
      <circle r={R} fill="none" stroke={theme.colors.line} strokeWidth={3} />
    </svg>
  );
};
