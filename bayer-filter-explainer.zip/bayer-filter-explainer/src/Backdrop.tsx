import React from "react";
import {AbsoluteFill, useCurrentFrame} from "remotion";
import {theme} from "./theme";

// Layer 1: animated background mesh (never a flat colour)
export const BgMesh: React.FC = () => {
  const frame = useCurrentFrame();
  const d1 = Math.sin(frame / 55) * 50;
  const d2 = Math.cos(frame / 70) * 40;
  return (
    <AbsoluteFill style={{background: `linear-gradient(160deg, ${theme.colors.bgAlt} 0%, ${theme.colors.bg} 62%)`}}>
      <div style={{position: "absolute", width: 1300, height: 1300, borderRadius: "50%", top: -560, left: -300 + d1, filter: "blur(60px)", background: `radial-gradient(circle, ${theme.colors.hero}2E, transparent 62%)`}} />
      <div style={{position: "absolute", width: 1000, height: 1000, borderRadius: "50%", bottom: -480, right: -260 - d2, filter: "blur(70px)", background: `radial-gradient(circle, ${theme.colors.amber}1A, transparent 65%)`}} />
      <AbsoluteFill style={{backgroundImage: `linear-gradient(${theme.colors.line}22 1px, transparent 1px), linear-gradient(90deg, ${theme.colors.line}22 1px, transparent 1px)`, backgroundSize: "96px 96px", opacity: 0.35}} />
    </AbsoluteFill>
  );
};

// Layer 4: colour grade
export const Grade: React.FC = () => (
  <AbsoluteFill style={{pointerEvents: "none"}}>
    <AbsoluteFill style={{backgroundColor: theme.colors.hero, mixBlendMode: "soft-light", opacity: 0.14}} />
    <AbsoluteFill style={{background: "linear-gradient(180deg, rgba(0,0,0,0.10), transparent 26%, transparent 76%, rgba(0,0,0,0.16))"}} />
  </AbsoluteFill>
);

// Layer 5a: procedural grain
export const Grain: React.FC = () => {
  const frame = useCurrentFrame();
  const noise = `url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='220' height='220'%3E%3Cfilter id='n'%3E%3CfeTurbulence type='fractalNoise' baseFrequency='0.9' numOctaves='2'/%3E%3C/filter%3E%3Crect width='220' height='220' filter='url(%23n)' opacity='0.5'/%3E%3C/svg%3E")`;
  return (
    <AbsoluteFill
      style={{pointerEvents: "none", backgroundImage: noise, backgroundSize: "220px", backgroundPosition: `${(frame * 7) % 220}px ${(frame * 13) % 220}px`, opacity: 0.05, mixBlendMode: "overlay"}}
    />
  );
};

// Layer 5b: vignette (top-most)
export const Vignette: React.FC = () => (
  <AbsoluteFill style={{pointerEvents: "none", background: "radial-gradient(ellipse at center, transparent 58%, rgba(0,0,0,0.2) 100%)"}} />
);
