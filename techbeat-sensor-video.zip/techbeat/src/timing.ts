// All timing is derived from the SRT. Nothing is hand-placed in absolute frames.
import {RAW_SRT} from "./srt-data";

export const FPS = 30;
export const WIDTH = 1920;
export const HEIGHT = 1080;

export type Cue = {n: number; startF: number; endF: number; text: string};

const toSec = (t: string) => {
  const m = t.trim().match(/(\d+):(\d+):(\d+)[,.](\d+)/);
  if (!m) throw new Error("Bad SRT time: " + t);
  return +m[1] * 3600 + +m[2] * 60 + +m[3] + +m[4] / 1000;
};

export const parseSrt = (raw: string, fps: number): Cue[] =>
  raw
    .replace(/\r/g, "")
    .trim()
    .split(/\n\s*\n/)
    .map((block) => {
      const lines = block.split("\n");
      const [a, b] = lines[1].split("-->");
      return {
        n: parseInt(lines[0], 10),
        startF: Math.round(toSec(a) * fps),
        endF: Math.round(toSec(b) * fps),
        text: lines.slice(2).join(" "),
      };
    });

export const CUES = parseSrt(RAW_SRT, FPS);
export const cue = (n: number) => CUES[n - 1];
/** Absolute frame at fraction `frac` of cue `n`. */
export const cueAt = (n: number, frac = 0) => {
  const c = cue(n);
  return Math.round(c.startF + (c.endF - c.startF) * frac);
};
export const TOTAL_FRAMES = CUES[CUES.length - 1].endF;

export const LEAD = 6; // visuals land ~6 frames before the matching words
export const XFADE = 10; // scene overlap

export type SceneId = "sensor" | "pixel" | "light" | "electric";
export const ORDER: SceneId[] = ["sensor", "pixel", "light", "electric"];
// Scene boundaries coincide with cue boundaries.
export const SCENE_CUES: Record<SceneId, [number, number]> = {
  sensor: [1, 2],
  pixel: [3, 5],
  light: [6, 7],
  electric: [8, 9],
};

export const sceneRange = (id: SceneId) => {
  const [a, b] = SCENE_CUES[id];
  const from = id === "sensor" ? 0 : cue(a).startF - XFADE;
  const to = id === "electric" ? TOTAL_FRAMES : cue(b).endF;
  return {from, to, dur: to - from};
};

/** Scene-local frame for cue `n` at `frac`, `lead` frames early. */
export const at = (id: SceneId, n: number, frac = 0, lead = LEAD) =>
  cueAt(n, frac) - lead - sceneRange(id).from;
