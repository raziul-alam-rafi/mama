import React, {useMemo} from 'react';
import * as THREE from 'three';
import {COLORS, LIGHT} from '../../config/theme';
import {floorPlanks, woodTexture} from '../materials/textures';
import {ContactShadow, RBox} from './parts';

type V3 = [number, number, number];

/**
 * Cut-away house (front open for the camera): living room + gable roof.
 * House centre x=200; interior x 196..204, z -3.2..3.2, wall height 3.2, ridge 5.0.
 */
export const House: React.FC<{position: V3; frame: number}> = ({position, frame}) => {
  const gable = useMemo(() => {
    const s = new THREE.Shape();
    s.moveTo(-3.2, 0);
    s.lineTo(3.2, 0);
    s.lineTo(0, 1.8);
    s.closePath();
    return new THREE.ShapeGeometry(s);
  }, []);
  const wall = {color: '#cdbba0', roughness: 0.92} as const;
  const lampFlicker = 1 + 0.015 * Math.sin(frame * 0.7);
  const slope = Math.atan2(1.8, 3.2);
  const slopeLen = Math.hypot(1.8, 3.2) + 0.5;
  return (
    <group position={position} name="House_Cutaway">
      <ContactShadow position={[0, 0.02, 0]} size={[16, 14]} opacity={0.8} />
      {/* foundation / floor */}
      <mesh position={[0, 0.05, 0]} receiveShadow>
        <boxGeometry args={[8.6, 0.1, 6.8]} />
        <meshStandardMaterial color="#555" roughness={1} />
      </mesh>
      <mesh position={[0, 0.105, 0]} rotation={[-Math.PI / 2, 0, 0]}>
        <planeGeometry args={[7.8, 6.4]} />
        <meshStandardMaterial map={floorPlanks()} roughness={0.55} />
      </mesh>
      {/* back + side walls */}
      <mesh position={[0, 1.7, -3.3]}>
        <boxGeometry args={[8.2, 3.2, 0.2]} />
        <meshStandardMaterial {...wall} />
      </mesh>
      {[-4, 4].map((x) => (
        <mesh key={x} position={[x, 1.7, 0]}>
          <boxGeometry args={[0.2, 3.2, 6.6]} />
          <meshStandardMaterial {...wall} />
        </mesh>
      ))}
      {/* wainscot panel on back wall */}
      <mesh position={[0, 0.55, -3.19]}>
        <boxGeometry args={[7.8, 0.9, 0.04]} />
        <meshStandardMaterial map={woodTexture('#7a5a3a', 8)} roughness={0.6} />
      </mesh>
      {/* ceiling slab */}
      <mesh position={[0, 3.3, 0]}>
        <boxGeometry args={[8.2, 0.2, 6.8]} />
        <meshStandardMaterial color="#e9e3d6" roughness={0.95} />
      </mesh>
      {/* gable ends */}
      {[-4.0, 4.0].map((x, i) => (
        <mesh key={i} geometry={gable} position={[x + (i ? 0.1 : -0.1), 3.4, 0]} rotation={[0, Math.PI / 2, 0]}>
          <meshStandardMaterial color="#b9a88c" roughness={0.95} side={THREE.DoubleSide} />
        </mesh>
      ))}
      {/* roof slopes */}
      {[-1, 1].map((s) => (
        <mesh
          key={s}
          position={[0, 3.4 + 0.9 + 0.08, s * 1.6]}
          rotation={[s * slope, 0, 0]}
        >
          <boxGeometry args={[8.4, 0.14, slopeLen]} />
          <meshStandardMaterial color="#6a3a30" roughness={0.85} />
        </mesh>
      ))}
      {/* cable grommet where the coax enters the wall */}
      <mesh position={[4.115, 1.5, -1.8]} rotation={[0, Math.PI / 2, 0]}>
        <torusGeometry args={[0.05, 0.015, 8, 20]} />
        <meshStandardMaterial color="#111" roughness={0.7} />
      </mesh>
      {/* ridge cap */}
      <mesh position={[0, 5.28, 0]}>
        <boxGeometry args={[8.4, 0.12, 0.3]} />
        <meshStandardMaterial color="#4f2b24" roughness={0.8} />
      </mesh>

      {/* ---- room dressing ---- */}
      {/* TV stand */}
      <RBox size={[1.4, 0.5, 0.6]} radius={0.02} position={[0, 0.35, -2.1]}>
        <meshStandardMaterial map={woodTexture('#5a3a22', 5)} roughness={0.6} />
      </RBox>
      {/* rug */}
      <mesh position={[0, 0.115, -0.2]} rotation={[-Math.PI / 2, 0, 0]}>
        <planeGeometry args={[3.6, 2.4]} />
        <meshStandardMaterial color="#7a2f2a" roughness={1} />
      </mesh>
      {/* armchair (side) */}
      <RBox size={[0.9, 0.5, 0.9]} radius={0.12} position={[2.7, 0.35, 0.2]}>
        <meshStandardMaterial color="#2f4a46" roughness={0.95} />
      </RBox>
      <RBox size={[0.9, 0.7, 0.22]} radius={0.1} position={[3.0, 0.75, 0.2]} rotation={[0, Math.PI / 2, 0]}>
        <meshStandardMaterial color="#2f4a46" roughness={0.95} />
      </RBox>
      {/* side table + lamp (warm light) */}
      <RBox size={[0.6, 0.6, 0.6]} radius={0.03} position={[-3.2, 0.4, -2.5]}>
        <meshStandardMaterial map={woodTexture('#5a3a22', 6)} roughness={0.6} />
      </RBox>
      <mesh position={[-3.2, 0.82, -2.5]}>
        <cylinderGeometry args={[0.04, 0.07, 0.24, 14]} />
        <meshStandardMaterial color="#c8a15b" metalness={0.8} roughness={0.35} />
      </mesh>
      <mesh position={[-3.2, 1.08, -2.5]}>
        <cylinderGeometry args={[0.16, 0.24, 0.3, 28, 1, true]} />
        <meshBasicMaterial color={COLORS.warm} side={THREE.DoubleSide} toneMapped={false} />
      </mesh>
      <pointLight
        position={[-3.0, 1.1, -2.2]}
        color="#ffb36b"
        intensity={LIGHT.roomLamp * lampFlicker}
        distance={9}
        decay={0}
      />
      <pointLight position={[0.5, 2.9, 1.5]} color="#ffe2c0" intensity={LIGHT.roomFill} distance={10} decay={0} />
      {/* framed picture + shelf */}
      <mesh position={[2.2, 1.9, -3.17]}>
        <boxGeometry args={[1.0, 0.7, 0.04]} />
        <meshStandardMaterial color="#2b2018" roughness={0.6} />
      </mesh>
      <mesh position={[2.2, 1.9, -3.145]}>
        <planeGeometry args={[0.88, 0.58]} />
        <meshStandardMaterial color="#5f7f93" roughness={0.9} />
      </mesh>
      <mesh position={[-1.9, 1.7, -3.0]}>
        <boxGeometry args={[1.6, 0.05, 0.3]} />
        <meshStandardMaterial map={woodTexture('#6b4426', 9)} roughness={0.6} />
      </mesh>
      {[-2.4, -2.0, -1.6].map((x, i) => (
        <mesh key={i} position={[x, 1.84 + i * 0.02, -3.0]}>
          <boxGeometry args={[0.1 + i * 0.03, 0.22 + i * 0.04, 0.2]} />
          <meshStandardMaterial color={['#9a3b2b', '#2c5f7a', '#b09a45'][i]} roughness={0.8} />
        </mesh>
      ))}
    </group>
  );
};
