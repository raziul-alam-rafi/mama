import React from "react";
import { AbsoluteFill, Sequence } from "remotion";
import { BgMesh, Grade, Grain, Vignette } from "./fx";
import { PreviewAudio } from "./PreviewAudio";
import { sceneTimes } from "./timeline";
import { S1Hook } from "./scenes/S1Hook";
import { S2Mechanism } from "./scenes/S2Mechanism";
import { S3Amount } from "./scenes/S3Amount";
import { S4Grid } from "./scenes/S4Grid";
import { S5Problem } from "./scenes/S5Problem";
import { S6Filter } from "./scenes/S6Filter";

const scenes = [S1Hook, S2Mechanism, S3Amount, S4Grid, S5Problem, S6Filter];

export const Main: React.FC = () => (
  <AbsoluteFill>
    {/* লেয়ার ১: ব্যাকগ্রাউন্ড মেশ */}
    <BgMesh />
    {/* লেয়ার ২–৩: সিন (অ্যাসেট + গ্রাফিক্স/টাইপ) */}
    {scenes.map((Scene, i) => (
      <Sequence key={i} from={sceneTimes[i].from} durationInFrames={sceneTimes[i].duration}>
        <Scene />
      </Sequence>
    ))}
    {/* লেয়ার ৪–৫: গ্রেড, গ্রেইন, ভিনিয়েট */}
    <Grade />
    <Grain />
    <Vignette />
    <PreviewAudio />
  </AbsoluteFill>
);
