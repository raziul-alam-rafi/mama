import React from 'react';
import * as THREE from 'three';
import {useCurrentFrame} from 'remotion';
import {LIGHT} from '../config/theme';
import {CameraRig} from '../three/cameras/CameraRig';
import {ANCHORS, PULSE1, PULSE2, SHOTS, WAVE_START} from '../three/cameras/shots';
import {
  ANT_POS,
  BROADCAST_CURVE,
  CAM_STATION,
  HOUSE,
  HOUSE_CURVE,
  TOWER,
  TOWER_H,
  TV_POS,
} from '../three/animations/paths';
import {EnvironmentSetup} from '../three/environments/EnvironmentSetup';
import {CrtTv} from '../three/models/CrtTv';
import {House} from '../three/models/House';
import {Landscape, Sky} from '../three/models/Landscape';
import {SensorHologram} from '../three/models/SensorHologram';
import {SignalCable} from '../three/models/Signals';
import {Stadium} from '../three/models/Stadium';
import {StudioCamera} from '../three/models/StudioCamera';
import {TransmitterTower} from '../three/models/TransmitterTower';
import {RadioWaves} from '../three/models/Waves';
import {YagiAntenna} from '../three/models/YagiAntenna';
import {clamp, smoothstep} from '../utils/math';

const D = SHOTS.find((s) => s.id === 'D')!;
const C = SHOTS.find((s) => s.id === 'C')!;

export const World: React.FC = () => {
  const frame = useCurrentFrame();

  // image->signal explainer: fades in at the end of shot C, out as the pulse leaves (start of E)
  const holoIn = smoothstep(C.end - 14, D.start + 10, frame);
  const holoOut = 1 - smoothstep(D.end - 10, D.end + 8, frame);
  const holoOpacity = holoIn * holoOut;
  const scan = ((frame - C.end) / 22) % 1; // exaggerated: one sweep per 22 frames
  const scanSafe = scan < 0 ? scan + 1 : scan;

  // distance tower-top -> antenna: wave front must arrive at the end of shot F
  const towerTop = new THREE.Vector3(TOWER.x, TOWER_H + 6, 0);
  const dist = towerTop.distanceTo(new THREE.Vector3(ANT_POS.x - 1.4, ANT_POS.y, 0));
  const arrive = ANCHORS.G - 4;
  const speed = dist / Math.max(1, arrive - WAVE_START - 11 * 0);
  const excite = smoothstep(arrive - 6, arrive + 14, frame) * (0.6 + 0.4 * Math.sin(frame * 0.8) ** 2);

  return (
    <>
      <CameraRig />
      <EnvironmentSetup />
      <Sky />
      <hemisphereLight args={['#6f86c4', '#1a2418', LIGHT.hemi]} />
      <directionalLight position={[-60, 90, 50]} color="#9db4ff" intensity={LIGHT.moon} />

      <Landscape />
      <Stadium frame={frame} />
      <StudioCamera position={[CAM_STATION.x, 0, CAM_STATION.z]} />
      <SensorHologram position={[35.2, 2.7, 0]} frame={frame} scan={scanSafe} opacity={holoOpacity} />

      <TransmitterTower position={[TOWER.x, 0, TOWER.z]} frame={frame} />
      <SignalCable curve={BROADCAST_CURVE} frame={frame} start={PULSE1.start} end={PULSE1.end} />
      <RadioWaves origin={towerTop} frame={frame} startFrame={WAVE_START} speed={speed} maxRadius={dist + 10} />

      <House position={[HOUSE.x, 0, HOUSE.z]} frame={frame} />
      <YagiAntenna position={[ANT_POS.x, ANT_POS.y, ANT_POS.z]} excite={clamp(excite)} />
      <SignalCable curve={HOUSE_CURVE} frame={frame} start={PULSE2.start} end={PULSE2.end} radius={0.025} glowRadius={0.045} segments={320} headSize={0.12} />
      <CrtTv position={[TV_POS.x, TV_POS.y, TV_POS.z]} frame={frame} />
    </>
  );
};
