import React from "react";
import { AbsoluteFill, Audio, Sequence, staticFile } from "remotion";
import { BgMesh, Grade, Grain, Vignette } from "./components/layers";
import { PreviewAudio } from "./PreviewAudio";
import { SFX_EARLY, SFX_FILE, SFX_VOL, SfxEvent } from "./sfx";
import { BOUNDS, OVERLAP, SCENE_COUNT } from "./timing";
import { Scene01, sfx01 } from "./scenes/Scene01";
import { Scene02, sfx02 } from "./scenes/Scene02";
import { Scene03, sfx03 } from "./scenes/Scene03";
import { Scene04, sfx04 } from "./scenes/Scene04";
import { Scene05, sfx05 } from "./scenes/Scene05";
import { Scene06, sfx06 } from "./scenes/Scene06";
import { Scene07, sfx07 } from "./scenes/Scene07";
import { Scene08, sfx08 } from "./scenes/Scene08";
import { Scene09, sfx09 } from "./scenes/Scene09";
import { Scene10, sfx10 } from "./scenes/Scene10";

const SCENES: { C: React.FC; sfx: SfxEvent[] }[] = [
  { C: Scene01, sfx: sfx01 }, { C: Scene02, sfx: sfx02 }, { C: Scene03, sfx: sfx03 }, { C: Scene04, sfx: sfx04 },
  { C: Scene05, sfx: sfx05 }, { C: Scene06, sfx: sfx06 }, { C: Scene07, sfx: sfx07 }, { C: Scene08, sfx: sfx08 },
  { C: Scene09, sfx: sfx09 }, { C: Scene10, sfx: sfx10 },
];

// সিন ট্রানজিশনে ছোট whoosh (প্রতিবার সামান্য ভিন্ন pitch)
const TRANSITION_RATES = [1.0, 1.08, 0.94, 1.04, 0.98, 1.1, 0.96, 1.02, 1.06];

const allSfx = (): { from: number; ev: SfxEvent }[] => {
  const list: { from: number; ev: SfxEvent }[] = [];
  SCENES.forEach((s, i) => {
    if (i > 0) list.push({ from: BOUNDS[i] - 2, ev: { kind: "whoosh", frame: 0, vol: 0.9, rate: TRANSITION_RATES[i - 1] } });
    s.sfx.forEach((ev) => list.push({ from: Math.max(0, BOUNDS[i] + ev.frame - SFX_EARLY), ev }));
  });
  return list;
};

export const Main: React.FC = () => {
  const sfx = allSfx();
  return (
    <AbsoluteFill>
      {/* স্তর ১: ব্যাকগ্রাউন্ড মেশ */}
      <BgMesh />
      {/* স্তর ২–৩: সিনের অ্যাসেট ও গ্রাফিক্স */}
      {SCENES.map(({ C }, i) => {
        const len = BOUNDS[i + 1] - BOUNDS[i] + (i === SCENE_COUNT - 1 ? 0 : OVERLAP);
        return (
          <Sequence key={i} from={BOUNDS[i]} durationInFrames={len} name={`scene-${i + 1}`}>
            <C />
          </Sequence>
        );
      })}
      {/* স্তর ৪–৫: গ্রেড, গ্রেইন, ভিনিয়েট */}
      <Grade />
      <Grain />
      <Vignette />
      {/* শুধু SFX */}
      {sfx.map(({ from, ev }, i) => (
        <Sequence key={i} from={from} durationInFrames={45} name={`sfx-${ev.kind}`}>
          <Audio src={staticFile(SFX_FILE[ev.kind])} volume={SFX_VOL[ev.kind] * (ev.vol ?? 1)} playbackRate={ev.rate ?? 1} />
        </Sequence>
      ))}
      <PreviewAudio />
    </AbsoluteFill>
  );
};
