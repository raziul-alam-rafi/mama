// Scene 5 — Question (cues 7-8): satellite -> device path, then the kinetic "ঠিক কিভাবে?" slam.
import React from "react";
import { AbsoluteFill, interpolate, spring, useCurrentFrame, useVideoConfig } from "remotion";
import { theme } from "../theme";
import { question as b } from "../beats";
import { WIDTH, HEIGHT, sec } from "../timing";
import { WordReveal } from "../components/Words";
import { CL, Entrance } from "../components/Motion";
import { LaptopShape, SatelliteShape } from "../components/Icons";

const P0 = { x: 440, y: 760 };
const P1 = { x: 800, y: 530 };
const P2 = { x: 1130, y: 530 };
const P3 = { x: 1480, y: 830 };
const bez = (t: number) => {
  const m = 1 - t;
  return {
    x: m * m * m * P0.x + 3 * m * m * t * P1.x + 3 * m * t * t * P2.x + t * t * t * P3.x,
    y: m * m * m * P0.y + 3 * m * m * t * P1.y + 3 * m * t * t * P2.y + t * t * t * P3.y,
  };
};
const PATH_D = `M ${P0.x} ${P0.y} C ${P1.x} ${P1.y} ${P2.x} ${P2.y} ${P3.x} ${P3.y}`;

export const QuestionScene: React.FC = () => {
  const frame = useCurrentFrame();
  const { fps } = useVideoConfig();

  const pSat = Math.min(1, spring({ frame: frame - b.t7, fps, config: theme.spring.bouncy }));
  const pDev = Math.min(1, spring({ frame: frame - b.tDevice, fps, config: theme.spring.bouncy }));
  const pPath = interpolate(frame, [b.tTitle, b.tDevice + sec(0.3)], [0, 1], { easing: theme.ease.inOut, ...CL });
  const pQ = Math.min(1, spring({ frame: frame - b.tQ, fps, config: theme.spring.bouncy }));
  const mid = bez(0.5);
  const period = sec(1.5);
  const packets = Array.from({ length: 4 }, (_, k) => {
    const t = (((frame - b.tDevice) / period + k / 4) % 1 + 1) % 1;
    return { k, t, ...bez(t) };
  });
  const flowing = frame >= b.tDevice;

  // the final slam: everything else recedes
  const dim = interpolate(frame, [b.t8, b.t8 + sec(0.35)], [0, 1], { easing: theme.ease.out, ...CL });
  const ringP = (d: number) => interpolate(frame, [b.t8 + d, b.t8 + d + sec(0.9)], [0, 1], { easing: theme.ease.out, ...CL });

  return (
    <AbsoluteFill>
      <div style={{ position: "absolute", inset: 0, opacity: 1 - dim * 0.88, filter: `blur(${dim * 7}px)` }}>
        {/* headline */}
        <div style={{ position: "absolute", left: 120, top: 80, width: 1680 }}>
          <Entrance delay={b.t7} y={24}>
            <div style={{ fontFamily: theme.fonts.display, fontSize: 56, fontWeight: 600, color: theme.colors.accent, lineHeight: 1.3 }}>
              তাহলে প্রশ্ন হলো…
            </div>
          </Entrance>
          <WordReveal
            text="এত দ্রুত গতির satellite থেকে আপনার device-এ internet আসে"
            delay={b.tTitle}
            per={3}
            size={92}
            maxWidth={1680}
            marks={{
              satellite: { color: theme.colors.accent },
              "device-এ": { color: theme.colors.accent },
              internet: { color: theme.colors.accent, underline: true },
            }}
          />
        </div>

        <svg width={WIDTH} height={HEIGHT} style={{ position: "absolute", left: 0, top: 0 }}>
          <defs>
            <clipPath id="qReveal">
              <rect x={0} y={0} width={P0.x - 40 + (P3.x - P0.x + 80) * pPath} height={HEIGHT} />
            </clipPath>
          </defs>

          {/* satellite */}
          <g transform={`translate(${P0.x - 110} ${P0.y - 40 + Math.sin(frame / 26) * 6}) scale(${0.72 * pSat})`} opacity={pSat}>
            <SatelliteShape />
          </g>

          {/* path */}
          <g clipPath="url(#qReveal)">
            <path d={PATH_D} fill="none" stroke={theme.colors.textDim} strokeWidth={4} strokeDasharray="4 16" strokeLinecap="round" opacity={0.7} />
          </g>

          {/* packets (hero) */}
          {flowing
            ? packets.map((p) => (
                <g key={p.k} opacity={Math.sin(Math.PI * p.t)}>
                  <circle cx={p.x} cy={p.y} r={26} fill={theme.colors.primary} opacity={0.18} />
                  <circle cx={p.x} cy={p.y} r={11} fill={theme.colors.primary} />
                </g>
              ))
            : null}

          {/* device */}
          <g transform={`translate(${P3.x + 110} ${P3.y + 10}) scale(${0.95 * pDev})`} opacity={pDev}>
            <LaptopShape bars={flowing ? 1 + Math.floor((frame / 10) % 3) : 0} />
          </g>

          {/* question bubble */}
          <g transform={`translate(${mid.x} ${mid.y - 120 + Math.sin(frame / 20) * 5}) scale(${pQ * (1 + Math.sin(frame / 12) * 0.04)})`} opacity={pQ}>
            <circle r={52} fill={theme.colors.accent} />
            <text y={20} textAnchor="middle" fontFamily={theme.fonts.display} fontSize={68} fontWeight={700} fill={theme.colors.bg}>
              ?
            </text>
          </g>
        </svg>
      </div>

      {/* "ঠিক কিভাবে?" */}
      <svg width={WIDTH} height={HEIGHT} style={{ position: "absolute", left: 0, top: 0 }}>
        {[0, 6].map((d) => (
          <circle
            key={d}
            cx={960}
            cy={540}
            r={140 + 700 * ringP(d)}
            fill="none"
            stroke={theme.colors.primary}
            strokeWidth={4}
            opacity={frame >= b.t8 + d ? (1 - ringP(d)) * 0.55 : 0}
          />
        ))}
      </svg>
      <div style={{ position: "absolute", left: 0, right: 0, top: 380, display: "flex", justifyContent: "center" }}>
        <WordReveal
          text="ঠিক কিভাবে?"
          delay={b.t8}
          per={6}
          size={210}
          align="center"
          marks={{ "কিভাবে?": { color: theme.colors.primary, glow: true, pop: true, underline: true } }}
        />
      </div>
    </AbsoluteFill>
  );
};
