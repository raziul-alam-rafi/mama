import React from "react";
import { AbsoluteFill } from "remotion";
import { theme } from "../theme";
import { useScene } from "../SceneContext";
import { Card, Chip, ip, keys, mono, clamp01 } from "../components/Motion";
import { SensorGrid } from "../components/SensorGrid";
import { Sfx } from "../components/Sfx";

// Scene 8 · Electronic shutter (cue 11): the sensor itself decides when to collect light and for how long.
export const ElectronicTimeline: React.FC = () => {
  const S = useScene();
  const f = S.frame;
  const c11 = Math.max(S.cue(11), 0);
  const fDur = S.word(11, "কতক্ষণ");
  const fCtl = S.word(11, "নিয়ন্ত্রণ");
  const [a, b, c, d] = mono([c11 + 30, fDur, fCtl + 6, S.cueEnd(11) - 10], 8);
  const width = keys(f, [a, b, c, d], [0.0, 0.3, 0.56, 0.3]);
  const start = 0.2;
  const CY = 110;
  const ph = ((f - c11) % CY) / CY;
  const peak = 0.3 + 0.7 * (width / 0.56);
  const acc = width < 0.01 ? 0 : ph < start ? 0 : peak * clamp01((ph - start) / width);
  const level = (c: number, r: number) => acc * (0.9 + 0.1 * Math.sin(c * 1.3 + r * 0.8));

  const tx0 = 1060, tx1 = 1740, ty = 520;
  const wx0 = tx0 + start * (tx1 - tx0), wx1 = wx0 + width * (tx1 - tx0);
  const px = tx0 + ph * (tx1 - tx0);
  const active = ph >= start && ph <= start + width && width > 0.01;

  return (
    <AbsoluteFill>
      <div style={{ position: "absolute", left: 130, top: 108 }}>
        <Chip text="Electronic Shutter" tone="signal" size={56} delay={c11 + 2} />
      </div>

      <Card x={110} y={250} w={880} h={700} delay={c11 + 8} border={theme.colors.signal}>
        <div style={{ position: "absolute", left: 38, top: 40, padding: 18, borderRadius: 22, background: theme.colors.bgAlt, border: `2px solid ${theme.colors.line}` }}>
          <SensorGrid cols={14} rows={9} cell={56} level={level} />
        </div>
        <div style={{ position: "absolute", left: 38, top: 600 }}>
          <Chip text="Sensor" tone="signal" size={40} delay={c11 + 20} />
        </div>
      </Card>

      <Card x={1030} y={250} w={780} h={700} delay={c11 + 16} border={theme.colors.accent}>
        <div style={{ position: "absolute", left: 30, top: 40 }}>
          <Chip text="কতক্ষণ আলো সংগ্রহ" tone="accent" size={44} delay={fDur - 4} />
        </div>
      </Card>
      <svg width="1920" height="1080" style={{ position: "absolute", left: 0, top: 0, opacity: ip(f, [c11 + 24, c11 + 40], [0, 1]) }}>
        <rect x={tx0} y={ty - 14} width={tx1 - tx0} height={28} rx={14} fill={theme.colors.bgAlt} stroke={theme.colors.line} strokeWidth={3} />
        {width > 0.01 && <rect x={wx0} y={ty - 14} width={wx1 - wx0} height={28} rx={14} fill={theme.colors.accent} opacity={active ? 1 : 0.55} />}
        {width > 0.01 && (
          <>
            <rect x={wx0 - 7} y={ty - 40} width={14} height={80} rx={7} fill={theme.colors.accentSoft} />
            <rect x={wx1 - 7} y={ty - 40} width={14} height={80} rx={7} fill={theme.colors.accentSoft} />
            <line x1={wx0} x2={wx1} y1={ty + 80} y2={ty + 80} stroke={theme.colors.accent} strokeWidth={4} />
            <path d={`M${wx0 + 14} ${ty + 66} L${wx0} ${ty + 80} L${wx0 + 14} ${ty + 94}`} fill="none" stroke={theme.colors.accent} strokeWidth={4} strokeLinecap="round" strokeLinejoin="round" />
            <path d={`M${wx1 - 14} ${ty + 66} L${wx1} ${ty + 80} L${wx1 - 14} ${ty + 94}`} fill="none" stroke={theme.colors.accent} strokeWidth={4} strokeLinecap="round" strokeLinejoin="round" />
          </>
        )}
        <circle cx={px} cy={ty} r={15} fill={theme.colors.text} />
        <line x1={px} x2={px} y1={ty + 15} y2={ty + 150} stroke={theme.colors.text} strokeWidth={3} strokeDasharray="6 8" opacity={0.6} />
      </svg>
      <div style={{ position: "absolute", left: 1060, top: 760, fontFamily: theme.fonts.display, fontWeight: 600, fontSize: 40, color: active ? theme.colors.accent : theme.colors.textDim }}>
        {active ? "আলো সংগ্রহ চলছে" : "অপেক্ষা"}
      </div>

      <Sfx name="pop" at={c11 + 6} />
      <Sfx name="chime" at={fDur} vol={0.8} />
      <Sfx name="click" at={fCtl + 2} />
    </AbsoluteFill>
  );
};
