#!/usr/bin/env bash
# Tests every Remotion OpenGL backend in Remotion's own browser, with a real three.js draw call.
# Saves the first working one (in order of preference for GPU-less machines) to .glmode.
set -u
mkdir -p out
WORKING=""
for m in swangle angle-egl angle egl vulkan; do
  LOG="out/glprobe_$m.log"
  if npx remotion still src/index.ts GlProbe "out/glprobe_$m.png" --gl="$m" --log=verbose --overwrite >"$LOG" 2>&1 \
     && grep -q "GLPROBE_RENDERER=" "$LOG"; then
    echo "OK    --gl=$m   $(grep -o 'GLPROBE_RENDERER=.*' "$LOG" | head -1)"
    [ -z "$WORKING" ] && WORKING="$m"
  else
    echo "FAIL  --gl=$m   $(grep -m1 -iE 'GLPROBE_FAILED|webgl|error' "$LOG" | cut -c1-160)"
  fi
done
if [ -z "$WORKING" ]; then
  echo; echo "No GL backend worked. Send me out/glprobe_*.log (all 5 files) and the output of: npx remotion browser ensure; npx remotion versions"
  exit 1
fi
echo "$WORKING" > .glmode
echo; echo "Selected: --gl=$WORKING (saved to .glmode)"
