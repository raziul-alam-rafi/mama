import React, {useLayoutEffect, useMemo, useRef} from 'react';
import * as THREE from 'three';
import {COLORS} from '../../config/theme';
import {mulberry32} from '../../utils/math';

/** Ground, road, trees, village lights and a star-filled dusk sky. All seeded => deterministic. */
export const Landscape: React.FC = () => {
  const treeRef = useRef<THREE.InstancedMesh>(null);
  const trunkRef = useRef<THREE.InstancedMesh>(null);
  const homeRef = useRef<THREE.InstancedMesh>(null);

  const {trees, homes} = useMemo(() => {
    const r = mulberry32(7);
    const t: {x: number; z: number; s: number}[] = [];
    const h: {x: number; z: number; w: number; d: number; ht: number}[] = [];
    const inKeepOut = (x: number, z: number) =>
      (x > 188 && x < 212 && Math.abs(z) < 12) || (x > 76 && x < 104 && Math.abs(z) < 14) || (x < 76 && Math.hypot(x, z) < 72);
    while (t.length < 160) {
      const x = 70 + r() * 260;
      const z = (r() - 0.5) * 220;
      if (!inKeepOut(x, z)) t.push({x, z, s: 0.8 + r() * 1.4});
    }
    while (h.length < 26) {
      const x = 110 + r() * 150;
      const z = (r() - 0.5) * 200;
      if (!inKeepOut(x, z) && Math.abs(z) > 14) h.push({x, z, w: 4 + r() * 3, d: 4 + r() * 3, ht: 2.8 + r() * 1.5});
    }
    return {trees: t, homes: h};
  }, []);

  useLayoutEffect(() => {
    const m = new THREE.Matrix4();
    trees.forEach((t, i) => {
      m.compose(new THREE.Vector3(t.x, 2.2 * t.s, t.z), new THREE.Quaternion(), new THREE.Vector3(t.s, t.s, t.s));
      treeRef.current!.setMatrixAt(i, m);
      m.compose(new THREE.Vector3(t.x, 0.6 * t.s, t.z), new THREE.Quaternion(), new THREE.Vector3(t.s, t.s, t.s));
      trunkRef.current!.setMatrixAt(i, m);
    });
    homes.forEach((h, i) => {
      m.compose(new THREE.Vector3(h.x, h.ht / 2, h.z), new THREE.Quaternion(), new THREE.Vector3(h.w, h.ht, h.d));
      homeRef.current!.setMatrixAt(i, m);
    });
    [treeRef, trunkRef, homeRef].forEach((ref) => (ref.current!.instanceMatrix.needsUpdate = true));
  }, [trees, homes]);

  const stars = useMemo(() => {
    const r = mulberry32(13);
    const pos = new Float32Array(900 * 3);
    for (let i = 0; i < 900; i++) {
      const th = r() * Math.PI * 2;
      const ph = Math.acos(0.1 + r() * 0.9);
      pos.set([1900 * Math.sin(ph) * Math.cos(th), 1900 * Math.cos(ph), 1900 * Math.sin(ph) * Math.sin(th)], i * 3);
    }
    return pos;
  }, []);

  return (
    <group name="Landscape">
      <mesh rotation={[-Math.PI / 2, 0, 0]} position={[150, -0.03, 0]}>
        <planeGeometry args={[1600, 1200]} />
        <meshStandardMaterial color={COLORS.ground} roughness={1} />
      </mesh>
      {/* road from stadium toward the village */}
      <mesh rotation={[-Math.PI / 2, 0, 0]} position={[130, 0.0, 22]}>
        <planeGeometry args={[220, 7]} />
        <meshStandardMaterial color="#2c2d31" roughness={0.95} />
      </mesh>
      <instancedMesh ref={treeRef} args={[undefined, undefined, trees.length]}>
        <coneGeometry args={[1.5, 4.4, 10]} />
        <meshStandardMaterial color="#1c3a22" roughness={1} />
      </instancedMesh>
      <instancedMesh ref={trunkRef} args={[undefined, undefined, trees.length]}>
        <cylinderGeometry args={[0.2, 0.28, 1.2, 6]} />
        <meshStandardMaterial color="#3a2a1b" roughness={1} />
      </instancedMesh>
      <instancedMesh ref={homeRef} args={[undefined, undefined, homes.length]}>
        <boxGeometry args={[1, 1, 1]} />
        <meshStandardMaterial color="#6b6258" roughness={0.95} emissive="#ffb866" emissiveIntensity={0.18} />
      </instancedMesh>
      <points>
        <bufferGeometry>
          <bufferAttribute attach="attributes-position" args={[stars, 3]} />
        </bufferGeometry>
        <pointsMaterial color="#dfe8ff" size={2.2} sizeAttenuation={false} fog={false} transparent opacity={0.85} />
      </points>
    </group>
  );
};

const skyVert = `varying vec3 vP; void main(){ vP = position; gl_Position = projectionMatrix*modelViewMatrix*vec4(position,1.0); }`;
const skyFrag = `
uniform vec3 uTop; uniform vec3 uMid; uniform vec3 uHor; varying vec3 vP;
void main(){
  float h = clamp(normalize(vP).y, -0.1, 1.0);
  vec3 c = mix(uHor, uMid, smoothstep(0.0, 0.25, h));
  c = mix(c, uTop, smoothstep(0.2, 0.9, h));
  gl_FragColor = vec4(c, 1.0);
}`;

export const Sky: React.FC = () => {
  const uniforms = useMemo(
    () => ({
      uTop: {value: new THREE.Color(COLORS.skyTop)},
      uMid: {value: new THREE.Color(COLORS.skyMid)},
      uHor: {value: new THREE.Color(COLORS.skyHorizon)},
    }),
    [],
  );
  return (
    <mesh renderOrder={-10} frustumCulled={false}>
      <sphereGeometry args={[2000, 32, 16]} />
      <shaderMaterial
        vertexShader={skyVert}
        fragmentShader={skyFrag}
        uniforms={uniforms}
        side={THREE.BackSide}
        depthWrite={false}
        fog={false}
      />
    </mesh>
  );
};
