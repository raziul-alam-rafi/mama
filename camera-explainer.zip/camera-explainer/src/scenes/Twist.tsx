import React from "react";
import { useCurrentFrame } from "remotion";
import { theme, alpha, mix } from "../theme";
import { Draw, Pop, SceneShell, Tag, WordReveal, ease, Pt, pointAt, toD } from "../components/ui";
import { WorldSVG, gridCells, lumColor } from "../world";
import { at } from "../timing";
import type { Sfx } from "../sfx";

const K = 2;
const T = theme.colors;
const PW = 820;
const PH = PW / 1.6;
const LX = 100;
const RX = 1000;
const PY = 250;

const E = {
  left: at(K, 4, 0),
  right: at(K, 4, 0.12),
  cross: at(K, 4, 0.6),
  beams: at(K, 5, 0),
  wave: at(K, 5, 0.38),
};

export const sfx: Sfx[] = [
  { f: E.left, s: "pop", r: 1.0 },
  { f: E.right, s: "pop", r: 0.94 },
  { f: E.cross, s: "thud", v: 0.26 },
  { f: E.beams, s: "whoosh", v: 0.2, r: 1.1 },
  { f: E.wave, s: "click", v: 0.28 },
];

const COLS = 40;
const ROWS = 25;

export const Twist: React.FC = () => {
  const f = useCurrentFrame();
  const cells = gridCells(COLS, ROWS);
  const cw = PW / COLS;

  // সেন্সরের ঘর: শুরুতে ফাঁকা, cue ৫-এ বাঁ→ডানে আলোয় ভরে
  const noImg = ease(f, [E.cross, E.cross + 12], [0, 1]);
  const noImgOut = ease(f, [E.beams, E.beams + 9], [1, 0], theme.ease.in);

  // সিগন্যাল ওয়েভফর্ম: মাঝের সারির উজ্জ্বলতা থেকে
  const mid = cells.filter((c) => c.j === 10);
  const wx0 = RX;
  const wy0 = 820;
  const wH = 100;
  const wpts: Pt[] = [];
  mid.forEach((c, i) => {
    const x = wx0 + (i / (COLS - 1)) * PW;
    const y = wy0 + wH - ((c.lum - 0.1) / 0.9) * wH;
    if (i > 0) wpts.push([x, wpts[wpts.length - 1][1]]);
    wpts.push([x, y]);
  });
  const wp = ease(f, [E.wave, E.wave + 46], [0, 1], theme.ease.inOut);

  const beamY = [0.2, 0.35, 0.5, 0.65, 0.8].map((v) => PY + v * PH);

  return (
    <SceneShell>
      {/* শিরোনাম-ট্যাগ */}
      <div style={{ position: "absolute", left: LX, top: 130 }}>
        <Tag text="আপনার দেখা" delay={E.left} color={T.text} size={40} />
      </div>
      <div style={{ position: "absolute", left: RX, top: 130 }}>
        <Tag text="ক্যামেরার ভেতরে" delay={E.right} color={T.hero} size={40} />
      </div>

      {/* বাঁ প্যানেল: আমরা যা দেখি */}
      <div style={{ position: "absolute", left: LX, top: PY }}>
        <Pop delay={E.left} y={40}>
          <div
            style={{
              width: PW,
              height: PH,
              borderRadius: 22,
              overflow: "hidden",
              border: `2px solid ${T.line}`,
              boxShadow: theme.shadow,
            }}
          >
            <WorldSVG w={PW} id="left" />
          </div>
        </Pop>
      </div>

      {/* ডান প্যানেল: সেন্সরের ঘর */}
      <div style={{ position: "absolute", left: RX, top: PY }}>
        <Pop delay={E.right} y={40}>
          <div
            style={{
              width: PW,
              height: PH,
              borderRadius: 22,
              overflow: "hidden",
              border: `2px solid ${T.hero}`,
              background: T.bgAlt,
              boxShadow: theme.shadow,
              position: "relative",
            }}
          >
            <svg width={PW} height={PH} viewBox={`0 0 ${PW} ${PH}`}>
              {cells.map((c) => {
                const on = ease(f, [E.beams + 4 + c.i * 1.1, E.beams + 22 + c.i * 1.1], [0, 1]);
                return (
                  <rect
                    key={`${c.i}-${c.j}`}
                    x={c.i * cw}
                    y={c.j * cw}
                    width={cw - 1.5}
                    height={cw - 1.5}
                    rx={2}
                    fill={on > 0 ? lumColor(c.lum) : T.panel}
                    opacity={on > 0 ? 0.25 + on * 0.75 : 0.35}
                  />
                );
              })}
            </svg>
            {/* "কোনো ছবি নেই" */}
            <div
              style={{
                position: "absolute",
                inset: 0,
                display: "flex",
                alignItems: "center",
                justifyContent: "center",
                opacity: noImg * noImgOut,
                background: alpha(T.bg, 0.72),
              }}
            >
              <svg width={PW} height={PH} viewBox={`0 0 ${PW} ${PH}`} style={{ position: "absolute", left: 0, top: 0 }}>
                <Draw d={`M${PW / 2 - 90} ${PH / 2 - 120} L${PW / 2 + 90} ${PH / 2 - 20}`} p={ease(f, [E.cross, E.cross + 9], [0, 1])} stroke={T.textDim} w={9} />
                <Draw d={`M${PW / 2 + 90} ${PH / 2 - 120} L${PW / 2 - 90} ${PH / 2 - 20}`} p={ease(f, [E.cross + 5, E.cross + 14], [0, 1])} stroke={T.textDim} w={9} />
              </svg>
              <div style={{ marginTop: 150, fontSize: 70, fontWeight: 700, lineHeight: 1.4, letterSpacing: 0, color: T.text }}>
                কোনো ছবি নেই
              </div>
            </div>
          </div>
        </Pop>
      </div>

      {/* আলোর রশ্মি: দৃশ্য থেকে সেন্সরে */}
      <svg width={1920} height={1080} style={{ position: "absolute", left: 0, top: 0, pointerEvents: "none" }}>
        <g style={{ filter: `drop-shadow(0 0 7px ${T.glowAccent})` }}>
          {beamY.map((y, i) => {
            const pts: Pt[] = [[LX + 560, y], [RX + 260, y]];
            const p = ease(f, [E.beams + i * 4, E.beams + 26 + i * 4], [0, 1], theme.ease.inOut);
            const hide = ease(f, [E.wave + 40, E.wave + 60], [1, 0.25], theme.ease.inOut);
            return (
              <g key={i} opacity={hide}>
                <Draw d={toD(pts)} p={p} stroke={T.accent} w={3} />
                {p >= 1 &&
                  [0, 0.5].map((k) => {
                    const [x, yy] = pointAt(pts, (((f * 0.014 + i * 0.13 + k) % 1) + 1) % 1);
                    return <circle key={k} cx={x} cy={yy} r={5} fill={T.accent} />;
                  })}
              </g>
            );
          })}
        </g>
      </svg>

      {/* আলো-ট্যাগ (বাঁয়ে নিচে) */}
      <div style={{ position: "absolute", left: LX, top: 800 }}>
        <Tag text="আলো" delay={E.beams} color={T.accent} size={52} />
      </div>

      {/* সিগন্যাল ওয়েভফর্ম (ডানে নিচে) */}
      <svg width={1920} height={1080} style={{ position: "absolute", left: 0, top: 0, pointerEvents: "none" }}>
        <line x1={wx0} x2={wx0 + PW} y1={wy0 + wH + 6} y2={wy0 + wH + 6} stroke={T.lineSoft} strokeWidth={2} opacity={wp > 0 ? 1 : 0} />
        <g style={{ filter: `drop-shadow(0 0 8px ${T.glowHero})` }}>
          <Draw d={toD(wpts)} p={wp} stroke={T.hero} w={4} />
        </g>
      </svg>
      <div style={{ position: "absolute", left: RX, top: 790 + 140 }}>
        <Tag text="ইলেকট্রনিক সিগন্যাল" delay={E.wave} color={T.hero} size={46} />
      </div>
    </SceneShell>
  );
};
