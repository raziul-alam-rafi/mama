import {Config} from '@remotion/cli/config';

// WebGL (Three.js) needs a GL backend in headless Chrome.
// "angle" = GPU. If rendering fails or you have no GPU, change to "swangle" (CPU, slower).
Config.setChromiumOpenGlRenderer('angle');
Config.setVideoImageFormat('jpeg');
Config.setJpegQuality(95);
Config.setCodec('h264');
Config.setCrf(16);
Config.setOverwriteOutput(true);
// 3D scenes are heavy; keep concurrency modest. Raise it if you have a strong GPU + lots of RAM.
Config.setConcurrency(2);
