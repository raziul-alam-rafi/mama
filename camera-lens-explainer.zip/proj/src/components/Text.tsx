import React from "react";
import {interpolate, Sequence, spring, useCurrentFrame, useVideoConfig} from "remotion";
import {theme} from "../theme";

const clamp = {extrapolateLeft: "clamp", extrapolateRight: "clamp"} as const;

/** Entrance: opacity + rise + scale together. */
export const Entrance: React.FC<{
  delay?: number; y?: number; from?: number; style?: React.CSSProperties; children: React.ReactNode;
}> = ({delay = 0, y = 36, from = 0.94, style, children}) => {
  const frame = useCurrentFrame();
  const {fps} = useVideoConfig();
  const p = spring({frame: frame - delay, fps, config: theme.spring.smooth});
  return (
    <div
      style={{
        opacity: p,
        transform: `translateY(${interpolate(p, [0, 1], [y, 0])}px) scale(${interpolate(p, [0, 1], [from, 1])})`,
        ...style,
      }}
    >
      {children}
    </div>
  );
};

export type Word = string | {t: string; color?: string};

/** Word-by-word staggered reveal. Splits ONLY on spaces — Bengali clusters are never broken. */
export const WordReveal: React.FC<{
  words: Word[]; delay?: number; per?: number; size: number; color?: string; weight?: number;
  gap?: number; justify?: "flex-start" | "center"; style?: React.CSSProperties;
}> = ({words, delay = 0, per = 4, size, color = theme.colors.text, weight = theme.weight.heavy, gap = 16, justify = "flex-start", style}) => {
  const frame = useCurrentFrame();
  const {fps} = useVideoConfig();
  return (
    <div
      style={{
        display: "flex", flexWrap: "wrap", columnGap: gap, rowGap: 6, justifyContent: justify,
        fontFamily: theme.fonts.display, fontSize: size, fontWeight: weight, lineHeight: 1.38,
        letterSpacing: 0, color, ...style,
      }}
    >
      {words.map((w, i) => {
        const t = typeof w === "string" ? w : w.t;
        const c = typeof w === "string" ? undefined : w.color;
        const p = spring({frame: frame - delay - i * per, fps, config: theme.spring.snappy});
        return (
          <span
            key={i}
            style={{
              display: "inline-block", opacity: p, color: c,
              transform: `translateY(${interpolate(p, [0, 1], [30, 0])}px) scale(${interpolate(p, [0, 1], [0.92, 1])})`,
            }}
          >
            {t}
          </span>
        );
      })}
    </div>
  );
};

type HeadlineItem = {words: Word[]; from: number; to: number};

const HeadlineBlock: React.FC<{words: Word[]; dur: number; size: number}> = ({words, dur, size}) => {
  const frame = useCurrentFrame();
  const o = interpolate(frame, [dur - 10, dur - 1], [1, 0], {easing: theme.ease.in, ...clamp});
  const y = interpolate(frame, [dur - 10, dur - 1], [0, -26], {easing: theme.ease.in, ...clamp});
  return (
    <div style={{opacity: o, transform: `translateY(${y}px)`}}>
      <WordReveal words={words} size={size} per={4} />
    </div>
  );
};

/** Timed headline swaps at a fixed spot (scene-local frames). */
export const Headlines: React.FC<{items: HeadlineItem[]; x?: number; y?: number; size?: number; width?: number}> = ({
  items, x = 120, y = 84, size = 84, width = 1500,
}) => (
  <>
    {items.map((it, i) => (
      <Sequence key={i} from={it.from} durationInFrames={Math.max(12, it.to - it.from)} layout="none">
        <div style={{position: "absolute", left: x, top: y, width}}>
          <HeadlineBlock words={it.words} dur={Math.max(12, it.to - it.from)} size={size} />
        </div>
      </Sequence>
    ))}
  </>
);

/** Small pill label, absolutely positioned in 1920×1080 scene space. */
export const Tag: React.FC<{
  x: number; y: number; text: string; delay?: number; accent?: boolean; size?: number; center?: boolean;
}> = ({x, y, text, delay = 0, accent = false, size = 34, center = true}) => {
  const frame = useCurrentFrame();
  const {fps} = useVideoConfig();
  const p = spring({frame: frame - delay, fps, config: theme.spring.bouncy});
  const col = accent ? theme.colors.accent : theme.colors.text;
  return (
    <div
      style={{
        position: "absolute", left: x, top: y, opacity: Math.min(1, p * 1.4),
        transform: `translate(${center ? "-50%" : "0"}, -50%) scale(${interpolate(p, [0, 1], [0.7, 1])})`,
        padding: "8px 22px 12px", borderRadius: 999,
        background: "rgba(16,26,46,0.9)", border: `2px solid ${accent ? theme.colors.accent : theme.colors.panelEdge}`,
        fontFamily: theme.fonts.display, fontWeight: theme.weight.heavy, fontSize: size, lineHeight: 1.35,
        letterSpacing: 0, color: col, whiteSpace: "nowrap",
        boxShadow: accent ? `0 0 30px ${theme.colors.accentGlow}` : "none",
      }}
    >
      {text}
    </div>
  );
};
