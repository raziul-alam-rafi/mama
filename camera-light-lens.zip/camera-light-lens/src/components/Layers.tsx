import React from "react";
import { AbsoluteFill, useCurrentFrame } from "remotion";
import { theme } from "../theme";

const c = theme.colors;

/** স্তর ১ — ব্যাকগ্রাউন্ড মেশ (কখনো ফ্ল্যাট নয়) + সূক্ষ্ম গ্রিড */
export const BgMesh: React.FC = () => {
  const frame = useCurrentFrame();
  const d1 = Math.sin(frame / 55) * 50;
  const d2 = Math.cos(frame / 70) * 40;
  return (
    <AbsoluteFill style={{ background: `linear-gradient(160deg, ${c.bg} 0%, ${c.bgDeep} 100%)` }}>
      <div
        style={{
          position: "absolute", width: 1300, height: 1300, borderRadius: "50%", top: -560, left: -380 + d1,
          filter: "blur(60px)", background: `radial-gradient(circle, ${c.primary}38, transparent 62%)`,
        }}
      />
      <div
        style={{
          position: "absolute", width: 1000, height: 1000, borderRadius: "50%", bottom: -480, right: -300 - d2,
          filter: "blur(80px)", background: `radial-gradient(circle, ${c.accent}22, transparent 65%)`,
        }}
      />
      <AbsoluteFill
        style={{
          backgroundImage: `linear-gradient(${c.line} 1px, transparent 1px), linear-gradient(90deg, ${c.line} 1px, transparent 1px)`,
          backgroundSize: "96px 96px",
          opacity: 0.22,
          maskImage: "radial-gradient(ellipse at center, black 30%, transparent 78%)",
          WebkitMaskImage: "radial-gradient(ellipse at center, black 30%, transparent 78%)",
        }}
      />
    </AbsoluteFill>
  );
};

/** স্তর ৪ — কালার গ্রেড */
export const Grade: React.FC = () => (
  <AbsoluteFill style={{ pointerEvents: "none" }}>
    <AbsoluteFill style={{ backgroundColor: c.primary, mixBlendMode: "soft-light", opacity: 0.2 }} />
    <AbsoluteFill
      style={{ background: "linear-gradient(180deg, rgba(0,0,0,0.12), transparent 28%, transparent 72%, rgba(0,0,0,0.22))" }}
    />
  </AbsoluteFill>
);

/** স্তর ৫ — প্রসিডিউরাল গ্রেইন */
export const Grain: React.FC = () => {
  const frame = useCurrentFrame();
  const noise = `url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='220' height='220'%3E%3Cfilter id='n'%3E%3CfeTurbulence type='fractalNoise' baseFrequency='0.9' numOctaves='2'/%3E%3C/filter%3E%3Crect width='220' height='220' filter='url(%23n)' opacity='0.5'/%3E%3C/svg%3E")`;
  return (
    <AbsoluteFill
      style={{
        pointerEvents: "none", backgroundImage: noise, backgroundSize: "220px",
        backgroundPosition: `${(frame * 7) % 220}px ${(frame * 13) % 220}px`,
        opacity: 0.06, mixBlendMode: "overlay",
      }}
    />
  );
};

/** স্তর ৫ — ভিনিয়েট (সবার উপরে) */
export const Vignette: React.FC = () => (
  <AbsoluteFill
    style={{ pointerEvents: "none", background: "radial-gradient(ellipse at center, transparent 56%, rgba(0,0,0,0.3) 100%)" }}
  />
);
