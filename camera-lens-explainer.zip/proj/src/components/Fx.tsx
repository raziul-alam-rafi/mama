import React from "react";
import {AbsoluteFill, interpolate, useCurrentFrame, useVideoConfig} from "remotion";
import {theme} from "../theme";

/** Layer 1 — animated mesh + faint blueprint grid. Never a flat colour. */
export const BgMesh: React.FC = () => {
  const frame = useCurrentFrame();
  const d1 = Math.sin(frame / 55) * 50;
  const d2 = Math.cos(frame / 70) * 40;
  return (
    <AbsoluteFill style={{background: theme.colors.bg}}>
      <div
        style={{
          position: "absolute", width: 1300, height: 1300, borderRadius: "50%",
          top: -520, left: -380 + d1, filter: "blur(60px)",
          background: `radial-gradient(circle, ${theme.colors.hero}2e, transparent 62%)`,
        }}
      />
      <div
        style={{
          position: "absolute", width: 1000, height: 1000, borderRadius: "50%",
          bottom: -470, right: -300 - d2, filter: "blur(70px)",
          background: `radial-gradient(circle, ${theme.colors.accent}1c, transparent 65%)`,
        }}
      />
      <svg width="100%" height="100%" style={{position: "absolute", inset: 0, opacity: 0.5}}>
        <defs>
          <pattern id="bpgrid" width="80" height="80" patternUnits="userSpaceOnUse">
            <path d="M80 0H0V80" fill="none" stroke={theme.colors.panelEdge} strokeWidth="1" opacity="0.28" />
          </pattern>
        </defs>
        <rect width="100%" height="100%" fill="url(#bpgrid)" />
      </svg>
    </AbsoluteFill>
  );
};

/** Layer 4 — colour grade. */
export const Grade: React.FC = () => (
  <AbsoluteFill style={{pointerEvents: "none"}}>
    <AbsoluteFill style={{backgroundColor: theme.colors.hero, mixBlendMode: "soft-light", opacity: 0.14}} />
    <AbsoluteFill
      style={{background: "linear-gradient(180deg, rgba(0,0,0,0.14), transparent 28%, transparent 72%, rgba(0,0,0,0.22))"}}
    />
  </AbsoluteFill>
);

/** Layer 5a — procedural film grain. */
export const Grain: React.FC = () => {
  const frame = useCurrentFrame();
  const noise = `url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='220' height='220'%3E%3Cfilter id='n'%3E%3CfeTurbulence type='fractalNoise' baseFrequency='0.9' numOctaves='2'/%3E%3C/filter%3E%3Crect width='220' height='220' filter='url(%23n)' opacity='0.5'/%3E%3C/svg%3E")`;
  return (
    <AbsoluteFill
      style={{
        pointerEvents: "none", backgroundImage: noise, backgroundSize: "220px",
        backgroundPosition: `${(frame * 7) % 220}px ${(frame * 13) % 220}px`,
        opacity: 0.05, mixBlendMode: "overlay",
      }}
    />
  );
};

/** Layer 5b — vignette (topmost). */
export const Vignette: React.FC = () => (
  <AbsoluteFill
    style={{pointerEvents: "none", background: "radial-gradient(ellipse at center, transparent 56%, rgba(0,0,0,0.3) 100%)"}}
  />
);

/** Scene wrapper: quick exit (faster than entrances). `dur` = scene length in frames. */
export const SceneShell: React.FC<{dur: number; children: React.ReactNode}> = ({dur, children}) => {
  const frame = useCurrentFrame();
  const o = interpolate(frame, [dur - 9, dur - 1], [1, 0], {
    easing: theme.ease.in, extrapolateLeft: "clamp", extrapolateRight: "clamp",
  });
  const s = interpolate(frame, [dur - 9, dur - 1], [1, 1.03], {
    easing: theme.ease.in, extrapolateLeft: "clamp", extrapolateRight: "clamp",
  });
  return <AbsoluteFill style={{opacity: o, transform: `scale(${s})`}}>{children}</AbsoluteFill>;
};

/** Scene-to-scene swipe. Rendered at Main level with absolute frames; the cut hides behind it. */
export const Wipe: React.FC<{at: number}> = ({at}) => {
  const frame = useCurrentFrame();
  const {width} = useVideoConfig();
  const span = 18;
  if (frame < at - span / 2 - 1 || frame > at + span / 2 + 1) return null;
  const x = interpolate(frame, [at - span / 2, at + span / 2], [-width * 1.5, width * 1.15], {
    easing: theme.ease.inOut, extrapolateLeft: "clamp", extrapolateRight: "clamp",
  });
  return (
    <AbsoluteFill style={{pointerEvents: "none", overflow: "hidden"}}>
      <div
        style={{
          position: "absolute", top: -100, bottom: -100, width: width * 1.4, left: 0,
          transform: `translateX(${x}px) skewX(-14deg)`,
          background: `linear-gradient(90deg, ${theme.colors.bg} 0%, ${theme.colors.bg} 88%, ${theme.colors.panel} 96%, ${theme.colors.hero} 100%)`,
        }}
      />
    </AbsoluteFill>
  );
};
