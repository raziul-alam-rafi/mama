import React from "react";
import {
  AbsoluteFill,
  Audio,
  Sequence,
  interpolate,
  spring,
  staticFile,
  useCurrentFrame,
  useVideoConfig,
} from "remotion";
import { theme } from "./theme";

export const clampOpts = {
  extrapolateLeft: "clamp",
  extrapolateRight: "clamp",
} as const;

/** from থেকে dur ফ্রেমে 0→1, ইজিংসহ */
export const P = (
  frame: number,
  from: number,
  dur: number,
  easing: (t: number) => number = theme.ease.out
) => interpolate(frame, [from, from + dur], [0, 1], { easing, ...clampOpts });

export const sp = (
  frame: number,
  fps: number,
  delay: number,
  config: { damping: number; stiffness: number; mass: number } = theme.spring.smooth
) => spring({ frame: frame - delay, fps, config });

export const lerp = (a: number, b: number, t: number) => a + (b - a) * t;

/* ---------------- ৫-লেয়ার স্ট্যাকের গ্লোবাল অংশ ---------------- */

export const BgMesh: React.FC = () => {
  const frame = useCurrentFrame();
  const d1 = Math.sin(frame / 55) * 50;
  const d2 = Math.cos(frame / 70) * 40;
  return (
    <AbsoluteFill style={{ background: theme.colors.bg }}>
      <div
        style={{
          position: "absolute",
          width: 1300,
          height: 1300,
          borderRadius: "50%",
          top: -560,
          left: -300 + d1,
          filter: "blur(50px)",
          background: `radial-gradient(circle, ${theme.colors.primary}2E, transparent 62%)`,
        }}
      />
      <div
        style={{
          position: "absolute",
          width: 1000,
          height: 1000,
          borderRadius: "50%",
          bottom: -470,
          right: -250 - d2,
          filter: "blur(70px)",
          background: `radial-gradient(circle, ${theme.colors.accent}1F, transparent 65%)`,
        }}
      />
    </AbsoluteFill>
  );
};

export const Grade: React.FC = () => (
  <AbsoluteFill style={{ pointerEvents: "none" }}>
    <AbsoluteFill
      style={{
        backgroundColor: theme.colors.primary,
        mixBlendMode: "soft-light",
        opacity: 0.16,
      }}
    />
    <AbsoluteFill
      style={{
        background:
          "linear-gradient(180deg, rgba(0,0,0,0.10), transparent 28%, transparent 72%, rgba(0,0,0,0.18))",
      }}
    />
  </AbsoluteFill>
);

export const Grain: React.FC = () => {
  const frame = useCurrentFrame();
  const noise = `url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='220' height='220'%3E%3Cfilter id='n'%3E%3CfeTurbulence type='fractalNoise' baseFrequency='0.9' numOctaves='2'/%3E%3C/filter%3E%3Crect width='220' height='220' filter='url(%23n)' opacity='0.5'/%3E%3C/svg%3E")`;
  return (
    <AbsoluteFill
      style={{
        pointerEvents: "none",
        backgroundImage: noise,
        backgroundSize: "220px",
        backgroundPosition: `${(frame * 7) % 220}px ${(frame * 13) % 220}px`,
        opacity: 0.045,
        mixBlendMode: "overlay",
      }}
    />
  );
};

export const Vignette: React.FC = () => (
  <AbsoluteFill
    style={{
      pointerEvents: "none",
      background:
        "radial-gradient(ellipse at center, transparent 58%, rgba(0,0,0,0.30) 100%)",
    }}
  />
);

/* ---------------- সাউন্ড ---------------- */

export type SfxName = "pop" | "click" | "whoosh" | "chime" | "thud";

/** at = যে ফ্রেমে ভিজ্যুয়াল ল্যান্ড করে (সাউন্ড ৩ ফ্রেম আগে শুরু হয়) */
export const Sfx: React.FC<{
  at: number;
  name: SfxName;
  vol?: number;
  rate?: number;
}> = ({ at, name, vol = 0.28, rate = 1 }) => (
  <Sequence from={Math.max(0, Math.round(at) - 3)} layout="none">
    <Audio src={staticFile(`sfx/${name}.wav`)} volume={vol} playbackRate={rate} />
  </Sequence>
);

/* ---------------- সিন র‍্যাপার (এন্ট্রি + দ্রুত এক্সিট) ---------------- */

export const SceneShell: React.FC<{ children: React.ReactNode; last?: boolean }> = ({ children, last = false }) => {
  const frame = useCurrentFrame();
  const { durationInFrames } = useVideoConfig();
  const enter = P(frame, 0, 16, theme.ease.out);
  const exit = last ? 0 : P(frame, durationInFrames - 10, 9, theme.ease.in);
  return (
    <AbsoluteFill
      style={{
        opacity: enter * (1 - exit),
        transform: `translateX(${(1 - enter) * 90 - exit * 70}px)`,
      }}
    >
      {children}
    </AbsoluteFill>
  );
};

/* ---------------- টেক্সট ও লেবেল ---------------- */

/** শব্দ ধরে স্ট্যাগার্ড রিভিল — কখনো অক্ষর ধরে ভাঙে না */
export const Title: React.FC<{
  text: string;
  delay?: number;
  per?: number;
  size?: number;
  left?: number;
  top?: number;
  weight?: number;
  color?: string;
  highlight?: Record<number, string>;
  center?: boolean;
  width?: number;
}> = ({
  text,
  delay = 0,
  per = 4,
  size = theme.sizes.title,
  left = 120,
  top = 80,
  weight = 700,
  color = theme.colors.text,
  highlight = {},
  center = false,
  width = 1680,
}) => {
  const frame = useCurrentFrame();
  const { fps } = useVideoConfig();
  return (
    <div
      style={{
        position: "absolute",
        left: center ? (theme.width - width) / 2 : left,
        top,
        width,
        display: "flex",
        flexWrap: "wrap",
        justifyContent: center ? "center" : "flex-start",
        columnGap: Math.round(size * 0.26),
        rowGap: 0,
        fontFamily: theme.fonts.main,
        fontSize: size,
        fontWeight: weight,
        lineHeight: 1.3,
        letterSpacing: 0,
        color,
      }}
    >
      {text.split(" ").map((w, i) => {
        const p = sp(frame, fps, delay + i * per, theme.spring.snappy);
        return (
          <span
            key={i}
            style={{
              display: "inline-block",
              opacity: p,
              transform: `translateY(${lerp(34, 0, p)}px) scale(${lerp(0.94, 1, p)})`,
              color: highlight[i] ?? color,
              whiteSpace: "nowrap",
            }}
          >
            {w}
          </span>
        );
      })}
    </div>
  );
};

/** ছোট পিল লেবেল — x,y স্ক্রিন স্পেসে (১৯২০×১০৮০) */
export const Tag: React.FC<{
  x: number;
  y: number;
  text: string;
  sub?: string;
  color?: string;
  delay?: number;
  anchor?: "c" | "l" | "r";
  size?: number;
  exitAt?: number;
}> = ({ x, y, text, sub, color = theme.colors.text, delay = 0, anchor = "c", size = theme.sizes.label, exitAt }) => {
  const frame = useCurrentFrame();
  const { fps } = useVideoConfig();
  const p = sp(frame, fps, delay, theme.spring.snappy);
  const ex = exitAt === undefined ? 0 : P(frame, exitAt, 9, theme.ease.in);
  const tx = anchor === "c" ? "-50%" : anchor === "r" ? "-100%" : "0%";
  return (
    <div
      style={{
        position: "absolute",
        left: x,
        top: y,
        opacity: p * (1 - ex),
        transform: `translate(${tx}, -50%) translateY(${lerp(22, 0, p)}px) scale(${lerp(0.9, 1, p)})`,
        padding: sub ? "10px 28px 12px" : "8px 28px 10px",
        borderRadius: 999,
        border: `2px solid ${color}`,
        background: "rgba(19,27,53,0.88)",
        boxShadow: "0 18px 40px -16px rgba(0,0,0,0.6)",
        fontFamily: theme.fonts.main,
        color,
        textAlign: "center",
        whiteSpace: "nowrap",
      }}
    >
      <div style={{ fontSize: size, fontWeight: 600, lineHeight: 1.3, letterSpacing: 0 }}>{text}</div>
      {sub ? (
        <div style={{ fontSize: size * 0.72, fontWeight: 500, lineHeight: 1.25, color: theme.colors.textDim }}>
          {sub}
        </div>
      ) : null}
    </div>
  );
};

/** HTML এন্ট্রি: opacity + translateY + scale */
export const Reveal: React.FC<{
  delay?: number;
  children: React.ReactNode;
  style?: React.CSSProperties;
  exitAt?: number;
}> = ({ delay = 0, children, style, exitAt }) => {
  const frame = useCurrentFrame();
  const { fps } = useVideoConfig();
  const p = sp(frame, fps, delay, theme.spring.smooth);
  const ex = exitAt === undefined ? 0 : P(frame, exitAt, 9, theme.ease.in);
  return (
    <div
      style={{
        ...style,
        opacity: p * (1 - ex),
        transform: `translateY(${lerp(40, 0, p) - ex * 30}px) scale(${lerp(0.94, 1, p)})`,
      }}
    >
      {children}
    </div>
  );
};

export const FullSvg: React.FC<{ children: React.ReactNode }> = ({ children }) => (
  <svg
    viewBox={`0 0 ${theme.width} ${theme.height}`}
    width={theme.width}
    height={theme.height}
    style={{ position: "absolute", left: 0, top: 0 }}
  >
    {children}
  </svg>
);

/** বাংলা অঙ্ক + ভারতীয় গ্রুপিং (১,০০,০০,০০০) */
export const bnNumber = (n: number) => {
  const s = Math.max(0, Math.round(n)).toString();
  let out: string;
  if (s.length <= 3) out = s;
  else {
    const last3 = s.slice(-3);
    const rest = s.slice(0, -3).replace(/\B(?=(\d{2})+(?!\d))/g, ",");
    out = rest + "," + last3;
  }
  return out.replace(/\d/g, (d) => "০১২৩৪৫৬৭৮৯"[+d]);
};

/** ডিটারমিনিস্টিক হ্যাশ 0..1 */
export const hash = (i: number, salt = 0) => {
  const x = Math.sin(i * 127.1 + salt * 311.7) * 43758.5453;
  return x - Math.floor(x);
};

/** from..to ফ্রেম পর্যন্ত দৃশ্যমান উইন্ডো; ভেতরের ফ্রেম লোকাল (from = ০) */
export const Win: React.FC<{ from: number; to: number; children: React.ReactNode }> = ({ from, to, children }) => {
  const frame = useCurrentFrame();
  if (frame < from || frame > to) return null;
  const o = P(frame, from, 8) * (1 - P(frame, to - 8, 8, theme.ease.in));
  return (
    <Sequence from={from} layout="none">
      <div style={{ position: "absolute", left: 0, top: 0, width: theme.width, height: theme.height, opacity: o }}>
        {children}
      </div>
    </Sequence>
  );
};
