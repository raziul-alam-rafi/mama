import React from "react";
import {AbsoluteFill, spring, useCurrentFrame, useVideoConfig} from "remotion";
import {theme} from "../theme";
import {at} from "../timeline";
import {Elem, LensShape, Ray, SvgDefs, traceRay} from "../components/Optics";
import {PictureArt, SensorBar} from "../components/Art";
import {Headlines, Tag} from "../components/Text";
import {Sfx} from "../components/Sfx";
import {prog} from "../components/util";

const SI = 4;
const PANEL_Y = 290;
const PANEL_W = 830;
const PANEL_H = 620;
const AX = PANEL_Y + 300;
const PX = [80, 1010]; // panel x
const LX = 240, F = 220;
const SEN = LX + F;
const ELEM: Elem[] = [{x: LX, power: 1 / F, kind: "convex", h: 150, w: 24}];
const ALL_H = [-120, -90, -60, -30, 0, 30, 60, 90, 120];
const NORMAL = [-60, 0, 60]; // heights of the 3 "normal" rays
const MORE = ALL_H.filter((h) => !NORMAL.includes(h));
const DIM = [0];
const DIM_GONE = [-60, 60];

/** One exposure panel. `bright` = picture brightness factor, `wash` = white/black overlay, rays are listed by height with their own opacity. */
const Panel: React.FC<{
  px: number; rays: {h: number; op: number}[]; bright: number; sat: number; overlay: string; overlayOp: number; pIn: number;
}> = ({px, rays, bright, sat, overlay, overlayOp, pIn}) => {
  const ox = px;
  const el = ELEM.map((e) => ({...e, x: ox + e.x}));
  const PIC = {x: ox + 540, y: AX - 130, w: 260, h: 260};
  return (
    <g opacity={pIn}>
      <rect x={ox} y={PANEL_Y} width={PANEL_W} height={PANEL_H} rx={theme.radius} fill={theme.colors.bgAlt} stroke={theme.colors.panelEdge} strokeWidth={3} />
      <line x1={ox + 20} x2={ox + SEN + 30} y1={AX} y2={AX} stroke={theme.colors.panelEdge} strokeWidth={2} strokeDasharray="12 10" />
      {rays.map((r, i) => (
        <g key={i} opacity={r.op}>
          <Ray pts={traceRay(r.h, 0, ox + 24, el, ox + SEN, AX)} p={1} width={3.2} />
        </g>
      ))}
      <LensShape x={ox + LX} cy={AX} h={150} w={24} kind="convex" />
      <SensorBar x={ox + SEN} cy={AX} h={110} />
      <path d={`M ${ox + SEN + 24} ${AX} H ${PIC.x - 30}`} stroke={theme.colors.accent} strokeWidth={4} strokeLinecap="round" />
      <path d={`M ${PIC.x - 26} ${AX - 12} L ${PIC.x - 10} ${AX} L ${PIC.x - 26} ${AX + 12}`} fill="none" stroke={theme.colors.accent} strokeWidth={4} strokeLinecap="round" strokeLinejoin="round" />
      {/* the resulting picture */}
      <rect x={PIC.x - 4} y={PIC.y - 4} width={PIC.w + 8} height={PIC.h + 8} rx={14} fill={theme.colors.bg} stroke={theme.colors.panelEdge} strokeWidth={3} />
      <svg x={PIC.x} y={PIC.y} width={PIC.w} height={PIC.h} viewBox="-200 -170 400 340" preserveAspectRatio="xMidYMid slice">
        <g style={{filter: `brightness(${bright}) saturate(${sat})`}}>
          <PictureArt />
        </g>
        <rect x={-200} y={-170} width={400} height={340} fill={overlay} opacity={overlayOp} />
      </svg>
    </g>
  );
};

/** Scene 5 — before/after split: too much light washes the picture out, too little leaves it dark. */
export const S5Exposure: React.FC = () => {
  const frame = useCurrentFrame();
  const {fps} = useVideoConfig();

  const tMore = at(SI, 8, "বেশি");
  const tBright = at(SI, 9, "উজ্জ্বল");
  const tLess = at(SI, 9, "কম");
  const tDark = at(SI, 9, "অন্ধকার");
  const end = at(SI, 9) + 380;

  const pIn = spring({frame: frame - 2, fps, config: theme.spring.smooth});
  const pIn2 = spring({frame: frame - 8, fps, config: theme.spring.smooth});

  const more = prog(frame, tMore, 26, theme.ease.inOut); // left: more light
  const wash = prog(frame, tBright - 6, 22, theme.ease.inOut); // left: picture washes out
  const less = prog(frame, tLess, 24, theme.ease.inOut); // right: less light
  const dark = prog(frame, tDark - 6, 22, theme.ease.inOut); // right: picture darkens

  const leftRays = [
    ...NORMAL.map((h) => ({h, op: 1})),
    ...MORE.map((h, i) => ({h, op: prog(frame, tMore + i * 2, 12)})),
  ];
  const rightRays = [
    ...DIM.map((h) => ({h, op: 1})),
    ...DIM_GONE.map((h) => ({h, op: 1 - prog(frame, tLess, 16)})),
  ];

  return (
    <AbsoluteFill>
      <svg width={1920} height={1080} viewBox="0 0 1920 1080" style={{position: "absolute", inset: 0}}>
        <SvgDefs />
        <Panel px={PX[0]} rays={leftRays} bright={1 + 1.6 * wash} sat={1 - 0.5 * wash} overlay="#FFFFFF" overlayOp={0.5 * wash} pIn={Math.min(1, pIn)} />
        <Panel px={PX[1]} rays={rightRays} bright={1 - 0.8 * dark} sat={1 - 0.3 * dark} overlay="#050A14" overlayOp={0.35 * dark} pIn={Math.min(1, pIn2)} />
      </svg>

      <Headlines
        items={[
          {words: ["একটা", {t: "নতুন", color: theme.colors.accent}, "সমস্যা"], from: 4, to: Math.max(tMore - 4, 40)},
          {words: [{t: "বেশি", color: theme.colors.accent}, "আলো", "→", "অতিরিক্ত", "উজ্জ্বল"], from: Math.max(tMore - 4, 40), to: Math.max(tLess - 4, 100)},
          {words: [{t: "কম", color: theme.colors.accent}, "আলো", "→", "অন্ধকার"], from: Math.max(tLess - 4, 100), to: end},
        ]}
        size={84}
      />
      <Tag x={PX[0] + 40} y={PANEL_Y + 46} text="বেশি আলো" delay={tMore} accent size={34} center={false} />
      <Tag x={PX[1] + 40} y={PANEL_Y + 46} text="কম আলো" delay={tLess} accent size={34} center={false} />
      <Tag x={PX[0] + 540 + 130} y={AX + 190} text="অতিরিক্ত উজ্জ্বল" delay={tBright} size={30} />
      <Tag x={PX[1] + 540 + 130} y={AX + 190} text="অন্ধকার" delay={tDark} size={30} />
      <Sfx at={4} name="thud" />
      <Sfx at={tMore} name="pop" />
      <Sfx at={tBright} name="chime" vol={0.8} />
      <Sfx at={tLess} name="pop" rate={0.85} />
      <Sfx at={tDark} name="click" />
    </AbsoluteFill>
  );
};
