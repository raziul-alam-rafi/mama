// SFX সিন্থেসাইজার: public/sfx/*.wav (মনো, 44.1kHz, 16-bit)। কোনো ডাউনলোড লাগে না, ফলাফল নির্ধারিত।
import fs from "fs";
import path from "path";
import { fileURLToPath } from "url";

const SR = 44100;
const out = path.join(path.dirname(fileURLToPath(import.meta.url)), "..", "public", "sfx");
fs.mkdirSync(out, { recursive: true });

let seed = 7;
const rnd = () => ((seed = (seed * 16807) % 2147483647) / 2147483647) * 2 - 1;
const buf = (sec) => new Float32Array(Math.round(sec * SR));

const lowpass = (x, fc) => {
  const a = Math.exp((-2 * Math.PI * fc) / SR);
  let y = 0;
  return x.map((v) => (y = (1 - a) * v + a * y));
};
const highpass = (x, fc) => {
  const lp = lowpass(x, fc);
  return x.map((v, i) => v - lp[i]);
};
const bandpassSweep = (x, f0, f1) => {
  // স্টেট-ভ্যারিয়েবল ফিল্টার, কেন্দ্র-কম্পাঙ্ক সুইপ করে
  let low = 0, band = 0;
  return x.map((v, i) => {
    const t = i / x.length;
    const fc = f0 * Math.pow(f1 / f0, t);
    const f = 2 * Math.sin((Math.PI * fc) / SR);
    low += f * band;
    const high = v - low - 0.28 * band;
    band += f * high;
    return band;
  });
};
const reverb = (x) => {
  // খুব ছোট রিভার্ব: দুটি দুর্বল টেপ
  const y = new Float32Array(x.length + Math.round(0.06 * SR));
  x.forEach((v, i) => {
    y[i] += v;
    y[i + Math.round(0.023 * SR)] += v * 0.2;
    y[i + Math.round(0.041 * SR)] += v * 0.1;
  });
  return y;
};
const env = (n, atk, dec) => (i) => {
  const t = i / SR;
  return Math.min(1, t / atk) * Math.exp(-t / dec);
};

const sounds = {
  // নিচে নামা pitch সহ sine + ছোট envelope
  pop() {
    const x = buf(0.2);
    let ph = 0;
    const e = env(x.length, 0.004, 0.05);
    for (let i = 0; i < x.length; i++) {
      const t = i / SR;
      ph += (2 * Math.PI * (180 + 420 * Math.exp(-t / 0.03))) / SR;
      x[i] = Math.sin(ph) * e(i);
    }
    return reverb(lowpass(x, 3200));
  },
  // high-pass করা ছোট noise burst + হালকা টিক
  click() {
    const x = buf(0.1);
    const e = env(x.length, 0.0008, 0.011);
    let ph = 0;
    for (let i = 0; i < x.length; i++) {
      ph += (2 * Math.PI * 2100) / SR;
      x[i] = (rnd() * 0.8 + Math.sin(ph) * 0.35) * e(i);
    }
    return reverb(lowpass(highpass(x, 1800), 7500));
  },
  // band-pass noise sweep, fade in/out
  whoosh() {
    const n = buf(0.7);
    for (let i = 0; i < n.length; i++) n[i] = rnd();
    const y = bandpassSweep(n, 420, 2300);
    for (let i = 0; i < y.length; i++) {
      const t = i / y.length;
      y[i] *= Math.pow(Math.sin(Math.PI * Math.min(1, t * 1.15)), 2) * (1 - t * 0.2);
    }
    return reverb(lowpass(y, 4200));
  },
  // নরম ওভারটোনসহ ছোট decay
  chime() {
    const x = buf(0.44);
    const e = env(x.length, 0.008, 0.1);
    const parts = [[880, 1], [1318.5, 0.5], [1760, 0.28], [2637, 0.1]];
    for (let i = 0; i < x.length; i++) {
      let s = 0;
      for (const [f, a] of parts) s += Math.sin((2 * Math.PI * f * i) / SR) * a;
      x[i] = s * e(i);
    }
    return reverb(lowpass(x, 5200));
  },
  // খুব হালকা সফট থাড
  thud() {
    const x = buf(0.32);
    let ph = 0;
    const e = env(x.length, 0.006, 0.09);
    for (let i = 0; i < x.length; i++) {
      const t = i / SR;
      ph += (2 * Math.PI * (46 + 60 * Math.exp(-t / 0.05))) / SR;
      x[i] = Math.sin(ph) * e(i);
    }
    return reverb(lowpass(x, 700));
  },
};

const report = [];
for (const [name, make] of Object.entries(sounds)) {
  let x = make();
  // শেষে নরম fade-out (ক্লিক এড়াতে)
  const tail = Math.round(0.012 * SR);
  for (let i = 0; i < tail; i++) x[x.length - 1 - i] *= i / tail;
  // একই স্তরে মেলাতে: লক্ষ্য RMS ≈ 0.10, peak সর্বোচ্চ 0.9 (clipping নেই)
  let peak = 0, e2 = 0;
  x.forEach((v) => { peak = Math.max(peak, Math.abs(v)); e2 += v * v; });
  const g = Math.min(0.9 / peak, 0.1 / Math.sqrt(e2 / x.length));
  const pcm = Buffer.alloc(44 + x.length * 2);
  pcm.write("RIFF", 0);
  pcm.writeUInt32LE(36 + x.length * 2, 4);
  pcm.write("WAVEfmt ", 8);
  pcm.writeUInt32LE(16, 16);
  pcm.writeUInt16LE(1, 20);
  pcm.writeUInt16LE(1, 22);
  pcm.writeUInt32LE(SR, 24);
  pcm.writeUInt32LE(SR * 2, 28);
  pcm.writeUInt16LE(2, 32);
  pcm.writeUInt16LE(16, 34);
  pcm.write("data", 36);
  pcm.writeUInt32LE(x.length * 2, 40);
  let clip = 0, pk = 0, sq = 0;
  x.forEach((v, i) => {
    const s = Math.max(-1, Math.min(1, v * g));
    if (Math.abs(s) >= 0.999) clip++;
    pk = Math.max(pk, Math.abs(s));
    sq += s * s;
    pcm.writeInt16LE(Math.round(s * 32767), 44 + i * 2);
  });
  fs.writeFileSync(path.join(out, `${name}.wav`), pcm);
  report.push({ name, sec: +(x.length / SR).toFixed(3), peak: +pk.toFixed(3), rms: +Math.sqrt(sq / x.length).toFixed(3), clip });
}
console.table(report);
