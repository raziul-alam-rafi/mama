// SRT is the ONLY timing authority. All frames derive from here.
import { SRT } from "./srtData";
import { FPS } from "./config";

export type Cue = { n: number; start: number; end: number; text: string };

const toSec = (t: string) => {
  const m = t.trim().match(/(\d+):(\d+):(\d+)[,.](\d+)/);
  if (!m) return 0;
  return +m[1] * 3600 + +m[2] * 60 + +m[3] + +m[4] / 1000;
};

export const parseSrt = (raw: string): Cue[] =>
  raw
    .replace(/\r/g, "")
    .trim()
    .split(/\n\s*\n/)
    .map((block) => {
      const lines = block.split("\n");
      const n = parseInt(lines[0], 10);
      const [a, b] = lines[1].split("-->");
      return { n, start: toSec(a), end: toSec(b), text: lines.slice(2).join(" ").trim() };
    })
    .filter((c) => !Number.isNaN(c.n));

export const CUES = parseSrt(SRT);
export const cue = (n: number) => CUES.find((c) => c.n === n)!;
export const TOTAL_FRAMES = Math.ceil(CUES[CUES.length - 1].end * FPS);

/** absolute frame of cue start */
export const cueStartF = (n: number) => Math.round(cue(n).start * FPS);
export const cueEndF = (n: number) => Math.round(cue(n).end * FPS);

/**
 * absolute frame where a word in a cue is (approximately) spoken: proportional to its
 * character position inside the cue's time span. `occ` = which occurrence (0-based).
 */
export const wordF = (n: number, word: string, occ = 0) => {
  const c = cue(n);
  const text = c.text;
  let idx = -1;
  for (let k = 0; k <= occ; k++) idx = text.indexOf(word, idx + 1);
  if (idx < 0) idx = 0;
  const frac = idx / text.length;
  return Math.round((c.start + frac * (c.end - c.start)) * FPS);
};
