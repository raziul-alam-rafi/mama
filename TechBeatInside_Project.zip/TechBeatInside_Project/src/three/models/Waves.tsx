import React, {useMemo, useRef} from 'react';
import * as THREE from 'three';
import {COLORS} from '../../config/theme';
import {clamp} from '../../utils/math';

const vert = `varying vec3 vN; varying vec3 vV;
void main(){ vec4 mv = modelViewMatrix*vec4(position,1.0); vN = normalize(normalMatrix*normal); vV = normalize(-mv.xyz); gl_Position = projectionMatrix*mv; }`;
const frag = `uniform vec3 uColor; uniform float uOpacity; varying vec3 vN; varying vec3 vV;
void main(){ float f = pow(1.0 - abs(dot(normalize(vN), normalize(vV))), 2.2); gl_FragColor = vec4(uColor, f*uOpacity); }`;

/** Expanding RF wave fronts (explanatory visualization; real radio waves are invisible). */
export const RadioWaves: React.FC<{
  origin: THREE.Vector3;
  frame: number;
  startFrame: number;
  speed: number; // metres per frame
  maxRadius: number;
}> = ({origin, frame, startFrame, speed, maxRadius}) => {
  const COUNT = 4;
  const GAP = 11;
  const geo = useMemo(() => new THREE.SphereGeometry(1, 72, 40), []);
  const mats = useRef<THREE.ShaderMaterial[]>([]);
  const uniformSets = useMemo(
    () =>
      Array.from({length: COUNT}).map(() => ({
        uColor: {value: new THREE.Color(COLORS.signal)},
        uOpacity: {value: 0},
      })),
    [],
  );
  return (
    <group position={origin}>
      {uniformSets.map((u, i) => {
        const age = frame - startFrame - i * GAP;
        const r = Math.max(0.001, age * speed);
        const visible = age > 0 && r < maxRadius * 1.02;
        u.uOpacity.value = visible ? 0.9 * clamp(1 - r / (maxRadius * 1.02)) ** 0.6 * clamp(age / 6) : 0;
        return (
          <mesh key={i} geometry={geo} scale={[r, r, r]} visible={visible} renderOrder={5}>
            <shaderMaterial
              ref={(m) => {
                if (m) mats.current[i] = m;
              }}
              vertexShader={vert}
              fragmentShader={frag}
              uniforms={u}
              transparent
              depthWrite={false}
              side={THREE.DoubleSide}
              blending={THREE.AdditiveBlending}
              fog={false}
            />
          </mesh>
        );
      })}
    </group>
  );
};
