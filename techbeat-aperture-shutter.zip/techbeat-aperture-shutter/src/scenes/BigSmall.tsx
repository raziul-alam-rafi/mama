import React from "react";
import { AbsoluteFill } from "remotion";
import { theme } from "../theme";
import { useScene } from "../SceneContext";
import { Card, Chip, ip, clamp01 } from "../components/Motion";
import { LensCutaway } from "../components/LensCutaway";
import { passFraction } from "../components/optics";
import { Sfx } from "../components/Sfx";

const Meter: React.FC<{ x: number; y: number; w: number; value: number; label: string; color: string; delay: number }> = ({ x, y, w, value, label, color, delay }) => (
  <div style={{ position: "absolute", left: x, top: y, width: w }}>
    <div style={{ fontFamily: theme.fonts.display, fontWeight: 600, fontSize: 44, color: theme.colors.text, marginBottom: 12 }}>{label}</div>
    <div style={{ height: 30, borderRadius: 15, background: theme.colors.bgAlt, border: `2px solid ${theme.colors.line}`, overflow: "hidden" }}>
      <div style={{ width: `${clamp01(value) * 100}%`, height: "100%", borderRadius: 15, background: `linear-gradient(90deg, ${theme.colors.accent}, ${theme.colors.light})`, boxShadow: `0 0 24px ${color}` }} />
    </div>
  </div>
);

// Scene 3 · Big vs small aperture (cue 4): same lens, two openings → different amount of light reaches the sensor.
export const BigSmall: React.FC = () => {
  const S = useScene();
  const f = S.frame;
  const c4 = Math.max(S.cue(4), 0);
  const fL = S.word(4, "বড় হলে");
  const fR = S.word(4, "ছোট হলে");
  const openL = ip(f, [fL, fL + 30], [0.5, 1.0]);
  const openR = ip(f, [fR, fR + 30], [0.5, 0.13]);
  const progL = ip(f, [c4 + 6, c4 + 52], [0, 1], theme.ease.soft);
  const progR = ip(f, [fR - 8, fR + 40], [0, 1], theme.ease.soft);
  const meterL = passFraction(openL) * ip(progL, [0.82, 1], [0, 1]);
  const meterR = passFraction(openR) * ip(progR, [0.82, 1], [0, 1]);

  return (
    <AbsoluteFill>
      <Card x={40} y={200} w={900} h={740} delay={c4} border={theme.colors.primary}>
        <div style={{ position: "absolute", left: 34, top: 28 }}>
          <Chip text="বড় Aperture" tone="primary" size={46} delay={c4 + 8} />
        </div>
      </Card>
      <Card x={980} y={200} w={900} h={740} delay={fR - 10} border={theme.colors.accent}>
        <div style={{ position: "absolute", left: 34, top: 28 }}>
          <Chip text="ছোট Aperture" tone="accent" size={46} delay={fR} />
        </div>
      </Card>

      <div style={{ position: "absolute", left: 60, top: 400 }}>
        <LensCutaway width={860} open={openL} prog={progL} highlightIris uid="bl" showSensorGlow />
      </div>
      <div style={{ position: "absolute", left: 1000, top: 400, opacity: ip(f, [fR - 10, fR + 6], [0, 1]) }}>
        <LensCutaway width={860} open={openR} prog={progR} highlightIris uid="sm" showSensorGlow />
      </div>

      <Meter x={84} y={780} w={780} value={meterL} label="বেশি আলো" color={theme.colors.accent} delay={fL} />
      <Meter x={1024} y={780} w={780} value={meterR} label="কম আলো" color={theme.colors.accent} delay={fR} />

      <Sfx name="pop" at={c4 + 2} />
      <Sfx name="click" at={fL + 4} />
      <Sfx name="pop" at={fR - 8} rate={1.06} />
      <Sfx name="click" at={fR + 4} rate={0.94} />
    </AbsoluteFill>
  );
};
