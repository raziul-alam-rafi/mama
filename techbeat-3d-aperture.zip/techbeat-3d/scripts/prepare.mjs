// Parses an SRT into src/data/cues.json + composition metadata.
// The narration text is preserved verbatim (line breaks joined by a space only).
import fs from "node:fs";
import path from "node:path";

const FPS = 30;
const TAIL_SECONDS = 0.5; // calm tail after the last cue
const file = process.argv[2] ?? "input/aperture.srt";
const raw = fs.readFileSync(file, "utf8").replace(/^\uFEFF/, "").replace(/\r/g, "");

const ts = (s) => {
  const m = s.trim().match(/^(\d+):(\d{2}):(\d{2})[,.](\d{1,3})$/);
  if (!m) throw new Error(`Bad timestamp: "${s}"`);
  return +m[1] * 3600 + +m[2] * 60 + +m[3] + +m[4].padEnd(3, "0") / 1000;
};

const cues = raw.split(/\n\s*\n/).map((b) => b.trim()).filter(Boolean).map((block) => {
  const lines = block.split("\n");
  const timeIdx = lines.findIndex((l) => l.includes("-->"));
  if (timeIdx < 0) throw new Error(`No timing line in block:\n${block}`);
  const [a, b] = lines[timeIdx].split("-->");
  const start = ts(a), end = ts(b);
  if (end <= start) throw new Error(`Cue end <= start: ${lines[timeIdx]}`);
  return {
    index: Number(lines[0]) || undefined,
    start, end,
    startFrame: Math.round(start * FPS),
    endFrame: Math.round(end * FPS),
    text: lines.slice(timeIdx + 1).join(" ").trim(),
  };
});

for (let i = 1; i < cues.length; i++) {
  if (cues[i].start < cues[i - 1].end - 0.001) console.warn(`WARN: cue ${i + 1} overlaps previous cue`);
}
const last = cues[cues.length - 1].end;
const out = {
  source: path.basename(file),
  fps: FPS,
  width: 1920,
  height: 1080,
  lastCueEnd: last,
  durationInFrames: Math.ceil((last + TAIL_SECONDS) * FPS),
  cues,
};
fs.mkdirSync("src/data", { recursive: true });
fs.writeFileSync("src/data/cues.json", JSON.stringify(out, null, 2));
console.log(`OK: ${cues.length} cues, last end ${last}s -> ${out.durationInFrames} frames @ ${FPS}fps (${(out.durationInFrames / FPS).toFixed(2)}s)`);
