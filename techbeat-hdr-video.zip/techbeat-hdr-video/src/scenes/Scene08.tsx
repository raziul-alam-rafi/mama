// সিন ৮ (cue 11–12): Sensor তথ্য + Computer হিসাব = ফলাফল; তারপর আলো → Sensor → বৈদ্যুতিক তথ্য → Processor (Process Flow)
// আলোর রশ্মি = নীল, বৈদ্যুতিক সংকেত = অ্যাম্বার, ডেটা-টাইল = আসল ছবির টুকরো
import React from "react";
import { random, useCurrentFrame } from "remotion";
import { theme } from "../theme";
import { makeT } from "../timing";
import { Entrance, SceneShell, tween, useBreathe } from "../components/anim";
import { Card, Chip, Label } from "../components/ui";
import { SensorDie } from "../components/sensor";
import { ProcChip } from "../components/chip";
import { EXPO, Photo, PhotoContent } from "../components/photo";
import { SfxEvent } from "../sfx";

const T = makeT(7);
const tComp = T(11);
const tEq = T(11, "মিলিয়ে");
const tRes = T(11, "ফলাফল");
const tLight = T(11, "ক্যামেরা আলো");
const tElec = T(12, "আলোকে বৈদ্যুতিক");
const tProc = T(12, "Processor সেই");
// সাজানো শুরু: Processor-এর কথার ঠিক পরে; "সাজায়" cue-র শেষ দিকে বলে সময় কম, তাই আগে শুরু করে সিনের মধ্যেই শেষ হয়
const tSort = tProc + 14;

export const sfx08: SfxEvent[] = [
  { kind: "pop", frame: 4 },
  { kind: "pop", frame: tComp + 6, rate: 1.06 },
  { kind: "click", frame: tEq + 4 },
  { kind: "chime", frame: tRes + 10, vol: 0.7 },
  { kind: "pop", frame: tLight + 10, rate: 0.95 },
  { kind: "click", frame: tLight + 34 },
  { kind: "pop", frame: tElec + 4, rate: 1.1 },
  { kind: "pop", frame: tProc + 6 },
  { kind: "whoosh", frame: tSort + 2, rate: 1.12, vol: 0.6 },
  { kind: "chime", frame: tSort + 58, vol: 0.9 },
];

// ---- জ্যামিতি ----
const OBJ_X = 330, LENS_X = 500, SENS_X = 860, CY = 540;
const OBJ_Y = [495, 540, 585];
const IMG_Y = OBJ_Y.map((y) => CY - (y - CY) * 2.6); // উল্টো প্রতিবিম্ব
const APERTURE = [-100, 0, 100];
const CELLS = 9, CELL_TOP = 390, CELL_H = 300 / CELLS;
const cellY = (i: number) => CELL_TOP + CELL_H * (i + 0.5);
const CHIP_X = 1180, CHIP_Y = 410, CHIP_S = 260;
const PIN_Y = (i: number) => CHIP_Y + 28 + i * (CHIP_S - 56) / (CELLS - 1);
const lvl = (i: number) => Math.max(...IMG_Y.map((y) => Math.exp(-(((cellY(i) - y) / 26) ** 2))));

// মোজাইক (প্রসেসরের আউটপুট ছবি): ৬×৪ টাইল
const MX = 1500, MY = 450, MW = 320, MH = 180, COLS = 6, ROWS = 4;
const TW = MW / COLS, TH = MH / ROWS;
const SCALE = MW / 640;

const Scrambled: React.FC<{ sortP: (i: number) => number; show: number; frame: number }> = ({ sortP, show, frame }) => (
  <svg width={1920} height={1080} style={{ position: "absolute", inset: 0 }}>
    <defs>
      {Array.from({ length: COLS * ROWS }).map((_, i) => {
        const c = i % COLS, r = Math.floor(i / COLS);
        return <clipPath key={i} id={`s8-clip-${i}`}><rect x={c * TW} y={r * TH} width={TW} height={TH} /></clipPath>;
      })}
    </defs>
    <rect x={MX - 8} y={MY - 8} width={MW + 16} height={MH + 16} rx={14} fill="none" stroke={theme.colors.line} strokeWidth={3} strokeDasharray="12 10" opacity={show} />
    {Array.from({ length: COLS * ROWS }).map((_, i) => {
      const c = i % COLS, r = Math.floor(i / COLS);
      const p = sortP(i);
      const sx = -300 + random(`tx${i}`) * 200 - c * TW, sy = -20 + random(`ty${i}`) * 140 - r * TH; // চিপের ভেতরে এলোমেলো
      const rot0 = (random(`tr${i}`) - 0.5) * 70;
      const ox = (1 - p) * sx, oy = (1 - p) * sy, rot = (1 - p) * rot0;
      const jitter = (1 - p) * Math.sin(frame / 4 + i) * 3;
      const cx = c * TW + TW / 2, cy = r * TH + TH / 2;
      return (
        <g key={i} opacity={show} transform={`translate(${MX + ox},${MY + oy + jitter}) rotate(${rot} ${cx} ${cy})`}>
          <g clipPath={`url(#s8-clip-${i})`}>
            <g transform={`scale(${SCALE})`}><PhotoContent uid={`s8t${i}`} gRoom={EXPO.over} gSky={EXPO.under} /></g>
          </g>
          <rect x={c * TW} y={r * TH} width={TW} height={TH} fill="none" stroke={theme.colors.bg} strokeWidth={1.5} opacity={0.6} />
        </g>
      );
    })}
  </svg>
);

export const Scene08: React.FC = () => {
  const frame = useCurrentFrame();
  const bob = useBreathe(44, 3);

  // ধাপ A: সমীকরণ
  const outA = tween(frame, tLight - 2, tLight + 10, 1, 0, theme.ease.in);
  const outAy = tween(frame, tLight - 2, tLight + 10, 0, -50, theme.ease.in);

  // ধাপ B: পাইপলাইন
  const rayP = tween(frame, tLight + 6, tLight + 36, 0, 1, theme.ease.inOut);
  const lit = tween(frame, tLight + 34, tLight + 52, 0, 1);
  const elec = tween(frame, tElec, tElec + 16, 0, 1);
  const procA = tween(frame, tProc, tProc + 18, 0, 1);
  const tilesShow = tween(frame, tProc, tProc + 12, 0, 1);
  const sortP = (i: number) => tween(frame, tSort + i * 1.5, tSort + i * 1.5 + 24, 0, 1, theme.ease.inOut);

  const rays: { p0: [number, number]; p1: [number, number]; p2: [number, number]; l1: number; l2: number }[] = [];
  OBJ_Y.forEach((yo, pi) => APERTURE.forEach((a) => {
    const p0: [number, number] = [OBJ_X, yo], p1: [number, number] = [LENS_X, CY + a], p2: [number, number] = [SENS_X, IMG_Y[pi]];
    rays.push({ p0, p1, p2, l1: Math.hypot(p1[0] - p0[0], p1[1] - p0[1]), l2: Math.hypot(p2[0] - p1[0], p2[1] - p1[1]) });
  }));
  const bTop = 780;

  return (
    <SceneShell>
      {/* ---------- ধাপ A ---------- */}
      <div style={{ position: "absolute", inset: 0, opacity: outA, transform: `translateY(${outAy}px)` }}>
        <Entrance delay={0} style={{ position: "absolute", left: 210, top: 330 + bob }}>
          <Card w={440} h={380} border={theme.colors.hero}>
            <div style={{ display: "flex", flexDirection: "column", alignItems: "center", gap: 26, paddingTop: 36 }}>
              <SensorDie size={220} />
              <Label size={42} color={theme.colors.hero} weight={700}>Sensor-এর তথ্য</Label>
            </div>
          </Card>
        </Entrance>
        <Entrance delay={tComp - 4} style={{ position: "absolute", left: 650, top: 450 }}><Label size={110} color={theme.colors.accent} weight={700} style={{ width: 90, textAlign: "center" }}>+</Label></Entrance>
        <Entrance delay={tComp} style={{ position: "absolute", left: 740, top: 330 - bob }}>
          <Card w={440} h={380} border={theme.colors.accent}>
            <div style={{ display: "flex", flexDirection: "column", alignItems: "center", gap: 26, paddingTop: 36 }}>
              <ProcChip size={220} active={0.4} color={theme.colors.accent} />
              <Label size={42} color={theme.colors.accent} weight={700}>Computer হিসাব</Label>
            </div>
          </Card>
        </Entrance>
        <Entrance delay={tEq} style={{ position: "absolute", left: 1180, top: 450 }}><Label size={110} color={theme.colors.text} weight={700} style={{ width: 90, textAlign: "center" }}>=</Label></Entrance>
        <Entrance delay={tRes} style={{ position: "absolute", left: 1270, top: 330 + bob }}>
          <Card w={440} h={380} border={theme.colors.ok}>
            <div style={{ display: "flex", flexDirection: "column", alignItems: "center", gap: 24, paddingTop: 44 }}>
              <div style={{ borderRadius: 14, overflow: "hidden" }}><Photo uid="s8r" gRoom={EXPO.over} gSky={EXPO.under} width={360} radius={0} /></div>
              <Label size={42} color={theme.colors.ok} weight={700}>ফলাফল</Label>
            </div>
          </Card>
        </Entrance>
      </div>

      {/* ---------- ধাপ B ---------- */}
      <svg width={1920} height={1080} style={{ position: "absolute", inset: 0 }}>
        {/* আলোর রশ্মি */}
        {rays.map((r, k) => {
          const d = `M${r.p0} L${r.p1} L${r.p2}`;
          const tot = r.l1 + r.l2;
          return (
            <g key={k}>
              <path d={d} fill="none" stroke={theme.colors.hero} strokeWidth={3.5} strokeOpacity={0.75} pathLength={1} strokeDasharray={1} strokeDashoffset={1 - rayP} strokeLinejoin="round" />
              {[0, 1].map((j) => {
                const u = ((frame * 0.014 + j * 0.5 + k * 0.083) % 1) * tot;
                const pos: [number, number] = u < r.l1
                  ? [r.p0[0] + (r.p1[0] - r.p0[0]) * (u / r.l1), r.p0[1] + (r.p1[1] - r.p0[1]) * (u / r.l1)]
                  : [r.p1[0] + (r.p2[0] - r.p1[0]) * ((u - r.l1) / r.l2), r.p1[1] + (r.p2[1] - r.p1[1]) * ((u - r.l1) / r.l2)];
                return <circle key={j} cx={pos[0]} cy={pos[1]} r={6} fill={theme.colors.text} opacity={rayP > 0.95 ? 0.95 : 0} />;
              })}
            </g>
          );
        })}
        {/* লেন্স */}
        <g opacity={tween(frame, tLight, tLight + 16, 0, 1)}>
          <ellipse cx={LENS_X} cy={CY} rx={34} ry={175} fill={`${theme.colors.hero}22`} stroke={theme.colors.hero} strokeWidth={5} style={{ filter: `drop-shadow(0 0 16px ${theme.colors.glowHero})` }} />
        </g>
        {/* Sensor-এর পিক্সেল কলাম */}
        <g opacity={tween(frame, tLight + 18, tLight + 34, 0, 1)}>
          <rect x={SENS_X - 14} y={CELL_TOP - 16} width={56} height={300 + 32} rx={12} fill={theme.colors.surface} stroke={theme.colors.line} strokeWidth={3} />
          {Array.from({ length: CELLS }).map((_, i) => {
            const L = lvl(i) * lit;
            return (
              <g key={i}>
                <rect x={SENS_X} y={cellY(i) - 13} width={28} height={26} rx={5} fill={theme.colors.hero} opacity={0.15 + 0.85 * L} />
                <rect x={SENS_X} y={cellY(i) - 13} width={28} height={26} rx={5} fill="none" stroke={theme.colors.accent} strokeWidth={3} opacity={elec * (0.3 + 0.7 * lvl(i))} />
              </g>
            );
          })}
        </g>
        {/* তার + বৈদ্যুতিক সংকেত */}
        {Array.from({ length: CELLS }).map((_, i) => {
          const x0 = SENS_X + 32, y0 = cellY(i), x1 = CHIP_X + 4, y1 = PIN_Y(i);
          const u = (frame * 0.022 + i * 0.137) % 1;
          return (
            <g key={i} opacity={elec}>
              <line x1={x0} y1={y0} x2={x1} y2={y1} stroke={theme.colors.accent} strokeOpacity={0.4} strokeWidth={2.5} />
              <rect x={x0 + (x1 - x0) * u - 8} y={y0 + (y1 - y0) * u - 8} width={16} height={16} rx={4} fill={theme.colors.accent}
                opacity={0.3 + 0.7 * lvl(i)} style={{ filter: `drop-shadow(0 0 8px ${theme.colors.accent})` }} />
            </g>
          );
        })}
      </svg>

      {/* দৃশ্য (আলোর উৎস) */}
      <Entrance delay={tLight} style={{ position: "absolute", left: 90, top: CY - 62 + bob }}>
        <div style={{ borderRadius: 12, overflow: "hidden", border: `3px solid ${theme.colors.hero}`, boxShadow: theme.shadow.card, opacity: 1 }}>
          <Photo uid="s8o" gRoom={0.9} gSky={0.3} width={240} radius={0} />
        </div>
      </Entrance>

      {/* Processor চিপ + আউটপুট */}
      <div style={{ position: "absolute", left: CHIP_X, top: CHIP_Y, opacity: tween(frame, tElec - 6, tElec + 10, 0, 1) }}>
        <ProcChip size={CHIP_S} active={procA} />
      </div>
      <Scrambled sortP={sortP} show={tilesShow} frame={frame} />

      {/* লেবেল */}
      <Entrance delay={tLight + 8} style={{ position: "absolute", left: 360, top: bTop }}><Chip text="আলো" color={theme.colors.hero} /></Entrance>
      <Entrance delay={tLight + 30} style={{ position: "absolute", left: 790, top: bTop }}><Chip text="Sensor" color={theme.colors.hero} /></Entrance>
      <Entrance delay={tElec + 4} style={{ position: "absolute", left: 960, top: 330 }}><Chip text="বৈদ্যুতিক তথ্য" color={theme.colors.accent} solid /></Entrance>
      <Entrance delay={tProc + 4} style={{ position: "absolute", left: 1200, top: bTop }}><Chip text="Processor" color={theme.colors.hero} /></Entrance>
      <Entrance delay={tSort + 6} style={{ position: "absolute", left: 1520, top: 700 }}><Chip text="সাজানো ছবি" color={theme.colors.ok} /></Entrance>
    </SceneShell>
  );
};
