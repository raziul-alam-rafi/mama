import React from "react";
import { useCurrentFrame } from "remotion";
import { theme } from "../theme";
import { rng } from "./kit";

const O = theme.objects;

/* ============================================================
   Cricket scene (used on the TV screen, as the stadium, as the "picture")
   ============================================================ */
export const CricketField: React.FC<{ t?: number }> = ({ t = 0 }) => {
  const r = rng(7);
  const crowd = Array.from({ length: 150 }, () => ({
    x: r() * 640,
    y: 112 + r() * 60,
    c: ["#e8d9c4", "#c0453a", "#4a78c9", "#f1c04f", "#8fd0a0", "#d9d9e4"][
      Math.floor(r() * 6)
    ],
  }));
  const rings = [0, 1, 2, 3, 4, 5];
  const p = (t % 70) / 70; // ball run
  const bx = 318 + (1 - p) * 4 - p * 0;
  const by = 238 + p * 100;
  const bowlerY = 236 + Math.min(1, p * 1.6) * 28;
  const fielders = [
    [130, 268],
    [200, 345],
    [455, 350],
    [520, 275],
    [90, 300],
    [560, 315],
    [320, 395],
  ];
  return (
    <svg
      viewBox="0 0 640 430"
      width="100%"
      height="100%"
      preserveAspectRatio="xMidYMid slice"
      style={{ display: "block" }}
    >
      <defs>
        <linearGradient id="cf-sky" x1="0" y1="0" x2="0" y2="1">
          <stop offset="0" stopColor="#6aa5f2" />
          <stop offset="1" stopColor="#cfe6ff" />
        </linearGradient>
        <linearGradient id="cf-stand" x1="0" y1="0" x2="0" y2="1">
          <stop offset="0" stopColor="#4a5775" />
          <stop offset="1" stopColor="#2c3550" />
        </linearGradient>
        <radialGradient id="cf-grass" cx="0.5" cy="0.45" r="0.7">
          <stop offset="0" stopColor={O.grass} />
          <stop offset="1" stopColor={O.grassDark} />
        </radialGradient>
      </defs>
      <rect width="640" height="430" fill="url(#cf-sky)" />
      <rect y="104" width="640" height="84" fill="url(#cf-stand)" />
      {crowd.map((d, i) => (
        <circle key={i} cx={d.x} cy={d.y} r="2.6" fill={d.c} opacity="0.9" />
      ))}
      {/* floodlight masts */}
      {[60, 580].map((x) => (
        <g key={x}>
          <rect x={x - 3} y="30" width="6" height="90" fill="#8b93a6" />
          <rect x={x - 22} y="18" width="44" height="18" rx="3" fill="#e8ecf5" />
        </g>
      ))}
      <rect y="186" width="640" height="244" fill={O.grassDark} />
      <ellipse cx="320" cy="298" rx="330" ry="122" fill="url(#cf-grass)" />
      {rings.map((i) => (
        <ellipse
          key={i}
          cx="320"
          cy="298"
          rx={330 - i * 52}
          ry={122 - i * 19}
          fill={i % 2 ? "rgba(0,0,0,0.07)" : "rgba(255,255,255,0.05)"}
        />
      ))}
      <ellipse
        cx="320"
        cy="298"
        rx="326"
        ry="119"
        fill="none"
        stroke="#f4f6fa"
        strokeWidth="3"
        strokeDasharray="10 7"
        opacity="0.8"
      />
      {/* pitch */}
      <polygon points="292,222 348,222 374,356 266,356" fill={O.pitch} />
      <line x1="288" y1="238" x2="352" y2="238" stroke="#fff" strokeWidth="2" />
      <line x1="272" y1="338" x2="368" y2="338" stroke="#fff" strokeWidth="2.5" />
      {[308, 320, 332].map((x) => (
        <rect key={x} x={x - 1.6} y="214" width="3.2" height="14" fill="#f2efe6" />
      ))}
      {[300, 320, 340].map((x) => (
        <rect key={x} x={x - 2} y="344" width="4" height="20" fill="#f2efe6" />
      ))}
      {/* fielders */}
      {fielders.map(([x, y], i) => (
        <g key={i}>
          <ellipse cx={x} cy={y + 14} rx="9" ry="3" fill="rgba(0,0,0,0.25)" />
          <rect x={x - 5} y={y - 12} width="10" height="24" rx="5" fill="#f5f7fb" />
          <circle cx={x} cy={y - 18} r="6" fill="#e0b48f" />
        </g>
      ))}
      {/* bowler */}
      <g>
        <rect x="313" y={bowlerY - 12} width="10" height="24" rx="5" fill="#4a78c9" />
        <circle cx="318" cy={bowlerY - 18} r="6" fill="#e0b48f" />
      </g>
      {/* batter */}
      <g>
        <ellipse cx="330" cy="372" rx="12" ry="3.5" fill="rgba(0,0,0,0.3)" />
        <rect x="324" y="342" width="13" height="30" rx="6" fill="#c0453a" />
        <circle cx="330" cy="334" r="7.5" fill="#2b3c78" />
        <rect x="338" y="346" width="5" height="26" rx="2" fill="#c8a465" transform="rotate(14 340 360)" />
      </g>
      {/* ball */}
      <circle cx={bx} cy={by} r="5" fill="#c4312a" stroke="#fff" strokeWidth="1" />
    </svg>
  );
};

/** Analog noise (TV with no signal yet). */
export const StaticNoise: React.FC = () => {
  const frame = useCurrentFrame();
  return (
    <svg width="100%" height="100%" style={{ display: "block" }}>
      <filter id="sn">
        <feTurbulence
          type="fractalNoise"
          baseFrequency="0.85"
          numOctaves="1"
          seed={frame % 24}
          result="n"
        />
        <feColorMatrix
          in="n"
          type="matrix"
          values="0.9 0.9 0.9 0 -0.3  0.9 0.9 0.9 0 -0.3  0.9 0.9 0.9 0 -0.3  0 0 0 0 1"
        />
      </filter>
      <rect width="100%" height="100%" filter="url(#sn)" />
    </svg>
  );
};

/* ============================================================
   CRT television — pseudo-3D (stacked tapered layers + CSS perspective)
   ============================================================ */
export const CRTTV: React.FC<{
  rot?: number;
  screen?: React.ReactNode;
  on?: number; // 0..1 screen glow
  scale?: number;
}> = ({ rot = -24, screen, on = 1, scale = 1 }) => {
  const frame = useCurrentFrame();
  const W = 760;
  const H = 600;
  const N = 14;
  const led = Math.sin(frame / 9) > -0.2 ? 1 : 0.35;
  return (
    <div style={{ width: W * scale, height: H * scale }}>
      <div
        style={{
          width: W,
          height: H,
          transform: `scale(${scale})`,
          transformOrigin: "0 0",
          perspective: 3000,
          perspectiveOrigin: "50% 45%",
        }}
      >
        <div
          style={{
            position: "relative",
            width: W,
            height: H,
            transformStyle: "preserve-3d",
            transform: `rotateY(${rot}deg)`,
          }}
        >
          {/* floor shadow */}
          <div
            style={{
              position: "absolute",
              left: 40,
              top: H - 40,
              width: W - 80,
              height: 90,
              borderRadius: "50%",
              background:
                "radial-gradient(ellipse, rgba(0,0,0,0.55), transparent 70%)",
              transform: "translateZ(-150px) rotateX(90deg) translateZ(-30px)",
              filter: "blur(6px)",
            }}
          />
          {/* tapered rear (cabinet behind the glass) */}
          {Array.from({ length: N }, (_, i) => {
            const t = (i + 1) / N;
            const shade = Math.round(48 - t * 24);
            return (
              <div
                key={i}
                style={{
                  position: "absolute",
                  inset: 0,
                  borderRadius: 64,
                  transform: `translateZ(${-i * 46 - 12}px) scale(${1 - 0.08 * t - 0.3 * t * t * t * t})`,
                  background: `linear-gradient(160deg, rgb(${shade + 14},${shade + 15},${shade + 20}), rgb(${shade - 6},${shade - 5},${shade}))`,
                  border: `2px solid rgba(0,0,0,0.45)`,
                  boxShadow: "inset 0 0 40px rgba(0,0,0,0.35)",
                }}
              >
                {i === 5 &&
                  Array.from({ length: 9 }, (_, k) => (
                    <div
                      key={k}
                      style={{
                        position: "absolute",
                        left: "18%",
                        right: "18%",
                        top: `${22 + k * 6}%`,
                        height: 5,
                        borderRadius: 3,
                        background: "rgba(0,0,0,0.55)",
                      }}
                    />
                  ))}
              </div>
            );
          })}
          {/* front bezel */}
          <div
            style={{
              position: "absolute",
              inset: 0,
              borderRadius: 40,
              background: `linear-gradient(150deg, ${O.casingHi}, ${O.casing} 40%, ${O.casingLo})`,
              boxShadow:
                "inset 0 3px 0 rgba(255,255,255,0.18), inset 0 -6px 18px rgba(0,0,0,0.5), 0 30px 60px rgba(0,0,0,0.45)",
              transform: "translateZ(0px)",
            }}
          >
            {/* recessed screen frame */}
            <div
              style={{
                position: "absolute",
                left: 40,
                top: 34,
                width: 680,
                height: 462,
                borderRadius: "74px / 56px",
                background: `linear-gradient(180deg, ${O.casingLo}, #2a2c30)`,
                boxShadow: "inset 0 6px 18px rgba(0,0,0,0.7)",
              }}
            />
            {/* glass */}
            <div
              style={{
                position: "absolute",
                left: 56,
                top: 48,
                width: 648,
                height: 434,
                borderRadius: "64px / 48px",
                overflow: "hidden",
                background: "#0c0e10",
                boxShadow: `inset 0 0 50px rgba(0,0,0,0.85), 0 0 ${90 * on}px rgba(150,190,255,${0.35 * on})`,
              }}
            >
              <div style={{ position: "absolute", inset: 0, opacity: 0.35 + 0.65 * on }}>
                {screen}
              </div>
              {/* scanline texture */}
              <div
                style={{
                  position: "absolute",
                  inset: 0,
                  background:
                    "repeating-linear-gradient(180deg, rgba(0,0,0,0.16) 0px, rgba(0,0,0,0.16) 1px, transparent 1px, transparent 3px)",
                }}
              />
              {/* curvature shading + glass reflection */}
              <div
                style={{
                  position: "absolute",
                  inset: 0,
                  background:
                    "radial-gradient(ellipse at 50% 50%, transparent 55%, rgba(0,0,0,0.55) 100%)",
                }}
              />
              <div
                style={{
                  position: "absolute",
                  inset: 0,
                  background:
                    "linear-gradient(118deg, rgba(255,255,255,0.22) 0%, rgba(255,255,255,0.05) 28%, transparent 40%)",
                }}
              />
            </div>
            {/* control strip */}
            <div
              style={{
                position: "absolute",
                left: 70,
                right: 70,
                top: 520,
                height: 54,
                display: "flex",
                alignItems: "center",
                gap: 22,
              }}
            >
              {Array.from({ length: 6 }, (_, i) => (
                <div
                  key={i}
                  style={{
                    width: 30,
                    height: 30,
                    borderRadius: 999,
                    background: `radial-gradient(circle at 35% 30%, #4a4d55, #17181b)`,
                    boxShadow: "0 2px 4px rgba(0,0,0,0.6)",
                  }}
                />
              ))}
              <div style={{ flex: 1 }} />
              <div
                style={{
                  width: 40,
                  height: 36,
                  borderRadius: 8,
                  background: "linear-gradient(180deg,#2a2c30,#141518)",
                  boxShadow: "0 2px 4px rgba(0,0,0,0.6)",
                }}
              />
              <div
                style={{
                  width: 12,
                  height: 12,
                  borderRadius: 999,
                  background: O.red,
                  opacity: led,
                  boxShadow: `0 0 14px ${O.red}`,
                }}
              />
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

/* ============================================================
   Broadcast TV camera on tripod — lens points LEFT
   ============================================================ */
export const TVCamera: React.FC<{ glow?: number }> = ({ glow = 0 }) => {
  const frame = useCurrentFrame();
  const tally = Math.sin(frame / 8) > 0 ? 1 : 0.4;
  return (
    <svg viewBox="0 0 640 580" width="640" height="580" style={{ overflow: "visible" }}>
      <defs>
        <linearGradient id="cam-body" x1="0" y1="0" x2="0" y2="1">
          <stop offset="0" stopColor="#434853" />
          <stop offset="1" stopColor="#1f2228" />
        </linearGradient>
        <linearGradient id="cam-barrel" x1="0" y1="0" x2="0" y2="1">
          <stop offset="0" stopColor="#6a707c" />
          <stop offset="0.5" stopColor="#2a2d35" />
          <stop offset="1" stopColor="#14161a" />
        </linearGradient>
        <radialGradient id="cam-glass" cx="0.4" cy="0.4" r="0.7">
          <stop offset="0" stopColor="#9bc4ff" />
          <stop offset="0.5" stopColor="#2a4f9a" />
          <stop offset="1" stopColor="#0a1530" />
        </radialGradient>
      </defs>
      {/* tripod */}
      <g stroke="#2a2d33" strokeLinecap="round">
        <line x1="330" y1="372" x2="170" y2="560" strokeWidth="14" />
        <line x1="330" y1="372" x2="500" y2="560" strokeWidth="14" />
        <line x1="330" y1="372" x2="332" y2="566" strokeWidth="14" />
        <line x1="205" y1="520" x2="458" y2="520" strokeWidth="6" stroke="#3d4048" />
      </g>
      <rect x="296" y="350" width="70" height="34" rx="8" fill="#3b3e46" />
      {/* body */}
      <rect x="170" y="176" width="320" height="180" rx="22" fill="url(#cam-body)" />
      <rect x="170" y="176" width="320" height="8" rx="4" fill="rgba(255,255,255,0.14)" />
      {/* handle */}
      <path d="M230 176 V148 H420 V176" fill="none" stroke="#3a3d45" strokeWidth="14" strokeLinejoin="round" />
      {/* viewfinder */}
      <rect x="360" y="96" width="170" height="64" rx="12" fill="#23262d" />
      <rect x="372" y="106" width="60" height="44" rx="6" fill="#0c0e12" />
      {/* back box + tally light */}
      <rect x="460" y="196" width="70" height="140" rx="12" fill="#262a31" />
      <circle cx="498" cy="214" r="9" fill={O.red} opacity={tally} />
      {/* lens barrel (to the left) */}
      <rect x="62" y="206" width="130" height="120" rx="18" fill="url(#cam-barrel)" />
      <rect x="94" y="196" width="22" height="140" rx="6" fill="#16181d" />
      <rect x="130" y="196" width="14" height="140" rx="5" fill="#16181d" />
      {/* lens hood + glass */}
      <ellipse cx="62" cy="266" rx="40" ry="78" fill="#101216" />
      <ellipse cx="58" cy="266" rx="30" ry="64" fill="url(#cam-glass)" />
      <ellipse cx="50" cy="248" rx="9" ry="22" fill="rgba(255,255,255,0.55)" />
      <ellipse
        cx="58"
        cy="266"
        rx="34"
        ry="68"
        fill="none"
        stroke={theme.colors.accent}
        strokeWidth="5"
        opacity={glow}
        style={{ filter: `drop-shadow(0 0 14px ${theme.colors.accent})` }}
      />
    </svg>
  );
};

/* ============================================================
   Transmission tower, Yagi antenna, house
   ============================================================ */
export const Tower: React.FC<{ t: number; rings?: boolean; ringT?: number }> = ({
  t,
  rings = true,
  ringT = 0,
}) => {
  const levels = Array.from({ length: 9 }, (_, i) => i);
  const xAt = (y: number, side: -1 | 1) => 150 + side * ((y - 70) / 550) * 92;
  const blink = Math.sin(t / 7) > 0 ? 1 : 0.35;
  return (
    <svg viewBox="0 0 300 640" width="300" height="640" style={{ overflow: "visible" }}>
      {rings &&
        [0, 1, 2].map((k) => {
          const ph = ((ringT / 46 + k / 3) % 1 + 1) % 1;
          return (
            <circle
              key={k}
              cx="150"
              cy="62"
              r={14 + ph * 215}
              fill="none"
              stroke={theme.colors.hero}
              strokeWidth={5 - ph * 3}
              opacity={Math.max(0, (1 - ph) * 0.85)}
            />
          );
        })}
      <g stroke="#9aa3b2" strokeWidth="7" strokeLinecap="round" fill="none">
        <line x1="58" y1="620" x2="150" y2="70" />
        <line x1="242" y1="620" x2="150" y2="70" />
      </g>
      <g stroke="#7d8696" strokeWidth="4" strokeLinecap="round">
        {levels.map((i) => {
          const y1 = 620 - i * 61;
          const y2 = 620 - (i + 1) * 61;
          return (
            <g key={i}>
              <line x1={xAt(y1, -1)} y1={y1} x2={xAt(y1, 1)} y2={y1} />
              <line x1={xAt(y1, -1)} y1={y1} x2={xAt(y2, 1)} y2={Math.max(70, y2)} />
            </g>
          );
        })}
      </g>
      <rect x="140" y="70" width="20" height="30" fill="#b9c0cc" />
      <circle
        cx="150"
        cy="60"
        r="13"
        fill={theme.colors.accent}
        opacity={blink}
        style={{ filter: `drop-shadow(0 0 12px ${theme.colors.accent})` }}
      />
    </svg>
  );
};

export const YagiAntenna: React.FC<{ glow?: number }> = ({ glow = 0 }) => {
  const els = [
    { x: 56, h: 150 },
    { x: 96, h: 120 },
    { x: 136, h: 110 },
    { x: 176, h: 96 },
    { x: 216, h: 82 },
    { x: 252, h: 70 },
  ];
  return (
    <svg
      viewBox="0 0 300 200"
      width="300"
      height="200"
      style={{
        overflow: "visible",
        filter: `drop-shadow(0 0 ${22 * glow}px ${theme.colors.glow})`,
      }}
    >
      <line x1="30" y1="100" x2="280" y2="100" stroke="#cfd5dd" strokeWidth="9" strokeLinecap="round" />
      {els.map((e) => (
        <line
          key={e.x}
          x1={e.x}
          y1={100 - e.h / 2}
          x2={e.x}
          y2={100 + e.h / 2}
          stroke={glow > 0.5 ? "#e8efff" : "#cfd5dd"}
          strokeWidth="7"
          strokeLinecap="round"
        />
      ))}
      <line x1="130" y1="100" x2="130" y2="200" stroke="#9aa3b2" strokeWidth="10" strokeLinecap="round" />
    </svg>
  );
};

/** House with a window cut-out; the interior TV is overlaid by the scene. */
export const House: React.FC = () => (
  <svg viewBox="0 0 760 760" width="760" height="760" style={{ overflow: "visible" }}>
    <defs>
      <linearGradient id="h-wall" x1="0" y1="0" x2="0" y2="1">
        <stop offset="0" stopColor="#e2d8c4" />
        <stop offset="1" stopColor="#bfb299" />
      </linearGradient>
      <linearGradient id="h-room" x1="0" y1="0" x2="0" y2="1">
        <stop offset="0" stopColor="#2b3350" />
        <stop offset="1" stopColor="#171c30" />
      </linearGradient>
    </defs>
    <ellipse cx="380" cy="716" rx="400" ry="34" fill="rgba(0,0,0,0.4)" />
    <rect x="120" y="330" width="520" height="380" fill="url(#h-wall)" />
    <polygon points="70,344 380,110 690,344" fill={O.roof} />
    <polygon points="70,344 380,110 380,134 100,344" fill="rgba(255,255,255,0.12)" />
    <rect x="520" y="150" width="46" height="110" fill="#8d7f68" />
    {/* window / cutaway */}
    <rect x="196" y="402" width="368" height="256" rx="10" fill="#6d5f4a" />
    <rect x="208" y="414" width="344" height="232" rx="6" fill="url(#h-room)" />
    <rect x="208" y="600" width="344" height="46" fill="#3a2f26" />
    <rect x="262" y="590" width="236" height="14" rx="4" fill="#5a4636" />
    <rect x="130" y="660" width="500" height="50" fill="rgba(0,0,0,0.12)" />
  </svg>
);

/** Quadratic bezier point (for pulses travelling along curved signal paths). */
export const qpt = (
  p0: [number, number],
  c: [number, number],
  p1: [number, number],
  t: number
): [number, number] => {
  const u = 1 - t;
  return [
    u * u * p0[0] + 2 * u * t * c[0] + t * t * p1[0],
    u * u * p0[1] + 2 * u * t * c[1] + t * t * p1[1],
  ];
};
