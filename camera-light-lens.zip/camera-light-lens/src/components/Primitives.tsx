import React from "react";
import { AbsoluteFill, interpolate, spring, useCurrentFrame, useVideoConfig } from "remotion";
import { theme } from "../theme";
import { Sfx } from "./audio";

const c = theme.colors;
const clampOpts = { extrapolateLeft: "clamp", extrapolateRight: "clamp" } as const;

type Preset = { damping: number; stiffness: number; mass: number };

/** spring 0→1 */
export const usePop = (delay = 0, preset: Preset = theme.spring.snappy) => {
  const frame = useCurrentFrame();
  const { fps } = useVideoConfig();
  return spring({ frame: frame - delay, fps, config: preset });
};

/** দ্রুত এক্সিট 0→1 (এন্ট্রির চেয়ে ছোট) */
export const useExit = (at?: number, dur: number = theme.timing.exit) => {
  const frame = useCurrentFrame();
  if (at === undefined) return 0;
  return interpolate(frame, [at, at + dur], [0, 1], { easing: theme.ease.in, ...clampOpts });
};

/** bezier প্রগ্রেস 0→1 */
export const useProgress = (start: number, dur: number = theme.timing.enter, easing = theme.ease.out) => {
  const frame = useCurrentFrame();
  return interpolate(frame, [start, start + dur], [0, 1], { easing, ...clampOpts });
};

/** ২-৩ প্রপার্টি একসাথে: opacity + translate + scale (+ ঐচ্ছিক blur)। exitAt দিলে দ্রুত এক্সিট */
export const Enter: React.FC<{
  delay?: number; x?: number; y?: number; scaleFrom?: number; exitAt?: number;
  preset?: Preset; style?: React.CSSProperties; children?: React.ReactNode;
}> = ({ delay = 0, x = 0, y = 40, scaleFrom = 0.94, exitAt, preset = theme.spring.smooth, style, children }) => {
  const p = usePop(delay, preset);
  const q = useExit(exitAt);
  const o = Math.min(1, p) * (1 - q);
  return (
    <div
      style={{
        opacity: o,
        transform: `translate(${interpolate(p, [0, 1], [x, 0]) + 0}px, ${interpolate(p, [0, 1], [y, 0]) - q * 36}px) scale(${interpolate(p, [0, 1], [scaleFrom, 1]) * (1 + q * 0.03)})`,
        willChange: "transform, opacity",
        ...style,
      }}
    >
      {children}
    </div>
  );
};

/** ওয়ার্ড-বাই-ওয়ার্ড স্ট্যাগার্ড — শব্দ-বিভাজন শুধু স্পেসে (বাংলা যুক্তাক্ষর কখনো ভাঙে না) */
export const Words: React.FC<{
  text: string; delay?: number; per?: number; size: number; color?: string; weight?: number;
  align?: "flex-start" | "center" | "flex-end"; exitAt?: number; maxWidth?: number;
  wordStyle?: (word: string, i: number) => React.CSSProperties; style?: React.CSSProperties;
}> = ({ text, delay = 0, per = theme.timing.word, size, color = c.text, weight = theme.weight.heavy, align = "flex-start", exitAt, maxWidth, wordStyle, style }) => {
  const frame = useCurrentFrame();
  const { fps } = useVideoConfig();
  const words = text.split(" ");
  return (
    <div
      style={{
        display: "flex", flexWrap: "wrap", justifyContent: align, columnGap: Math.round(size * 0.26), rowGap: Math.round(size * 0.08),
        fontFamily: theme.fonts.display, fontWeight: weight, fontSize: size, lineHeight: 1.22, letterSpacing: 0, color, maxWidth, ...style,
      }}
    >
      {words.map((w, i) => {
        const p = spring({ frame: frame - delay - i * per, fps, config: theme.spring.snappy });
        const q = exitAt === undefined ? 0 : interpolate(frame, [exitAt + i * 2, exitAt + i * 2 + theme.timing.exit], [0, 1], { easing: theme.ease.in, ...clampOpts });
        return (
          <span
            key={i}
            style={{
              display: "inline-block", opacity: Math.min(1, p) * (1 - q),
              transform: `translateY(${interpolate(p, [0, 1], [34, 0]) - q * 30}px) scale(${interpolate(p, [0, 1], [0.9, 1])})`,
              ...wordStyle?.(w, i),
            }}
          >
            {w}
          </span>
        );
      })}
    </div>
  );
};

/** লাইন মাস্ক রিভিল — লাইনটি নিচ থেকে মাস্কের ভেতরে উঠে আসে */
export const MaskLine: React.FC<{ delay?: number; exitAt?: number; pad?: number; children: React.ReactNode; style?: React.CSSProperties }> = ({
  delay = 0, exitAt, pad = 26, children, style,
}) => {
  const p = useProgress(delay, theme.timing.enter + 4);
  const q = useExit(exitAt);
  const y = interpolate(p, [0, 1], [118, 0]) - q * 118;
  return (
    <div style={{ overflow: "hidden", paddingTop: pad, paddingBottom: pad, marginTop: -pad, marginBottom: -pad, ...style }}>
      <div style={{ transform: `translateY(${y}%)`, opacity: Math.min(1, p * 3) * (1 - q * q) }}>{children}</div>
    </div>
  );
};

/** অ্যানিমেটেড স্ট্রাইক-থ্রু */
export const Strike: React.FC<{ delay?: number; color?: string; thick?: number; children: React.ReactNode; dimTo?: number }> = ({
  delay = 0, color = c.accent, thick = 9, children, dimTo = 0.45,
}) => {
  const p = useProgress(delay, 14, theme.ease.inOut);
  return (
    <span style={{ position: "relative", display: "inline-block", opacity: interpolate(p, [0, 1], [1, dimTo]) }}>
      {children}
      <span
        style={{
          position: "absolute", left: -8, right: -8, top: "55%", height: thick, borderRadius: thick,
          background: color, transformOrigin: "left center", transform: `scaleX(${p})`, boxShadow: `0 0 24px ${c.accentGlow}`,
        }}
      />
    </span>
  );
};

/** হাইলাইট সুইপ — টেক্সটের পেছনে পিল বাঁ→ডানে স্কেল করে */
export const Sweep: React.FC<{ delay?: number; color?: string; children: React.ReactNode; style?: React.CSSProperties }> = ({
  delay = 0, color = c.primary, children, style,
}) => {
  const p = useProgress(delay, 18, theme.ease.inOut);
  return (
    <span style={{ position: "relative", display: "inline-block", padding: "0 22px", ...style }}>
      <span
        style={{
          position: "absolute", inset: "6px 0 2px 0", borderRadius: 22, background: `linear-gradient(90deg, ${color}, ${color}CC)`,
          transformOrigin: "left center", transform: `scaleX(${p})`, boxShadow: `0 0 50px ${c.glow}`,
        }}
      />
      <span style={{ position: "relative" }}>{children}</span>
    </span>
  );
};

/** idle micro-motion */
export const Breathe: React.FC<{ amp?: number; phase?: number; children: React.ReactNode; style?: React.CSSProperties }> = ({
  amp = 1, phase = 0, children, style,
}) => {
  const frame = useCurrentFrame();
  return (
    <div style={{ transform: `translateY(${Math.sin(frame / 30 + phase) * 6 * amp}px) scale(${1 + Math.sin(frame / 22 + phase) * 0.012 * amp})`, ...style }}>
      {children}
    </div>
  );
};

/** গ্লাস কার্ড — সারা ভিডিওতে একই কোণ, ছায়া, বর্ডার */
export const Glass: React.FC<{ style?: React.CSSProperties; children?: React.ReactNode; glow?: boolean }> = ({ style, children, glow }) => (
  <div
    style={{
      position: "relative", borderRadius: theme.radius.card, border: `1.5px solid ${c.glassBorder}`,
      background: `linear-gradient(150deg, rgba(255,255,255,0.10), rgba(255,255,255,0.03) 60%), ${c.bgAlt}`,
      boxShadow: glow ? `${theme.shadow.card}, 0 0 80px ${c.glow}` : theme.shadow.card,
      ...style,
    }}
  >
    <div style={{ position: "absolute", inset: 0, borderRadius: style?.borderRadius ?? theme.radius.card, boxShadow: "inset 0 1.5px 0 rgba(255,255,255,0.22)", pointerEvents: "none" }} />
    {children}
  </div>
);

/** ছোট লেবেল-পিল */
export const Chip: React.FC<{ text: string; size?: number; tone?: "dim" | "accent" | "primary"; style?: React.CSSProperties }> = ({
  text, size = 40, tone = "dim", style,
}) => {
  const col = tone === "accent" ? c.accent : tone === "primary" ? c.primary : c.text;
  return (
    <div
      style={{
        display: "inline-flex", alignItems: "center", gap: 14, padding: `${Math.round(size * 0.3)}px ${Math.round(size * 0.7)}px`,
        borderRadius: theme.radius.pill, border: `1.5px solid ${c.glassBorder}`, background: "rgba(255,255,255,0.07)",
        fontFamily: theme.fonts.body, fontWeight: theme.weight.heavy, fontSize: size, lineHeight: 1.2, letterSpacing: 0, color: c.text,
        boxShadow: theme.shadow.soft, ...style,
      }}
    >
      <span style={{ width: size * 0.3, height: size * 0.3, borderRadius: "50%", background: col, boxShadow: tone === "dim" ? "none" : `0 0 18px ${col}` }} />
      {text}
    </div>
  );
};

/** সিন র‍্যাপার — সিনের শেষ ফ্রেমগুলোতে দ্রুত এক্সিট (opacity + scale + blur) */
export const SceneFrame: React.FC<{ duration: number; children: React.ReactNode }> = ({ duration, children }) => {
  const frame = useCurrentFrame();
  const q = interpolate(frame, [duration - theme.timing.exit, duration - 1], [0, 1], { easing: theme.ease.in, ...clampOpts });
  return (
    <AbsoluteFill style={{ opacity: 1 - q, transform: `scale(${1 + q * 0.04})`, filter: q > 0.01 ? `blur(${q * 8}px)` : undefined }}>
      {children}
    </AbsoluteFill>
  );
};

/** সিন ট্রানজিশন: মাস্ক-উইপ প্যানেল (কাট প্যানেলের পেছনে লুকোয়) + whoosh। boundary = পরবর্তী সিনের শুরুর ফ্রেম */
export const Wipe: React.FC<{ boundary: number; index: number }> = ({ boundary, index }) => {
  const frame = useCurrentFrame();
  const { width } = useVideoConfig();
  const W = theme.timing.wipe;
  const q = interpolate(frame, [boundary - W / 2, boundary + W / 2], [0, 1], { easing: theme.ease.inOut, ...clampOpts });
  const panelW = Math.round(width * 1.35);
  const left = -panelW + q * (width + panelW);
  const visible = frame >= boundary - W / 2 - 1 && frame <= boundary + W / 2 + 1;
  return (
    <>
      <Sfx name="whoosh" at={boundary - W / 2 - 3} n={index} />
      {visible && (
        <div
          style={{
            position: "absolute", top: -60, bottom: -60, left, width: panelW, transform: "skewX(-12deg)",
            background: `linear-gradient(90deg, ${c.bgDeep}00 0%, ${c.bgDeep} 14%, ${c.bgAlt} 86%, ${c.bgDeep}00 100%)`,
            borderRight: `6px solid ${c.primary}`, boxShadow: `18px 0 90px ${c.glow}`,
          }}
        />
      )}
    </>
  );
};
