import React, { useMemo } from "react";
import { Segment } from "./Segment";
import { theme } from "../theme";
import { Vec3 } from "../lib/ease";

export const RAY_X0 = -6.5; // where the beam starts
export const LENS_X = -2.0; // converging glass
export const SENSOR_X = 4.8; // focus plane
const IRIS_X = 0;
const SPEED = 3.2; // world units / second
const PULSES = 3;

interface RayDef { y: number; z: number; ring: number }

const makeRays = (): RayDef[] => {
  const rings: [number, number][] = [[0, 1], [0.35, 6], [0.7, 12], [1.05, 18], [1.4, 24]];
  const out: RayDef[] = [];
  rings.forEach(([rad, n], ring) => {
    for (let j = 0; j < n; j++) {
      const a = (2 * Math.PI * j) / n + ring * 0.37;
      out.push({ y: rad * Math.sin(a), z: rad * Math.cos(a), ring });
    }
  });
  return out;
};

const len3 = (a: Vec3, b: Vec3) => Math.hypot(a[0] - b[0], a[1] - b[1], a[2] - b[2]);
const mix = (a: Vec3, b: Vec3, p: number): Vec3 => [a[0] + (b[0] - a[0]) * p, a[1] + (b[1] - a[1]) * p, a[2] + (b[2] - a[2]) * p];

/**
 * Light rays from a distant point source, converging through the lens toward the sensor.
 * Rays that reach the iris plane outside the opening are stopped by the blades.
 * (Simplified single-element lens model: in-focus point source -> rays meet on the sensor.)
 * Fully deterministic: everything is a function of `t` (seconds), the iris radius `r`.
 */
export const Rays: React.FC<{ t: number; r: number; raysOn: number; revealDur: number }> = ({ t, r, raysOn, revealDur }) => {
  const rays = useMemo(makeRays, []);
  const k = (SENSOR_X - IRIS_X) / (SENSOR_X - LENS_X); // fraction of height left at the iris plane
  const rEff = r * Math.cos(Math.PI / 7); // polygon hole: inscribed radius is the safe passage
  const fullLen = len3([RAY_X0, 0, 0], [LENS_X, 0, 0]) + len3([LENS_X, 0, 0], [SENSOR_X, 0, 0]);

  return (
    <group>
      {rays.map((ray, i) => {
        const p0: Vec3 = [RAY_X0, ray.y, ray.z];
        const p1: Vec3 = [LENS_X, ray.y, ray.z];
        const atIris: Vec3 = [IRIS_X, ray.y * k, ray.z * k];
        const blocked = Math.hypot(atIris[1], atIris[2]) > rEff;
        const p2: Vec3 = blocked ? atIris : [SENSOR_X, 0, 0];
        const l1 = len3(p0, p1), l2 = len3(p1, p2), total = l1 + l2;

        // staggered reveal: outer rings start a little later; eased growth along the path
        const start = raysOn + ray.ring * 0.12;
        const pr = Math.min(1, Math.max(0, (t - start) / revealDur));
        const grow = 1 - Math.pow(1 - pr, 3);
        const reveal = grow * total;
        if (reveal <= 0.001) return null;

        const pointAt = (d: number): Vec3 => (d <= l1 ? mix(p0, p1, d / l1) : mix(p1, p2, (d - l1) / l2));
        const end = pointAt(Math.min(reveal, total));
        const seg1End = reveal <= l1 ? end : p1;

        const pulses = [];
        for (let q = 0; q < PULSES; q++) {
          const d = (t * SPEED + q * (fullLen / PULSES) + ray.ring * 0.7 + i * 0.13) % fullLen;
          if (d > reveal || d > total) continue;
          pulses.push(
            <mesh key={q} position={pointAt(d)}>
              <sphereGeometry args={[0.035, 8, 8]} />
              <meshBasicMaterial color={theme.colors.ray} toneMapped={false} />
            </mesh>,
          );
        }
        return (
          <group key={i}>
            <Segment a={p0} b={seg1End} color={theme.colors.ray} opacity={0.35} radius={0.008} />
            {reveal > l1 ? <Segment a={p1} b={end} color={theme.colors.ray} opacity={0.35} radius={0.008} /> : null}
            {pulses}
            {blocked && reveal >= total ? (
              <mesh position={p2}>
                <sphereGeometry args={[0.03, 8, 8]} />
                <meshBasicMaterial color="#7a86a8" toneMapped={false} />
              </mesh>
            ) : null}
          </group>
        );
      })}
    </group>
  );
};
