// Scene 5 (cues 9-11) — The Image Processor fixes the picture one problem at a time, then the shutter button.
import React from "react";
import { AbsoluteFill } from "remotion";
import { theme } from "../theme";
import { T } from "../timing";
import { clamp, lerp, prog, progIO } from "../util";
import { IMG_H, IMG_W, stageCanvas, stageData } from "../sceneImage";
import { Defs } from "../components/Defs";
import { CameraGlyph, ChipGlyph } from "../components/Glyphs";
import { CanvasView, CropView } from "../components/CanvasView";
import { useClock, popAt } from "../components/clock";

const IMG = { x: 110, y: 262, w: 1040, h: 585 };
const S = IMG.w / IMG_W;
const PANEL = { x: 1230, y: 262, w: 580, h: 585 };
const lumAt = (k: number, x: number, y: number) => {
  const d = stageData(k);
  let s = 0, n = 0;
  for (let j = -3; j <= 3; j++) for (let i = -3; i <= 3; i++) {
    const idx = (clamp(y + j, 0, IMG_H - 1) * IMG_W + clamp(x + i, 0, IMG_W - 1)) * 3;
    s += 0.2126 * d[idx] + 0.7152 * d[idx + 1] + 0.0722 * d[idx + 2]; n++;
  }
  return s / n;
};

type Row = { label: string; t: number; stage: number | null; from: number; to: number };

export const Scene5: React.FC = () => {
  const { f, fps, at } = useClock();
  const c = theme.colors;

  const rows: Row[] = [
    { label: "উজ্জ্বলতা", t: at(T("উজ্জ্বলতা"), 8), stage: 1, from: 0.25, to: 0.62 },
    { label: "রঙের ভারসাম্য", t: at(T("রঙের ভারসাম্য"), 8), stage: 2, from: 0.2, to: 0.5 },
    { label: "Contrast", t: at(T("Contrast"), 8), stage: 3, from: 0.3, to: 0.68 },
    { label: "অন্যান্য বিষয়", t: at(T("অন্যান্য"), 8), stage: null, from: 0.5, to: 0.5 },
    { label: "Noise কমানো", t: at(T("Noise"), 8), stage: 4, from: 0.85, to: 0.2 },
    { label: "সূক্ষ্ম Details", t: at(T("সূক্ষ্ম"), 8), stage: 5, from: 0.2, to: 0.72 },
    { label: "উজ্জ্বল ও অন্ধকার", t: at(T("উজ্জ্বল ও অন্ধকার"), 8), stage: 6, from: 0.25, to: 0.55 },
  ];
  const WIPE = 38;
  const tProc = at(T("Processor ছবির"), 6);
  const tAfter = at(T("অর্থাৎ"), 4);
  const tGone = at(T("আপনি"), 2);
  const tCam = at(T("ক্যামেরার Button"), 8);
  const tPress = at(T("চাপ"), 4);

  // which stage is currently being wiped in
  let cur = 0, p = 1, curRow = -1;
  rows.forEach((r, i) => {
    if (r.stage !== null && f >= r.t + 4) {
      cur = r.stage; curRow = i;
      p = prog(f, r.t + 4, r.t + 4 + WIPE, theme.ease.inOut);
    }
  });
  const base = stageCanvas(Math.max(0, cur - 1 + (p >= 1 ? 1 : 0)));
  const top = p < 1 && cur > 0 ? stageCanvas(cur) : null;
  const wipeX = p * IMG.w;

  const gone = prog(f, tGone, tGone + 14, theme.ease.in);
  const enter = popAt(f, fps, tProc - 4, theme.spring.smooth);
  const pulse = 0.5 + 0.5 * Math.sin(f / 7);

  // loupe for noise (stage 4) and details (stage 5)
  const loupeStage = curRow === 4 ? 4 : curRow === 5 ? 5 : 0;
  const loupeOn = (f >= rows[4].t - 2 && f < rows[6].t - 2) ? 1 : 0;
  const crop = loupeStage === 5 || (curRow >= 5) ? { sx: 95, sy: 112 } : { sx: 306, sy: 86 };
  const lpStage = f >= rows[5].t + 4 ? 5 : 4;
  const lpBase = stageCanvas(lpStage - 1), lpTop = stageCanvas(lpStage);
  const lpP = lpStage === 5 ? prog(f, rows[5].t + 4, rows[5].t + 4 + WIPE, theme.ease.inOut) : prog(f, rows[4].t + 4, rows[4].t + 4 + WIPE, theme.ease.inOut);
  const lp = { x: IMG.w - 350, y: IMG.h - 215, w: 320, h: 188 };
  const loupeP = popAt(f, fps, rows[4].t - 2, theme.spring.snappy) * (1 - prog(f, rows[6].t - 4, rows[6].t + 6));
  const cropScreen = { x: crop.sx * S, y: crop.sy * S, w: 60 * S, h: 34 * S };

  // tone markers
  const toneP = prog(f, rows[6].t + 4, rows[6].t + 4 + WIPE, theme.ease.inOut);
  const toneIn = popAt(f, fps, rows[6].t, theme.spring.snappy);
  const sunL = lerp(lumAt(5, 336, 103), lumAt(6, 336, 103), toneP);
  const darkL = lerp(lumAt(5, 360, 250), lumAt(6, 360, 250), toneP);

  // camera + button
  const camIn = popAt(f, fps, tCam, theme.spring.bouncy);
  const press = prog(f, tPress, tPress + 5, theme.ease.out) * (1 - prog(f, tPress + 8, tPress + 18, theme.ease.out));
  const ring = prog(f, tPress, tPress + 22);
  const flash = (1 - prog(f, tPress, tPress + 10)) * (f >= tPress ? 1 : 0);

  return (
    <AbsoluteFill>
      {/* ---------- picture ---------- */}
      <div style={{ position: "absolute", left: IMG.x, top: IMG.y, width: IMG.w, height: IMG.h, opacity: enter * (1 - gone), transform: `translateY(${(1 - enter) * 30}px) scale(${1 - 0.06 * gone})`, borderRadius: 28, overflow: "hidden", boxShadow: `0 40px 90px -30px rgba(0,0,0,0.7), 0 0 0 3px ${c.line}` }}>
        <CanvasView source={base} width={IMG.w} height={IMG.h} />
        {top && (
          <div style={{ position: "absolute", inset: 0, clipPath: `inset(0 ${(1 - p) * 100}% 0 0)` }}>
            <CanvasView source={top} width={IMG.w} height={IMG.h} />
          </div>
        )}
        {p > 0.01 && p < 0.99 && <div style={{ position: "absolute", left: wipeX - 2, top: 0, width: 4, height: IMG.h, background: "#fff", boxShadow: `0 0 24px 4px ${c.primary}` }} />}
      </div>

      <svg width="1920" height="1080" style={{ position: "absolute", inset: 0 }}>
        <Defs />
        <g opacity={enter * (1 - gone)}>
          {/* crop marker + loupe */}
          <g opacity={loupeOn * loupeP} transform={`translate(${IMG.x} ${IMG.y})`}>
            <rect x={cropScreen.x} y={cropScreen.y} width={cropScreen.w} height={cropScreen.h} rx={6} fill="none" stroke="#fff" strokeWidth={3} strokeDasharray="8 6" />
            <line x1={cropScreen.x + cropScreen.w} y1={cropScreen.y + cropScreen.h} x2={lp.x} y2={lp.y} stroke="#fff" strokeOpacity={0.6} strokeWidth={2} />
          </g>
          {/* tone markers */}
          <g opacity={toneIn * (1 - 0) * (f >= rows[6].t ? 1 : 0)} transform={`translate(${IMG.x} ${IMG.y})`}>
            {[{ x: 336 * S, y: 103 * S, l: sunL, name: "উজ্জ্বল", col: c.accent }, { x: 360 * S, y: 250 * S, l: darkL, name: "অন্ধকার", col: c.primary }].map((m, i) => (
              <g key={i} transform={`translate(${m.x} ${m.y})`}>
                <circle r={22 + 4 * pulse} fill="none" stroke={m.col} strokeWidth={4} filter="url(#fGlow)" />
                <g transform={`translate(${i === 0 ? -250 : -270} ${i === 0 ? -80 : -76})`}>
                  <rect width={230} height={56} rx={16} fill={c.bg} stroke={m.col} strokeWidth={2.5} opacity={0.94} />
                  <text x={16} y={26} fontFamily={theme.fonts.main} fontWeight={700} fontSize={22} fill={c.text}>{m.name}</text>
                  <rect x={16} y={34} width={198} height={10} rx={5} fill={c.panel2} />
                  <rect x={16} y={34} width={198 * clamp(m.l)} height={10} rx={5} fill={m.col} />
                </g>
              </g>
            ))}
          </g>

          {/* ---------- processor panel ---------- */}
          <g transform={`translate(${PANEL.x} ${PANEL.y + (1 - enter) * 30})`}>
            <rect width={PANEL.w} height={PANEL.h} rx={30} fill="url(#gPanel)" stroke={c.line} strokeWidth={3} filter="url(#fShadow)" />
            <rect width={PANEL.w} height={PANEL.h} rx={30} fill="url(#gSheen)" />
            <g transform="translate(86 62)"><g transform="scale(0.52)"><ChipGlyph size={120} glow={0.7 + 0.3 * pulse} act={f} pins={4} /></g></g>
            <text x={150} y={78} fontFamily={theme.fonts.main} fontWeight={700} fontSize={40} fill={c.text}>Image Processor</text>
            <line x1={30} x2={PANEL.w - 30} y1={112} y2={112} stroke={c.line} strokeWidth={2} />
            {rows.map((r, i) => {
              const y = 124 + i * 64;
              const vis = prog(f, r.t - 4, r.t + 8);
              const active = f >= r.t && f < r.t + 60;
              const knob = lerp(r.from, r.to, prog(f, r.t + 2, r.t + 2 + WIPE, theme.ease.inOut));
              const done = prog(f, tAfter + i * 4, tAfter + i * 4 + 10);
              return (
                <g key={i} opacity={vis} transform={`translate(0 ${y + (1 - vis) * 14})`}>
                  <rect x={18} y={0} width={PANEL.w - 36} height={54} rx={16} fill={active ? c.panel2 : "none"} stroke={active ? c.primary : "none"} strokeWidth={2.5} />
                  <circle cx={52} cy={27} r={14} fill={c.bg} stroke={done > 0.5 ? c.ok : active ? c.primary : c.line} strokeWidth={3} />
                  {done > 0.2 && <path d="M45 27 l5 5 l10 -11" fill="none" stroke={c.ok} strokeWidth={4} strokeLinecap="round" strokeLinejoin="round" opacity={done} />}
                  <text x={82} y={37} fontFamily={theme.fonts.main} fontWeight={600} fontSize={27} fill={c.text}>{r.label}</text>
                  {r.stage !== null ? (
                    <g>
                      <rect x={PANEL.w - 190} y={23} width={150} height={8} rx={4} fill={c.bg} />
                      <rect x={PANEL.w - 190} y={23} width={150 * knob} height={8} rx={4} fill={active ? c.primary : c.line} />
                      <circle cx={PANEL.w - 190 + 150 * knob} cy={27} r={12} fill="#fff" stroke={c.primary} strokeWidth={3} />
                    </g>
                  ) : (
                    <g fill={c.textDim}>{[0, 1, 2].map((k) => <circle key={k} cx={PANEL.w - 120 + k * 24} cy={27} r={5} opacity={0.4 + 0.6 * (0.5 + 0.5 * Math.sin(f / 5 + k))} />)}</g>
                  )}
                </g>
              );
            })}
          </g>
        </g>
      </svg>

      {/* loupe content (HTML canvases) */}
      <div style={{ position: "absolute", left: IMG.x + lp.x, top: IMG.y + lp.y, width: lp.w, height: lp.h, opacity: loupeOn * loupeP * (1 - gone), borderRadius: 20, overflow: "hidden", boxShadow: `0 0 0 4px #fff, 0 0 40px ${c.primary}88`, transform: `scale(${0.85 + 0.15 * loupeP})` }}>
        <CropView source={lpBase} sx={crop.sx} sy={crop.sy} sw={60} sh={34} width={lp.w} height={lp.h} />
        <div style={{ position: "absolute", inset: 0, clipPath: `inset(0 ${(1 - lpP) * 100}% 0 0)` }}>
          <CropView source={lpTop} sx={crop.sx} sy={crop.sy} sw={60} sh={34} width={lp.w} height={lp.h} />
        </div>
        <div style={{ position: "absolute", left: lpP * lp.w - 2, top: 0, width: 4, height: lp.h, background: "#fff", opacity: lpP > 0.01 && lpP < 0.99 ? 1 : 0 }} />
      </div>

      {/* ---------- shutter button beat ---------- */}
      <svg width="1920" height="1080" style={{ position: "absolute", inset: 0, opacity: camIn * 0 + (f >= tCam ? 1 : 0) }}>
        <Defs />
        <g transform={`translate(960 ${590 + (1 - camIn) * 40}) scale(${0.8 + 0.2 * camIn})`} opacity={Math.min(1, camIn * 1.4)}>
          <CameraGlyph s={2.5} press={press} glow={0.4 + press} />
          {ring > 0 && ring < 1 && [0, 1].map((k) => <circle key={k} cx={114 * 2.5} cy={-78 * 2.5} r={30 + 120 * clamp(ring - k * 0.2)} fill="none" stroke={c.accent} strokeWidth={5} opacity={(1 - clamp(ring - k * 0.2)) * 0.8} />)}
          <g transform={`translate(${114 * 2.5 + 40} ${-78 * 2.5 - 70})`} opacity={prog(f, tPress - 10, tPress)}>
            <rect width={150} height={52} rx={26} fill={c.bg} stroke={c.accent} strokeWidth={3} />
            <text x={75} y={36} textAnchor="middle" fontFamily={theme.fonts.main} fontWeight={700} fontSize={30} fill={c.text}>Button</text>
          </g>
        </g>
      </svg>
      <AbsoluteFill style={{ background: "#fff", opacity: flash * 0.16, pointerEvents: "none" }} />
    </AbsoluteFill>
  );
};
