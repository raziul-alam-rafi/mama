// timeline.ts — সব সময় SRT থেকে আসে। হাতে বসানো কোনো frame নম্বর নেই।
import { SRT } from "./script.srt";
import { parseSrt } from "./srt";
import { FPS, theme } from "./theme";

export const cues = parseSrt(SRT);
const lead = theme.timing.lead;

export const cueStartFrame = (n: number) => Math.round(cues[n - 1].start * FPS);
export const cueEndFrame = (n: number) => Math.round(cues[n - 1].end * FPS);

/** cue n-এর ভেতরে `kw` শব্দটি যে অক্ষর-অনুপাতে আছে তা থেকে আনুমানিক সময় (frame) বের করে। kw না পেলে error */
export function cueFrame(n: number, kw?: string, leadFrames: number = lead): number {
  const c = cues[n - 1];
  let frac = 0;
  if (kw) {
    const i = c.text.indexOf(kw);
    if (i < 0) throw new Error(`cue ${n}-এ "${kw}" পাওয়া যায়নি: ${c.text}`);
    frac = i / c.text.length;
  }
  return Math.round((c.start + frac * (c.end - c.start)) * FPS) - leadFrames;
}

// ---- সিনের সীমা: cue-র সীমায়; একটি সিনে একাধিক cue ----
export type SceneDef = { id: string; from: number; to: number };
export const SCENE_DEFS: SceneDef[] = [
  { id: "hook", from: 1, to: 2 }, // হুক — Kinetic
  { id: "apple", from: 3, to: 4 }, // আপেল → চোখ → ক্যামেরা
  { id: "scatter", from: 5, to: 6 }, // সমস্যা: ছড়ানো আলো
  { id: "control", from: 7, to: 8 }, // আলো নিয়ন্ত্রণ
  { id: "lens", from: 9, to: 10 }, // Lens ও optical element
  { id: "optics", from: 11, to: 11 }, // আলো বাঁকে → ফোকাস
];

export const TOTAL_FRAMES = cueEndFrame(cues.length) + theme.timing.tail;

export type Scene = SceneDef & { start: number; end: number; duration: number };

const starts = SCENE_DEFS.map((s, i) => (i === 0 ? 0 : cueStartFrame(s.from) - lead));
export const scenes: Scene[] = SCENE_DEFS.map((s, i) => {
  const start = starts[i];
  const end = i === SCENE_DEFS.length - 1 ? TOTAL_FRAMES : starts[i + 1];
  return { ...s, start, end, duration: end - start };
});

/** সিন `si`-র লোকাল ফ্রেমে: cue n (ও ঐচ্ছিক কীওয়ার্ড) কখন */
export const at = (si: number, n: number, kw?: string, leadFrames: number = lead) =>
  cueFrame(n, kw, leadFrames) - scenes[si].start;
