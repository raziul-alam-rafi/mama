import React from "react";
import {useCurrentFrame} from "remotion";
import {theme} from "../theme";

export type Pt = {x: number; y: number};
export type Elem = {x: number; power: number; kind: "convex" | "concave"; h: number; w: number};

/** Shared SVG defs: glow filters, glass gradient, cutaway hatch. Mount once per <svg>. */
export const SvgDefs: React.FC = () => (
  <defs>
    <filter id="glow" x="-50%" y="-50%" width="200%" height="200%">
      <feGaussianBlur stdDeviation="5" result="b" />
      <feMerge><feMergeNode in="b" /><feMergeNode in="SourceGraphic" /></feMerge>
    </filter>
    <filter id="glowSm" x="-50%" y="-50%" width="200%" height="200%">
      <feGaussianBlur stdDeviation="2.5" result="b" />
      <feMerge><feMergeNode in="b" /><feMergeNode in="SourceGraphic" /></feMerge>
    </filter>
    <linearGradient id="glass" x1="0" y1="0" x2="1" y2="1">
      <stop offset="0" stopColor="#BFE9FF" stopOpacity="0.30" />
      <stop offset="0.5" stopColor={theme.colors.hero} stopOpacity="0.10" />
      <stop offset="1" stopColor="#BFE9FF" stopOpacity="0.22" />
    </linearGradient>
    <linearGradient id="metal" x1="0" y1="0" x2="0" y2="1">
      <stop offset="0" stopColor={theme.colors.panelEdge} />
      <stop offset="1" stopColor={theme.colors.panel} />
    </linearGradient>
    <pattern id="hatch" width="12" height="12" patternUnits="userSpaceOnUse" patternTransform="rotate(45)">
      <line x1="0" y1="0" x2="0" y2="12" stroke={theme.colors.textDim} strokeWidth="2.5" opacity="0.55" />
    </pattern>
  </defs>
);

/**
 * Paraxial multi-element ray trace (thin lenses, ray transfer matrices).
 * y is measured from the optical axis (screen-down positive). theta = dy/dx.
 */
export const traceRay = (
  y0: number, theta0: number, x0: number, elems: Elem[], xEnd: number, axisY: number,
): Pt[] => {
  const pts: Pt[] = [{x: x0, y: axisY + y0}];
  let x = x0, y = y0, th = theta0;
  for (const e of elems) {
    y += th * (e.x - x);
    x = e.x;
    pts.push({x, y: axisY + y});
    th -= y * e.power; // positive power bends toward the axis
  }
  y += th * (xEnd - x);
  pts.push({x: xEnd, y: axisY + y});
  return pts;
};

/** x where parallel paraxial rays meet the axis after the last element. */
export const focusX = (elems: Elem[]): number => {
  let y = 40, th = 0, x = -1000;
  for (const e of elems) {
    y += th * (e.x - x);
    x = e.x;
    th -= y * e.power;
  }
  return x - y / th;
};

const dist = (a: Pt, b: Pt) => Math.hypot(b.x - a.x, b.y - a.y);
export const pathLen = (pts: Pt[]) => pts.slice(1).reduce((s, p, i) => s + dist(pts[i], p), 0);

/** Polyline cut at fraction p of its length. */
export const partial = (pts: Pt[], p: number): {pts: Pt[]; head: Pt} => {
  const total = pathLen(pts);
  let left = Math.max(0, Math.min(1, p)) * total;
  const out: Pt[] = [pts[0]];
  for (let i = 1; i < pts.length; i++) {
    const d = dist(pts[i - 1], pts[i]);
    if (left >= d) { out.push(pts[i]); left -= d; }
    else {
      const t = d === 0 ? 0 : left / d;
      out.push({x: pts[i - 1].x + (pts[i].x - pts[i - 1].x) * t, y: pts[i - 1].y + (pts[i].y - pts[i - 1].y) * t});
      break;
    }
  }
  return {pts: out, head: out[out.length - 1]};
};

const pointAt = (pts: Pt[], d: number): Pt => {
  let left = d;
  for (let i = 1; i < pts.length; i++) {
    const s = dist(pts[i - 1], pts[i]);
    if (left <= s) {
      const t = s === 0 ? 0 : left / s;
      return {x: pts[i - 1].x + (pts[i].x - pts[i - 1].x) * t, y: pts[i - 1].y + (pts[i].y - pts[i - 1].y) * t};
    }
    left -= s;
  }
  return pts[pts.length - 1];
};

/** An animated light ray: draws itself (p 0→1), then light "packets" keep flowing along it. */
export const Ray: React.FC<{
  pts: Pt[]; p: number; color?: string; width?: number; opacity?: number; flow?: boolean; glow?: boolean;
}> = ({pts, p, color = theme.colors.hero, width = 3, opacity = 0.9, flow = true, glow = true}) => {
  const frame = useCurrentFrame();
  if (p <= 0) return null;
  const cut = partial(pts, p);
  const poly = cut.pts.map((q) => `${q.x.toFixed(1)},${q.y.toFixed(1)}`).join(" ");
  const total = pathLen(pts);
  const dots: Pt[] = [];
  if (flow && p >= 1) {
    const gap = 260;
    for (let k = 0; k * gap < total + gap; k++) {
      const d = (frame * 9 + k * gap) % (total + gap);
      if (d <= total) dots.push(pointAt(pts, d));
    }
  }
  return (
    <g filter={glow ? "url(#glowSm)" : undefined}>
      <polyline points={poly} fill="none" stroke={color} strokeWidth={width} strokeLinecap="round"
        strokeLinejoin="round" opacity={opacity} />
      {dots.map((d, i) => <circle key={i} cx={d.x} cy={d.y} r={width * 1.7} fill="#FFFFFF" opacity={0.95} />)}
      {p < 1 && <circle cx={cut.head.x} cy={cut.head.y} r={width * 1.9} fill="#FFFFFF" />}
    </g>
  );
};

/** One glass element: biconvex (thick centre) or biconcave (thick edges). */
export const LensShape: React.FC<{x: number; cy: number; h: number; w: number; kind: "convex" | "concave"; opacity?: number}> = ({
  x, cy, h, w, kind, opacity = 1,
}) => {
  const d =
    kind === "convex"
      ? `M ${x} ${cy - h} Q ${x + 2 * w} ${cy} ${x} ${cy + h} Q ${x - 2 * w} ${cy} ${x} ${cy - h} Z`
      : `M ${x - w} ${cy - h} L ${x + w} ${cy - h} Q ${x + w - 1.8 * w} ${cy} ${x + w} ${cy + h} L ${x - w} ${cy + h} Q ${x - w + 1.8 * w} ${cy} ${x - w} ${cy - h} Z`;
  return (
    <path d={d} fill="url(#glass)" stroke={theme.colors.glassEdge} strokeWidth={theme.stroke.base}
      strokeLinejoin="round" opacity={opacity} />
  );
};
