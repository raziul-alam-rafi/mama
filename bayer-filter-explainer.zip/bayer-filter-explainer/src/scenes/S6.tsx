import React from "react";
import {AbsoluteFill, interpolate} from "remotion";
import {Chip, Pop, Sfx, Words, clamp01, useAnim} from "../anim";
import {bayerAt, chColor, theme} from "../theme";
import {cue} from "../script";

// ---- Part A geometry (eye + spectrum + sensitivity curve)
const SX0 = 260;
const SX1 = 1660;
const SY = 790;
const PEAK_X = SX0 + 0.4 * (SX1 - SX0);
const curvePts = Array.from({length: Math.round((SX1 - SX0) / 14) + 1}).map((_, i) => {
  const x = SX0 + i * 14;
  return [x, SY - 12 - 250 * Math.exp(-Math.pow((x - PEAK_X) / 200, 2))] as const;
});
const curveLine = curvePts.map(([x, y], i) => `${i ? "L" : "M"}${x} ${y}`).join(" ");
const curveArea = `${curveLine} L${SX1} ${SY - 12} L${SX0} ${SY - 12} Z`;

// ---- Part B geometry (scene card + mosaic)
const CW = 1200;
const CHH = 720;
const CX = 360;
const CY = 220;
const MC = 15;
const MR = 9;
const MS = 80;
const RIDGE: [number, number][] = [[0, 520], [210, 360], [380, 470], [560, 250], [760, 430], [900, 330], [1200, 510]];
const ridgeD = RIDGE.map(([x, y], i) => `${i ? "L" : "M"}${x} ${y}`).join(" ");
const mountainD = `${ridgeD} L${CW} ${CHH} L0 ${CHH} Z`;

const lerp = (a: number, b: number, t: number) => Math.round(a + (b - a) * t);

// Scene 6 - why green: the eye's sensitivity (part A), then green samples give extra detail (part B).
export const S6: React.FC = () => {
  const a = useAnim();
  const split = a.lead + (cue(6).end - cue(6).start) + 0.9; // part B starts after "সংবেদনশীল।"
  const aOut = 1 - a.ease(split - 0.3, split, 0, 1, theme.ease.in);
  const bIn = a.sp(split);

  // eye
  const open = a.sp(0.25, theme.spring.smooth);
  const look = a.wave(4.0, 10);
  // spectrum / curve
  const specP = a.prog(0.9, 1.7, theme.ease.out);
  const curveP = a.prog(1.7, 3.2, theme.ease.inOut);
  const peakGlow = a.prog(3.0, 3.6) * (0.8 + 0.2 * Math.sin(a.t * 3));
  // ramp
  const scan = a.prog(2.2, 5.0, theme.ease.inOut);

  // part B
  const ridgeP = a.prog(split + 1.4, split + 2.9, theme.ease.inOut);

  return (
    <AbsoluteFill>
      <Sfx name="whoosh_swipe" at={0.05} vol={0.22} />
      <Sfx name="pop" at={0.4} vol={0.24} />
      <Sfx name="click" at={3.1} vol={0.22} rate={1.04} />
      <Sfx name="whoosh_swipe" at={split} vol={0.2} rate={1.05} />
      <Sfx name="pop" at={split + 0.5} vol={0.24} rate={0.98} />
      <Sfx name="click" at={split + 1.5} vol={0.22} />

      {/* ---------------- Part A ---------------- */}
      <AbsoluteFill style={{opacity: aOut, transform: `translateY(${(1 - aOut) * -24}px)`}}>
        <div style={{position: "absolute", left: 140, top: 64, width: 1640}}>
          <Words text="সবুজ আলোয় চোখ বেশি সংবেদনশীল" at={0.1} highlight={["সবুজ"]} hlColor={theme.colors.green} />
        </div>

        <svg width={1920} height={1080} style={{position: "absolute", inset: 0}}>
          <defs>
            <linearGradient id="s6spec" x1="0" y1="0" x2="1" y2="0">
              <stop offset="0" stopColor={theme.colors.blue} />
              <stop offset="0.2" stopColor={theme.colors.hero} />
              <stop offset="0.4" stopColor={theme.colors.green} />
              <stop offset="0.65" stopColor={theme.colors.amber} />
              <stop offset="1" stopColor={theme.colors.red} />
            </linearGradient>
            <linearGradient id="s6area" x1="0" y1="0" x2="0" y2="1">
              <stop offset="0" stopColor={theme.colors.text} stopOpacity={0.5} />
              <stop offset="1" stopColor={theme.colors.text} stopOpacity={0} />
            </linearGradient>
            <radialGradient id="s6iris" cx="0.4" cy="0.35" r="0.8">
              <stop offset="0" stopColor={theme.colors.text} />
              <stop offset="0.35" stopColor={theme.colors.hero} />
              <stop offset="1" stopColor={theme.colors.blue} />
            </radialGradient>
            <clipPath id="s6eyeclip">
              <path d="M-170 0 Q0 -125 170 0 Q0 125 -170 0 Z" />
            </clipPath>
          </defs>

          {/* eye */}
          <g transform="translate(430 440) scale(1.55)">
            <g style={{transformOrigin: "0px 0px", transform: `scaleY(${0.08 + 0.92 * open})`}} opacity={clamp01(open * 1.5)}>
              <path d="M-170 0 Q0 -125 170 0 Q0 125 -170 0 Z" fill={theme.colors.text} stroke={theme.colors.line} strokeWidth={4} />
              <g clipPath="url(#s6eyeclip)">
                <g transform={`translate(${look} 0)`}>
                  <circle r={66} fill="url(#s6iris)" />
                  <circle r={28} fill={theme.colors.bg} />
                  <circle cx={-18} cy={-20} r={10} fill={theme.colors.text} opacity={0.9} />
                </g>
              </g>
            </g>
          </g>

          {/* spectrum bar */}
          <g style={{transformOrigin: `${SX0}px ${SY}px`, transform: `scaleX(${specP})`}}>
            <rect x={SX0} y={SY} width={SX1 - SX0} height={56} rx={28} fill="url(#s6spec)" />
          </g>
          {/* sensitivity curve */}
          <g opacity={curveP}>
            <path d={curveArea} fill="url(#s6area)" opacity={0.7 * curveP} />
          </g>
          <path d={curveLine} fill="none" stroke={theme.colors.amber} strokeWidth={8} strokeLinecap="round" strokeLinejoin="round" pathLength={1} strokeDasharray="1" strokeDashoffset={1 - curveP} style={{filter: `drop-shadow(0 0 10px ${theme.colors.amber})`}} />
          <circle cx={PEAK_X} cy={SY - 262} r={14} fill={theme.colors.amber} opacity={peakGlow} style={{filter: `drop-shadow(0 0 16px ${theme.colors.amber})`}} />
          <line x1={PEAK_X} y1={SY - 262} x2={PEAK_X} y2={SY} stroke={theme.colors.green} strokeWidth={4} strokeDasharray="8 10" opacity={peakGlow} />
        </svg>

        {/* brightness ramp */}
        <div style={{position: "absolute", left: 1010, top: 215}}>
          <div style={{position: "relative", display: "flex", gap: 10, opacity: a.prog(1.6, 2.2)}}>
            {Array.from({length: 10}).map((_, i) => {
              const k = i / 9;
              const col = `rgb(${lerp(18, 63, k)}, ${lerp(70, 224, k)}, ${lerp(44, 138, k)})`;
              return <div key={i} style={{width: 58, height: 58, borderRadius: 12, background: col, border: "2px solid rgba(255,255,255,0.18)"}} />;
            })}
            <div
              style={{
                position: "absolute",
                top: -8,
                left: -8 + scan * (9 * 68),
                width: 74,
                height: 74,
                borderRadius: 16,
                border: `5px solid ${theme.colors.amber}`,
                boxShadow: `0 0 22px ${theme.colors.amberGlow}`,
              }}
            />
          </div>
        </div>
        <Pop at={2.2} y={16} style={{position: "absolute", left: 1010, top: 305}}>
          <Chip size={theme.size.small}>উজ্জ্বলতার সূক্ষ্ম পরিবর্তন</Chip>
        </Pop>
        <Pop at={3.4} y={16} style={{position: "absolute", left: PEAK_X + 40, top: 480}}>
          <Chip dot={theme.colors.green}>সবুজ অঞ্চলে বেশি</Chip>
        </Pop>
      </AbsoluteFill>

      {/* ---------------- Part B ---------------- */}
      <AbsoluteFill style={{opacity: clamp01(bIn * 1.6)}}>
        <div style={{position: "absolute", left: 140, top: 64, width: 1640}}>
          <Words text="বিস্তারিত তথ্য পুনর্গঠনের সুবিধা" at={split + 0.05} highlight={["বিস্তারিত"]} />
        </div>
        <div
          style={{
            position: "absolute",
            left: CX,
            top: CY,
            width: CW,
            height: CHH,
            borderRadius: theme.radius.card,
            overflow: "hidden",
            border: `2px solid ${theme.colors.cardLine}`,
            boxShadow: `0 40px 80px -20px ${theme.colors.shadow}`,
            transform: `translateY(${(1 - bIn) * 50}px) scale(${interpolate(bIn, [0, 1], [0.94, 1])})`,
            background: `linear-gradient(180deg, ${theme.colors.bg}, ${theme.colors.bgAlt})`,
          }}
        >
          <svg width={CW} height={CHH} style={{position: "absolute", inset: 0}}>
            <circle cx={980} cy={150} r={62} fill={theme.colors.amber} opacity={0.9} />
            <path d={mountainD} fill={theme.colors.surfaceHi} />
            <path d={ridgeD} fill="none" stroke={theme.colors.amber} strokeWidth={7} strokeLinejoin="round" strokeLinecap="round" pathLength={1} strokeDasharray="1" strokeDashoffset={1 - ridgeP} style={{filter: `drop-shadow(0 0 10px ${theme.colors.amber})`}} />
          </svg>
          {Array.from({length: MR * MC}).map((_, i) => {
            const r = Math.floor(i / MC);
            const c = i % MC;
            const ch = bayerAt(r, c);
            const p = a.sp(split + 0.4 + (r + c) * 0.035, theme.spring.snappy);
            const isG = ch === "G";
            const mark = a.prog(split + 1.1, split + 1.6);
            return (
              <div key={i} style={{position: "absolute", left: c * MS, top: r * MS, width: MS, height: MS, padding: 4, opacity: clamp01(p * 1.5)}}>
                <div style={{width: "100%", height: "100%", borderRadius: 10, background: chColor[ch], opacity: isG ? 0.2 + 0.08 * mark : 0.1, border: `2px solid ${chColor[ch]}66`, position: "relative"}}>
                  {isG && <div style={{position: "absolute", left: "50%", top: "50%", width: 16, height: 16, marginLeft: -8, marginTop: -8, borderRadius: "50%", background: theme.colors.text, boxShadow: `0 0 14px ${theme.colors.green}`, transform: `scale(${mark})`}} />}
                </div>
              </div>
            );
          })}
        </div>
        <Pop at={split + 3.2} y={16} style={{position: "absolute", left: CX + CW - 560, top: CY + CHH + 26}}>
          <Chip dot={theme.colors.green}>সবুজ নমুনা বেশি</Chip>
        </Pop>
      </AbsoluteFill>
    </AbsoluteFill>
  );
};
