import React from "react";
import { interpolate, spring, useCurrentFrame, useVideoConfig } from "remotion";
import { theme } from "../theme";
import { beat } from "../cues";
import { prog } from "../draw";
import { Label, Sfx, WordReveal } from "../components/Common";

const c = theme.colors;
const CX = 1400, CY = 560;

export const LensScene: React.FC<{ from: number }> = ({ from }) => {
  const frame = useCurrentFrame();
  const { fps } = useVideoConfig();
  const tTitle = beat(from, 9);
  const tLens = beat(from, 9, "lens");
  const tGlass = beat(from, 9, "কাঁচের মতো");

  const rings = [250, 226, 196, 158, 126];
  const ringP = rings.map((_, i) => spring({ frame: frame - (4 + i * 5), fps, config: theme.spring.smooth }));
  const bodyP = spring({ frame: frame - 0, fps, config: theme.spring.smooth });
  const spin = frame * 0.12;
  const breathe = 1 + Math.sin(frame / 26) * 0.01;

  const glint = prog(frame, tGlass, 26, theme.ease.inOut);
  const pulse = prog(frame, tGlass + 2, 30, theme.ease.out);

  return (
    <>
      <svg width={1920} height={1080} style={{ position: "absolute", inset: 0 }}>
        <defs>
          <radialGradient id="ls-glass" cx="35%" cy="30%" r="85%">
            <stop offset="0%" stopColor="#A9D0FF" /><stop offset="40%" stopColor="#3E73C4" /><stop offset="100%" stopColor="#0E1D44" />
          </radialGradient>
          <linearGradient id="ls-ring" x1="0" y1="0" x2="1" y2="1">
            <stop offset="0%" stopColor={c.surfaceHi} /><stop offset="100%" stopColor={c.bgAlt} />
          </linearGradient>
          <linearGradient id="ls-glint" x1="0" y1="0" x2="1" y2="0">
            <stop offset="0%" stopColor="#fff" stopOpacity="0" /><stop offset="50%" stopColor="#fff" stopOpacity="0.55" /><stop offset="100%" stopColor="#fff" stopOpacity="0" />
          </linearGradient>
          <clipPath id="ls-clip"><circle cx={CX} cy={CY} r={124} /></clipPath>
        </defs>
        {/* camera body (front view) */}
        <g opacity={bodyP} transform={`translate(0 ${(1 - bodyP) * 40})`}>
          <rect x={1100} y={198} width={190} height={70} rx={14} fill={c.surface} stroke={c.line} strokeWidth={3} />
          <rect x={1010} y={250} width={780} height={620} rx={56} fill="url(#ls-ring)" stroke={c.line} strokeWidth={3} />
          <circle cx={1700} cy={330} r={22} fill={c.line} />
          <rect x={1050} y={300} width={90} height={26} rx={13} fill={c.bg} opacity={0.6} />
        </g>
        <g transform={`translate(${CX} ${CY}) scale(${breathe}) translate(${-CX} ${-CY})`}>
          {rings.map((r, i) => (
            <g key={r} opacity={ringP[i]} transform={`translate(${CX} ${CY}) scale(${interpolate(ringP[i], [0, 1], [0.6, 1])}) translate(${-CX} ${-CY})`}>
              {i === 0 && <circle cx={CX} cy={CY} r={r} fill={c.ink} stroke={c.line} strokeWidth={4} />}
              {i === 1 && (
                <g transform={`rotate(${spin} ${CX} ${CY})`}>
                  <circle cx={CX} cy={CY} r={r} fill="url(#ls-ring)" stroke={c.line} strokeWidth={3} />
                  {Array.from({ length: 72 }).map((_, k) => {
                    const a = (k / 72) * Math.PI * 2;
                    return <line key={k} x1={CX + Math.cos(a) * (r - 4)} y1={CY + Math.sin(a) * (r - 4)} x2={CX + Math.cos(a) * (r - (k % 6 === 0 ? 22 : 12))} y2={CY + Math.sin(a) * (r - (k % 6 === 0 ? 22 : 12))} stroke={c.textDim} strokeWidth={k % 6 === 0 ? 3 : 1.5} opacity={0.7} />;
                  })}
                </g>
              )}
              {i === 2 && <circle cx={CX} cy={CY} r={r} fill={c.bgAlt} stroke={c.line} strokeWidth={3} />}
              {i === 3 && <circle cx={CX} cy={CY} r={r} fill={c.ink} stroke={c.primary} strokeWidth={3} opacity={0.95} />}
              {i === 4 && (
                <g>
                  <circle cx={CX} cy={CY} r={r - 2} fill="url(#ls-glass)" />
                  <path d={`M${CX - 90} ${CY - 20} A 92 92 0 0 1 ${CX + 20} ${CY - 90}`} fill="none" stroke={c.accent} strokeWidth={5} strokeLinecap="round" opacity={0.7} />
                  <path d={`M${CX + 70} ${CY + 40} A 80 80 0 0 1 ${CX - 10} ${CY + 82}`} fill="none" stroke={c.primary} strokeWidth={5} strokeLinecap="round" opacity={0.8} />
                  <circle cx={CX} cy={CY} r={58} fill="none" stroke="#fff" strokeOpacity={0.12} strokeWidth={2} />
                  <g clipPath="url(#ls-clip)">
                    <rect x={CX - 190 + glint * 380} y={CY - 150} width={70} height={300} fill="url(#ls-glint)" transform={`rotate(20 ${CX} ${CY})`} opacity={glint > 0 && glint < 1 ? 1 : 0} />
                  </g>
                </g>
              )}
            </g>
          ))}
        </g>
        <circle cx={CX} cy={CY} r={126 + pulse * 70} fill="none" stroke={c.primary} strokeWidth={4} opacity={(1 - pulse) * (pulse > 0 ? 0.9 : 0)} />
      </svg>
      <div style={{ position: "absolute", left: 110, top: 230 }}>
        <WordReveal text="সবচেয়ে *গুরুত্বপূর্ণ* অংশ" delay={tTitle} size={70} hi={c.accent} color={c.text} />
      </div>
      <div style={{ position: "absolute", left: 110, top: 355 }}>
        <WordReveal text="ক্যামেরার" delay={tTitle + 8} size={64} color={c.textDim} weight={500} />
      </div>
      <div style={{ position: "absolute", left: 100, top: 420, lineHeight: 1 }}>
        {frame >= tLens - 2 && <WordReveal text="*lens*" delay={tLens} size={300} hi={c.primary} />}
      </div>
      <Label text="কাঁচের মতো অংশ" x={CX} y={CY + 372} delay={tGlass + 6} />
      <Sfx name="pop" at={tTitle + 2} vol={0.28} />
      <Sfx name="chime" at={tLens} vol={0.26} />
      <Sfx name="tick" at={tGlass + 4} vol={0.26} />
    </>
  );
};
