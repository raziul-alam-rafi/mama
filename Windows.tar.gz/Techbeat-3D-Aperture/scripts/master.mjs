// Two-pass loudness normalisation to ~-14 LUFS, true peak -1 dBTP; video stream copied untouched.
// Usage: npm run master            or   node scripts/master.mjs in.mp4 out.mp4
import fs from "node:fs";
import { run } from "./lib.mjs";

const IN = process.argv[2] ?? "out/aperture_raw.mp4";
const OUT = process.argv[3] ?? "out/aperture_final.mp4";
if (!fs.existsSync(IN)) { console.error(`Input not found: ${IN}\nRun: npm run render:test`); process.exit(1); }

// system ffmpeg first (works on every OS if installed), then Remotion's bundled one
let FF = null;
for (const c of ["ffmpeg", "npx remotion ffmpeg"]) {
  if (run(`${c} -version`, { capture: true }).status === 0) { FF = c; break; }
}
if (!FF) {
  console.error("ffmpeg not found. Windows: install with `winget install Gyan.FFmpeg` (then reopen CMD),\nor skip this step: out/aperture_raw.mp4 is already a valid video.");
  process.exit(1);
}
console.log("Using:", FF);

const p1 = run(`${FF} -hide_banner -i "${IN}" -af loudnorm=I=-14:TP=-1:LRA=11:print_format=json -f null -`, { capture: true });
const m = p1.out.match(/\{[^{}]*"input_i"[^{}]*\}/);
if (p1.status !== 0 || !m) { console.error("Loudness analysis failed:\n" + p1.out.slice(-1500)); process.exit(1); }
const j = JSON.parse(m[0]);
const af = `loudnorm=I=-14:TP=-1:LRA=11:measured_I=${j.input_i}:measured_TP=${j.input_tp}:measured_LRA=${j.input_lra}:measured_thresh=${j.input_thresh}:offset=${j.target_offset}:linear=true`;
const p2 = run(`${FF} -y -hide_banner -i "${IN}" -c:v copy -af ${af} -ar 48000 -c:a aac -b:a 256k "${OUT}"`, { capture: true });
if (p2.status !== 0) { console.error("Mastering failed:\n" + p2.out.slice(-1500)); process.exit(1); }

const p3 = run(`${FF} -hide_banner -i "${OUT}" -af ebur128=peak=true -f null -`, { capture: true });
const sum = p3.out.slice(p3.out.lastIndexOf("Summary:"));
console.log(`input: ${j.input_i} LUFS, ${j.input_tp} dBTP`);
console.log((sum.match(/I:\s+[-\d.]+ LUFS/) || [""])[0], (sum.match(/Peak:\s+[-\d.]+ dBFS/) || [""])[0]);
console.log("Wrote", OUT);
