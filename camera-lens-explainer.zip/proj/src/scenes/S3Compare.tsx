import React from "react";
import {AbsoluteFill, spring, useCurrentFrame, useVideoConfig} from "remotion";
import {theme} from "../theme";
import {at} from "../timeline";
import {Elem, LensShape, Ray, SvgDefs, traceRay} from "../components/Optics";
import {MagnifierIcon} from "../components/Art";
import {ELEMS_BASE, FOCUS, LensRig} from "../components/Rig";
import {Headlines, Tag} from "../components/Text";
import {Sfx} from "../components/Sfx";
import {prog} from "../components/util";

const SI = 2;
const AX = 600;
const L_PANEL = {x: 80, y: 370, w: 830, h: 460};
const R_PANEL = {x: 1010, y: 370, w: 830, h: 460};
const SINGLE: Elem[] = [{x: 400, power: 1 / 300, kind: "convex", h: 135, w: 28}];
const L_H = [-100, -50, 0, 50, 100];
const R_H = [-60, -30, 0, 30, 60];
const K = 0.7;
const R_START = 420; // base-x where the right rig's rays start
const R_TX = R_PANEL.x + 40 - R_START * K;

/** Scene 3 — same principle, side by side: a single glass vs. a controlled multi-element lens. */
export const S3Compare: React.FC = () => {
  const frame = useCurrentFrame();
  const {fps} = useVideoConfig();

  const tRight = at(SI, 4, "লেন্সও");
  const tEq = at(SI, 4, "একই");
  const tCtl = at(SI, 4, "অনেক");
  const tRays = at(SI, 4, "তবে");

  const lIn = prog(frame, 0, 16);
  const lRays = L_H.map((_, i) => prog(frame, 6 + i * 3, 30, theme.ease.inOut));
  const rIn = spring({frame: frame - tRight, fps, config: theme.spring.smooth});
  const eq = spring({frame: frame - tEq, fps, config: theme.spring.bouncy});
  const rReveal = prog(frame, tRight, 22, theme.ease.inOut);
  const rAssemble = ELEMS_BASE.map((_, i) => spring({frame: frame - tRight - 6 - i * 3, fps, config: theme.spring.smooth}));
  const rRays = R_H.map((_, i) => prog(frame, tRays + i * 3, 38, theme.ease.inOut));
  const tLock = tRays + 4 * 3 + 34;
  const glow = prog(frame, tLock, 14);
  const under = prog(frame, tCtl + 6, 24, theme.ease.inOut);

  const lx = (x: number) => L_PANEL.x + x; // single-lens panel is drawn in panel-local x
  const singleElems = SINGLE.map((e) => ({...e, x: lx(e.x)}));

  return (
    <AbsoluteFill>
      <svg width={1920} height={1080} viewBox="0 0 1920 1080" style={{position: "absolute", inset: 0}}>
        <SvgDefs />
        {/* left panel — magnifying glass */}
        <g opacity={lIn}>
          <rect {...L_PANEL} rx={theme.radius} fill={`${theme.colors.panel}88`} stroke={theme.colors.panelEdge} strokeWidth={3} />
          <line x1={L_PANEL.x + 20} x2={L_PANEL.x + L_PANEL.w - 20} y1={AX} y2={AX} stroke={theme.colors.panelEdge} strokeWidth={2} strokeDasharray="12 10" />
          {L_H.map((h, i) => (
            <Ray key={i} pts={traceRay(h, 0, L_PANEL.x + 30, singleElems, L_PANEL.x + L_PANEL.w - 40, AX)} p={lRays[i]} />
          ))}
          <LensShape x={lx(400)} cy={AX} h={135} w={28} kind="convex" />
          <g filter="url(#glow)"><circle cx={lx(700)} cy={AX} r={9} fill={theme.colors.accent} opacity={prog(frame, 30, 10)} /></g>
          <MagnifierIcon x={L_PANEL.x + L_PANEL.w - 80} y={L_PANEL.y + 80} s={0.6} />
        </g>

        {/* "=" link */}
        <g transform={`translate(960 ${AX}) scale(${eq})`} opacity={Math.min(1, eq)}>
          <circle r={42} fill={theme.colors.panel} stroke={theme.colors.accent} strokeWidth={4} />
          <rect x={-18} y={-12} width={36} height={7} rx={3} fill={theme.colors.accent} />
          <rect x={-18} y={6} width={36} height={7} rx={3} fill={theme.colors.accent} />
        </g>

        {/* right panel — camera lens (multi-element), same convergence but exactly on the sensor */}
        <g opacity={Math.min(1, rIn * 1.5)} transform={`translate(${(1 - rIn) * 60} 0)`}>
          <rect {...R_PANEL} rx={theme.radius} fill={`${theme.colors.panel}88`} stroke={theme.colors.panelEdge} strokeWidth={3} />
          <rect {...R_PANEL} rx={theme.radius} fill="none" stroke={theme.colors.accent} strokeWidth={5} opacity={under} />
          <LensRig
            id="s3" k={K} tx={R_TX} ty={AX} reveal={rReveal} assemble={rAssemble}
            heights={R_H} rayP={rRays} startX={R_START} sensorGlow={glow} rayWidth={3.4}
          />
        </g>
      </svg>

      <Headlines
        items={[
          {words: ["একই", {t: "মূলনীতি", color: theme.colors.accent}], from: 4, to: Math.max(tCtl - 3, 40)},
          {words: ["অনেক", "বেশি", {t: "নিয়ন্ত্রিত", color: theme.colors.accent}], from: Math.max(tCtl - 3, 40), to: 400},
        ]}
        size={92}
      />
      <Tag x={L_PANEL.x + 150} y={L_PANEL.y + 50} text="Magnifying Glass" delay={4} size={30} center={false} />
      <Tag x={R_PANEL.x + 40} y={R_PANEL.y + 50} text="ক্যামেরার লেন্স" delay={tRight + 4} size={30} center={false} />
      <Sfx at={4} name="pop" vol={0.8} />
      <Sfx at={tRight} name="whoosh" vol={0.5} />
      <Sfx at={tEq} name="click" />
      <Sfx at={tLock} name="chime" />
    </AbsoluteFill>
  );
};
