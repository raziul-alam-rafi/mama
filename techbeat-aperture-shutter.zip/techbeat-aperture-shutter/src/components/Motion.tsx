import React from "react";
import { interpolate, spring, useCurrentFrame, useVideoConfig, Easing } from "remotion";
import { theme } from "../theme";

/** clamped, eased interpolate (never linear) */
export const ip = (
  frame: number,
  input: [number, number],
  output: [number, number],
  easing: (t: number) => number = theme.ease.inOut,
) =>
  interpolate(frame, input, output, {
    easing,
    extrapolateLeft: "clamp",
    extrapolateRight: "clamp",
  });

/** multi-keyframe eased path */
export const keys = (
  frame: number,
  frames: number[],
  values: number[],
  easing: (t: number) => number = theme.ease.inOut,
) =>
  interpolate(frame, frames, values, {
    easing,
    extrapolateLeft: "clamp",
    extrapolateRight: "clamp",
  });

export const useSpring = (delay: number, config: any = theme.spring.smooth) => {
  const frame = useCurrentFrame();
  const { fps } = useVideoConfig();
  return spring({ frame: frame - delay, fps, config });
};

/** premium entrance: opacity + translate + scale together */
export const Entrance: React.FC<{
  delay?: number;
  x?: number;
  y?: number;
  from?: number;
  config?: any;
  style?: React.CSSProperties;
  children: React.ReactNode;
}> = ({ delay = 0, x = 0, y = 36, from = 0.94, config = theme.spring.smooth, style, children }) => {
  const p = useSpring(delay, config);
  return (
    <div
      style={{
        opacity: Math.min(1, p * 1.4),
        transform: `translate(${(1 - p) * x}px, ${(1 - p) * y}px) scale(${from + (1 - from) * p})`,
        ...style,
      }}
    >
      {children}
    </div>
  );
};

/** word-by-word stagger; splits ONLY on spaces (Bengali conjuncts stay intact) */
export const WordReveal: React.FC<{
  text: string;
  delay?: number;
  per?: number;
  size?: number;
  weight?: number;
  color?: string;
  highlight?: Record<string, string>;
  align?: "flex-start" | "center" | "flex-end";
  style?: React.CSSProperties;
}> = ({ text, delay = 0, per = 4, size = theme.type.title, weight = 700, color = theme.colors.text, highlight = {}, align = "flex-start", style }) => {
  const frame = useCurrentFrame();
  const { fps } = useVideoConfig();
  return (
    <div
      style={{
        display: "flex",
        flexWrap: "wrap",
        justifyContent: align,
        columnGap: Math.round(size * 0.26),
        fontFamily: theme.fonts.display,
        fontSize: size,
        fontWeight: weight,
        lineHeight: 1.25,
        letterSpacing: 0,
        color,
        ...style,
      }}
    >
      {text.split(" ").map((w, i) => {
        const p = spring({ frame: frame - delay - i * per, fps, config: theme.spring.snappy });
        return (
          <span
            key={i}
            style={{
              display: "inline-block",
              opacity: Math.min(1, p * 1.5),
              transform: `translateY(${(1 - p) * 34}px) scale(${0.92 + 0.08 * p})`,
              color: highlight[w] ?? color,
            }}
          >
            {w}
          </span>
        );
      })}
    </div>
  );
};

/** label chip */
export const Chip: React.FC<{
  text: string;
  tone?: "primary" | "accent" | "signal" | "dim";
  size?: number;
  delay?: number;
  style?: React.CSSProperties;
}> = ({ text, tone = "primary", size = theme.type.small, delay = 0, style }) => {
  const col = {
    primary: theme.colors.primary,
    accent: theme.colors.accent,
    signal: theme.colors.signal,
    dim: theme.colors.textDim,
  }[tone];
  return (
    <Entrance delay={delay} y={18} from={0.9} config={theme.spring.snappy} style={style}>
      <div
        style={{
          display: "inline-flex",
          alignItems: "center",
          padding: `${size * 0.22}px ${size * 0.62}px`,
          borderRadius: theme.radius.chip,
          background: `${theme.colors.bgAlt}F2`,
          border: `2px solid ${col}`,
          color: theme.colors.text,
          fontFamily: theme.fonts.display,
          fontWeight: 600,
          fontSize: size,
          lineHeight: 1.3,
          boxShadow: `0 10px 30px -10px ${theme.colors.shadow}`,
          whiteSpace: "nowrap",
        }}
      >
        <span style={{ width: size * 0.3, height: size * 0.3, borderRadius: "50%", background: col, marginRight: size * 0.4 }} />
        {text}
      </div>
    </Entrance>
  );
};

/** glass card */
export const Card: React.FC<{
  w: number;
  h: number;
  x: number;
  y: number;
  delay?: number;
  children?: React.ReactNode;
  border?: string;
  style?: React.CSSProperties;
}> = ({ w, h, x, y, delay = 0, children, border = theme.colors.line, style }) => (
  <div style={{ position: "absolute", left: x, top: y, width: w, height: h }}>
    <Entrance delay={delay} y={44} from={0.93} style={{ width: w, height: h }}>
      <div
        style={{
          width: w,
          height: h,
          borderRadius: theme.radius.card,
          background: `linear-gradient(160deg, ${theme.colors.panelHi}CC, ${theme.colors.panel}E6)`,
          border: `2px solid ${border}`,
          boxShadow: `0 40px 80px -30px ${theme.colors.shadow}, inset 0 1px 0 rgba(255,255,255,0.06)`,
          overflow: "hidden",
          position: "relative",
          ...style,
        }}
      >
        {children}
      </div>
    </Entrance>
  </div>
);

/** idle breathing offsets */
export const useBreathe = (amp = 1) => {
  const frame = useCurrentFrame();
  return {
    scale: 1 + Math.sin(frame / 22) * 0.012 * amp,
    float: Math.sin(frame / 30) * 4 * amp,
  };
};

export const clamp01 = (v: number) => Math.max(0, Math.min(1, v));
export const lerp = (a: number, b: number, t: number) => a + (b - a) * t;
export { Easing };

/** make a keyframe list strictly increasing (guards against words resolving to the same frame) */
export const mono = (arr: number[], gap = 4) => {
  const out: number[] = [];
  arr.forEach((v, i) => out.push(i === 0 ? v : Math.max(v, out[i - 1] + gap)));
  return out;
};
