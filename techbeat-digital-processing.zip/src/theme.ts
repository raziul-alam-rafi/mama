// theme.ts — single source of truth: colors, easing, springs, fonts.
import { Easing } from "remotion";
import { loadFont } from "@remotion/google-fonts/HindSiliguri";

const { fontFamily } = loadFont("normal", {
  weights: ["500", "600", "700"],
  subsets: ["bengali", "latin"],
});

export const theme = {
  colors: {
    bg: "#0B1020",
    bgAlt: "#10172E",
    panel: "#151E3C",
    panel2: "#1C2750",
    line: "#2D3C70",
    primary: "#4F8CFF", // hero blue
    primaryDeep: "#2C5FD8",
    accent: "#FFB84D", // amber
    accentDeep: "#E8832A",
    text: "#F4F7FF",
    textDim: "#9FACD2",
    // colour channels (RGB) — used only where the narration talks about red/green/blue
    chR: "#FF5A66",
    chG: "#43D18B",
    chB: "#4D7DFF",
    ok: "#43D18B",
  },
  fonts: {
    main: `${fontFamily}, "Noto Sans Bengali", "Hind Siliguri", FreeSans, sans-serif`,
  },
  radius: { card: 26, cell: 12, pill: 999 },
  shadow: {
    card: "0 30px 70px -24px rgba(0,0,0,0.65)",
    glowBlue: "0 0 60px rgba(79,140,255,0.35), 0 0 120px rgba(79,140,255,0.18)",
    glowAmber: "0 0 50px rgba(255,184,77,0.35)",
  },
  ease: {
    out: Easing.bezier(0.16, 1, 0.3, 1),
    inOut: Easing.bezier(0.83, 0, 0.17, 1),
    soft: Easing.bezier(0.45, 0, 0.2, 1),
    in: Easing.bezier(0.7, 0, 0.84, 0),
  },
  spring: {
    snappy: { damping: 14, stiffness: 160, mass: 0.6 },
    smooth: { damping: 20, stiffness: 90, mass: 1 },
    bouncy: { damping: 11, stiffness: 170, mass: 0.7 },
  },
} as const;

export type Theme = typeof theme;
