import React from "react";
import {AbsoluteFill, interpolate, spring, useCurrentFrame, useVideoConfig} from "remotion";
import {theme} from "./theme";

export const clamp01 = (v: number) => Math.min(1, Math.max(0, v));
export const lerp = (a: number, b: number, t: number) => a + (b - a) * t;

type Ease = (t: number) => number;

export const useFx = () => {
  const frame = useCurrentFrame();
  const {fps} = useVideoConfig();
  const ramp = (from: number, dur: number, easing: Ease = theme.ease.out) =>
    interpolate(frame, [from, from + dur], [0, 1], {
      easing,
      extrapolateLeft: "clamp",
      extrapolateRight: "clamp",
    });
  const pop = (from: number, config: object = theme.spring.snappy) =>
    spring({frame: frame - from, fps, config});
  return {frame, fps, ramp, pop};
};

export const baseText: React.CSSProperties = {
  fontFamily: theme.fonts.display,
  letterSpacing: 0,
  color: theme.colors.text,
  whiteSpace: "nowrap",
  lineHeight: 1.25,
};

type Tone = "light" | "amber" | "dim";
const toneColor = (t: Tone) =>
  t === "amber" ? theme.colors.accent : t === "light" ? theme.colors.text : theme.colors.textDim;

/** Label pill: opacity + rise + scale entrance, faster exit. */
export const Pill: React.FC<{
  x: number;
  y: number;
  at: number;
  text: string;
  tone?: Tone;
  size?: number;
  out?: number;
}> = ({x, y, at: from, text, tone = "light", size = 40, out}) => {
  const {pop, ramp} = useFx();
  const p = pop(from);
  const o = out === undefined ? 1 : 1 - ramp(out, 10, theme.ease.in);
  const c = toneColor(tone);
  return (
    <div
      style={{
        ...baseText,
        position: "absolute",
        left: x,
        top: y,
        opacity: Math.min(1, p) * o,
        transform: `translate(-50%, -50%) translateY(${interpolate(p, [0, 1], [18, 0])}px) scale(${interpolate(p, [0, 1], [0.9, 1])})`,
        fontSize: size,
        fontWeight: 700,
        color: c,
        padding: `${size * 0.2}px ${size * 0.65}px`,
        borderRadius: theme.radius.pill,
        background: `rgba(11,16,32,0.82)`,
        border: `2px solid ${tone === "dim" ? theme.colors.panelEdge : c}`,
        boxShadow: `0 14px 34px ${theme.colors.shadow}`,
      }}
    >
      {text}
    </div>
  );
};

/** SVG line that draws itself (pathLength trick). */
export const Leader: React.FC<{
  x1: number;
  y1: number;
  x2: number;
  y2: number;
  at: number;
  color?: string;
  out?: number;
}> = ({x1, y1, x2, y2, at: from, color = theme.colors.accent, out}) => {
  const {ramp} = useFx();
  const p = ramp(from, 16);
  const o = out === undefined ? 1 : 1 - ramp(out, 10, theme.ease.in);
  if (p <= 0.001 || o <= 0.001) return null; // avoids a round-cap dot at p=0
  return (
    <line
      x1={x1}
      y1={y1}
      x2={x2}
      y2={y2}
      pathLength={1}
      strokeDasharray={`${p} 2`}
      stroke={color}
      strokeWidth={2.5}
      strokeLinecap="round"
      opacity={o}
    />
  );
};

/** Words split on spaces only (never per-letter: Bengali conjuncts break). */
export const Words: React.FC<{
  text: string;
  at: number;
  size: number;
  per?: number;
  accentWord?: number;
  style?: React.CSSProperties;
}> = ({text, at: from, size, per = 4, accentWord, style}) => {
  const {pop} = useFx();
  return (
    <div style={{display: "flex", gap: size * 0.28, justifyContent: "center", ...style}}>
      {text.split(" ").map((w, i) => {
        const p = pop(from + i * per);
        return (
          <span
            key={i}
            style={{
              ...baseText,
              display: "inline-block",
              fontSize: size,
              fontWeight: 700,
              opacity: Math.min(1, p),
              color: i === accentWord ? theme.colors.accent : theme.colors.text,
              transform: `translateY(${interpolate(p, [0, 1], [30, 0])}px)`,
            }}
          >
            {w}
          </span>
        );
      })}
    </div>
  );
};

/** Scene wrapper: faster exit than entrance. */
export const SceneShell: React.FC<{dur: number; exit?: boolean; children: React.ReactNode}> = ({
  dur,
  exit = true,
  children,
}) => {
  const {frame, ramp} = useFx();
  void frame;
  const e = exit ? ramp(dur - 10, 9, theme.ease.in) : 0;
  return (
    <AbsoluteFill
      style={{opacity: 1 - e, transform: `scale(${1 + 0.05 * e}) translateY(${-18 * e}px)`}}
    >
      {children}
    </AbsoluteFill>
  );
};

const BN = "০১২৩৪৫৬৭৮৯";
/** 12000000 -> "১,২০,০০,০০০" (Bengali digits, lakh/crore grouping). */
export const bnNumber = (n: number) => {
  const s = Math.round(n).toString();
  let out = s;
  if (s.length > 3) {
    const head = s.slice(0, -3);
    const tail = s.slice(-3);
    out = head.replace(/\B(?=(\d{2})+(?!\d))/g, ",") + "," + tail;
  }
  return out.replace(/\d/g, (d) => BN[+d]);
};
