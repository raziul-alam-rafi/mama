import React from "react";
import { AbsoluteFill } from "remotion";
import { theme } from "../theme";
import { useScene } from "../SceneContext";
import { Chip, ip, mono, clamp01, useSpring, useBreathe } from "../components/Motion";
import { LensCutaway, lensPx } from "../components/LensCutaway";
import { SensorGrid } from "../components/SensorGrid";
import { Sfx } from "../components/Sfx";

const W = 1500, LEFT = 210, TOP = 250;

// Scene 10 · Where does the light land? (cues 16–17): rays reach the sensor, camera pushes in to the pixel grid.
export const Finale: React.FC = () => {
  const S = useScene();
  const f = S.frame;
  const c16 = Math.max(S.cue(16), 0);
  const fWhere = S.word(16, "কোথায়");
  const fMost = S.word(16, "সবচেয়ে");
  const fWow = S.word(17, "অবিশ্বাস্য");
  const [z0] = mono([fMost - 6]);

  const prog = ip(f, [c16 + 4, c16 + 52], [0, 1], theme.ease.soft);
  const zoom = ip(f, [z0, z0 + 40], [1, 4.4], theme.ease.inOut);
  const camOp = 1 - ip(f, [z0 + 14, z0 + 36], [0, 1]);
  const gridIn = ip(f, [z0 + 18, z0 + 44], [0, 1]);
  const qIn = useSpring(fWhere, theme.spring.bouncy);
  const qOut = 1 - ip(f, [z0 - 4, z0 + 12], [0, 1]);
  const b = useBreathe(1);
  const pulse = ip(f, [fWhere, fWhere + 20], [0, 1]) * (0.5 + 0.5 * Math.sin(f / 5)) * qOut;
  const sensor = lensPx(925, 0, W);
  const wow = useSpring(fWow, theme.spring.snappy);

  const cols = 16, rows = 10, cell = 62;
  const level = (c: number, r: number) => {
    const d = Math.hypot(c - (cols - 1) / 2, r - (rows - 1) / 2);
    const wave = 0.5 + 0.5 * Math.sin(d * 1.1 - (f - z0) / 5);
    return clamp01((0.35 + 0.65 * wave) * ip(f, [z0 + 24, z0 + 54], [0, 1]));
  };

  return (
    <AbsoluteFill>
      <div style={{ position: "absolute", left: LEFT, top: TOP + b.float * 0.4, opacity: camOp, transform: `scale(${zoom})`, transformOrigin: `${sensor.x}px ${sensor.y}px` }}>
        <LensCutaway width={W} open={0.82} prog={prog} shutter={[-180, 180]} subject={false} sensorPulse={pulse} uid="fi" />
      </div>

      {/* question mark at the sensor */}
      <div style={{ position: "absolute", left: LEFT + sensor.x - 60, top: TOP + sensor.y - 270, width: 120, textAlign: "center", opacity: Math.min(1, qIn * 1.4) * qOut, transform: `scale(${0.6 + 0.4 * qIn}) translateY(${Math.sin(f / 9) * 6}px)`, fontFamily: theme.fonts.display, fontWeight: 700, fontSize: 170, lineHeight: 1, color: theme.colors.accent, textShadow: `0 0 50px ${theme.colors.accent}88` }}>?</div>

      {/* sensor pixel grid */}
      <div style={{ position: "absolute", left: 960 - (cols * cell) / 2, top: 560 - (rows * cell) / 2 + 10, opacity: gridIn, transform: `scale(${0.9 + 0.1 * gridIn})` }}>
        <div style={{ padding: 22, borderRadius: 28, background: theme.colors.panel, border: `3px solid ${theme.colors.signal}`, boxShadow: `0 40px 90px -30px ${theme.colors.shadow}` }}>
          <SensorGrid cols={cols} rows={rows} cell={cell} level={level} bayer />
        </div>
      </div>
      <div style={{ position: "absolute", left: 960 - 130, top: 950, opacity: gridIn }}>
        <Chip text="Sensor" tone="signal" size={46} delay={z0 + 30} />
      </div>

      {/* key word */}
      <div style={{ position: "absolute", left: 0, right: 0, top: 70, display: "flex", justifyContent: "center", opacity: Math.min(1, wow * 1.4), transform: `translateY(${(1 - wow) * 30}px) scale(${0.92 + 0.08 * wow})` }}>
        <span style={{ fontFamily: theme.fonts.display, fontWeight: 700, fontSize: 128, lineHeight: 1.25, letterSpacing: 0, background: `linear-gradient(90deg, ${theme.colors.accentSoft}, ${theme.colors.accent})`, WebkitBackgroundClip: "text", color: "transparent", filter: `drop-shadow(0 0 30px ${theme.colors.accent}55)` }}>অবিশ্বাস্য</span>
      </div>

      <Sfx name="whoosh" at={c16 + 8} vol={0.7} />
      <Sfx name="pop" at={fWhere - 2} />
      <Sfx name="whoosh" at={z0 + 4} vol={0.8} rate={0.9} />
      <Sfx name="chime" at={z0 + 30} />
      <Sfx name="thud" at={fWow} vol={0.8} />
    </AbsoluteFill>
  );
};
