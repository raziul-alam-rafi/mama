// Scene-local event frames, all derived from SRT cues. Scenes AND SFX share these.
import {at, sceneRange} from "./timing";

export const E = {
  sensor: {
    lens: at("sensor", 1, 0.05),
    rays: at("sensor", 1, 0.12),
    sensor: at("sensor", 1, 0.3),
    pivot: at("sensor", 1, 0.4),
    pivotDur: 46,
    cells: at("sensor", 1, 0.76),
    wave: at("sensor", 2, 0.12),
    amber: at("sensor", 2, 0.55),
    pill: at("sensor", 2, 0.6),
    pillOut: sceneRange("sensor").dur - 28,
  },
  pixel: {
    zoomIn: at("pixel", 3, 0),
    ripple: at("pixel", 3, 0.18),
    ring: at("pixel", 3, 0.28),
    label: at("pixel", 3, 0.34),
    zoomOut: at("pixel", 3, 0.6),
    density: at("pixel", 3, 0.6) + 30,
    chip: at("pixel", 3, 0.84),
    countFrom: at("pixel", 4, 0.5),
    countTo: at("pixel", 4, 0.95),
    densityBack: at("pixel", 5, 0),
    sweep: at("pixel", 5, 0.22),
    zoomPatch: at("pixel", 5, 0.58),
  },
  light: {
    fadeNeighbors: 4,
    photons: at("light", 6, 0.04),
    detect: at("light", 6, 0.22),
    more: at("light", 6, 0.62),
    less: at("light", 7, 0.25),
    compare: at("light", 7, 0.5),
  },
  electric: {
    waves: at("electric", 8, 0),
    notEq: at("electric", 8, 0.14),
    box: at("electric", 8, 0.3),
    question: at("electric", 8, 0.5),
    zoomIn: at("electric", 8, 0.8),
    interior: at("electric", 9, 0),
    photodiode: at("electric", 9, 0.4),
  },
};
