#!/usr/bin/env bash
set -euo pipefail
GL="$(cat .glmode 2>/dev/null || echo swangle)"
echo "Using --gl=$GL"
mkdir -p out
for f in 10 45 90 140 215 260 300 345 400 470 540; do
  npx remotion still src/index.ts ApertureExplainer "out/check_$f.png" --frame="$f" --gl="$GL" --timeout=120000 --overwrite
done
echo "Stills in out/check_*.png"
