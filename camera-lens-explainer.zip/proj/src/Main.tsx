import React from "react";
import {AbsoluteFill, Sequence} from "remotion";
import {BgMesh, Grade, Grain, SceneShell, Vignette, Wipe} from "./components/Fx";
import {PreviewAudio} from "./components/PreviewAudio";
import {Sfx} from "./components/Sfx";
import {SCENES, sceneDur, sceneStart} from "./timeline";
import {S1Lens} from "./scenes/S1Lens";
import {S2Magnifier} from "./scenes/S2Magnifier";
import {S3Compare} from "./scenes/S3Compare";
import {S4Image} from "./scenes/S4Image";
import {S5Exposure} from "./scenes/S5Exposure";
import {S6Question} from "./scenes/S6Question";

const COMPONENTS = [S1Lens, S2Magnifier, S3Compare, S4Image, S5Exposure, S6Question];

/** Layer stack: mesh → scenes (assets + graphics) → transitions → grade → grain → vignette. */
export const Main: React.FC = () => (
  <AbsoluteFill style={{background: "#000"}}>
    <BgMesh />
    {SCENES.map((s, i) => {
      const C = COMPONENTS[i];
      return (
        <Sequence key={s.id} name={s.id} from={sceneStart(i)} durationInFrames={sceneDur(i)}>
          <SceneShell dur={sceneDur(i)}>
            <C />
          </SceneShell>
        </Sequence>
      );
    })}
    {SCENES.slice(1).map((s, i) => (
      <React.Fragment key={s.id}>
        <Wipe at={sceneStart(i + 1)} />
        <Sequence from={Math.max(0, sceneStart(i + 1) - 11)} durationInFrames={30} layout="none">
          <Sfx at={0} name="whoosh" vol={0.9} />
        </Sequence>
      </React.Fragment>
    ))}
    <Grade />
    <Grain />
    <Vignette />
    <PreviewAudio />
  </AbsoluteFill>
);
