import React from "react";
import {theme} from "../theme";
import {E} from "../events";
import {Pill, Leader, Words, baseText, bnNumber, clamp01, lerp, useFx} from "../ui";
import {
  AMBER_CELL,
  COLS,
  DenseGrid,
  FACE_H,
  FACE_X,
  FACE_Y,
  GridCells,
  PATCH_CELL,
  PATCH_TARGET,
  PATCH_ZOOM,
  cellCenter,
  zoomTransform,
} from "../components/sensor";

const CENTER = {x: 960, y: 545};
const ZOOM1 = 6.5;

export const ScenePixel: React.FC<{dur: number}> = ({dur}) => {
  const {frame, ramp, pop} = useFx();
  const ev = E.pixel;
  if (frame >= dur - 10) return null; // hand-off to the light scene (identical state)

  // ---- zoom state ----
  const zin = ramp(ev.zoomIn, 28, theme.ease.inOut);
  const zout = ramp(ev.zoomOut, 30, theme.ease.inOut);
  const z1 = zin * (1 - zout);
  const amberC = cellCenter(AMBER_CELL.c, AMBER_CELL.r);
  const patchC = cellCenter(PATCH_CELL.c, PATCH_CELL.r);
  const zp = ramp(ev.zoomPatch, 46, theme.ease.inOut);

  let s = 1 + (ZOOM1 - 1) * z1;
  let F = amberC;
  let T = {x: lerp(amberC.x, CENTER.x, z1), y: lerp(amberC.y, CENTER.y, z1)};
  if (frame >= ev.zoomPatch) {
    s = 1 + (PATCH_ZOOM - 1) * zp;
    F = patchC;
    T = {x: lerp(patchC.x, PATCH_TARGET.x, zp), y: lerp(patchC.y, PATCH_TARGET.y, zp)};
  }

  // ---- density: cells shrink to megapixel scale and come back ----
  const dens = ramp(ev.density, 50, theme.ease.inOut) * (1 - ramp(ev.densityBack, 40, theme.ease.inOut));
  const dense = dens > 0.001;
  const cellSize = lerp(40, 6, dens);
  const gs = lerp(1, 0.8, dens);
  const gy = lerp(0, -85, dens);

  // ---- sweep ("sampling") ----
  const sweepP = ramp(ev.sweep, 56, theme.ease.soft);
  const sweepX = sweepP * (COLS + 2);
  const fill = (c: number) => clamp01((sweepX - c) / 1.2);
  const mosaicOn = frame >= ev.sweep;
  const ripple = (c: number, r: number) => {
    const dist = Math.hypot(c - AMBER_CELL.c, r - AMBER_CELL.r);
    return clamp01(1 - Math.abs(frame - (ev.ripple + 4 * dist)) / 9) * 0.5;
  };

  // pulse ring highlight on the focal cell
  const ringP = ramp(ev.ring, 22);
  const hiAmber = frame < ev.zoomPatch;

  // counter
  const cnt = ramp(ev.countFrom, ev.countTo - ev.countFrom, theme.ease.out);
  const counterOut = 1 - ramp(ev.densityBack - 4, 10, theme.ease.in);
  const counterIn = pop(ev.countFrom - 6);
  const chipOut = 1 - ramp(ev.densityBack - 4, 10, theme.ease.in);
  const digits = bnNumber(cnt * 12000000).split("");

  const labelOut = ev.zoomOut - 4;
  const sampleOut = ev.zoomPatch + 6;

  return (
    <>
      <svg width={1920} height={1080} style={{position: "absolute", inset: 0}}>
        <g transform={`translate(0 ${gy}) translate(960 545) scale(${gs}) translate(-960 -545)`}>
          <g transform={zoomTransform(s, F, T)}>
            {/* the sensor face panel */}
            <rect x={FACE_X - 2} y={FACE_Y - 2} width={960 + 4} height={FACE_H + 4} rx={18} fill={theme.colors.panelDeep} stroke={theme.colors.panelEdge} strokeWidth={2} vectorEffect="non-scaling-stroke" />
            {dense ? (
              <DenseGrid size={cellSize} />
            ) : (
              <GridCells
                fill={mosaicOn ? (c) => fill(c) : undefined}
                scale={mosaicOn ? (c) => 1 + 0.14 * Math.sin(Math.PI * fill(c)) : undefined}
                glow={(c, r) => ripple(c, r)}
              />
            )}
            {hiAmber && (
              <rect
                x={amberC.x - 18}
                y={amberC.y - 18}
                width={36}
                height={36}
                rx={5}
                fill={`rgba(${theme.rgb.accent},0.55)`}
                stroke={theme.colors.accent}
                strokeWidth={3}
                vectorEffect="non-scaling-stroke"
                opacity={dense ? 0 : 1}
              />
            )}
            {hiAmber && ringP > 0 && ringP < 1 && (
              <rect
                x={amberC.x - 18 - 14 * ringP}
                y={amberC.y - 18 - 14 * ringP}
                width={36 + 28 * ringP}
                height={36 + 28 * ringP}
                rx={5 + 8 * ringP}
                fill="none"
                stroke={theme.colors.accent}
                strokeWidth={3}
                vectorEffect="non-scaling-stroke"
                opacity={1 - ringP}
              />
            )}
          </g>
          {mosaicOn && sweepP > 0 && sweepP < 1 && (
            <line
              x1={FACE_X + sweepX * 40}
              x2={FACE_X + sweepX * 40}
              y1={FACE_Y - 20}
              y2={FACE_Y + FACE_H + 20}
              stroke={theme.colors.accent}
              strokeWidth={4}
              strokeLinecap="round"
              opacity={0.9}
            />
          )}
        </g>
        <Leader x1={960} y1={232} x2={960} y2={FACE_Y + 175} at={ev.label + 6} out={labelOut} />
      </svg>

      <Pill x={960} y={196} at={ev.label} text="pixel" tone="amber" size={64} out={labelOut} />

      {/* 12 megapixel chip */}
      <div style={{position: "absolute", left: 0, right: 0, top: 60, opacity: chipOut}}>
        {frame >= ev.chip && <Words text="12 megapixel" at={ev.chip} size={92} accentWord={0} per={5} />}
      </div>

      {/* counter */}
      <div
        style={{
          ...baseText,
          position: "absolute",
          left: 0,
          right: 0,
          top: 805,
          display: "flex",
          justifyContent: "center",
          alignItems: "baseline",
          gap: 26,
          opacity: Math.min(1, counterIn) * counterOut,
          transform: `translateY(${lerp(30, 0, Math.min(1, counterIn))}px)`,
        }}
      >
        <div style={{display: "flex", fontSize: 128, fontWeight: 700}}>
          {digits.map((ch, i) => (
            <span
              key={i}
              style={{
                display: "inline-block",
                width: ch === "," ? 26 : 74,
                textAlign: "center",
                color: theme.colors.text,
              }}
            >
              {ch}
            </span>
          ))}
        </div>
        <span style={{fontSize: 60, fontWeight: 600, color: theme.colors.accent}}>pixel</span>
      </div>

      <Pill x={960} y={120} at={ev.sweep} text="নমুনা" tone="light" size={56} out={sampleOut} />
    </>
  );
};

void Words;
