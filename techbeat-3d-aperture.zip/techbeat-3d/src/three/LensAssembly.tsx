import React from "react";
import * as THREE from "three";
import { Iris } from "./Iris";
import { Rays, SENSOR_X, LENS_X } from "./Rays";
import { theme } from "../theme";
import { T, IRIS_KEYS, IRIS_MAX, IRIS_MIN } from "../scenes/aperture/timeline";
import { kf, seg } from "../lib/ease";

const BARREL_R = 1.6;
const BARREL_X0 = -3.2;
const BARREL_X1 = SENSOR_X;

/** The complete lens + camera body + light path. Pure function of `t` (seconds). */
export const LensAssembly: React.FC<{ t: number }> = ({ t }) => {
  const r = kf(t, IRIS_KEYS);
  const e = 1 - seg(t, T.assembleStart, T.assembleEnd, theme.ease.out); // 1 = exploded, 0 = assembled
  const barrelOpacity = kf(t, [{ t: 0, v: 0.5 }, { t: T.cutawayStart, v: 0.45 }, { t: T.cutawayEnd, v: 0.12 }, { t: 99, v: 0.12 }]);

  // amber hero glow on the iris: strong while it is introduced, gentle afterwards
  const intro = seg(t, T.irisHighlightStart, T.irisHighlightStart + 0.5, theme.ease.out) *
    (1 - seg(t, T.irisHighlightEnd - 0.4, T.irisHighlightEnd + 0.6, theme.ease.inOut));
  const pulse = 0.5 + 0.5 * Math.sin(t * 5);
  const glow = Math.min(1, 0.3 + intro * (0.7 + 0.3 * pulse));

  // light reaching the sensor: proportional to the opening area (r^2), floor so it never goes fully black
  const area = (r * r) / (IRIS_MAX * IRIS_MAX);
  const raysFade = seg(t, T.raysOn + 0.6, T.raysOn + T.rayRevealDur + 0.8, theme.ease.out);
  const brightness = (0.06 + 0.94 * Math.max(0, (area - (IRIS_MIN * IRIS_MIN) / (IRIS_MAX * IRIS_MAX)) / (1 - (IRIS_MIN * IRIS_MIN) / (IRIS_MAX * IRIS_MAX)))) * raysFade;

  const breathe = Math.sin(t * 1.3) * 0.035; // idle micro-motion

  return (
    <group position={[0, breathe, 0]}>
      {/* barrel (translucent, open-ended cylinder along X) */}
      <mesh position={[(BARREL_X0 + BARREL_X1) / 2, 0, 0]} rotation={[0, 0, Math.PI / 2]}>
        <cylinderGeometry args={[BARREL_R, BARREL_R, BARREL_X1 - BARREL_X0, 72, 1, true]} />
        <meshPhysicalMaterial color={theme.colors.primary} metalness={0.55} roughness={0.3}
          transparent opacity={barrelOpacity} side={THREE.DoubleSide} depthWrite={false} />
      </mesh>
      {[BARREL_X0, 2.4].map((x, i) => (
        <mesh key={i} position={[x, 0, 0]} rotation={[0, Math.PI / 2, 0]}>
          <torusGeometry args={[BARREL_R, 0.06, 16, 72]} />
          <meshStandardMaterial color={theme.colors.primary} metalness={0.8} roughness={0.25} />
        </mesh>
      ))}

      {/* front converging glass (slides in during the exploded intro) */}
      <mesh position={[LENS_X - 2.6 * e, 0, 0]} scale={[0.28, 1, 1]}>
        <sphereGeometry args={[BARREL_R * 0.96, 64, 48]} />
        <meshPhysicalMaterial color="#cfe4ff" roughness={0.05} metalness={0} transparent opacity={0.3}
          clearcoat={1} depthWrite={false} />
      </mesh>

      {/* iris diaphragm */}
      <Iris r={r} glow={glow} />

      {/* camera body + sensor (slides in during the exploded intro) */}
      <group position={[2.2 * e, 0, 0]}>
        <mesh position={[SENSOR_X + 0.75, 0, 0]} castShadow receiveShadow>
          <boxGeometry args={[1.5, 3.4, 4.0]} />
          <meshStandardMaterial color={theme.colors.sensorBody} metalness={0.5} roughness={0.45} />
        </mesh>
        <mesh position={[SENSOR_X + 0.02, 0, 0]}>
          <boxGeometry args={[0.05, 1.5, 2.0]} />
          <meshStandardMaterial color="#10162b" emissive={theme.colors.ray}
            emissiveIntensity={brightness * 1.9} toneMapped={false} />
        </mesh>
        <pointLight position={[SENSOR_X - 0.6, 0, 0]} color={theme.colors.ray}
          intensity={brightness * 6} distance={7} />
      </group>

      <Rays t={t} r={r} raysOn={T.raysOn} revealDur={T.rayRevealDur} />
    </group>
  );
};
