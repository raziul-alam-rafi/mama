// Offline fonts: Hind Siliguri files are copied from the npm package into public/fonts on `npm install`.
// If they are missing, the bundled fallback font (public/fonts/BanglaFallback-*.ttf) is used.
import { staticFile } from "remotion";

const BN = "U+0951-0952,U+0964-0965,U+0980-09FE,U+1CF7,U+200C-200D,U+20B9,U+25CC";
const LATIN = "U+0000-00FF,U+0131,U+0152-0153,U+02BB-02BC,U+02C6,U+02DA,U+02DC,U+2000-206F,U+2074,U+20AC,U+2122,U+2191,U+2193,U+2212,U+2215,U+FEFF,U+FFFD";

const faces = [
  { family: "Hind Siliguri", file: "hind-siliguri-bengali-700-normal.woff2", weight: "700", range: BN },
  { family: "Hind Siliguri", file: "hind-siliguri-latin-700-normal.woff2", weight: "700", range: LATIN },
  { family: "Hind Siliguri", file: "hind-siliguri-bengali-500-normal.woff2", weight: "500", range: BN },
  { family: "Hind Siliguri", file: "hind-siliguri-latin-500-normal.woff2", weight: "500", range: LATIN },
  { family: "BanglaFallback", file: "BanglaFallback-Regular.ttf", weight: "400", range: undefined },
  { family: "BanglaFallback", file: "BanglaFallback-Bold.ttf", weight: "700", range: undefined },
];

let started: Promise<void> | null = null;
export const loadFonts = (): Promise<void> => {
  if (started) return started;
  started = Promise.all(
    faces.map(async (f) => {
      try {
        const ff = new FontFace(f.family, `url(${staticFile("fonts/" + f.file)})`, {
          weight: f.weight,
          ...(f.range ? { unicodeRange: f.range } : {}),
        });
        await ff.load();
        document.fonts.add(ff);
      } catch {
        /* file not present — next family in the stack is used */
      }
    })
  ).then(() => undefined);
  return started;
};
