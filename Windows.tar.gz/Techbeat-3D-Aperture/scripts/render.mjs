// Renders the composition to out/aperture_raw.mp4 (1920x1080, 30fps, H.264 + AAC).
// Usage: npm run render:test            (default concurrency 2)
//        npm run render:test -- --concurrency=1
import { run, readGlMode, mkdirOut, extraArgs } from "./lib.mjs";

const v = run("node scripts/validate.mjs");
if (v.status !== 0) process.exit(v.status);
const gl = readGlMode();
console.log("Using --gl=" + gl);
mkdirOut();
const extra = extraArgs();
const conc = /--concurrency/.test(extra) ? "" : "--concurrency=2";
const r = run(`npx remotion render src/index.ts ApertureExplainer out/aperture_raw.mp4 --codec=h264 --crf=17 --audio-codec=aac --gl=${gl} ${conc} --timeout=120000 --overwrite ${extra}`);
process.exit(r.status);
