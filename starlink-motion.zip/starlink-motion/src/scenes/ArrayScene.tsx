// Scene 3 — Glossy UI mockup (cues 3-4): many small antennas, beam direction steered electronically.
import React from "react";
import { AbsoluteFill, interpolate, spring, useCurrentFrame, useVideoConfig } from "remotion";
import { theme } from "../theme";
import { array as b } from "../beats";
import { sec } from "../timing";
import { WordReveal } from "../components/Words";
import { CL, Entrance, TimedBlock } from "../components/Motion";

const PANEL = { left: 900, top: 150, w: 900, h: 780 };
const GRID = { cx: 450, cy: 560, gap: 58, n: 7, r: 10 };
const ORIGIN = { x: 450, y: 372 };
const BEAM_LEN = 200;

export const ArrayScene: React.FC = () => {
  const frame = useCurrentFrame();
  const { fps } = useVideoConfig();

  // panel starts centred, then slides right when the title arrives
  const pShift = spring({ frame: frame - b.tTitle, fps, config: theme.spring.smooth });
  const shift = -(PANEL.left - (1920 - PANEL.w) / 2) * (1 - Math.min(1, pShift));

  // electronic steering: beam direction changes while the dish itself never moves
  const tA = b.beam + 2;
  const tB = tA + sec(1.0);
  const tC = tB + sec(1.1);
  const tD = tC + sec(1.0);
  const ang = interpolate(frame, [tA, tB, tC, tD], [0, -32, 30, 0], { easing: theme.ease.inOut, ...CL });
  const rad = (ang * Math.PI) / 180;
  const pBeam = Math.min(1, spring({ frame: frame - b.beam, fps, config: theme.spring.smooth }));
  const Lb = BEAM_LEN * pBeam;
  const wf = 16 + 64 * pBeam;
  const amp = Math.min(1, spring({ frame: frame - b.tSig, fps, config: theme.spring.smooth }));

  return (
    <AbsoluteFill>
      {/* left: copy */}
      <div style={{ position: "absolute", left: 110, top: 290, width: 740 }}>
        <TimedBlock to={b.t4 + 4}>
          <WordReveal
            text="ছোট ছোট antenna"
            delay={b.tTitle}
            size={100}
            maxWidth={740}
            marks={{ antenna: { color: theme.colors.accent, underline: true } }}
          />
          <div style={{ marginTop: 22 }}>
            <WordReveal text="signal-এর মধ্যে সামান্য পরিবর্তন" delay={b.tSig} per={3} size={52} weight={500} color={theme.colors.textDim} maxWidth={720} />
          </div>
        </TimedBlock>
        <div style={{ position: "absolute", left: 0, top: 0, width: 740 }}>
          <WordReveal text="signal কোন দিকে যাবে" delay={b.title2} size={88} maxWidth={740} marks={{ signal: { color: theme.colors.accent } }} />
          <div style={{ marginTop: 18 }}>
            <WordReveal
              text="ইলেকট্রনিক নিয়ন্ত্রণ"
              delay={b.title2 + 10}
              size={80}
              maxWidth={740}
              marks={{ "ইলেকট্রনিক": { color: theme.colors.accent, underline: true } }}
            />
          </div>
        </div>
      </div>

      {/* right: glossy device panel */}
      <div style={{ position: "absolute", left: PANEL.left, top: PANEL.top, width: PANEL.w, height: PANEL.h, transform: `translateX(${shift}px)` }}>
        <Entrance delay={b.t3} y={70} scaleFrom={0.92} style={{ width: PANEL.w, height: PANEL.h }}>
          <div
            style={{
              position: "relative",
              width: PANEL.w,
              height: PANEL.h,
              borderRadius: theme.radius.card,
              overflow: "hidden",
              background: `linear-gradient(160deg, ${theme.colors.surfaceHi}, ${theme.colors.surface} 55%, ${theme.colors.bgAlt})`,
              border: `1px solid ${theme.colors.border}`,
              boxShadow: theme.shadow.card,
            }}
          >
            {/* glossy highlight */}
            <div
              style={{
                position: "absolute",
                inset: 0,
                background: `linear-gradient(115deg, ${theme.colors.text}14, transparent 32%)`,
              }}
            />
            {/* header */}
            <div style={{ position: "absolute", left: 0, right: 0, top: 0, height: 72, borderBottom: `1px solid ${theme.colors.border}` }}>
              {[0, 1, 2].map((k) => (
                <div key={k} style={{ position: "absolute", left: 30 + k * 28, top: 28, width: 16, height: 16, borderRadius: 8, background: theme.colors.textDim, opacity: 0.45 }} />
              ))}
              <div style={{ position: "absolute", left: 0, right: 0, top: 10, textAlign: "center", fontFamily: theme.fonts.display, fontSize: 34, fontWeight: 600, color: theme.colors.textDim, lineHeight: 1.6 }}>
                Starlink dish
              </div>
            </div>

            <svg width={PANEL.w} height={PANEL.h} viewBox={`0 0 ${PANEL.w} ${PANEL.h}`} style={{ position: "absolute", left: 0, top: 0 }}>
              <defs>
                <linearGradient id="arrBeam" gradientUnits="userSpaceOnUse" x1={0} y1={0} x2={0} y2={-BEAM_LEN}>
                  <stop offset="0" stopColor={theme.colors.primary} stopOpacity={0.9} />
                  <stop offset="1" stopColor={theme.colors.primary} stopOpacity={0} />
                </linearGradient>
              </defs>

              {/* beam: the only hero-glow element */}
              <g transform={`translate(${ORIGIN.x} ${ORIGIN.y}) rotate(${ang})`} opacity={pBeam}>
                <polygon points={`-16,0 16,0 ${wf},${-Lb} ${-wf},${-Lb}`} fill="url(#arrBeam)" />
                <line x1={0} y1={0} x2={0} y2={-Lb} stroke={theme.colors.primary} strokeWidth={4} strokeLinecap="round" opacity={0.9} />
              </g>
              {pBeam > 0.3 ? (
                <text
                  x={ORIGIN.x + (Lb + 40) * Math.sin(rad)}
                  y={ORIGIN.y - (Lb + 40) * Math.cos(rad)}
                  textAnchor="middle"
                  fontFamily={theme.fonts.display}
                  fontSize={36}
                  fontWeight={600}
                  fill={theme.colors.accent}
                  opacity={pBeam}
                >
                  signal
                </text>
              ) : null}

              {/* antenna grid */}
              {Array.from({ length: GRID.n }).map((_, j) =>
                Array.from({ length: GRID.n }).map((__, i) => {
                  const x = GRID.cx + (i - 3) * GRID.gap;
                  const y = GRID.cy + (j - 3) * GRID.gap;
                  const pd = Math.min(1, spring({ frame: frame - (b.t3 + 8 + (i + j) * 2), fps, config: theme.spring.snappy }));
                  const phase = frame / 6 - (i * (0.55 + 1.1 * Math.sin(rad)) + j * 0.55);
                  const w = (0.5 + 0.5 * Math.sin(phase)) * amp;
                  return (
                    <g key={`${i}-${j}`} opacity={Math.max(0, pd)}>
                      <circle cx={x} cy={y} r={GRID.r * (0.4 + 0.6 * pd)} fill={theme.colors.bg} stroke={theme.colors.border} strokeWidth={2} />
                      <circle cx={x} cy={y} r={GRID.r * (0.35 + 0.55 * w)} fill={theme.colors.accent} opacity={0.25 + 0.75 * w} />
                    </g>
                  );
                })
              )}
            </svg>
          </div>
        </Entrance>
      </div>
    </AbsoluteFill>
  );
};
