// fonts.ts — ফন্ট অফলাইনে চলে: প্রজেক্টের public/fonts থেকে লোড হয় (ইন্টারনেট লাগে না)।
// • FreeSans.ttf / FreeSansBold.ttf — বান্ডলড (GNU FreeFont), বাংলা যুক্তাক্ষরসহ (সবসময় আছে)
// • HindSiliguri-Bold.ttf / HindSiliguri-Regular.ttf — ঐচ্ছিক। public/fonts-এ রাখলে এটাই আগে ব্যবহার হবে
import { continueRender, delayRender, staticFile } from "remotion";

type Face = { family: string; file: string; weight: string };
const FACES: Face[] = [
  { family: "Hind Siliguri", file: "fonts/HindSiliguri-Bold.ttf", weight: "700" },
  { family: "Hind Siliguri", file: "fonts/HindSiliguri-Regular.ttf", weight: "400" },
  // ল্যাটিন (Camera, Lens, Sensor…) — আসল Bold
  { family: "Free Sans Latin", file: "fonts/FreeSansBold.ttf", weight: "700" },
  // বাংলা — FreeSans-এ শুধু Regular আছে; weight 400 ঘোষণা করা, তাই ব্রাউজার Bold সিন্থেসাইজ করে
  { family: "Free Sans Bn", file: "fonts/FreeSans.ttf", weight: "400" },
];

let started = false;
export function loadFonts(): void {
  if (started || typeof document === "undefined") return;
  started = true;
  const handle = delayRender("fonts");
  Promise.all(
    FACES.map(async (f) => {
      try {
        const ff = new FontFace(f.family, `url(${staticFile(f.file)})`, { weight: f.weight });
        await ff.load();
        document.fonts.add(ff);
      } catch {
        /* ঐচ্ছিক ফন্ট না থাকলে চুপচাপ বাদ */
      }
    })
  ).then(() => continueRender(handle));
}
