#!/usr/bin/env bash
set -euo pipefail
node scripts/validate.mjs
GL="$(cat .glmode 2>/dev/null || echo swangle)"
echo "Using --gl=$GL"
mkdir -p out
npx remotion render src/index.ts ApertureExplainer out/aperture_raw.mp4 \
  --codec=h264 --crf=17 --audio-codec=aac --gl="$GL" --concurrency="${CONCURRENCY:-2}" --timeout=120000 --overwrite
