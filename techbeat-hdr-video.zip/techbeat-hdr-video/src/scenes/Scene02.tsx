// সিন ২ (cue 3–4): জানালার সামনে দাঁড়ানো — মুখ ছায়ায়, বাইরে উজ্জ্বল আকাশ (Flat Vector + আলোর মিটার)
import React from "react";
import { useCurrentFrame } from "remotion";
import { theme } from "../theme";
import { makeT } from "../timing";
import { Entrance, SceneShell, tween, useBreathe } from "../components/anim";
import { Card, Chip, Label, Meter } from "../components/ui";
import { FACE, Photo, SUN, WIN } from "../components/photo";
import { SfxEvent } from "../sfx";

const T = makeT(1);
const tPhoto = 6;
const tWin = T(3, "জানালার");
const tFace = T(3, "আপনার মুখটা");
const tShadow = T(4, "ভেতরের ছায়ায়");
const tSky = T(4, "জানালার বাইরে");
const tBright = T(4, "উজ্জ্বল আকাশ");

export const sfx02: SfxEvent[] = [
  { kind: "pop", frame: tPhoto + 4 },
  { kind: "click", frame: tWin + 8 },
  { kind: "pop", frame: tFace + 6, rate: 1.05 },
  { kind: "pop", frame: tSky + 6, rate: 0.95 },
  { kind: "chime", frame: tBright + 10, vol: 0.7 },
];

// ছবি বসানোর মাপ: স্কেল ১.৬, উপরে-বামে (130,170)
const OX = 130, OY = 215, SC = 1.6;
const px = (x: number) => OX + x * SC;
const py = (y: number) => OY + y * SC;

const Ring: React.FC<{ cx: number; cy: number; r: number; color: string; at: number }> = ({ cx, cy, r, color, at }) => {
  const frame = useCurrentFrame();
  const p = tween(frame, at, at + 16, 0, 1);
  const pulse = 1 + Math.sin((frame - at) / 7) * 0.035 * p;
  return (
    <svg width={1920} height={1080} style={{ position: "absolute", inset: 0, pointerEvents: "none" }}>
      <circle cx={cx} cy={cy} r={r * pulse * (1.25 - 0.25 * p)} fill="none" stroke={color} strokeWidth={5} strokeDasharray="14 10" opacity={p}
        style={{ filter: `drop-shadow(0 0 14px ${color})` }} />
    </svg>
  );
};

export const Scene02: React.FC = () => {
  const frame = useCurrentFrame();
  const bob = useBreathe(44, 4);
  const winP = tween(frame, tWin, tWin + 18, 0, 1);
  const faceFill = tween(frame, tShadow, tShadow + 40, 0, 0.16, theme.ease.inOut);
  const skyFill = tween(frame, tBright, tBright + 44, 0, 0.96, theme.ease.inOut);

  return (
    <SceneShell>
      {/* ছবি + ভিউফাইন্ডার কোণা */}
      <Entrance delay={tPhoto} style={{ position: "absolute", left: OX, top: OY + bob }}>
        <div style={{ position: "relative", boxShadow: theme.shadow.card, borderRadius: 22 }}>
          <Photo uid="s2" gRoom={0.9} gSky={0.3} width={1024} radius={22} />
          {[[0, 0, 1, 1], [1, 0, -1, 1], [0, 1, 1, -1], [1, 1, -1, -1]].map(([a, b, sx, sy], i) => (
            <div key={i} style={{ position: "absolute", left: a ? undefined : 16, right: a ? 16 : undefined, top: b ? undefined : 16, bottom: b ? 16 : undefined,
              width: 44, height: 44, borderTop: sy === 1 ? `5px solid ${theme.colors.text}` : undefined, borderBottom: sy === -1 ? `5px solid ${theme.colors.text}` : undefined,
              borderLeft: sx === 1 ? `5px solid ${theme.colors.text}` : undefined, borderRight: sx === -1 ? `5px solid ${theme.colors.text}` : undefined, opacity: 0.85 }} />
          ))}
        </div>
      </Entrance>

      {/* জানালার আউটলাইন */}
      <svg width={1920} height={1080} style={{ position: "absolute", inset: 0, pointerEvents: "none", transform: `translateY(${bob}px)` }}>
        <rect x={px(WIN.x)} y={py(WIN.y)} width={WIN.w * SC} height={WIN.h * SC} rx={6} fill="none" stroke={theme.colors.hero} strokeWidth={6}
          pathLength={1} strokeDasharray={1} strokeDashoffset={1 - winP} style={{ filter: `drop-shadow(0 0 12px ${theme.colors.hero})` }} />
      </svg>
      <div style={{ transform: `translateY(${bob}px)` }}>
        <Ring cx={px(FACE.cx)} cy={py(FACE.cy)} r={100} color={theme.colors.accent} at={tFace} />
        <Ring cx={px(SUN.cx) - 40} cy={py(SUN.cy) + 40} r={150} color={theme.colors.hero} at={tSky} />
      </div>
      <Entrance delay={tWin + 4} style={{ position: "absolute", left: px(WIN.x) , top: py(WIN.y) - 74 }}>
        <Chip text="জানালা" color={theme.colors.hero} size={34} />
      </Entrance>

      {/* ডানের কার্ড: আলোর পরিমাণ */}
      <Entrance delay={tFace + 4} x={50} y={0} style={{ position: "absolute", left: 1260, top: 295 }}>
        <Card w={530} h={230} border={theme.colors.accent}>
          <div style={{ padding: "30px 36px", display: "flex", flexDirection: "column", gap: 20 }}>
            <Label size={46} color={theme.colors.accent} weight={700}>মুখ</Label>
            <Label size={36} color={theme.colors.textDim}>ঘরের ভেতরের ছায়ায়</Label>
            <Meter w={458} value={faceFill} color={theme.colors.accent} />
          </div>
        </Card>
      </Entrance>
      <Entrance delay={tSky + 4} x={50} y={0} style={{ position: "absolute", left: 1260, top: 565 }}>
        <Card w={530} h={230} border={theme.colors.hero}>
          <div style={{ padding: "30px 36px", display: "flex", flexDirection: "column", gap: 20 }}>
            <Label size={46} color={theme.colors.hero} weight={700}>আকাশ</Label>
            <Label size={36} color={theme.colors.textDim}>জানালার বাইরে, উজ্জ্বল</Label>
            <Meter w={458} value={skyFill} color={theme.colors.hero} />
          </div>
        </Card>
      </Entrance>
    </SceneShell>
  );
};
