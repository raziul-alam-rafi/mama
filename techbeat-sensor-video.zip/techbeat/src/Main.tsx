import React from "react";
import {AbsoluteFill, Sequence} from "remotion";
import {theme} from "./theme";
import {ORDER, SceneId, sceneRange} from "./timing";
import {BgMesh, Grade, Grain, Vignette} from "./components/Backdrop";
import {SceneShell} from "./ui";
import {SceneSensor} from "./scenes/SceneSensor";
import {ScenePixel} from "./scenes/ScenePixel";
import {SceneLight} from "./scenes/SceneLight";
import {SceneElectric} from "./scenes/SceneElectric";
import {PreviewAudio} from "./PreviewAudio";
import {Sfx} from "./Sfx";

const SCENES: Record<SceneId, {C: React.FC<{dur: number}>; exit: boolean}> = {
  sensor: {C: SceneSensor, exit: false}, // hands off to the next scene with an identical grid
  pixel: {C: ScenePixel, exit: false},
  light: {C: SceneLight, exit: true},
  electric: {C: SceneElectric, exit: false}, // final hold
};

export const Main: React.FC = () => (
  <AbsoluteFill style={{backgroundColor: theme.colors.bg, fontFamily: theme.fonts.display}}>
    <BgMesh />
    {ORDER.map((id) => {
      const {from, dur} = sceneRange(id);
      const {C, exit} = SCENES[id];
      return (
        <Sequence key={id} from={from} durationInFrames={dur} name={id}>
          <SceneShell dur={dur} exit={exit}>
            <C dur={dur} />
          </SceneShell>
        </Sequence>
      );
    })}
    <Grade />
    <Grain />
    <Vignette />
    <PreviewAudio />
    <Sfx />
  </AbsoluteFill>
);
