import * as THREE from 'three';
import {FPS, LEAD_FRAMES} from '../../config/theme';
import {TOTAL_FRAMES, at} from '../../subtitles/subtitles';
import {clamp, easeInOutCubic, easeInOutSine, lerp} from '../../utils/math';
import {BROADCAST_CURVE, TOWER_TOP, ANT_FEED, HOUSE_CURVE} from '../animations/paths';

export type CamState = {pos: THREE.Vector3; target: THREE.Vector3; fov: number};
export type ShotId = 'A' | 'B' | 'C' | 'D' | 'E' | 'F' | 'G';

export type Shot = {
  id: ShotId;
  name: string;
  narration: string;
  start: number;
  end: number; // exclusive
  ease: (t: number) => number;
  cam: (p: number, frame: number) => CamState;
};

const V = (x: number, y: number, z: number) => new THREE.Vector3(x, y, z);

/** Smooth path through keyframes (Catmull-Rom) sampled at p in 0..1. */
function spline(keys: {pos: [number, number, number]; target: [number, number, number]; fov: number}[]) {
  const pc = new THREE.CatmullRomCurve3(keys.map((k) => V(...k.pos)), false, 'centripetal');
  const tc = new THREE.CatmullRomCurve3(keys.map((k) => V(...k.target)), false, 'centripetal');
  return (p: number): CamState => {
    const n = keys.length - 1;
    const f = clamp(p) * n;
    const i = Math.min(n - 1, Math.floor(f));
    return {
      pos: pc.getPoint(p),
      target: tc.getPoint(p),
      fov: lerp(keys[i].fov, keys[i + 1].fov, f - i),
    };
  };
}

const f = (t: number) => Math.max(0, Math.round(t * FPS) - LEAD_FRAMES);

// Anchor frames come from the SRT (see subtitles.ts). First shot starts at frame 0.
const S = {
  A: 0,
  B: f(at(1, 'এখানে মাঠে')),
  C: f(at(2, 'এরপর ক্যামেরার')),
  D: f(at(2, 'বৈদ্যুতিক সংকেতে')),
  E: f(at(2, 'সম্প্রচারের')),
  F: f(at(3, 'আর সেই সংকেত')),
  G: f(at(3, 'আপনার বাড়ির')),
  END: TOTAL_FRAMES,
};
export const ANCHORS = S;

// Signal-pulse timing (absolute frames), used by Signal + Waves components.
export const PULSE1 = {start: S.E, end: S.E + Math.round((S.F - S.E) * 0.72)}; // camera -> tower top
export const WAVE_START = PULSE1.end;
export const PULSE2 = {start: S.G - 2, end: S.END - 6}; // antenna -> TV

export const SHOTS: Shot[] = [
  {
    id: 'A',
    name: 'Establishing: living room, CRT TV shows the cricket match',
    narration: 'ধরুন একটি টিভি চ্যানেলে ক্রিকেট ম্যাচ দেখানো হচ্ছে',
    start: S.A,
    end: S.B,
    ease: easeInOutSine,
    cam: spline([
      {pos: [201.9, 1.55, 3.0], target: [200.0, 1.0, -2.0], fov: 40},
      {pos: [200.45, 1.12, 0.6], target: [199.91, 0.94, -1.8], fov: 30},
    ]),
  },
  {
    id: 'B',
    name: 'Stadium reveal: crane down to the studio camera aimed at the pitch',
    narration: 'এখানে মাঠে যা ঘটছে ক্যামেরা',
    start: S.B,
    end: S.C,
    ease: easeInOutCubic,
    cam: spline([
      {pos: [56, 17, 16], target: [8, 1.5, 0], fov: 42},
      {pos: [40, 6.5, 12], target: [32, 1.6, 0], fov: 36},
      {pos: [27.5, 2.0, 6.5], target: [32.6, 1.6, 0], fov: 32},
    ]),
  },
  {
    id: 'C',
    name: 'Macro: push-in to the lens',
    narration: 'সেই দৃশ্য ধারণ করছে। এরপর ক্যামেরার ছবিকে',
    start: S.C,
    end: S.D,
    ease: easeInOutCubic,
    cam: spline([
      {pos: [27.5, 2.0, 6.5], target: [32.6, 1.6, 0.0], fov: 32},
      {pos: [30.4, 1.68, 1.5], target: [32.0, 1.58, 0.0], fov: 26},
    ]),
  },
  {
    id: 'D',
    name: 'Orbit behind the camera: image -> electrical signal (explanatory overlay)',
    narration: 'বৈদ্যুতিক সংকেতে রূপান্তর করে',
    start: S.D,
    end: S.E,
    ease: easeInOutSine,
    cam: spline([
      {pos: [31.5, 3.2, -6.5], target: [34.4, 2.7, 0.0], fov: 34},
      {pos: [39.8, 2.9, -2.4], target: [34.9, 2.7, 0.05], fov: 30},
      {pos: [40.5, 2.6, 0.9], target: [35.0, 2.65, 0.05], fov: 28},
    ]),
  },
  {
    id: 'E',
    name: 'Tracking: follow the signal along the cable, climb the transmitter tower',
    narration: 'সম্প্রচারের জন্য পাঠানো হত',
    start: S.E,
    end: S.F,
    ease: (t) => t, // linear: the pulse head and the camera share the same clock
    cam: (p) => {
      const u = clamp(p / 0.72);
      const head = BROADCAST_CURVE.getPointAt(easeInOutSine(u));
      const follow = head.clone().add(V(-7, 3.2, 8));
      const crane = V(116, 34, 40);
      // continue from the end of shot D, then lock onto the signal head, then crane up the tower
      const k0 = easeInOutCubic(clamp(p / 0.18));
      const dEnd = V(40.5, 2.6, 0.9);
      const dEndT = V(35.0, 2.65, 0.05);
      const k = easeInOutCubic(clamp((p - 0.45) / 0.55));
      const pos = dEnd.clone().lerp(follow, k0).lerp(crane, k);
      const target = dEndT.clone().lerp(head, k0).lerp(TOWER_TOP.clone().add(V(0, -4, 0)), k);
      return {pos, target, fov: lerp(30, 36, k0) + 6 * k};
    },
  },
  {
    id: 'F',
    name: 'Tracking the radio waves across the landscape to the rooftop antenna',
    narration: 'আর সেই সংকেত antennaর মাধ্যমে',
    start: S.F,
    end: S.G,
    ease: easeInOutCubic,
    cam: spline([
      {pos: [118, 36, 40], target: [90, 50, 0], fov: 42},
      {pos: [150, 20, 30], target: [175, 12, 0], fov: 40},
      {pos: [193, 10.2, 11], target: [201, 7.2, 0], fov: 32},
      {pos: [197.2, 9.0, 6.0], target: [200.8, 7.3, 0.0], fov: 26},
    ]),
  },
  {
    id: 'G',
    name: 'Follow the cable from antenna to the TV at home',
    narration: 'আপনার বাড়ির টিভিতে পৌঁছাত',
    start: S.G,
    end: S.END,
    ease: easeInOutCubic,
    cam: spline([
      {pos: [197.2, 9.0, 6.0], target: [200.8, 7.3, 0.0], fov: 26},
      {pos: [205.6, 5.4, 6.2], target: [204.3, 3.8, 0.0], fov: 30},
      {pos: [204.0, 1.9, 6.0], target: [203.5, 1.4, -1.0], fov: 34},
      {pos: [201.4, 1.5, 3.2], target: [200.0, 0.95, -2.0], fov: 36},
      {pos: [200.42, 1.04, 0.5], target: [199.91, 0.94, -1.8], fov: 29},
    ]),
  },
];

export const shotAt = (frame: number): Shot =>
  SHOTS.find((s) => frame >= s.start && frame < s.end) ?? SHOTS[SHOTS.length - 1];

export const shotProgress = (shot: Shot, frame: number) =>
  clamp((frame - shot.start) / Math.max(1, shot.end - shot.start - 1));

// re-exports so other modules do not need to import curves directly
export {HOUSE_CURVE, ANT_FEED};
