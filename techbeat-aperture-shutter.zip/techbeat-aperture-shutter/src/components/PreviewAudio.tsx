import React, { useEffect, useState } from "react";
import { Audio, getRemotionEnvironment, staticFile } from "remotion";
import { PREVIEW_VOICEOVER, RENDER_VOICEOVER, VOICEOVER_FILE } from "../config";

/** Plays public/voiceover.mp3 in Studio preview if the file exists; silently skipped otherwise. */
export const PreviewAudio: React.FC = () => {
  const env = getRemotionEnvironment();
  const [exists, setExists] = useState(false);
  const allowed = env.isRendering ? RENDER_VOICEOVER : PREVIEW_VOICEOVER;

  useEffect(() => {
    if (!allowed || env.isRendering) return;
    let alive = true;
    fetch(staticFile(VOICEOVER_FILE), { method: "HEAD" })
      .then((r) => {
        const type = r.headers.get("content-type") ?? "";
        if (alive) setExists(r.ok && !type.includes("text/html"));
      })
      .catch(() => alive && setExists(false));
    return () => {
      alive = false;
    };
  }, [allowed, env.isRendering]);

  if (!allowed) return null;
  if (env.isRendering) return <Audio src={staticFile(VOICEOVER_FILE)} />; // only when RENDER_VOICEOVER = true
  return exists ? <Audio src={staticFile(VOICEOVER_FILE)} volume={1} /> : null;
};
