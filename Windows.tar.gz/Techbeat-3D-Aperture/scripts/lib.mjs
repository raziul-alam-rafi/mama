// Cross-platform helpers (Windows CMD / PowerShell / macOS / Linux). No bash required.
import { spawnSync } from "node:child_process";
import fs from "node:fs";

/** Run one command string through the platform shell. Args used here never contain spaces. */
export function run(cmd, { capture = false } = {}) {
  const r = spawnSync(cmd, { shell: true, stdio: capture ? "pipe" : "inherit", encoding: "utf8", maxBuffer: 1024 * 1024 * 256 });
  return { status: r.status ?? 1, out: (r.stdout || "") + (r.stderr || "") };
}

export const GLMODE_FILE = ".glmode";
export const VALID_GL = ["swangle", "angle-egl", "angle", "egl", "vulkan"];

/** The GL backend chosen by `npm run gl-check`; defaults to swangle (software, no GPU needed). */
export function readGlMode() {
  try {
    const v = fs.readFileSync(GLMODE_FILE, "utf8").trim();
    if (VALID_GL.includes(v)) return v;
  } catch { /* not created yet */ }
  return "swangle";
}

export function mkdirOut() { fs.mkdirSync("out", { recursive: true }); }

/** Extra CLI args typed after `npm run <script> --`, e.g. --concurrency=1 */
export const extraArgs = () => process.argv.slice(2).filter((a) => /^--[\w-]+(=[\w.:-]+)?$/.test(a)).join(" ");
