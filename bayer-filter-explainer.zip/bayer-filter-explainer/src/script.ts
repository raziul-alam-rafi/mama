// The SRT is the ONLY timing source. Everything (scene bounds, SFX, duration) derives from it.
export const SRT_TEXT = `1
00:00:00,240 --> 00:00:06,260
বেশিরভাগ প্রচলিত camera sensor pixel উপর
ক্ষুদ্র ক্ষুদ্র রঙিন filter বসানো থাকে।

2
00:00:06,260 --> 00:00:12,740
সাধারণত এই filter গুলো লাল, সবুজ আর নীল
আলোর জন্য তৈরি করা হয়। ফলে প্রতিটি

3
00:00:12,740 --> 00:00:19,600
photosite সব রঙের আলোকে একইভাবে মাপে না।
তার উপরে থাকা filter যে রঙের আলোকে বেশি

4
00:00:19,600 --> 00:00:25,780
যেতে দেয় sensor মূলত সেই রঙের আলোর তথ্য
সংগ্রহ করে। এখানে একটা মজার ব্যাপার আছে।

5
00:00:25,820 --> 00:00:32,100
অনেক sensor লাল ও নীল filter তুলনায় সবুজ
filter বেশি থাকে। কারণ আমাদের

6
00:00:32,100 --> 00:00:37,980
দৃষ্টিশক্তি উজ্জ্বলতার সূক্ষ পরিবর্তনের
প্রতি সবুজ আলোর অঞ্চলে তুলনামূলক বেশি

7
00:00:37,980 --> 00:00:43,700
সংবেদনশীল। তাই এই বিন্যাস থেকে ছবির
বিস্তারিত তথ্য পুনর্গঠনের সুবিধা পাওয়া

8
00:00:43,720 --> 00:00:50,500
যায়। তবে প্রতিটি pixel সাধারণত পুরো রংটা
সরাসরি শনাক্ত করে না। তাহলে সম্পূর্ণ

9
00:00:50,500 --> 00:00:52,440
রঙিন ছবিটা তৈরি হয় কিভাবে?
`;

export type Cue = {index: number; start: number; end: number; text: string};

const toSec = (t: string) => {
  const [h, m, rest] = t.trim().split(":");
  const [s, ms] = rest.split(",");
  return Number(h) * 3600 + Number(m) * 60 + Number(s) + Number(ms) / 1000;
};

export const parseSrt = (src: string): Cue[] =>
  src
    .replace(/\r/g, "")
    .trim()
    .split(/\n\s*\n/)
    .map((block) => {
      const lines = block.split("\n");
      const [a, b] = lines[1].split("-->");
      return {index: Number(lines[0]), start: toSec(a), end: toSec(b), text: lines.slice(2).join(" ")};
    });

export const CUES = parseSrt(SRT_TEXT);
export const cue = (n: number) => CUES[n - 1];
export const TOTAL_SEC = CUES[CUES.length - 1].end;

// Scene plan: meaning-based groups of cue numbers (scene bounds sit on cue bounds).
export type ScenePlan = {id: string; from: number; to: number};
export const PLAN: ScenePlan[] = [
  {id: "s1-stack", from: 1, to: 1},
  {id: "s2-cutaway", from: 2, to: 2},
  {id: "s3-lanes", from: 3, to: 3},
  {id: "s4-photosite", from: 4, to: 4},
  {id: "s5-mosaic", from: 5, to: 5},
  {id: "s6-eye", from: 6, to: 7},
  {id: "s7-split", from: 8, to: 8},
  {id: "s8-question", from: 9, to: 9},
];
