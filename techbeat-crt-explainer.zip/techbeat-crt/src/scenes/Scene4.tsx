// Scene 4 — "সংকেত antenna মাধ্যমে আপনার বাড়ির টিভিতে পৌঁছাত"
// Style: Hub/route. Tower -> signal pulses across the sky -> rooftop antenna -> wire -> TV in the house.
import React from "react";
import { AbsoluteFill, useCurrentFrame } from "remotion";
import { theme } from "../theme";
import { BEATS } from "../timeline";
import { ip, Pop, Tag } from "../components/kit";
import { CRTTV, House, StaticNoise, CricketField, Tower, YagiAntenna, qpt } from "../components/objects";
import { SceneProps, makeQ } from "./types";

const TOWER = { left: 100, top: 230 };
const HOUSE = { left: 1000, top: 250 };
const YAGI = { left: 1230, top: 130 }; // antenna centre ~ (1380, 230)
const TV = { left: 1243, top: 700, scale: 0.36 };

export const Scene4: React.FC<SceneProps> = ({ cs, cd }) => {
  const frame = useCurrentFrame();
  const q = makeQ(cs, cd);
  const pulseAt = q(BEATS.s4.pulse);
  const antAt = q(BEATS.s4.antenna);
  const wireAt = q(BEATS.s4.wire);
  const P0: [number, number] = [TOWER.left + 150, TOWER.top + 60];
  const P1: [number, number] = [YAGI.left + 40, YAGI.top + 100];
  const C: [number, number] = [740, 40];
  const pulse = ip(frame, [pulseAt, pulseAt + 10], [0, 1], theme.ease.out);
  const wire = ip(frame, [wireAt, wireAt + 22], [0, 1], theme.ease.out);
  const antGlow = ip(frame, [antAt, antAt + 14], [0, 1], theme.ease.out);
  const tvOn = ip(frame, [wireAt + 16, wireAt + 36], [0.35, 1], theme.ease.out);
  // route path as polyline for drawing
  const path = Array.from({ length: 41 }, (_, i) => qpt(P0, C, P1, i / 40));
  const dPath = path.map((p, i) => `${i ? "L" : "M"}${p[0].toFixed(1)},${p[1].toFixed(1)}`).join(" ");
  const wireTopY = YAGI.top + 200;
  const wireBotY = TV.top + 6;
  return (
    <AbsoluteFill>
      <div style={{ position: "absolute", left: TOWER.left, top: TOWER.top }}>
        <Pop delay={q(BEATS.s4.tower) + 2} y={60} s={0.92}>
          <Tower t={frame} rings ringT={frame} />
        </Pop>
      </div>

      <div style={{ position: "absolute", left: HOUSE.left, top: HOUSE.top }}>
        <Pop delay={6} y={70} s={0.92}>
          <House />
        </Pop>
      </div>

      {/* TV in the window */}
      <div style={{ position: "absolute", left: TV.left, top: TV.top }}>
        <Pop delay={12} y={30} s={0.9}>
          <CRTTV
            rot={-16}
            scale={TV.scale}
            on={tvOn}
            screen={
              frame > wireAt + 26 ? (
                <CricketField t={frame} />
              ) : (
                <StaticNoise />
              )
            }
          />
        </Pop>
      </div>

      {/* antenna on the roof */}
      <div style={{ position: "absolute", left: YAGI.left, top: YAGI.top }}>
        <Pop delay={q(BEATS.s4.antenna) - 22} y={50} s={0.9} cfg={theme.spring.bouncy}>
          <YagiAntenna glow={antGlow} />
        </Pop>
      </div>

      {/* signal route + pulses + wire */}
      <svg width="1920" height="1080" style={{ position: "absolute", left: 0, top: 0 }}>
        <path
          d={dPath}
          fill="none"
          stroke={theme.colors.hero}
          strokeWidth="5"
          strokeDasharray="16 14"
          strokeDashoffset={-frame * 3.2}
          strokeLinecap="round"
          opacity={pulse * 0.9}
          style={{ filter: `drop-shadow(0 0 10px ${theme.colors.hero})` }}
        />
        {[0, 1, 2, 3].map((k) => {
          const ph = (((frame - pulseAt) / 62 + k / 4) % 1 + 1) % 1;
          const [x, y] = qpt(P0, C, P1, ph);
          return (
            <circle
              key={k}
              cx={x}
              cy={y}
              r="11"
              fill={theme.colors.text}
              opacity={frame >= pulseAt ? Math.min(1, ph * 6) * (1 - Math.max(0, ph - 0.94) * 16) : 0}
              style={{ filter: `drop-shadow(0 0 10px ${theme.colors.accent})` }}
            />
          );
        })}
        {/* cable from antenna down to the TV */}
        <line
          x1={YAGI.left + 130}
          y1={wireTopY}
          x2={YAGI.left + 130}
          y2={wireTopY + (wireBotY - wireTopY) * wire}
          stroke={theme.colors.accent}
          strokeWidth="6"
          strokeLinecap="round"
          opacity={wire > 0 ? 1 : 0}
        />
        {[0, 1].map((k) => {
          const ph = (((frame - wireAt) / 26 + k / 2) % 1 + 1) % 1;
          return (
            <circle
              key={k}
              cx={YAGI.left + 130}
              cy={wireTopY + (wireBotY - wireTopY) * ph}
              r="9"
              fill={theme.colors.text}
              opacity={wire >= 1 ? 1 : 0}
            />
          );
        })}
      </svg>

      <div style={{ position: "absolute", left: 1500, top: 120 }}>
        <Tag text="antenna" tone="accent" delay={antAt - 4} size={52} />
      </div>
      <div style={{ position: "absolute", left: 1090, top: 950 }}>
        <Tag text="আপনার বাড়ি" tone="hero" delay={antAt + 6} size={52} />
      </div>
    </AbsoluteFill>
  );
};
