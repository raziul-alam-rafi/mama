import fs from 'node:fs';
import { parseSrt, msToFrame } from '../src/lib/srt.mjs';
const cues = parseSrt(fs.readFileSync(new URL('../public/audio/narration.srt', import.meta.url), 'utf8'));
let prev = 0, issues = 0;
for (const c of cues) {
  if (c.startMs < prev) { console.log(`overlap at cue ${c.index}`); issues++; }
  if (prev && c.startMs - prev > 100) { console.log(`gap ${c.startMs - prev}ms before cue ${c.index}`); issues++; }
  prev = c.endMs;
}
const last = cues[cues.length - 1];
console.log(`cues=${cues.length} issues=${issues} lastEnd=${last.endMs}ms frames@30fps=${msToFrame(last.endMs)}`);
