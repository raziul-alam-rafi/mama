import React, { useLayoutEffect, useRef } from "react";

/** Draws a pre-built canvas (see sceneImage.ts) synchronously — no async image loading. */
export const CanvasView: React.FC<{
  source: HTMLCanvasElement;
  width: number;
  height: number;
  pixelated?: boolean;
  style?: React.CSSProperties;
}> = ({ source, width, height, pixelated = false, style }) => {
  const ref = useRef<HTMLCanvasElement>(null);
  useLayoutEffect(() => {
    const c = ref.current!;
    c.width = source.width;
    c.height = source.height;
    const ctx = c.getContext("2d")!;
    ctx.drawImage(source, 0, 0);
  }, [source]);
  return <canvas ref={ref} style={{ width, height, display: "block", imageRendering: pixelated ? "pixelated" : "auto", ...style }} />;
};

/** Magnified crop of a source canvas (rect in source pixels), pixel-crisp. */
export const CropView: React.FC<{
  source: HTMLCanvasElement;
  sx: number;
  sy: number;
  sw: number;
  sh: number;
  width: number;
  height: number;
  style?: React.CSSProperties;
}> = ({ source, sx, sy, sw, sh, width, height, style }) => {
  const ref = useRef<HTMLCanvasElement>(null);
  useLayoutEffect(() => {
    const c = ref.current!;
    c.width = width;
    c.height = height;
    const ctx = c.getContext("2d")!;
    ctx.imageSmoothingEnabled = false;
    ctx.drawImage(source, sx, sy, sw, sh, 0, 0, width, height);
  }, [source, sx, sy, sw, sh, width, height]);
  return <canvas ref={ref} style={{ width, height, display: "block", ...style }} />;
};
