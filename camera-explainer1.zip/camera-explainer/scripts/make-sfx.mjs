// Synthesizes a small, clean UI-style SFX kit into public/sfx/*.wav (44.1kHz, 16-bit mono).
// pop · click · whoosh · chime · thud · tick — short, soft attack, fast decay, light low-pass + tiny reverb.
import fs from "node:fs";
const SR = 44100;
let seed = 1234;
const rnd = () => { seed = (seed * 1664525 + 1013904223) >>> 0; return seed / 4294967296 * 2 - 1; };
const N = (sec) => new Float32Array(Math.floor(sec * SR));
const lp = (x, fc) => { const a = Math.exp(-2 * Math.PI * fc / SR); let y = 0; return x.map((v) => (y = (1 - a) * v + a * y)); };
const hp = (x, fc) => { const l = lp(x, fc); return x.map((v, i) => v - l[i]); };
const bp = (x, f0, f1) => hp(lp(x, f1), f0);
const reverb = (x, mix = 0.12) => { const y = Float32Array.from(x); for (const [d, g] of [[0.011, 0.5], [0.019, 0.38], [0.029, 0.26], [0.041, 0.16]]) { const o = Math.floor(d * SR); for (let i = o; i < y.length; i++) y[i] += x[i - o] * g * mix * 3; } return y; };
const env = (i, n, att, dec) => { const t = i / SR; const a = Math.min(1, t / att); return a * Math.exp(-t / dec); };

const pop = () => { const x = N(0.2); let ph = 0; for (let i = 0; i < x.length; i++) { const t = i / SR; const f = 180 + 420 * Math.exp(-t / 0.03); ph += 2 * Math.PI * f / SR; x[i] = Math.sin(ph) * env(i, x.length, 0.004, 0.05); } return x; };
const click = () => { const x = N(0.07); for (let i = 0; i < x.length; i++) x[i] = rnd() * env(i, x.length, 0.0015, 0.012); return hp(x, 1800); };
const tick = () => { const x = N(0.045); for (let i = 0; i < x.length; i++) x[i] = rnd() * env(i, x.length, 0.001, 0.008); return bp(x, 2500, 6500); };
const whoosh = () => { const n = 0.62, x = N(n); for (let i = 0; i < x.length; i++) { const t = i / SR; x[i] = rnd() * Math.sin(Math.PI * Math.min(1, t / n)) ** 2; } // band-pass sweep
  const out = new Float32Array(x.length); const seg = 64; let st = { l1: 0, l2: 0 };
  for (let s = 0; s < x.length; s += seg) { const t = s / x.length; const fc = 500 + 2600 * Math.sin(Math.PI * t * 0.9) ; const a1 = Math.exp(-2 * Math.PI * fc * 1.5 / SR), a2 = Math.exp(-2 * Math.PI * fc * 0.5 / SR);
    for (let i = s; i < Math.min(x.length, s + seg); i++) { st.l1 = (1 - a1) * x[i] + a1 * st.l1; st.l2 = (1 - a2) * x[i] + a2 * st.l2; out[i] = st.l1 - st.l2; } }
  return out; };
const chime = () => { const x = N(0.5); for (let i = 0; i < x.length; i++) { const t = i / SR; const e = env(i, x.length, 0.004, 0.11); x[i] = e * (Math.sin(2 * Math.PI * 1318 * t) + 0.32 * Math.sin(2 * Math.PI * 1318 * 2.0 * t) * Math.exp(-t / 0.05) + 0.18 * Math.sin(2 * Math.PI * 1318 * 3.01 * t) * Math.exp(-t / 0.03)); } return x; };
const thud = () => { const x = N(0.32); let ph = 0; for (let i = 0; i < x.length; i++) { const t = i / SR; const f = 52 + 70 * Math.exp(-t / 0.05); ph += 2 * Math.PI * f / SR; x[i] = Math.sin(ph) * env(i, x.length, 0.006, 0.09); } return x; };

const kit = { pop: [pop(), 3800, 0.1], click: [click(), 9000, 0.06], tick: [tick(), 9000, 0.05], whoosh: [whoosh(), 5200, 0.1], chime: [chime(), 7000, 0.14], thud: [thud(), 900, 0.05] };
// loudness matching by RMS over the active region; then peak limit
const TARGET_RMS = 0.16, PEAK_MAX = 0.85;
fs.mkdirSync("public/sfx", { recursive: true });
for (const [name, [raw, fc, rv]] of Object.entries(kit)) {
  let y = reverb(lp(raw, fc), rv);
  // tiny fade-out to avoid clicks
  const f = Math.floor(0.008 * SR); for (let i = 0; i < f; i++) y[y.length - 1 - i] *= i / f;
  let sum = 0, cnt = 0; for (const v of y) if (Math.abs(v) > 0.002) { sum += v * v; cnt++; }
  const rms = Math.sqrt(sum / Math.max(1, cnt)); let g = TARGET_RMS / rms;
  let peak = 0; for (const v of y) peak = Math.max(peak, Math.abs(v)); if (peak * g > PEAK_MAX) g = PEAK_MAX / peak;
  const pcm = Buffer.alloc(44 + y.length * 2);
  pcm.write("RIFF", 0); pcm.writeUInt32LE(36 + y.length * 2, 4); pcm.write("WAVEfmt ", 8); pcm.writeUInt32LE(16, 16); pcm.writeUInt16LE(1, 20); pcm.writeUInt16LE(1, 22); pcm.writeUInt32LE(SR, 24); pcm.writeUInt32LE(SR * 2, 28); pcm.writeUInt16LE(2, 32); pcm.writeUInt16LE(16, 34); pcm.write("data", 36); pcm.writeUInt32LE(y.length * 2, 40);
  for (let i = 0; i < y.length; i++) pcm.writeInt16LE(Math.max(-32767, Math.min(32767, Math.round(y[i] * g * 32767))), 44 + i * 2);
  fs.writeFileSync(`public/sfx/${name}.wav`, pcm);
}
console.log("sfx written");
