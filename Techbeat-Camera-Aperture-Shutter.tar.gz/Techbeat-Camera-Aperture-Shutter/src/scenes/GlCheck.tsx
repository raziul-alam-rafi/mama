import React from 'react';
import {AbsoluteFill, useCurrentFrame, useVideoConfig} from 'remotion';
import {ThreeCanvas} from '@remotion/three';
import {theme} from '../theme';

/** Smallest possible WebGL proof: one lit, rotating cube. */
export const GlCheck: React.FC = () => {
  const frame = useCurrentFrame();
  const {width, height} = useVideoConfig();
  return (
    <AbsoluteFill style={{backgroundColor: theme.colors.bg}}>
      <ThreeCanvas width={width} height={height} camera={{fov: 40, position: [0, 0, 6]}}>
        <ambientLight intensity={0.6} />
        <directionalLight position={[3, 4, 5]} intensity={2} />
        <mesh rotation={[frame / 20, frame / 15, 0]}>
          <boxGeometry args={[2, 2, 2]} />
          <meshStandardMaterial color={theme.colors.primary} metalness={0.4} roughness={0.3} />
        </mesh>
      </ThreeCanvas>
    </AbsoluteFill>
  );
};
