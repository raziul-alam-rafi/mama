// timing.ts — the SRT is the ONLY clock. Everything is derived from it.
import { SRT_RAW } from "./data/srtRaw";
import { FPS } from "./config";

export type Cue = { n: number; start: number; end: number; text: string };
export type Word = { text: string; norm: string; start: number; end: number; cue: number };

const toSec = (s: string) => {
  const m = s.trim().match(/(\d+):(\d+):(\d+)[,.](\d+)/);
  if (!m) throw new Error("Bad SRT time: " + s);
  return +m[1] * 3600 + +m[2] * 60 + +m[3] + +m[4] / 1000;
};

export const cues: Cue[] = SRT_RAW.replace(/\r/g, "")
  .trim()
  .split(/\n\s*\n/)
  .map((block) => {
    const lines = block.split("\n");
    const [a, b] = lines[1].split("-->");
    return { n: +lines[0], start: toSec(a), end: toSec(b), text: lines.slice(2).join(" ").trim() };
  });

const normalize = (t: string) => t.replace(/[।,.?!]+$/u, "");

// Word timing: each cue's duration is shared between its words by character count.
export const words: Word[] = cues.flatMap((c, ci) => {
  const toks = c.text.split(/\s+/).filter(Boolean);
  const w = toks.map((t) => [...t].length + 1);
  const total = w.reduce((x, y) => x + y, 0);
  let acc = 0;
  return toks.map((t, i) => {
    const start = c.start + (acc / total) * (c.end - c.start);
    acc += w[i];
    const end = c.start + (acc / total) * (c.end - c.start);
    return { text: t, norm: normalize(t), start, end, cue: ci + 1 };
  });
});

/** Seconds at which a word/phrase (space-separated) is spoken. nth = which occurrence. */
export const T = (phrase: string, nth = 0): number => {
  const parts = phrase.split(/\s+/).map(normalize);
  let seen = 0;
  for (let i = 0; i + parts.length <= words.length; i++) {
    if (parts.every((p, j) => words[i + j].norm === p)) {
      if (seen === nth) return words[i].start;
      seen++;
    }
  }
  throw new Error(`SRT phrase not found: "${phrase}" (#${nth})`);
};

export const cueStart = (n: number) => cues[n - 1].start;
export const cueEnd = (n: number) => cues[n - 1].end;

export const TOTAL_SEC = cues[cues.length - 1].end;
export const TOTAL_FRAMES = Math.ceil(TOTAL_SEC * FPS);
export const sf = (sec: number, fps = FPS) => Math.round(sec * fps);

// Scenes follow cue boundaries (a scene may hold several cues).
export const SCENE_DEFS = [
  { id: "s1", cues: [1, 1] },
  { id: "s2", cues: [2, 3] },
  { id: "s3", cues: [4, 5] },
  { id: "s4", cues: [6, 8] },
  { id: "s5", cues: [9, 11] },
  { id: "s6", cues: [12, 14] },
] as const;

export const LEAD = 6; // visuals enter ~6 frames before the matching narration
export const OVERLAP = 12; // frames the outgoing scene lingers while the next enters

export type SceneId = (typeof SCENE_DEFS)[number]["id"];

export const SCENES = SCENE_DEFS.map((d, i) => {
  const startSec = cueStart(d.cues[0]);
  const endSec = cueEnd(d.cues[1]);
  const from = i === 0 ? 0 : Math.max(0, sf(startSec) - LEAD);
  return { id: d.id as SceneId, startSec, endSec, from };
}).map((s, i, arr) => {
  const next = arr[i + 1];
  const end = next ? next.from + OVERLAP : TOTAL_FRAMES;
  return { ...s, duration: end - s.from, last: !next };
});

export const sceneById = (id: SceneId) => SCENES.find((s) => s.id === id)!;
