import React from "react";
import { theme } from "../theme";
import { lerp } from "./Motion";

/** Window with curtains. open: 0 closed → 1 fully drawn aside. Light shaft width follows the gap. */
export const WindowScene: React.FC<{ width: number; open: number; uid?: string }> = ({ width, open, uid = "win" }) => {
  const VB = { w: 900, h: 760 };
  const wx = 150, wy = 70, ww = 600, wh = 400;
  const cw = lerp(300, 62, open); // each curtain width
  const gap = ww - cw * 2;
  const gx0 = wx + cw, gx1 = wx + ww - cw;
  const I = Math.max(0, gap / ww);
  const folds = (x: number, w: number, dir: 1 | -1) =>
    Array.from({ length: Math.max(2, Math.round(w / 22)) }).map((_, i, arr) => {
      const fx = x + (w / arr.length) * (i + 0.5);
      return <line key={i} x1={fx} x2={fx} y1={wy - 14} y2={wy + wh + 40} stroke={theme.colors.bgAlt} strokeOpacity={0.45} strokeWidth={5 + (i % 2) * 2} />;
    });
  return (
    <svg width={width} height={(width * VB.h) / VB.w} viewBox={`0 0 ${VB.w} ${VB.h}`}>
      <defs>
        <linearGradient id={`${uid}-wall`} x1="0" y1="0" x2="0" y2="1">
          <stop offset="0" stopColor={theme.colors.panel} />
          <stop offset="1" stopColor={theme.colors.bgAlt} />
        </linearGradient>
        <linearGradient id={`${uid}-sky`} x1="0" y1="0" x2="0" y2="1">
          <stop offset="0" stopColor={theme.colors.accentSoft} />
          <stop offset="1" stopColor={theme.colors.light} />
        </linearGradient>
        <linearGradient id={`${uid}-shaft`} x1="0" y1="0" x2="0" y2="1">
          <stop offset="0" stopColor={theme.colors.light} stopOpacity="0.55" />
          <stop offset="1" stopColor={theme.colors.light} stopOpacity="0.1" />
        </linearGradient>
        <linearGradient id={`${uid}-cur`} x1="0" y1="0" x2="1" y2="0">
          <stop offset="0" stopColor={theme.colors.primaryDeep} />
          <stop offset="0.5" stopColor={theme.colors.primary} />
          <stop offset="1" stopColor={theme.colors.primaryDeep} />
        </linearGradient>
        <clipPath id={`${uid}-room`}>
          <rect width={VB.w} height={VB.h} rx={30} />
        </clipPath>
        <clipPath id={`${uid}-glass`}>
          <rect x={wx} y={wy} width={ww} height={wh} />
        </clipPath>
      </defs>
      <g clipPath={`url(#${uid}-room)`}>
      {/* room */}
      <rect width={VB.w} height={560} fill={`url(#${uid}-wall)`} rx={0} />
      <rect y={560} width={VB.w} height={200} fill={theme.colors.bg} />
      <line x1={0} x2={VB.w} y1={560} y2={560} stroke={theme.colors.line} strokeWidth={4} />
      {/* outside */}
      <rect x={wx} y={wy} width={ww} height={wh} fill={`url(#${uid}-sky)`} />
      <g clipPath={`url(#${uid}-glass)`}>
        <circle cx={wx + 470} cy={wy + 110} r={56} fill="#FFF3D1" opacity={0.95} />
        <path d={`M${wx} ${wy + wh} L${wx + 150} ${wy + 270} L${wx + 290} ${wy + wh} Z`} fill={theme.colors.metalDark} opacity={0.55} />
        <path d={`M${wx + 200} ${wy + wh} L${wx + 400} ${wy + 240} L${wx + 600} ${wy + wh} Z`} fill={theme.colors.metalDark} opacity={0.7} />
      </g>
      {/* light shaft through the gap onto the floor */}
      {I > 0.02 && (
        <>
          <polygon points={`${gx0},${wy + wh} ${gx1},${wy + wh} ${gx1 + 120},700 ${gx0 - 120},700`} fill={`url(#${uid}-shaft)`} opacity={Math.min(1, I * 1.25)} />
          <ellipse cx={(gx0 + gx1) / 2} cy={650} rx={(gap / 2 + 110) * 0.95} ry={36} fill={theme.colors.light} opacity={0.5 * I} />
        </>
      )}
      {/* frame */}
      <rect x={wx - 12} y={wy - 12} width={ww + 24} height={wh + 24} fill="none" stroke={theme.colors.metal} strokeWidth={12} rx={6} />
      <line x1={wx + ww / 2} x2={wx + ww / 2} y1={wy} y2={wy + wh} stroke={theme.colors.metal} strokeWidth={8} opacity={0.9} />
      <line x1={wx} x2={wx + ww} y1={wy + wh / 2} y2={wy + wh / 2} stroke={theme.colors.metal} strokeWidth={8} opacity={0.9} />
      {/* curtain rod */}
      <rect x={wx - 60} y={wy - 40} width={ww + 120} height={10} rx={5} fill={theme.colors.metal} />
      {/* curtains */}
      <rect x={wx - 8} y={wy - 28} width={cw + 8} height={wh + 78} fill={`url(#${uid}-cur)`} rx={6} />
      <rect x={wx + ww - cw} y={wy - 28} width={cw + 8} height={wh + 78} fill={`url(#${uid}-cur)`} rx={6} />
      {folds(wx - 8, cw + 8, 1)}
      {folds(wx + ww - cw, cw + 8, -1)}
      </g>
      <rect width={VB.w} height={VB.h} rx={30} fill="none" stroke={theme.colors.line} strokeWidth={4} />
    </svg>
  );
};
