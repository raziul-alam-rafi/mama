// UI-ধাঁচের ছোট SFX সিন্থেসাইজ (ডিটারমিনিস্টিক)। চালান: npm run sfx
import fs from "node:fs";
import path from "node:path";

const SR = 44100;
const out = path.join(process.cwd(), "public", "sfx");
fs.mkdirSync(out, { recursive: true });

let seed = 12345;
const rnd = () => ((seed = (seed * 1664525 + 1013904223) >>> 0) / 4294967296) * 2 - 1;

const buf = (sec) => new Float32Array(Math.round(sec * SR));
const lowpass = (x, fc) => {
  const a = 1 - Math.exp((-2 * Math.PI * fc) / SR);
  let y = 0;
  return x.map((v) => (y += a * (v - y)));
};
const highpass = (x, fc) => {
  const lp = lowpass(x, fc);
  return x.map((v, i) => v - lp[i]);
};
const reverb = (x) => {
  const y = Float32Array.from(x);
  [[0.023, 0.16], [0.037, 0.1], [0.053, 0.06]].forEach(([d, g]) => {
    const n = Math.round(d * SR);
    for (let i = n; i < y.length; i++) y[i] += x[i - n] * g;
  });
  return y;
};
const fades = (x, inMs = 3, outMs = 12) => {
  const a = Math.round((inMs / 1000) * SR);
  const b = Math.round((outMs / 1000) * SR);
  for (let i = 0; i < a; i++) x[i] *= i / a;
  for (let i = 0; i < b; i++) x[x.length - 1 - i] *= i / b;
  return x;
};
const normalize = (x, peak = 0.8) => {
  let m = 0;
  for (const v of x) m = Math.max(m, Math.abs(v));
  return x.map((v) => (v / m) * peak);
};

const pop = () => {
  const x = buf(0.22);
  let ph = 0;
  for (let i = 0; i < x.length; i++) {
    const t = i / SR;
    const f = 180 + 360 * Math.exp(-t * 28);
    ph += (2 * Math.PI * f) / SR;
    x[i] = Math.sin(ph) * Math.exp(-t * 22) * Math.min(1, t / 0.003);
  }
  return x;
};
const click = () => {
  const x = buf(0.1);
  const n = Float32Array.from({ length: x.length }, () => rnd());
  const h = highpass(n, 2500);
  for (let i = 0; i < x.length; i++) {
    const t = i / SR;
    x[i] = h[i] * Math.exp(-t * 90) * 0.8 + Math.sin(2 * Math.PI * 1900 * t) * Math.exp(-t * 120) * 0.35;
  }
  return x;
};
const whoosh = () => {
  const len = 0.7;
  const x = buf(len);
  let low = 0, band = 0;
  for (let i = 0; i < x.length; i++) {
    const t = i / SR;
    const p = t / len;
    const fc = 350 + 3200 * Math.pow(p, 1.4);
    const f = 2 * Math.sin((Math.PI * fc) / SR);
    const q = 0.35;
    const n = rnd();
    low += f * band;
    const high = n - low - q * band;
    band += f * high;
    x[i] = band * Math.pow(Math.sin(Math.PI * p), 1.6);
  }
  return x;
};
const chime = () => {
  const x = buf(0.5);
  const parts = [[784, 1, 7], [1568, 0.45, 10], [2352, 0.22, 14], [1175, 0.3, 9]];
  for (let i = 0; i < x.length; i++) {
    const t = i / SR;
    let s = 0;
    for (const [f, a, d] of parts) s += Math.sin(2 * Math.PI * f * t) * a * Math.exp(-t * d);
    x[i] = s * Math.min(1, t / 0.004);
  }
  return x;
};
const thud = () => {
  const x = buf(0.3);
  let ph = 0;
  for (let i = 0; i < x.length; i++) {
    const t = i / SR;
    const f = 55 + 60 * Math.exp(-t * 18);
    ph += (2 * Math.PI * f) / SR;
    x[i] = Math.sin(ph) * Math.exp(-t * 12) * Math.min(1, t / 0.008);
  }
  return x;
};

const writeWav = (name, x) => {
  const data = Buffer.alloc(x.length * 2);
  x.forEach((v, i) => data.writeInt16LE(Math.max(-32768, Math.min(32767, Math.round(v * 32767))), i * 2));
  const h = Buffer.alloc(44);
  h.write("RIFF", 0); h.writeUInt32LE(36 + data.length, 4); h.write("WAVE", 8);
  h.write("fmt ", 12); h.writeUInt32LE(16, 16); h.writeUInt16LE(1, 20); h.writeUInt16LE(1, 22);
  h.writeUInt32LE(SR, 24); h.writeUInt32LE(SR * 2, 28); h.writeUInt16LE(2, 32); h.writeUInt16LE(16, 34);
  h.write("data", 36); h.writeUInt32LE(data.length, 40);
  fs.writeFileSync(path.join(out, name + ".wav"), Buffer.concat([h, data]));
};

const kit = { pop, click, whoosh, chime, thud };
const cutoff = { pop: 6500, click: 9000, whoosh: 7500, chime: 8000, thud: 3000 };
for (const [name, fn] of Object.entries(kit)) {
  let x = fn();
  x = lowpass(x, cutoff[name]); // হালকা low-pass
  x = reverb(x); // খুব ছোট reverb
  x = fades(Float32Array.from(x));
  x = normalize(x, 0.8);
  writeWav(name, x);
  let pk = 0, clip = 0;
  for (const v of x) { pk = Math.max(pk, Math.abs(v)); if (Math.abs(v) >= 0.999) clip++; }
  console.log(`${name}.wav  ${(x.length / SR).toFixed(2)}s  peak ${pk.toFixed(2)}  clipped ${clip}`);
}
