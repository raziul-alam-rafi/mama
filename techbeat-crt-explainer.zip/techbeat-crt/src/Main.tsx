import React from "react";
import { AbsoluteFill, Sequence, useCurrentFrame } from "remotion";
import { theme } from "./theme";
import { SCENES } from "./timeline";
import { BgMesh, Grade, Grain, SceneShell, Vignette, ip } from "./components/kit";
import { PreviewAudio, Sfx } from "./components/Audio";
import { Scene1 } from "./scenes/Scene1";
import { Scene2 } from "./scenes/Scene2";
import { Scene3 } from "./scenes/Scene3";
import { Scene4 } from "./scenes/Scene4";
import { Scene5 } from "./scenes/Scene5";

const SCENE_COMPONENTS = [Scene1, Scene2, Scene3, Scene4, Scene5];

/** Light sweep that hides each cut. */
const Sweep: React.FC<{ len: number }> = ({ len }) => {
  const frame = useCurrentFrame();
  const x = ip(frame, [0, len], [-2400, 2400]);
  const o = ip(frame, [0, len * 0.5, len], [0, 1, 0], theme.ease.out);
  return (
    <AbsoluteFill style={{ pointerEvents: "none", opacity: o * 0.7 }}>
      <div
        style={{
          position: "absolute",
          top: -300,
          bottom: -300,
          width: 520,
          left: 960 - 260,
          transform: `translateX(${x}px) rotate(-14deg)`,
          background: `linear-gradient(90deg, transparent, ${theme.colors.hero}55, ${theme.colors.text}33, transparent)`,
          filter: "blur(30px)",
        }}
      />
    </AbsoluteFill>
  );
};

export const Main: React.FC = () => {
  return (
    <AbsoluteFill style={{ background: theme.colors.bg }}>
      {/* layer 1: background mesh */}
      <BgMesh />
      {/* layers 2–3: assets + graphics (scenes) */}
      {SCENES.map((s, i) => {
        const Comp = SCENE_COMPONENTS[i];
        return (
          <Sequence key={i} from={s.from} durationInFrames={s.dur}>
            <SceneShell dur={s.dur} first={i === 0} last={i === SCENES.length - 1}>
              <Comp dur={s.dur} cs={s.cs} cd={s.cd} />
            </SceneShell>
          </Sequence>
        );
      })}
      {SCENES.slice(1).map((s, i) => (
        <Sequence key={`sw${i}`} from={Math.max(0, s.from - 2)} durationInFrames={14}>
          <Sweep len={14} />
        </Sequence>
      ))}
      {/* layer 4: color grade; layer 5: grain + vignette */}
      <Grade />
      <Grain />
      <Vignette />
      {/* audio: SFX always; voice-over preview only in Studio (if the file exists) */}
      <Sfx />
      <PreviewAudio />
    </AbsoluteFill>
  );
};
