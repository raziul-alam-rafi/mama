import React, { useEffect, useState } from "react";
import { Audio, continueRender, delayRender, getRemotionEnvironment, staticFile } from "remotion";
import { PREVIEW_VOICEOVER, VOICEOVER_IN_RENDER } from "../config";

/** Plays public/voiceover.mp3 if it exists (Studio preview). Silently skipped when the file is missing. */
export const PreviewAudio: React.FC = () => {
  const rendering = getRemotionEnvironment().isRendering;
  const enabled = PREVIEW_VOICEOVER && (!rendering || VOICEOVER_IN_RENDER);
  const [handle] = useState(() => (enabled && rendering ? delayRender("check voiceover.mp3") : null));
  const [ok, setOk] = useState(false);

  useEffect(() => {
    if (!enabled) return;
    let dead = false;
    fetch(staticFile("voiceover.mp3"), { method: "HEAD" })
      .then((r) => {
        const type = r.headers.get("content-type") || "";
        if (!dead) setOk(r.ok && (type.includes("audio") || type.includes("mpeg") || type.includes("octet-stream")));
      })
      .catch(() => undefined)
      .finally(() => {
        if (handle !== null) continueRender(handle);
      });
    return () => {
      dead = true;
    };
  }, [enabled, handle]);

  if (!enabled || !ok) return null;
  return <Audio src={staticFile("voiceover.mp3")} volume={1} />;
};
