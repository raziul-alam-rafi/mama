// Flags for the optional voiceover preview.
// Put the narration at public/voiceover.mp3 — if the file is missing the preview simply stays silent.
export const PREVIEW_VOICEOVER = true; // play voiceover.mp3 inside Remotion Studio
export const VOICEOVER_IN_RENDER = false; // keep false: the MP4 contains SFX only. Set true to bake the VO in.
