import React from "react";
import { AbsoluteFill } from "remotion";
import { theme } from "../theme";
import { useScene } from "../SceneContext";
import { Card, Chip, ip, clamp01, WordReveal, Entrance, mono } from "../components/Motion";
import { SensorGrid } from "../components/SensorGrid";
import { ShutterFront } from "../components/ShutterFront";
import { Sfx } from "../components/Sfx";

const FilmStrip: React.FC = () => (
  <svg width={150} height={420} viewBox="0 0 150 420">
    <rect width={150} height={420} rx={6} fill={theme.colors.metalDark} />
    {Array.from({ length: 14 }).map((_, i) => (
      <g key={i}>
        <rect x={10} y={14 + i * 29} width={14} height={16} rx={3} fill={theme.colors.bg} />
        <rect x={126} y={14 + i * 29} width={14} height={16} rx={3} fill={theme.colors.bg} />
      </g>
    ))}
    <rect x={36} y={30} width={78} height={160} rx={4} fill={theme.colors.accentSoft} opacity={0.9} />
    <rect x={36} y={222} width={78} height={160} rx={4} fill={theme.colors.light} opacity={0.6} />
  </svg>
);

// Scene 7 · Digital (cues 9–10): film is replaced by a sensor; shutter can be mechanical or electronic (rolling pixel rows).
export const DigitalSplit: React.FC = () => {
  const S = useScene();
  const f = S.frame;
  const c9 = Math.max(S.cue(9), 0);
  const fMech = S.word(9, "যান্ত্রিক");
  const fElec = S.word(10, "Electronic");
  const [s1] = mono([fMech]);

  const filmOut = ip(f, [c9 + 4, c9 + 26], [1, 0]);
  const chipIn = ip(f, [c9 + 10, c9 + 40], [0, 1]);
  const stage1 = 1 - ip(f, [s1 - 4, s1 + 12], [0, 1]);

  // mechanical shutter cycle (left)
  const tm = Math.max(0, f - fMech) % 84;
  const p1 = ip(tm, [10, 24], [0, 1]);
  const p2 = ip(tm, [48, 62], [0, 1]);

  // electronic rolling readout (right)
  const te = Math.max(0, f - fElec) % 90;
  const rows = 8, cols = 11;
  const rowLevel = (r: number) => ip(te, [r * 4, r * 4 + 12], [0, 1]) * (1 - ip(te, [r * 4 + 34, r * 4 + 46], [0, 1]));
  const level = (_c: number, r: number) => rowLevel(r) * 0.95;
  const band = (r: number) => (rowLevel(r) > 0.2 && rowLevel(r) < 1 ? theme.colors.signal : rowLevel(r) >= 1 ? theme.colors.signal : null);

  const chipLevel = (c: number, r: number) => 0.25 + 0.5 * Math.max(0, Math.sin((f - c9) / 10 - c * 0.5 + r * 0.4)) * chipIn;

  return (
    <AbsoluteFill>
      {/* stage 1 — film → digital sensor */}
      <div style={{ opacity: stage1 }}>
        <div style={{ position: "absolute", left: 0, right: 0, top: 110 }}>
          <WordReveal text="আধুনিক Digital ক্যামেরা" delay={c9 + 2} per={5} size={96} align="center" highlight={{ Digital: theme.colors.signal }} />
        </div>
        <div style={{ position: "absolute", left: 640, top: 380, opacity: filmOut, transform: `translateX(${(1 - filmOut) * -120}px)` }}>
          <FilmStrip />
        </div>
        <div style={{ position: "absolute", left: 960 - 330, top: 400, opacity: chipIn, transform: `scale(${0.85 + 0.15 * chipIn})` }}>
          <div style={{ padding: 28, borderRadius: 30, background: theme.colors.panel, border: `3px solid ${theme.colors.signal}`, boxShadow: `0 40px 80px -30px ${theme.colors.shadow}` }}>
            <SensorGrid cols={11} rows={8} cell={52} level={chipLevel} />
          </div>
        </div>
      </div>

      {/* stage 2 — mechanical vs electronic */}
      <Card x={60} y={200} w={850} h={760} delay={fMech - 4} border={theme.colors.accent}>
        <div style={{ position: "absolute", left: 34, top: 30 }}>
          <Chip text="যান্ত্রিক Shutter" tone="accent" size={50} delay={fMech} />
        </div>
        <div style={{ position: "absolute", left: 175, top: 230 }}>
          <ShutterFront w={500} h={420} p1={p1} p2={p2} uid="ds" />
        </div>
      </Card>
      <Card x={1010} y={200} w={850} h={760} delay={fElec - 4} border={theme.colors.signal}>
        <div style={{ position: "absolute", left: 34, top: 30 }}>
          <Chip text="Electronic Shutter" tone="signal" size={50} delay={fElec} />
        </div>
        <div style={{ position: "absolute", left: 128, top: 232, padding: 20, borderRadius: 24, background: theme.colors.bgAlt, border: `2px solid ${theme.colors.line}` }}>
          <SensorGrid cols={cols} rows={rows} cell={54} level={level} band={band} />
        </div>
      </Card>

      <Sfx name="whoosh" at={c9 + 6} vol={0.6} />
      <Sfx name="chime" at={c9 + 24} vol={0.8} />
      <Sfx name="pop" at={fMech - 4} />
      <Sfx name="pop" at={fElec - 4} rate={1.08} />
    </AbsoluteFill>
  );
};
