// সিন ২ — আলোর পথ: সূর্য → আপেল → চোখ → ক্যামেরা (Process Flow + Glass Cards) · cue 3–4
import React from "react";
import { AbsoluteFill, interpolate } from "remotion";
import { Beam, RayLayer } from "../components/Rays";
import { AppleIcon, CameraIcon, EyeIcon, SunIcon } from "../components/Icons";
import { Breathe, Chip, Enter, Glass, Sweep, Words, usePop, useProgress } from "../components/Primitives";
import { Sfx } from "../components/audio";
import { at } from "../timeline";
import { theme } from "../theme";

const c = theme.colors;
const SI = 1;
const CARD = { w: 400, h: 500, top: 250 };
const XS = [330, 960, 1590]; // কার্ডের কেন্দ্র-x
const BEAM_Y = CARD.top + 190;

const Label: React.FC<{ text: string; delay: number; exitAt?: number }> = ({ text, delay, exitAt }) => (
  <Enter delay={delay} y={22} exitAt={exitAt} style={{ position: "absolute", left: 0, right: 0, bottom: 44, display: "flex", justifyContent: "center" }}>
    <div style={{ fontFamily: theme.fonts.display, fontWeight: theme.weight.heavy, fontSize: 58, lineHeight: 1.25, letterSpacing: 0, color: c.text }}>{text}</div>
  </Enter>
);

const NodeCard: React.FC<{ cx: number; delay: number; children: React.ReactNode; glow?: boolean }> = ({ cx, delay, children, glow }) => (
  <div style={{ position: "absolute", left: cx - CARD.w / 2, top: CARD.top }}>
    <Enter delay={delay} y={60} scaleFrom={0.88} preset={theme.spring.bouncy}>
      <Glass glow={glow} style={{ width: CARD.w, height: CARD.h }}>
        {children}
      </Glass>
    </Enter>
  </div>
);

export const S2Apple: React.FC = () => {
  const tApple = at(SI, 3, "আপেলের");
  const tSun = at(SI, 3, "সূর্যের");
  const tHit = at(SI, 3, "পড়ছে");
  const tRefl = at(SI, 3, "প্রতিফলিত");
  const tEye = at(SI, 4, "আপনার");
  const tCam = at(SI, 4, "ক্যামেরার");
  const tBut = at(SI, 4, "কিন্তু");

  // বিম: সূর্য→আপেল, আপেল→চোখ/ক্যামেরা
  const b1 = useProgress(tHit, 22);
  const b2 = useProgress(tRefl, 26);
  // ফ্লিপ: চোখ → ক্যামেরা
  const flip = useProgress(tCam, 22, theme.ease.inOut);
  const eyeRot = interpolate(flip, [0, 0.5], [0, -90], { extrapolateRight: "clamp" });
  const camRot = interpolate(flip, [0.5, 1], [90, 0], { extrapolateLeft: "clamp" });
  const pulse = usePop(tCam + 14, theme.spring.bouncy);
  const eyeLook = interpolate(usePop(tEye + 8, theme.spring.smooth), [0, 1], [-10, 6]);

  return (
    <AbsoluteFill>
      {/* শিরোনাম */}
      <div style={{ position: "absolute", top: 78, left: 0, right: 0, display: "flex", justifyContent: "center" }}>
        <Words
          text="প্রতিফলিত আলো" delay={tRefl} size={84} align="center"
          wordStyle={(w) => (w === "আলো" ? { color: c.accent } : {})}
        />
      </div>

      {/* বিম (কার্ডের নিচের স্তর) */}
      <RayLayer>
        <Beam id="s2-b1" pts={[[XS[0] + CARD.w / 2 - 20, BEAM_Y], [XS[1] - CARD.w / 2 + 20, BEAM_Y]]} p={b1} width={8} />
        <Beam id="s2-b2" pts={[[XS[1] + CARD.w / 2 - 20, BEAM_Y], [XS[2] - CARD.w / 2 + 20, BEAM_Y]]} p={b2} width={8} />
      </RayLayer>

      {/* সূর্য */}
      <NodeCard cx={XS[0]} delay={tSun}>
        <div style={{ position: "absolute", left: 0, right: 0, top: 70, display: "flex", justifyContent: "center" }}>
          <Breathe><SunIcon size={250} delay={tSun + 4} /></Breathe>
        </div>
        <Label text="সূর্যের আলো" delay={tSun + 8} />
      </NodeCard>

      {/* আপেল */}
      <NodeCard cx={XS[1]} delay={tApple} glow>
        <div style={{ position: "absolute", left: 0, right: 0, top: 80, display: "flex", justifyContent: "center" }}>
          <Breathe phase={1}><AppleIcon size={230} uid="s2" /></Breathe>
        </div>
        <Label text="লাল আপেল" delay={tApple + 8} />
      </NodeCard>

      {/* চোখ ⇄ ক্যামেরা */}
      <NodeCard cx={XS[2]} delay={tEye}>
        <div style={{ position: "absolute", left: 0, right: 0, top: 70, height: 270, display: "flex", justifyContent: "center", perspective: 1200 }}>
          <div style={{ position: "absolute", transform: `rotateY(${eyeRot}deg)`, opacity: flip < 0.5 ? 1 : 0 }}>
            <EyeIcon size={260} look={eyeLook} />
          </div>
          <div style={{ position: "absolute", transform: `rotateY(${camRot}deg) scale(${interpolate(pulse, [0, 1], [0.94, 1])})`, opacity: flip >= 0.5 ? 1 : 0 }}>
            <CameraIcon size={260} />
          </div>
        </div>
        <Label text="আপনার চোখ" delay={tEye + 8} exitAt={tCam - 2} />
        <Label text="ক্যামেরা" delay={tCam + 10} />
      </NodeCard>

      {/* সমস্যার ইঙ্গিত */}
      <div style={{ position: "absolute", left: 0, right: 0, bottom: 112, display: "flex", justifyContent: "center" }}>
        <Enter delay={tBut} y={30}>
          <Chip text="কিন্তু এখানে একটা সমস্যা" size={48} tone="accent" />
        </Enter>
      </div>

      <Sfx name="pop" at={tApple - 2} />
      <Sfx name="pop" at={tSun - 2} n={1} />
      <Sfx name="whoosh-soft" at={tRefl - 2} />
      <Sfx name="pop" at={tEye - 2} n={2} />
      <Sfx name="chime" at={tCam + 8} />
      <Sfx name="click" at={tBut} n={1} />
    </AbsoluteFill>
  );
};
