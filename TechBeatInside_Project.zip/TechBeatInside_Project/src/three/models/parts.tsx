import React, {useMemo} from 'react';
import * as THREE from 'three';
import {RoundedBoxGeometry} from 'three/examples/jsm/geometries/RoundedBoxGeometry.js';
import {mergeGeometries} from 'three/examples/jsm/utils/BufferGeometryUtils.js';
import {blobShadow} from '../materials/textures';

type V3 = [number, number, number];

/** Rounded box with the material passed as children. */
export const RBox: React.FC<{
  size: V3;
  radius?: number;
  position?: V3;
  rotation?: V3;
  children?: React.ReactNode;
  name?: string;
}> = ({size, radius = 0.02, position, rotation, children, name}) => {
  const geo = useMemo(
    () => new RoundedBoxGeometry(size[0], size[1], size[2], 4, Math.min(radius, Math.min(...size) / 2 - 0.001)),
    [size[0], size[1], size[2], radius],
  );
  return (
    <mesh geometry={geo} position={position} rotation={rotation} name={name}>
      {children}
    </mesh>
  );
};

/** A cylinder between two points (struts, rods, legs). */
export const Beam: React.FC<{
  a: V3;
  b: V3;
  r?: number;
  segments?: number;
  children?: React.ReactNode;
}> = ({a, b, r = 0.02, segments = 12, children}) => {
  const {pos, quat, len} = useMemo(() => {
    const A = new THREE.Vector3(...a);
    const B = new THREE.Vector3(...b);
    const d = B.clone().sub(A);
    const q = new THREE.Quaternion().setFromUnitVectors(new THREE.Vector3(0, 1, 0), d.clone().normalize());
    return {pos: A.clone().add(B).multiplyScalar(0.5), quat: q, len: d.length()};
  }, [a.join(), b.join()]);
  return (
    <mesh position={pos} quaternion={quat}>
      <cylinderGeometry args={[r, r, len, segments]} />
      {children}
    </mesh>
  );
};

/** Merged lattice of beams, one draw call. */
export function beamGeometry(list: {a: V3; b: V3; r: number}[], segments = 6) {
  const geos = list.map(({a, b, r}) => {
    const A = new THREE.Vector3(...a);
    const B = new THREE.Vector3(...b);
    const d = B.clone().sub(A);
    const g = new THREE.CylinderGeometry(r, r, d.length(), segments);
    const m = new THREE.Matrix4().compose(
      A.clone().add(B).multiplyScalar(0.5),
      new THREE.Quaternion().setFromUnitVectors(new THREE.Vector3(0, 1, 0), d.clone().normalize()),
      new THREE.Vector3(1, 1, 1),
    );
    g.applyMatrix4(m);
    return g;
  });
  return mergeGeometries(geos)!;
}

/** Soft contact-shadow blob on the ground/floor. */
export const ContactShadow: React.FC<{position: V3; size: V3 | [number, number]; opacity?: number}> = ({
  position,
  size,
  opacity = 1,
}) => (
  <mesh position={position} rotation={[-Math.PI / 2, 0, 0]} renderOrder={1}>
    <planeGeometry args={[size[0], size[1]]} />
    <meshBasicMaterial map={blobShadow()} transparent opacity={opacity} depthWrite={false} toneMapped={false} />
  </mesh>
);
