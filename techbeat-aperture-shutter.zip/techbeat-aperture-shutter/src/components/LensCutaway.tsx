import React from "react";
import { useCurrentFrame } from "remotion";
import { theme } from "../theme";
import { lerp, clamp01 } from "./Motion";
import { G, RAY_YS, irisHalf, partial, passFraction, toPts, yAtIris, Pt } from "./optics";

/**
 * Side cutaway of a lens + camera body (simplified schematic).
 * Parallel rays from a distant subject are refracted by the front group, limited by the aperture blades,
 * and converge on the sensor. explode (0..1) separates the parts along the optical axis.
 */
export const LensCutaway: React.FC<{
  width: number;
  open: number;
  prog?: number; // 0..1 ray travel
  explode?: number;
  parts?: number; // 0..1 assembly reveal
  shutter?: [number, number] | null;
  subject?: boolean;
  highlightIris?: boolean;
  measure?: number; // 0..1 opacity of opening bracket
  sensorPulse?: number; // 0..1
  showSensorGlow?: boolean;
  uid?: string;
}> = ({ width, open, prog = 0, explode = 0, parts = 1, shutter = null, subject = false, highlightIris = false, measure = 0, sensorPulse = 0, showSensorGlow = true, uid = "lc" }) => {
  const frame = useCurrentFrame();
  const half = irisHalf(open);
  const VB = { x: -260, y: -290, w: 1400, h: 580 };
  const flow = -(frame * 7);
  const ex = explode;
  const partOp = clamp01(parts);

  const rays = RAY_YS.map((y0) => {
    const yI = yAtIris(y0);
    const blockedIris = Math.abs(yI) > half;
    const blockedShutter = shutter ? !(shutter[0] <= 0 && 0 <= shutter[1]) : false;
    const full: Pt[] = [[-90, y0], [G.XF - 14 * 0, y0], [G.XI, yI], [G.XS, 0]];
    const path: Pt[] = blockedIris ? full.slice(0, 3) : blockedShutter ? [[-90, y0], [G.XF, y0], [G.XI, yI], [G.XSH - 6, yAtIris(y0) * 0.1]] : full;
    return { y0, blocked: blockedIris, path };
  });

  const pf = passFraction(open);
  const reach = clamp01((prog - 0.82) / 0.18);
  const glow = showSensorGlow ? pf * reach * (shutter && !(shutter[0] <= 0 && 0 <= shutter[1]) ? 0 : 1) : 0;

  const glass = (id: string) => `url(#${uid}-${id})`;
  const blade = (sign: 1 | -1, dx: number, dark: boolean) => {
    const y0 = sign * 192, y1 = sign * (half + 12), y2 = sign * half;
    const x = G.XI + dx;
    const pts = `${x - 16},${y0} ${x + 16},${y0} ${x + 16},${y1} ${x + 4},${y2} ${x - 7},${y2}`;
    return (
      <polygon
        points={pts}
        fill={dark ? theme.colors.metalDark : glass("metal")}
        stroke={highlightIris ? theme.colors.accent : theme.colors.bgAlt}
        strokeWidth={highlightIris ? 3.5 : 2}
        strokeLinejoin="round"
      />
    );
  };

  return (
    <svg width={width} height={(width * VB.h) / VB.w} viewBox={`${VB.x} ${VB.y} ${VB.w} ${VB.h}`} style={{ overflow: "visible" }}>
      <defs>
        <linearGradient id={`${uid}-metal`} x1="0" y1="0" x2="1" y2="0">
          <stop offset="0" stopColor={theme.colors.metalDark} />
          <stop offset="0.5" stopColor={theme.colors.metal} />
          <stop offset="1" stopColor={theme.colors.metalDark} />
        </linearGradient>
        <linearGradient id={`${uid}-glass`} x1="0" y1="0" x2="1" y2="1">
          <stop offset="0" stopColor={theme.colors.primarySoft} stopOpacity="0.85" />
          <stop offset="1" stopColor={theme.colors.primaryDeep} stopOpacity="0.75" />
        </linearGradient>
        <linearGradient id={`${uid}-body`} x1="0" y1="0" x2="0" y2="1">
          <stop offset="0" stopColor={theme.colors.panelHi} />
          <stop offset="1" stopColor={theme.colors.panel} />
        </linearGradient>
        <pattern id={`${uid}-hatch`} width="9" height="9" patternUnits="userSpaceOnUse" patternTransform="rotate(45)">
          <line x1="0" y1="0" x2="0" y2="9" stroke={theme.colors.metalDark} strokeWidth="2.5" />
        </pattern>
        <radialGradient id={`${uid}-sg`} cx="0.5" cy="0.5" r="0.5">
          <stop offset="0" stopColor={theme.colors.accentSoft} stopOpacity="0.95" />
          <stop offset="1" stopColor={theme.colors.light} stopOpacity="0" />
        </radialGradient>
      </defs>

      {/* subject */}
      {subject && (
        <g opacity={partOp} transform="translate(-205,40)">
          <rect x={-8} y={20} width={16} height={70} rx={4} fill={theme.colors.metalDark} />
          <circle cx={0} cy={-14} r={42} fill={theme.colors.signal} opacity={0.85} />
          <circle cx={-26} cy={14} r={28} fill={theme.colors.signal} opacity={0.7} />
          <circle cx={28} cy={12} r={30} fill={theme.colors.signal} opacity={0.75} />
        </g>
      )}

      {/* camera body */}
      <g opacity={partOp}>
        <rect x={640} y={-250} width={400} height={500} rx={40} fill={glass("body")} stroke={theme.colors.line} strokeWidth={4} />
        <rect x={654} y={-236} width={372} height={472} rx={30} fill={theme.colors.bg} opacity={0.9} />
        <rect x={640} y={-250} width={20} height={500} fill={`url(#${uid}-hatch)`} opacity={0.35} />
      </g>

      {/* barrel */}
      <g opacity={partOp}>
        <rect x={60} y={-208} width={650} height={416} rx={24} fill={theme.colors.bgAlt} stroke={theme.colors.metalDark} strokeWidth={4} />
        <rect x={60} y={-208} width={650} height={20} fill={`url(#${uid}-hatch)`} opacity={0.5} />
        <rect x={60} y={188} width={650} height={20} fill={`url(#${uid}-hatch)`} opacity={0.5} />
      </g>

      {/* glass elements */}
      <g transform={`translate(${-150 * ex},0)`} opacity={partOp}>
        <path d="M128 -168 Q80 0 128 168 L152 168 Q200 0 152 -168 Z" fill={glass("glass")} stroke={theme.colors.primarySoft} strokeWidth={3} />
        <path d="M226 -146 Q206 0 226 146 L242 146 Q264 0 242 -146 Z" fill={glass("glass")} stroke={theme.colors.primarySoft} strokeWidth={2.5} opacity={0.9} />
      </g>
      <g transform={`translate(${150 * ex},0)`} opacity={partOp}>
        <path d="M600 -128 Q628 0 600 128 L618 128 Q646 0 618 -128 Z" fill={glass("glass")} stroke={theme.colors.primarySoft} strokeWidth={2.5} opacity={0.9} />
      </g>

      {/* iris blades — dark back layer + front layer for depth */}
      <g opacity={partOp}>
        <g transform={`translate(0,${-80 * ex})`}>{blade(-1, 10, true)}{blade(-1, 0, false)}</g>
        <g transform={`translate(0,${80 * ex})`}>{blade(1, 10, true)}{blade(1, 0, false)}</g>
        {/* opening bracket */}
        <g opacity={measure * (1 - ex)}>
          <line x1={G.XI - 52} x2={G.XI - 52} y1={-half} y2={half} stroke={theme.colors.accent} strokeWidth={4} strokeDasharray="10 8" />
          <path d={`M${G.XI - 64} ${-half + 14} L${G.XI - 52} ${-half} L${G.XI - 40} ${-half + 14}`} fill="none" stroke={theme.colors.accent} strokeWidth={4} strokeLinecap="round" strokeLinejoin="round" />
          <path d={`M${G.XI - 64} ${half - 14} L${G.XI - 52} ${half} L${G.XI - 40} ${half - 14}`} fill="none" stroke={theme.colors.accent} strokeWidth={4} strokeLinecap="round" strokeLinejoin="round" />
        </g>
      </g>

      {/* shutter curtains (optional) */}
      {shutter && (
        <g opacity={partOp}>
          <rect x={G.XSH - 6} y={-180} width={12} height={Math.max(0, shutter[0] + 180)} fill={glass("metal")} stroke={theme.colors.bgAlt} strokeWidth={1.5} />
          <rect x={G.XSH - 6} y={shutter[1]} width={12} height={Math.max(0, 180 - shutter[1])} fill={glass("metal")} stroke={theme.colors.bgAlt} strokeWidth={1.5} />
        </g>
      )}

      {/* sensor */}
      <g opacity={partOp} transform={`translate(${60 * ex},0)`}>
        <rect x={G.XS - 9} y={-165} width={18} height={330} rx={5} fill={theme.colors.panelHi} stroke={theme.colors.signal} strokeWidth={3} />
        {Array.from({ length: 11 }).map((_, i) => (
          <line key={i} x1={G.XS - 9} x2={G.XS + 9} y1={-150 + i * 30} y2={-150 + i * 30} stroke={theme.colors.signal} strokeOpacity={0.5} strokeWidth={2} />
        ))}
        <ellipse cx={G.XS} cy={0} rx={30 + glow * 70 + sensorPulse * 40} ry={30 + glow * 120 + sensorPulse * 50} fill={`url(#${uid}-sg)`} opacity={Math.min(1, glow + sensorPulse * 0.8)} />
      </g>

      {/* rays: base line + flowing dashes */}
      {prog > 0 &&
        rays.map((r, i) => {
          const p = partial(r.path, prog);
          const col = theme.colors.light;
          const end = p[p.length - 1];
          return (
            <g key={i}>
              <polyline points={toPts(p)} fill="none" stroke={col} strokeWidth={3} strokeOpacity={r.blocked ? 0.25 : 0.38} strokeLinecap="round" strokeLinejoin="round" />
              <polyline points={toPts(p)} fill="none" stroke={col} strokeWidth={4.5} strokeOpacity={r.blocked ? 0.55 : 1} strokeDasharray="16 34" strokeDashoffset={flow - i * 7} strokeLinecap="round" strokeLinejoin="round" />
              {r.blocked && prog > 0.5 && <circle cx={r.path[2][0]} cy={r.path[2][1]} r={6} fill={theme.colors.accent} opacity={0.9} />}
              {!r.blocked && prog < 0.99 && <circle cx={end[0]} cy={end[1]} r={5} fill={theme.colors.accentSoft} />}
            </g>
          );
        })}
    </svg>
  );
};

/** px position of a local lens-cutaway point inside an svg of given width */
export const lensPx = (x: number, y: number, width: number) => {
  const k = width / 1400;
  return { x: (x + 260) * k, y: (y + 290) * k, k };
};
export { lerp };
