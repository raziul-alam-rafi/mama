// Single place for all tunable production constants (colors, lighting, timing, flags).
export const FPS = 30;
export const WIDTH = 1920; // 4K: use `npm run render:4k` (scale=2)
export const HEIGHT = 1080;

// Visuals start this many frames BEFORE the narrator says the related words.
export const LEAD_FRAMES = 5;

// ---- Flags ----
export const SHOW_CAPTIONS = true; // burn SRT text at the bottom
export const SHOW_EXPLAINER_TAGS = true; // "visualization" tag on non-physical overlays
// Voiceover: put your narration at public/audio/voiceover.mp3 (optional).
export const VOICEOVER_FILE = 'audio/voiceover.mp3';
export const PLAY_VOICEOVER_IN_RENDER = true; // false => narration only in Studio preview

export const COLORS = {
  ink: '#05070b',
  signal: '#5ad1ff', // electrical / RF explanatory overlays only
  signalHot: '#d8f5ff',
  warm: '#ffb866',
  caption: '#ffffff',
  captionShade: 'rgba(5,7,11,0.62)',
  tag: '#9fe3ff',
  skyTop: '#070d1f',
  skyMid: '#1b2447',
  skyHorizon: '#c0714a',
  ground: '#17231a',
  wall: '#c9b79c',
  wood: '#6b4426',
};

// Lighting calibration (physically based units, r169). If a shot looks too dark / bright,
// change these numbers first.
export const LIGHT = {
  exposure: 1.0,
  envIntensity: 0.45,
  hemi: 0.55,
  moon: 0.9,
  stadiumPoint: 3.2,
  roomLamp: 4.5,
  roomFill: 0.9,
  tvGlow: 2.4,
};

export const FONT_WEIGHTS = ['500', '700'] as const;
