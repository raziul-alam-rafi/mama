import React from "react";
import {interpolate} from "remotion";
import {theme} from "../theme";
import {E} from "../events";
import {Leader, Pill, baseText, lerp, useFx} from "../ui";
import {
  AMBER_CELL,
  COLS,
  FACE_H,
  FACE_W,
  FACE_X,
  FACE_Y,
  GridCells,
  ROWS,
  cellCenter,
} from "../components/sensor";

const AXIS = 545;
const SUBJECT_X = 140;
const LENS_X = 478;
const SENSOR_X = 1266;
const PTS = [
  {y0: 489, label: "top"},
  {y0: 590, label: "bottom"},
];
// image of each object point (inverted through the lens)
const k = (SENSOR_X - LENS_X) / (LENS_X - SUBJECT_X);
const imgY = (y0: number) => AXIS - (y0 - AXIS) * k;
const OFFS = [-70, 0, 70];

const lensPath = (x: number, h: number, w: number) =>
  `M ${x} ${AXIS - h} C ${x + w} ${AXIS - h / 2} ${x + w} ${AXIS + h / 2} ${x} ${AXIS + h} C ${x - w} ${AXIS + h / 2} ${x - w} ${AXIS - h / 2} ${x} ${AXIS - h} Z`;

export const SceneSensor: React.FC<{dur: number}> = ({dur}) => {
  const {frame, ramp, pop} = useFx();
  const ev = E.sensor;
  if (frame >= dur - 10) return null; // hand-off to the next scene (identical grid)

  const draw = ramp(0, 34, theme.ease.inOut);
  const rayDraw = ramp(ev.rays, 30, theme.ease.inOut);
  const rayFade = 1 - ramp(ev.pivot, 14);
  const pv = ramp(ev.pivot, ev.pivotDur, theme.ease.inOut);
  const camOut = 1 - ramp(ev.pivot, 30);
  const sensorPop = pop(ev.sensor, theme.spring.bouncy);

  // sensor face: edge-on slab -> face-on grid
  const angle = lerp(88, 0, pv);
  const sc = lerp(0.47, 1, pv);
  const dx = lerp(320, 0, pv);
  const dy = lerp(-5, 0, pv);
  const faceOpacity = Math.min(1, sensorPop);
  const cellsOn = (c: number, r: number) =>
    ramp(ev.cells + (c + r) * 1.3, 14, theme.ease.out);

  // shimmer wave across cells (cue 2: "side by side")
  const wx = interpolate(frame, [ev.wave, ev.wave + 60], [-3, COLS + 3], {
    easing: theme.ease.soft,
    extrapolateLeft: "clamp",
    extrapolateRight: "clamp",
  });
  const glow = (c: number) => Math.exp(-Math.pow(c - wx, 2) / 5) * 0.9;

  const amber = AMBER_CELL;
  const ac = cellCenter(amber.c, amber.r);
  const aP = pop(ev.amber, theme.spring.bouncy);

  // "Image Sensor" pill travels from beside the slab to the top
  const labelMove = ramp(ev.pivot + 10, 36, theme.ease.inOut);
  const imgPillX = lerp(1280, 960, labelMove);
  const imgPillY = lerp(262, 112, labelMove);

  const dots = (frame * 0.012) % 1;

  return (
    <>
      <svg width={1920} height={1080} style={{position: "absolute", inset: 0}}>
        <defs>
          <linearGradient id="bodyGrad" x1="0" y1="0" x2="0" y2="1">
            <stop offset="0" stopColor="rgba(79,140,255,0.14)" />
            <stop offset="1" stopColor="rgba(79,140,255,0.03)" />
          </linearGradient>
          <filter id="rayGlow" x="-20%" y="-20%" width="140%" height="140%">
            <feGaussianBlur stdDeviation="3" />
          </filter>
        </defs>

        {/* camera cutaway (side view, simplified schematic) */}
        <g opacity={camOut} transform={`translate(${-60 * (1 - camOut)} 0)`}>
          {/* subject */}
          <g opacity={draw}>
            <rect x={SUBJECT_X - 7} y={548} width={14} height={44} rx={3} fill="none" stroke={theme.colors.textDim} strokeWidth={3} />
            <circle cx={SUBJECT_X} cy={519} r={30} fill={`rgba(${theme.rgb.accent},0.22)`} stroke={theme.colors.accent} strokeWidth={3} />
          </g>
          {/* body */}
          <rect x={630} y={325} width={750} height={440} rx={44} fill="url(#bodyGrad)" stroke={theme.colors.bodyEdge} strokeWidth={3} pathLength={1} strokeDasharray={`${draw} 2`} />
          <rect x={650} y={345} width={710} height={400} rx={32} fill="none" stroke={theme.colors.panelEdge} strokeWidth={1.5} strokeDasharray="6 10" opacity={draw} />
          {/* lens barrel */}
          <rect x={372} y={405} width={268} height={280} rx={26} fill="url(#bodyGrad)" stroke={theme.colors.bodyEdge} strokeWidth={3} pathLength={1} strokeDasharray={`${draw} 2`} />
          <line x1={640} y1={425} x2={640} y2={665} stroke={theme.colors.bodyEdge} strokeWidth={2} opacity={draw} />
          {/* lens group: three elements */}
          {[
            {x: 440, h: 105, w: 16},
            {x: 478, h: 118, w: 22},
            {x: 516, h: 98, w: 14},
          ].map((l, i) => {
            const p = pop(ev.lens + i * 5);
            return (
              <path
                key={i}
                d={lensPath(l.x, l.h, l.w)}
                fill={theme.colors.lensFill}
                stroke={theme.colors.lensEdge}
                strokeWidth={3}
                opacity={Math.min(1, p)}
                transform={`translate(0 ${AXIS}) scale(1 ${0.6 + 0.4 * Math.min(1, p)}) translate(0 ${-AXIS})`}
              />
            );
          })}
          {/* sensor board behind the slab */}
          <rect x={1296} y={380} width={14} height={330} rx={4} fill={theme.colors.panelDeep} stroke={theme.colors.bodyEdge} strokeWidth={2} opacity={Math.min(1, sensorPop)} />

          {/* light rays: object points -> lens -> sensor (inverted image) */}
          <g opacity={rayFade}>
            {PTS.map((pt, pi) =>
              OFFS.map((o, oi) => {
                const d = `M ${SUBJECT_X + 30} ${pt.y0} L ${LENS_X} ${AXIS + o} L ${SENSOR_X} ${imgY(pt.y0)}`;
                const start = pt.y0; // keep d well-formed
                void start;
                return (
                  <g key={`${pi}-${oi}`}>
                    <path d={d} fill="none" stroke={theme.colors.primary} strokeWidth={7} opacity={0.35} filter="url(#rayGlow)" pathLength={1} strokeDasharray={`${rayDraw} 2`} />
                    <path d={d} fill="none" stroke={theme.colors.primary} strokeWidth={2.5} opacity={0.75} pathLength={1} strokeDasharray={`${rayDraw} 2`} />
                    <path d={d} fill="none" stroke={theme.colors.text} strokeWidth={6} strokeLinecap="round" pathLength={1} strokeDasharray="0.003 0.04" strokeDashoffset={-dots - oi * 0.013} opacity={rayDraw >= 0.99 ? 0.9 : 0} />
                  </g>
                );
              })
            )}
            {PTS.map((pt, i) => {
              const p = pop(ev.rays + 28 + i * 4, theme.spring.bouncy);
              return <circle key={i} cx={SENSOR_X} cy={imgY(pt.y0)} r={9 * Math.min(1.2, p)} fill={theme.colors.text} opacity={Math.min(1, p)} />;
            })}
          </g>
          <Leader x1={LENS_X} y1={AXIS - 128} x2={LENS_X} y2={376} at={ev.lens + 8} color={theme.colors.lensEdge} out={ev.pivot} />
          <Leader x1={1280} y1={380} x2={1280} y2={300} at={ev.sensor + 4} out={ev.pivot + 4} />
        </g>

        {/* amber highlight + leader for a single light-sensitive cell */}
        <Leader x1={ac.x + 22} y1={ac.y} x2={1500} y2={585} at={ev.amber + 2} out={ev.pillOut} />
      </svg>

      {/* sensor face (3D pivot) */}
      <div
        style={{
          position: "absolute",
          left: FACE_X,
          top: FACE_Y,
          width: FACE_W,
          height: FACE_H,
          opacity: faceOpacity,
          transform: `translate(${dx}px, ${dy}px) perspective(1800px) rotateY(${angle}deg) scale(${sc})`,
          borderRadius: 18,
          background: `linear-gradient(160deg, ${theme.colors.panel}, ${theme.colors.panelDeep})`,
          border: `2px solid ${theme.colors.panelEdge}`,
          boxShadow: `0 40px 90px -20px ${theme.colors.shadow}, 0 0 ${60 * (1 - pv)}px ${theme.colors.amberGlow}`,
        }}
      >
        <svg width={FACE_W} height={FACE_H} viewBox={`${FACE_X} ${FACE_Y} ${FACE_W} ${FACE_H}`}>
          <GridCells
            opacity={(c, r) => cellsOn(c, r)}
            scale={(c, r) => 0.6 + 0.4 * cellsOn(c, r)}
            glow={(c) => glow(c)}
          />
          {frame >= ev.amber && (
            <g transform={`translate(${ac.x} ${ac.y}) scale(${Math.min(1.1, aP)}) translate(${-ac.x} ${-ac.y})`}>
              <rect x={ac.x - 18} y={ac.y - 18} width={36} height={36} rx={5} fill={`rgba(${theme.rgb.accent},0.55)`} stroke={theme.colors.accent} strokeWidth={3} vectorEffect="non-scaling-stroke" />
            </g>
          )}
        </svg>
      </div>

      <svg width={1920} height={1080} style={{position: "absolute", inset: 0, pointerEvents: "none"}} />
      <Pill x={LENS_X} y={350} at={ev.lens + 4} text="Lens" tone="light" size={38} out={ev.pivot - 6} />
      <Pill x={imgPillX} y={imgPillY} at={ev.sensor + 2} text="Image Sensor" tone="amber" size={44} out={ev.pillOut} />
      <Pill x={1690} y={585} at={ev.pill} text="আলোক সংবেদনশীল অংশ" tone="amber" size={34} out={ev.pillOut} />
      <div
        style={{
          ...baseText,
          position: "absolute",
          left: 0,
          right: 0,
          top: 960,
          textAlign: "center",
          fontSize: 28,
          fontWeight: 400,
          color: theme.colors.textDim,
          opacity: camOut * ramp(24, 14),
        }}
      >
        সরলীকৃত চিত্র
      </div>
    </>
  );
};

void ROWS;
