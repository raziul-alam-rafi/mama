// Scene-based audio timeline. Every SFX states the on-screen action it belongs to.
import { T, IRIS_MOVES } from "../scenes/aperture/timeline";

export interface Sfx {
  file: string; // under public/
  at: number; // seconds
  duration: number; // seconds (clip is faded out at the end)
  volume: number;
  fadeIn?: number;
  fadeOut?: number;
  action: string; // intended visual action (documentation + review)
}

const lead = 0.08; // SFX start ~2-3 frames BEFORE the visual lands

export const SFX: Sfx[] = [
  { file: "sfx/whoosh.wav", at: 0.1, duration: 0.9, volume: 0.5, action: "lens parts slide in (exploded view)" },
  { file: "sfx/click.wav", at: T.assembleEnd - lead, duration: 0.12, volume: 0.6, action: "parts snap together" },
  { file: "sfx/whoosh.wav", at: T.cutawayStart - lead, duration: 0.9, volume: 0.35, action: "camera pushes toward the lens interior" },
  { file: "sfx/shimmer.wav", at: T.irisHighlightStart - lead, duration: 1.4, volume: 0.22, action: "iris highlighted in amber (explanatory cue)" },
  { file: "sfx/whoosh.wav", at: 6.9 - lead, duration: 0.9, volume: 0.4, action: "camera pulls back to the side view" },
  { file: "sfx/shimmer.wav", at: T.raysOn - lead, duration: 1.4, volume: 0.3, action: "light rays appear (explanatory cue: light itself is silent)" },
  // iris moves: motor whirr for the full travel + a click at start and end of each move
  ...IRIS_MOVES.flatMap(([a, b]) => [
    { file: "sfx/click.wav", at: a - 0.03, duration: 0.12, volume: 0.5, action: "iris blades start moving" },
    { file: "sfx/iris_motor.wav", at: a, duration: b - a, volume: 0.32, fadeIn: 0.05, fadeOut: 0.25, action: "iris blades move" },
    { file: "sfx/click.wav", at: b - 0.03, duration: 0.12, volume: 0.5, action: "iris blades stop" },
  ] as Sfx[]),
  { file: "sfx/sweep_up.wav", at: T.bigStart + 0.1, duration: 1.5, volume: 0.28, fadeOut: 0.5, action: "large aperture: sensor receives more light" },
  { file: "sfx/sweep_down.wav", at: T.smallStart + 0.1, duration: 1.5, volume: 0.28, fadeOut: 0.5, action: "small aperture: sensor receives less light" },
];
