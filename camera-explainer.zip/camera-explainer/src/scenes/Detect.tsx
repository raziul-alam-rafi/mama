import React from "react";
import { AbsoluteFill, useCurrentFrame } from "remotion";
import { theme, alpha, mix } from "../theme";
import { Draw, Pop, SceneShell, Tag, WordReveal, ease } from "../components/ui";
import { BOX, WW, gridCells, lumColor } from "../world";
import { at } from "../timing";
import type { Sfx } from "../sfx";

const K = 3;
const T = theme.colors;
const FX = 400;
const FY = 280;
const FW = 1120;
const FH = FW / 1.6;
const COLS = 56;
const ROWS = 35;
const CELL = FW / COLS;

// cue-এর ভেতরে তিনটি আইটেম সমান ব্যবধানে: মুখ, আকাশ, গাছ
const E = {
  title: at(K, 6, 0),
  face: at(K, 6, 0.42),
  sky: at(K, 6, 0.64),
  tree: at(K, 6, 0.86),
};

export const sfx: Sfx[] = [
  { f: 4, s: "pop", v: 0.26, r: 0.96 },
  { f: E.face, s: "click", v: 0.28 },
  { f: E.sky, s: "click", v: 0.28, r: 1.06 },
  { f: E.tree, s: "click", v: 0.28, r: 1.12 },
];

const px = (x: number) => FX + (x / WW) * FW;
const py = (y: number) => FY + y * FH;

const Bracket: React.FC<{ x0: number; y0: number; x1: number; y1: number; p: number; color: string }> = ({ x0, y0, x1, y1, p, color }) => {
  const s = 26;
  const d = [
    `M${x0} ${y0 + s} V${y0} H${x0 + s}`,
    `M${x1 - s} ${y0} H${x1} V${y0 + s}`,
    `M${x1} ${y1 - s} V${y1} H${x1 - s}`,
    `M${x0 + s} ${y1} H${x0} V${y1 - s}`,
  ].join(" ");
  return <Draw d={d} p={p} stroke={color} w={5} />;
};

export const Detect: React.FC = () => {
  const f = useCurrentFrame();
  const cells = gridCells(COLS, ROWS);
  const scanX = ease(f, [6, 40], [0, FW], theme.ease.inOut);
  const faceK = ease(f, [E.face, E.face + 10], [0, 1]);
  const skyK = ease(f, [E.sky, E.sky + 14], [0, 1]);
  const treeK = ease(f, [E.tree, E.tree + 14], [0, 1]);
  return (
    <SceneShell>
      <AbsoluteFill style={{ alignItems: "center", paddingTop: 70 }}>
        <WordReveal text="কীভাবে বুঝতে পারে?" size={96} hi={[1]} glow delay={E.title} per={5} />
      </AbsoluteFill>

      <div style={{ position: "absolute", left: FX, top: FY }}>
        <Pop delay={2} y={50} cfg={theme.spring.smooth}>
          <div
            style={{
              width: FW,
              height: FH,
              borderRadius: 18,
              overflow: "hidden",
              border: `2px solid ${T.line}`,
              boxShadow: theme.shadow,
              background: T.bgAlt,
            }}
          >
            <svg width={FW} height={FH} viewBox={`0 0 ${FW} ${FH}`}>
              {cells.map((c) => {
                const x = c.i * CELL;
                if (x > scanX) return null;
                let col = lumColor(c.lum);
                if (c.region === "sky" || c.region === "sun") col = mix(col, T.hero, 0.55 * skyK);
                else if (c.region === "trunk" || c.region === "canopy") col = mix(col, T.text, 0.35 * treeK);
                else if (c.region === "face") col = mix(col, T.accent, 0.7 * faceK);
                return <rect key={`${c.i}-${c.j}`} x={x} y={c.j * CELL} width={CELL + 0.6} height={CELL + 0.6} fill={col} />;
              })}
            </svg>
          </div>
        </Pop>
        {/* স্ক্যান-রেখা */}
        {scanX < FW - 2 && (
          <div
            style={{
              position: "absolute",
              left: scanX,
              top: -10,
              width: 4,
              height: FH + 20,
              background: T.hero,
              boxShadow: `0 0 28px ${T.glowHero}`,
            }}
          />
        )}
      </div>

      {/* HUD: মুখ ও গাছের ব্র্যাকেট, লেবেল */}
      <svg width={1920} height={1080} style={{ position: "absolute", left: 0, top: 0, pointerEvents: "none" }}>
        <Bracket x0={px(BOX.face.x0) - 10} y0={py(BOX.face.y0)} x1={px(BOX.face.x1) + 10} y1={py(BOX.face.y1)} p={faceK} color={T.accent} />
        <Bracket x0={px(BOX.tree.x0)} y0={py(BOX.tree.y0)} x1={px(BOX.tree.x1)} y1={py(BOX.tree.y1)} p={treeK} color={T.text} />
        <Draw d={`M${px(BOX.face.x1) + 10} ${py(BOX.face.y0) + 10} L${px(BOX.face.x1) + 70} ${py(BOX.face.y0) - 40}`} p={faceK} stroke={T.accent} w={3} />
      </svg>
      <div style={{ position: "absolute", left: px(BOX.face.x1) + 80, top: py(BOX.face.y0) - 82 }}>
        <Tag text="মুখ" delay={E.face + 4} color={T.accent} size={50} />
      </div>
      <div style={{ position: "absolute", left: px(0.52), top: py(0.07) }}>
        <Tag text="আকাশ" delay={E.sky + 4} color={T.hero} size={50} />
      </div>
      <div style={{ position: "absolute", left: px(BOX.tree.x0) + 14, top: py(BOX.tree.y0) - 80 }}>
        <Tag text="গাছ" delay={E.tree + 4} color={T.text} size={50} />
      </div>
    </SceneShell>
  );
};
