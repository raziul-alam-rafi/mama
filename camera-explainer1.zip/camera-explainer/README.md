# Camera Explainer (Remotion)

    npm install
    npx remotion studio
    npx remotion render src/index.ts Main out/video.mp4

- Voiceover: put `public/voiceover.mp3` — plays in Studio (flags in `src/theme.ts`: `previewVoiceover`, `renderVoiceover`, `sfx`).
- Timing comes only from `public/script.srt` (`npm run cues` regenerates `src/cues.data.ts`; scene boundaries are in `src/cues.ts`).
- SFX: `public/sfx/*.wav` (`npm run sfx` regenerates them).
- Fonts: `npm install` copies Hind Siliguri into `public/fonts`; a bundled fallback is used if that fails.
